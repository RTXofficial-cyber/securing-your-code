import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';

const chatMock = vi.fn(async () => ({ ok: true, reply: 'Ji bro — ye Air_you ki apni yaad se jawab hai.', actionResults: [] }));
const sendMock = vi.fn(async () => ({ ok: true }));

vi.mock('../../src/lib/api.js', () => ({
  isDesktop: false,
  api: {
    chat: (...a) => chatMock(...a),
    terminalStart: async () => ({ ok: true, cwd: '/tmp' }),
    terminalSend: (...a) => sendMock(...a),
    terminalKill: async () => ({ ok: true }),
    onTerminal: () => () => {}
  }
}));

import AirMind from '../../src/components/AirMind.jsx';

describe('AirMind — Air_you ka apna terminal page', () => {
  it('traffic lights (red/yellow/green), prompt aur one-way banner render karta hai', () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    expect(document.querySelector('.am-red')).toBeTruthy();
    expect(document.querySelector('.am-yellow')).toBeTruthy();
    expect(document.querySelector('.am-green')).toBeTruthy();
    expect(screen.getByPlaceholderText(/Air_you sun raha hai/)).toBeTruthy();
    expect(screen.getByText(/SIRF apne AI ka/i)).toBeTruthy();
    expect(screen.getByText(/NAHI aate/i)).toBeTruthy();
  });

  it('har command SIRF builtin (Air_you) ko jati hai — connected AIs ko kabhi nahi', async () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    const input = screen.getByPlaceholderText(/Air_you sun raha hai/);
    fireEvent.change(input, { target: { value: 'tum kaun ho' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(chatMock).toHaveBeenCalled());
    const payload = chatMock.mock.calls[0][0];
    expect(payload.provider).toBe('builtin');
    expect(payload.messages[payload.messages.length - 1].content).toBe('tum kaun ho');
    await waitFor(() => expect(screen.getByText(/apni yaad se jawab/i)).toBeTruthy());
  });

  it('help local chalta hai (AI call nahi) aur "!" OS shell ko jata hai', async () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    const input = screen.getByPlaceholderText(/Air_you sun raha hai/);
    fireEvent.change(input, { target: { value: 'help' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(screen.getByText(/imagine <scene>/)).toBeTruthy());
    expect(chatMock).not.toHaveBeenCalled();
    fireEvent.change(input, { target: { value: '!node -v' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(sendMock).toHaveBeenCalledWith('node -v'));
    expect(screen.getByText(/\$ node -v/)).toBeTruthy();
  });
});
