=========================================================
 AIR DEVELOPING 1.16.0  —  FX FORGE + REAL WATER
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.16.0:
  * FX FORGE — AI KHUD SHADERS BANATA HAI:
    Aapke request words se ek naya effect recipe forge
    hota hai (kind + waves + tint + wire-lines + grain +
    lightning + embers + foam). Combination space:
    1,073,741,824 — ek arab se zyada. "lava river game"
    bolo → molten glow + rising embers; "storm" → bijli
    ke flashes; "toxic" → green sheen. Har game ka look
    us ke words se banta hai — hardcoding zero.

  * FX CODEX — 28 ASLI TECHNIQUES, ASLI MATH:
    Gerstner waves, Phillips spectrum (FFT oceans), SPH
    fluid particles, spring-mass-damper slosh (Dodge),
    Schlick Fresnel, Snell refraction, caustics, Kelvin
    wake (39°), foam lines, trauma shake... har entry:
    WHAT + MATH + kahan use hoti hai. Air_you se poocho:
    "shaders kaise kaam karte hain?" — crash course milega.

  * REAL WATER — NADI, DOOBNA, BOTTLE SLOSH:
    - City world mein NADI (river) + 2 pul; entry par
      crown splash + wake rings; body waves par bob karti
      hai (buoyancy)
    - DOOBNA real-life rules se: paani mein C hold = dive,
      O2 meter girta hai, zero par DROWNING damage, HP
      zero = "YOU DROWNED". Car river mein giri = car
      doobti hai — S se reverse karke niklo!
    - BOTTLE SLOSH: jab bottle hilti hai, andar ka paani
      BHI hilta hai — spring-damper physics, HUD bottle
      ki waterline live tilt hoti hai, settle karti hai.
      River se refill; saans low par peena = +34 O2.
    - Ripples: wading par phailte hue damped rings.

  * BUG FIX: "spider-man 3d game" jaisi requests galti se
    calculator mein chali jati thin (hyphen = minus samajh
    kar) — ab wordy text kabhi arithmetic nahi banta;
    2+2, (2+3)*4%7, 2^10 sab pehle jaise kaam karte hain.

  * SAB PURANA SYSTEM LIVE: GB-class Local AI download
    (Ollama), water/waves/lines, one-way learning,
    done-tick, Air Vault, platforms, franchise 3D games,
    ReAct/Deep/Autopilot, security + audit, bridge.

  * TESTS: 106 logic + 10 UI green. Har franchise headless
    600 frames + fuzz storm se guzarta hai.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
