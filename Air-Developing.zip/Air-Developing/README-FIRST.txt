=========================================================
 AIR DEVELOPING 1.18.0  —  AIR_you KA APNA TERMINAL
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.18.0:
  * AIR_you TERMINAL (AirMind page) 🔴🟡🟢:
    Landing par "Air_you Terminal" button — ek poora page
    jahan SIRF apna AI rehta hai. Terminal jaisa: red/
    yellow/green dots, green prompt, mono type. GPT/Claude/
    Groq/Perplexity is page par KABHI nahi aate (one-way
    rule visible). "!" se asli OS shell bhi chalta hai.

  * AIR_you KI NAYI POWERS (sab offline, sab uski apni):
    - think <sawal>   → READ → THINK → PLAN → ANSWER
    - imagine <scene> → apni ASCII canvas: raat/din,
      barish, sheher, paani, pahaar — same words = same
      tasveer, alag words = alag (khud generate karti hai)
    - read <file>     → workspace file padh kar summary
    - "khud ka naya knowledge generate karo: <topic>" →
      SELF-GENERATION: naya knowledge entry khud banati
      hai, disk par yaad rakhti hai (.dev-studio/selfgen
      .json), agli baar usi YAAD se jawab deti hai
    - "tumhari kya powers hain?" → poori list

  * INTRO BAND: Air_you ab khud se apna intro NAHI karti —
    "hi" par sirf "Ji bro, boliye". Poocho "tum kaun ho"
    tab hi batati hai (jaisa aapne kaha).

  * GAME DNA FEED: saara game system — GameKit3D, 12
    arcade games, franchise DNA, FX Forge (1 arab+ recipes),
    water physics (doobna/slosh/ripples), GTA-6 detail pack
    (tracks/crowds/alligators/weather/birds) — sab Air_you
    ke andar feed hai aur wo is par crash course deti hai:
    poocho "Air_you ke andar kaunsa game knowledge hai?"
    Connected AIs ko ye knowledge KABHI nahi milti — sirf
    Air_you aage badhti hai (GPT/Claude/Groq/Perplexity se
    aage nikalne ka rasta: seekhna + yaad rakhna + khud
    generate karna).

  * SAB PURANA SYSTEM LIVE: GTA-6 detail pack, FX Forge,
    real water, GB-class Local AI download (Ollama), one-way
    learning, done-tick, Air Vault, platforms, security.

  * TESTS: 109 logic + 13 UI green (naye: AirMind page ke
    3 UI tests — dots, builtin-only routing, help/shell;
    Air_you mind block — intro rule, powers, think,
    imagine determinism, read, self-gen + recall).

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
