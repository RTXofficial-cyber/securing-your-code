=========================================================
 AIR DEVELOPING 1.17.0  —  THE GTA-6 DETAIL PACK
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.17.0 — GTA 6 KI ASLI MINOR DETAILS, RESEARCH
KARKE, HAMARE GAMES MEIN (honest miniature, test-pinned):

  * MUD & TRACKS: pair ke nishan (baari L/R) mud ki tarah
    fade hote hain; handbrake/tez steering = twin TIRE
    TRACKS + screech; geeli sadak par skid threshold neecha
    (GTA 6 ki tarah weather traction badalta hai).

  * REACTIVE CROWDS: 9 pedestrians sheher mein ghoomte
    hain; goli ki awaaz (520m) ya tez car (130m) = sab
    BHAGTE hain (3.2x speed, tumse door); takkar = knockdown
    + crowd panic. Buildings se bachte, paani mein nahi
    jaate.

  * RIVER ALLIGATORS (iconic Leonida detail): nadi mein
    patrol; paani mein aao to 62 speed se HUNT — 16 damage
    roll-bite, cooldown ke saath; tairte gators apna wake
    chhodte hain.

  * DYNAMIC WEATHER CELL: static toggle nahi — intensity +
    wind drift karte hain; rain ka count/slant/alpha follow,
    storms mein fog qareeb, HUD par STORM readout, geeli
    sadak par car ki grip kam.

  * SEABIRDS: 5 gulls sir par mandlate hain — flapping, 3D
    projected. Duniya zinda lagti hai.

  * AIR_you KO POOCHO: "GTA 6 mein kya kya real details
    hain?" — poori research-based crash course: water redo,
    marine life, reactive mud, bottle liquid sim, muscle
    deformation, strand hair, tire deformation, hurricanes —
    AUR honest list jo humne NAHI banaya (~2000 log × ~10
    saal ka kaam; hum same LAYERS banate hain).

  * SAB PURANA SYSTEM LIVE: FX Forge (1 arab+ recipes, AI
    khud banata), real water (doobna/bottle slosh/ripples),
    GB-class Local AI download (Ollama), one-way learning,
    done-tick, Air Vault, platforms, security + audit.

  * TESTS: 108 logic + 10 UI green. Har franchise headless
    + fuzz storm se guzarta hai.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
