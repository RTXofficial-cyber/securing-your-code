=========================================================
 AIR DEVELOPING 1.15.0  —  GB-CLASS AI + WATER & FX
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.15.0:
  * LOCAL AI — GB-CLASS MODEL DOWNLOAD:
    Air_you app ke saath hi aata hai (zero download, offline).
    Ab Settings -> "Local AI" se ek GB-class AI bhi apne PC
    par download karo: phi3:mini (~2.2 GB), mistral:7b
    (~4.1 GB), llama3.1:8b (~4.7 GB, recommended),
    qwen2.5:7b, llama3.1:70b (~40 GB). Live progress
    (%, GB/GB, speed), download aapki apni disk par, aur
    phir model 100% LOCAL chalta hai — no cloud, no key,
    no credits. (Honest rule: GB weights GitHub zip mein
    nahi aa sakte — 100MB file limit — isliye app chhoti
    hai aur bada AI aapke PC par download hota hai.)
    Ollama chahiye: https://ollama.com/download

  * GAMING FX — WATER, WAVES, LINES (shader-style):
    - waterMesh(): asli vertex waves — paani ka har quad
      3 sine waves par tairta hai, crests par specular
      glint (GPU water shaders wali hi math, software mein)
    - LINES: har water quad par hairline wire edge;
      renderScene mein per-face + global wire support
    - postFX(): vignette + film grain + scanlines pass
    - Rails world: track ke dono taraf kaala paani;
      City world: skyline ke peeche bay; horror worlds:
      heavy vignette + grain + CRT scanlines

  * SAB PURANA SYSTEM LIVE: one-way learning, done-tick,
    Air Vault, platform targets, franchise 3D games,
    ReAct/Deep/Autopilot, security + audit, bridge.

  * TESTS: 101 logic + 10 UI green. Har game headless +
    fuzz storm se guzarta hai.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
