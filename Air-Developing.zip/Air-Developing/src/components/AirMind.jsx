import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api.js';

/**
 * AIR MIND — a terminal-style page where ONLY Air_you lives.
 * Traffic-light dots (red/yellow/green) on a real terminal chrome; everything
 * typed goes to the built-in offline AI (provider 'builtin') — never to
 * GPT/Claude/Groq/Perplexity. "!" prefix pipes into the real OS shell.
 */

const HELP = [
  'AIR_you commands:',
  '  <kuch bhi likho>       — Air_you se baat karo (sirf apna AI; connected AIs yahan nahi aate)',
  '  think <sawal>          — structured soch: READ → THINK → PLAN → ANSWER',
  '  imagine <scene>        — meri apni ASCII canvas (rainy night city, sea, mountains…)',
  '  read <file>            — workspace ki file padh kar summary + functions',
  '  khud ka naya knowledge generate karo: <topic>  — self-generation, disk par yaad',
  '  tumhari kya powers hain?  — poori power list',
  '  !<command>             — "!" se OS shell (asal terminal, e.g. !node -v)',
  '  help                   — ye list    ·    clear — screen saaf'
];

export default function AirMind({ onBack, onToggleTheme }) {
  const [lines, setLines] = useState([]);
  const [cmd, setCmd] = useState('');
  const [busy, setBusy] = useState(false);
  const logRef = useRef(null);
  const inputRef = useRef(null);
  const history = useRef([]); // session memory for Air_you

  const push = useCallback((items) => setLines((L) => [...L.slice(-600), ...items]), []);

  useEffect(() => {
    push([
      { k: 'sys', t: 'AIR_you TERMINAL — ye page SIRF apne AI ka hai. GPT / Claude / Groq / Perplexity yahan NAHI aate.' },
      { k: 'sys', t: 'One-way rule: connected AIs team mein aate hain, meri knowledge unhe kabhi nahi milti. "help" = commands.' }
    ]);
    api.terminalStart?.().catch?.(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const off = api.onTerminal?.((msg) => {
      if (!msg) return;
      if (msg.type === 'output') push([{ k: 'term', t: String(msg.data ?? '').replace(/\r\n/g, '\n') }]);
      else if (msg.type === 'exit') push([{ k: 'err', t: `[shell exited: ${msg.code}]` }]);
      else if (msg.type === 'done' && msg.command) push([{ k: 'sys', t: `[done: ${msg.command} → exit ${msg.exit}]` }]);
    });
    return () => { if (typeof off === 'function') off(); };
  }, [push]);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines, busy]);

  const run = async (raw) => {
    const c = raw.trim();
    if (!c || busy) return;
    push([{ k: 'in', t: c }]);
    setCmd('');
    if (c === 'help') { push(HELP.map((t) => ({ k: 'sys', t }))); return; }
    if (c === 'clear') { setLines([]); return; }
    if (c.startsWith('!')) {
      const shellCmd = c.slice(1).trim();
      if (!shellCmd) return;
      push([{ k: 'sys', t: `$ ${shellCmd}` }]);
      const r = await api.terminalSend?.(shellCmd);
      if (r && r.ok === false) push([{ k: 'err', t: r.error || 'shell unavailable here' }]);
      return; // output streams in via onTerminal
    }
    setBusy(true);
    try {
      history.current = [...history.current.slice(-8), { role: 'user', content: c }];
      const res = await api.chat({ provider: 'builtin', model: null, agentMode: 'solo', messages: history.current });
      if (res?.ok) {
        const reply = res.reply || '(done)';
        history.current = [...history.current, { role: 'assistant', content: reply }];
        push(reply.split('\n').map((t) => ({ k: 'out', t: t.replace(/\*\*/g, '') })));
        for (const a of res.actionResults || []) {
          push([{ k: a.ok === false ? 'err' : 'sys', t: `  ↳ action ${a.type || '?'}: ${a.ok === false ? a.error || 'failed' : 'ok'}${a.path ? ` (${a.path})` : ''}` }]);
        }
      } else {
        push([{ k: 'err', t: res?.error || 'Air_you jawab nahi de paya' }]);
      }
    } catch (e) {
      push([{ k: 'err', t: `Air_you error: ${e?.message || e}` }]);
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  };

  return (
    <div className="airmind">
      <div className="airmind-bar">
        <span className="am-dot am-red" role="button" title="back to app" onClick={onBack} />
        <span className="am-dot am-yellow" role="button" title="toggle theme" onClick={onToggleTheme} />
        <span className="am-dot am-green" role="img" title="Air_you live — offline" />
        <div className="airmind-title">air_you@air:~ — apna AI terminal (sirf Air_you)</div>
        <button className="btn btn-sm" onClick={onBack}>← App</button>
      </div>
      <div className="airmind-log" ref={logRef} onClick={() => inputRef.current?.focus()}>
        {lines.map((l, i) => (
          <div key={i} className={`aline a-${l.k}`}>
            {l.k === 'in' ? <span className="a-prompt">air_you@air:~$ </span> : null}
            {l.t === '' ? '\u00a0' : l.t}
          </div>
        ))}
        {busy && <div className="aline a-sys">Air_you soch raha hai…</div>}
        <div className="aline a-input-row">
          <span className="a-prompt">air_you@air:~$ </span>
          <input
            ref={inputRef}
            className="a-input"
            value={cmd}
            autoFocus
            spellCheck={false}
            autoComplete="off"
            placeholder={busy ? '…' : 'likho — Air_you sun raha hai  (help = commands)'}
            onChange={(e) => setCmd(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') run(cmd); }}
          />
        </div>
      </div>
    </div>
  );
}
