import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../lib/api.js';

/**
 * AIR MIND 2.0 — the vibe-coding split page.
 * LEFT  : Air_you chat (ONLY the built-in offline AI — GPT/Claude/Groq never
 *         run here), connectors strip on top (dots = ready), 📎 image upload
 *         (Air_you answers honestly: offline engine cannot see pixels).
 * RIGHT : the real OS terminal (asal shell) — "!cmd" from chat also lands here.
 * Traffic-light dots (red/yellow/green) kept on the chrome bar.
 */

const HELP = [
  'AIR_you commands:',
  '  <kuch bhi likho>       — Air_you se baat karo (sirf apna AI; connected AIs yahan nahi aate)',
  '  situation <goal>       — AIR_you 3.0: OBSERVE → TASKS → RISKS → PLAN → REFINE (fine handling)',
  '  store ka snapshot lo   — 💎 STORE DESK: versioned backup → "store history" → "rollback v1"',
  '  think <sawal>          — structured soch: READ → THINK → PLAN → ANSWER',
  '  imagine <scene>        — meri apni ASCII canvas (rainy night city, sea, mountains…)',
  '  read <file>            — workspace ki file padh kar summary + functions',
  '  search <sawal>         — LIVE internet search (WiFi par) — results links ke saath',
  '  khud ka naya knowledge generate karo: <topic>  — self-generation, disk par yaad',
  '  tumhari kya powers hain?  — poori power list',
  '  📎 button              — image attach karo (Air_you honest metadata jawab deta hai)',
  '  !<command>             — "!" se OS shell — right side TERMINAL pane mein chalta hai',
  '  help                   — ye list    ·    clear — chat saaf'
];

export default function AirMind({ onBack, onToggleTheme, onConnectors }) {
  const [lines, setLines] = useState([]);
  const [termLines, setTermLines] = useState([]);
  const [cmd, setCmd] = useState('');
  const [tcmd, setTcmd] = useState('');
  const [busy, setBusy] = useState(false);
  const [imgs, setImgs] = useState([]);
  const [attachNote, setAttachNote] = useState('');
  const [provs, setProvs] = useState([]);
  const logRef = useRef(null);
  const termRef = useRef(null);
  const inputRef = useRef(null);
  const tinputRef = useRef(null);
  const fileRef = useRef(null);
  const history = useRef([]); // session memory for Air_you

  const push = useCallback((items) => setLines((L) => [...L.slice(-600), ...items]), []);
  const pushTerm = useCallback((items) => setTermLines((L) => [...L.slice(-800), ...items]), []);

  useEffect(() => {
    push([
      { k: 'sys', t: 'AIR_you — ye page SIRF apne AI ka hai. GPT / Claude / Groq / Perplexity yahan NAHI aate.' },
      { k: 'sys', t: 'Left = Air_you chat (📎 images + "search" = live internet). Right = asal OS terminal. "help" = commands.' }
    ]);
    pushTerm([{ k: 'sys', t: 'AIR TERMINAL — ye asal OS shell hai. Command likho Enter dabao. (chat se "!cmd" bhi yahan aata hai)' }]);
    api.terminalStart?.().catch?.(() => {});
    (async () => {
      try {
        const r = await api.providers?.();
        if (Array.isArray(r)) setProvs(r);
        else if (Array.isArray(r?.providers)) setProvs(r.providers);
      } catch {}
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const off = api.onTerminal?.((msg) => {
      if (!msg) return;
      if (msg.type === 'output') pushTerm([{ k: 'term', t: String(msg.data ?? '').replace(/\r\n/g, '\n') }]);
      else if (msg.type === 'exit') pushTerm([{ k: 'err', t: `[shell exited: ${msg.code}]` }]);
      else if (msg.type === 'done' && msg.command) pushTerm([{ k: 'sys', t: `[done: ${msg.command} → exit ${msg.exit}]` }]);
    });
    return () => { if (typeof off === 'function') off(); };
  }, [pushTerm]);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines, busy]);
  useEffect(() => {
    const el = termRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [termLines]);

  const onPickImages = async (e) => {
    const files = Array.from(e.target.files || []).slice(0, 3);
    e.target.value = '';
    const picked = [];
    for (const f of files) {
      if (!f.type.startsWith('image/')) { setAttachNote('Sirf image files.'); continue; }
      if (f.size > 5 * 1024 * 1024) { setAttachNote(`"${f.name}" 5 MB se bari hai.`); continue; }
      // eslint-disable-next-line no-await-in-loop
      const dataUrl = await new Promise((res) => { const r = new FileReader(); r.onload = () => res(String(r.result || '')); r.readAsDataURL(f); });
      picked.push({ name: f.name, url: dataUrl });
    }
    if (picked.length) { setImgs((p) => [...p, ...picked].slice(0, 3)); setAttachNote(''); }
  };

  const shell = async (shellCmd) => {
    pushTerm([{ k: 'sys', t: `$ ${shellCmd}` }]);
    const r = await api.terminalSend?.(shellCmd);
    if (r && r.ok === false) pushTerm([{ k: 'err', t: r.error || 'shell unavailable here' }]);
  };

  const run = async (raw) => {
    const c = raw.trim();
    const attach = imgs;
    if ((!c && !attach.length) || busy) return;
    push([{ k: 'in', t: attach.length ? `${c || '(image)'}  📎${attach.length}` : c }]);
    setCmd(''); setImgs([]); setAttachNote('');
    if (c === 'help') { push(HELP.map((t) => ({ k: 'sys', t }))); return; }
    if (c === 'clear') { setLines([]); return; }
    if (c.startsWith('!')) {
      const shellCmd = c.slice(1).trim();
      if (shellCmd) await shell(shellCmd);
      return; // output streams into the RIGHT pane via onTerminal
    }
    const m = c.match(/^(?:search|dhundo|web)\s+(fresh\s+)?(.+)$/i);
    if (m && !attach.length) {
      const wantFresh = Boolean(m[1]);
      const q = m[2].trim().slice(0, 200);
      push([{ k: 'sys', t: `🔎 internet par dhoondh raha hoon: "${q}" (WiFi zaroori hai)…` }]);
      try {
        const r = await api.webSearch?.({ query: q, fresh: wantFresh });
        if (r?.ok && r.results?.length) {
          // v1.20 KNOWLEDGE BANK — honest reuse: bank hit batata hai kitna
          // purana/milta-julta jawab hai, aur fresh search ka rasta bhi.
          if (r.fromBank) {
            push([{ k: 'sys', t: `⚡ KNOWLEDGE BANK se jawab (${r.sim}% match, ~${r.ageH}h purana data) — dobara search NAHI ki, isi se tez hoon. Naya chahiye to: "search fresh ${q}"` }]);
          }
          push(r.results.slice(0, 5).map((x, i) => ({ k: 'out', t: `${i + 1}. ${x.title}\n   ${x.url}\n   ${String(x.snippet || '').slice(0, 150)}` })));
          if (r.summary) push([{ k: 'out', t: `summary: ${String(r.summary).slice(0, 300)}` }]);
          if (!r.fromBank) push([{ k: 'sys', t: '💾 ye results Knowledge Bank mein save ho gaye — agli baar milta-julta sawal tez jawab hoga.' }]);
        } else {
          push([{ k: 'err', t: r?.error || 'kuch nahi mila — WiFi/internet check karo' }]);
        }
      } catch (e) {
        push([{ k: 'err', t: `search error: ${e?.message || e}` }]);
      }
      return;
    }
    setBusy(true);
    try {
      history.current = [...history.current.slice(-8), { role: 'user', content: c }];
      const res = await api.chat({ provider: 'builtin', model: null, agentMode: 'solo', images: attach.map((a) => a.url), messages: history.current });
      if (res?.ok) {
        const reply = res.reply || '(done)';
        history.current = [...history.current, { role: 'assistant', content: reply }];
        push(reply.split('\n').map((t) => ({ k: 'out', t: t.replace(/\*\*/g, '') })));
        for (const a of res.actionResults || []) {
          push([{ k: a.ok === false ? 'err' : 'sys', t: `  ↳ action ${a.type || '?'}: ${a.ok === false ? a.error || 'failed' : 'ok'}${a.path ? ` (${a.path})` : ''}` }]);
        }
      } else {
        push([{ k: 'err', t: res?.error || 'Air_you jawab nahi de paya' }]);
      }
    } catch (e) {
      push([{ k: 'err', t: `Air_you error: ${e?.message || e}` }]);
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  };

  const runTerm = async () => {
    const c = tcmd.trim();
    if (!c) return;
    setTcmd('');
    await shell(c);
    tinputRef.current?.focus();
  };

  return (
    <div className="airmind">
      <div className="airmind-bar">
        <span className="am-dot am-red" role="button" title="back to app" onClick={onBack} />
        <span className="am-dot am-yellow" role="button" title="toggle theme" onClick={onToggleTheme} />
        <span className="am-dot am-green" role="img" title="Air_you live — offline" />
        <div className="airmind-title">air_you@air:~ — AIR MIND 2.0 (chat + terminal, sirf Air_you)</div>
        <button className="btn btn-sm" onClick={onBack}>← App</button>
      </div>
      <div className="am-main">
        <section className="am-chat">
          <div className="am-connectors" aria-label="connectors">
            {provs.length === 0 && <span className="am-conn am-static"><i className="am-cdot on" />Air_you (builtin)</span>}
            {provs.map((p) => (
              <button
                key={p.id}
                type="button"
                className={`am-conn ${p.ready ? 'ready' : ''}`}
                title={p.id === 'builtin' ? 'Air_you — offline, hamesha ready' : p.ready ? `${p.name} — key lagi hai (Settings)` : `${p.name} — key nahi lagi (click → Settings)`}
                onClick={() => { if (p.id !== 'builtin') onConnectors?.(p.id); }}
              >
                <i className={`am-cdot ${p.ready ? 'on' : 'off'}`} />
                {p.name}
              </button>
            ))}
          </div>
          <div className="airmind-log am-chat-log" ref={logRef} onClick={() => inputRef.current?.focus()}>
            {lines.map((l, i) => (
              <div key={i} className={`aline a-${l.k}`}>
                {l.k === 'in' ? <span className="a-prompt">air_you@air:~$ </span> : null}
                {l.t === '' ? '\u00a0' : l.t}
              </div>
            ))}
            {busy && <div className="aline a-sys">Air_you soch raha hai…</div>}
          </div>
          {imgs.length > 0 && (
            <div className="attach-strip">
              {imgs.map((a, i) => (
                <span key={i} className="attach-chip" title={a.name}>
                  <img src={a.url} alt={a.name} />
                  <b>{a.name.length > 12 ? `${a.name.slice(0, 10)}…` : a.name}</b>
                  <button onClick={() => setImgs((p) => p.filter((_, j) => j !== i))} title="Hatao">✕</button>
                </span>
              ))}
            </div>
          )}
          {attachNote && <div className="attach-note">{attachNote}</div>}
          <div className="a-input-row am-chat-in">
            <button className="attach" onClick={() => fileRef.current?.click()} disabled={busy || imgs.length >= 3} title="Image upload (Air_you honest jawab dega; vision ke liye Studio chat + connected provider)">📎</button>
            <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp,image/gif" multiple hidden onChange={onPickImages} />
            <span className="a-prompt">air_you@air:~$ </span>
            <input
              ref={inputRef}
              className="a-input"
              value={cmd}
              autoFocus
              spellCheck={false}
              autoComplete="off"
              placeholder={busy ? '…' : 'likho — Air_you sun raha hai  (help = commands · search = internet)'}
              onChange={(e) => setCmd(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') run(cmd); }}
            />
          </div>
        </section>
        <section className="am-term">
          <div className="am-term-head">TERMINAL — asal OS shell (yahan code banta aur chalta hai)</div>
          <div className="airmind-log am-term-log" ref={termRef} onClick={() => tinputRef.current?.focus()}>
            {termLines.map((l, i) => (
              <div key={i} className={`aline a-${l.k}`}>{l.t === '' ? '\u00a0' : l.t}</div>
            ))}
          </div>
          <div className="a-input-row am-term-in">
            <span className="a-prompt">air@air:~$ </span>
            <input
              ref={tinputRef}
              className="a-input"
              value={tcmd}
              spellCheck={false}
              autoComplete="off"
              placeholder="shell command likho — e.g. node -v, dir, git status"
              onChange={(e) => setTcmd(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') runTerm(); }}
            />
          </div>
        </section>
      </div>
    </div>
  );
}
