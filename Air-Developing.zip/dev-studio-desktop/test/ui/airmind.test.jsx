import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';

const chatMock = vi.fn(async () => ({ ok: true, reply: 'Ji bro — ye Air_you ki apni yaad se jawab hai.', actionResults: [] }));
const sendMock = vi.fn(async () => ({ ok: true }));
const searchMock = vi.fn(async () => ({
  ok: true,
  results: [{ title: 'GTA 6 trailer breakdown', url: 'https://example.com/gta6', snippet: 'water physics redone' }]
}));

vi.mock('../../src/lib/api.js', () => ({
  isDesktop: false,
  api: {
    chat: (...a) => chatMock(...a),
    providers: async () => [
      { id: 'builtin', name: 'Air_you', ready: true },
      { id: 'openai', name: 'ChatGPT', ready: false }
    ],
    webSearch: (...a) => searchMock(...a),
    terminalStart: async () => ({ ok: true, cwd: '/tmp' }),
    terminalSend: (...a) => sendMock(...a),
    terminalKill: async () => ({ ok: true }),
    onTerminal: () => () => {}
  }
}));

import AirMind from '../../src/components/AirMind.jsx';

describe('AirMind — Air_you ka apna terminal page', () => {
  it('traffic lights (red/yellow/green), prompt aur one-way banner render karta hai', () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    expect(document.querySelector('.am-red')).toBeTruthy();
    expect(document.querySelector('.am-yellow')).toBeTruthy();
    expect(document.querySelector('.am-green')).toBeTruthy();
    expect(screen.getByPlaceholderText(/Air_you sun raha hai/)).toBeTruthy();
    expect(screen.getByText(/SIRF apne AI ka/i)).toBeTruthy();
    expect(screen.getByText(/NAHI aate/i)).toBeTruthy();
  });

  it('har command SIRF builtin (Air_you) ko jati hai — connected AIs ko kabhi nahi', async () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    const input = screen.getByPlaceholderText(/Air_you sun raha hai/);
    fireEvent.change(input, { target: { value: 'tum kaun ho' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(chatMock).toHaveBeenCalled());
    const payload = chatMock.mock.calls[0][0];
    expect(payload.provider).toBe('builtin');
    expect(payload.messages[payload.messages.length - 1].content).toBe('tum kaun ho');
    await waitFor(() => expect(screen.getByText(/apni yaad se jawab/i)).toBeTruthy());
  });

  it('help local chalta hai (AI call nahi) aur "!" OS shell ko jata hai', async () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    const input = screen.getByPlaceholderText(/Air_you sun raha hai/);
    fireEvent.change(input, { target: { value: 'help' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(screen.getByText(/imagine <scene>/)).toBeTruthy());
    expect(chatMock).not.toHaveBeenCalled();
    fireEvent.change(input, { target: { value: '!node -v' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(sendMock).toHaveBeenCalledWith('node -v'));
    expect(screen.getByText(/\$ node -v/)).toBeTruthy();
  });

  it('v1.19 split layout: connectors strip ready-dots ke saath + click → Settings', async () => {
    const onConnectors = vi.fn();
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} onConnectors={onConnectors} />);
    await waitFor(() => expect(document.querySelectorAll('.am-conn').length).toBe(2));
    expect(document.querySelector('.am-chat .am-cdot.on')).toBeTruthy(); // Air_you ready
    const gpt = screen.getByText('ChatGPT').closest('.am-conn');
    expect(gpt.querySelector('.am-cdot.off')).toBeTruthy(); // key nahi lagi
    fireEvent.click(gpt);
    expect(onConnectors).toHaveBeenCalledWith('openai');
    // right pane: terminal head + apna input
    expect(screen.getByText(/TERMINAL — asal OS shell/i)).toBeTruthy();
    expect(screen.getByPlaceholderText(/shell command likho/i)).toBeTruthy();
  });

  it('v1.19: "search" command live internet (webSearch) se results laata hai — AI call nahi', async () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    const input = screen.getByPlaceholderText(/Air_you sun raha hai/);
    fireEvent.change(input, { target: { value: 'search gta 6 water physics' } });
    fireEvent.keyDown(input, { key: 'Enter' });
    await waitFor(() => expect(searchMock).toHaveBeenCalledWith({ query: 'gta 6 water physics' }));
    expect(chatMock).not.toHaveBeenCalled();
    await waitFor(() => expect(screen.getByText(/GTA 6 trailer breakdown/)).toBeTruthy());
    expect(screen.getByText(/example\.com\/gta6/)).toBeTruthy();
  });

  it('v1.19: terminal pane ka apna input seedha shell ko chalata hai + 📎 image button maujood', async () => {
    render(<AirMind onBack={() => {}} onToggleTheme={() => {}} />);
    const tinput = screen.getByPlaceholderText(/shell command likho/i);
    fireEvent.change(tinput, { target: { value: 'git status' } });
    fireEvent.keyDown(tinput, { key: 'Enter' });
    await waitFor(() => expect(sendMock).toHaveBeenCalledWith('git status'));
    expect(screen.getByText(/\$ git status/)).toBeTruthy();
    expect(document.querySelector('.am-chat-in button.attach')).toBeTruthy();
  });
});
