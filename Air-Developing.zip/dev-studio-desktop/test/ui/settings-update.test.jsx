import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';

const updMock = vi.fn(async () => ({
  ok: true, current: '1.20.0', latest: '1.21.0', updateAvailable: true,
  url: 'https://github.com/RTXofficial-cyber/securing-your-code/releases/tag/v1.21.0',
  notes: 'diamond polish', plan: ['1) Download + verify…', '2) App band karein.']
}));

vi.mock('../../src/lib/api.js', () => ({
  isDesktop: false,
  api: {
    checkUpdate: (...a) => updMock(...a),
    capabilities: async () => ({ ok: true, features: [], permissions: {} }),
    plugins: async () => ({ ok: true, plugins: [] }),
    lockState: async () => ({ ok: true, set: false }),
    auditRead: async () => ({ ok: true, entries: [] }),
    setKey: async () => ({ ok: true }),
    testConnection: async () => ({ ok: true, latencyMs: 5, sample: 'ok' }),
    roles: async () => ({ ok: true, roles: [] })
  }
}));

import Settings from '../../src/components/Settings.jsx';

const props = {
  info: { version: '1.20.0', platform: 'test' },
  providers: [
    { id: 'builtin', name: 'Air_you', vendor: 'Air Developing', ready: true, models: [{ id: 'studio-agent-2', name: 'v3 brain' }] },
    { id: 'openai', name: 'ChatGPT', vendor: 'OpenAI', keyEnv: 'OPENAI_API_KEY', ready: false, models: [] }
  ],
  workspace: '/tmp/ws',
  focusProvider: null,
  onClose: () => {}, onSaved: () => {}, onChooseWorkspace: () => {}, onLock: () => {}
};

describe('Settings — 💎 App Update section (v1.20)', () => {
  it('update section render hota hai aur installed version dikhata hai', () => {
    render(<Settings {...props} />);
    expect(screen.getByText(/💎 App Update/)).toBeTruthy();
    expect(screen.getByText(/Installed:/).textContent).toContain('1.20.0');
    expect(screen.getByText('Check for update')).toBeTruthy();
  });

  it('Check for update → live feed compare → UPDATE AVAILABLE + link + honest plan', async () => {
    render(<Settings {...props} />);
    fireEvent.click(screen.getByText('Check for update'));
    await waitFor(() => expect(updMock).toHaveBeenCalled());
    await waitFor(() => expect(screen.getByText(/UPDATE AVAILABLE: 1\.21\.0/)).toBeTruthy());
    expect(screen.getByText(/releases\/tag\/v1\.21\.0/)).toBeTruthy();
    await waitFor(() => expect(screen.getByText(/Download \+ verify/)).toBeTruthy());
  });
});
