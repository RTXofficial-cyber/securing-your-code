/**
 * fxcodex.cjs — THE FX CODEX + FX FORGE.
 *
 * Two honest answers to "lakhs of shaders":
 *
 * 1. THE CODEX — a library of real graphics techniques (Gerstner waves, FFT
 *    oceans, SPH fluids, spring–mass–damper slosh, Schlick Fresnel, Snell
 *    refraction, caustics, Kelvin wakes…) with the actual math each one runs.
 *    These are the "million details", grounded in the same literature AAA
 *    engines use — each entry says WHAT it is, the MATH, and where the game
 *    runtime USES it.
 *
 * 2. THE FORGE — AI banaata hai khud: forgeFX(seedText) deterministically
 *    composes a NEW effect recipe from any request text — kind + parameters
 *    inside safe ranges. 8 kinds × quantised params = 1,073,741,824 distinct
 *    recipes, so every different request carries a genuinely different look.
 *    composed3d consumes the recipe: water tint/brightness, wave amplitude,
 *    wire-line alpha, grain, vignette, storm lightning, rising embers.
 *
 * No engine on earth ships "lakhon" hand-written shaders — AAA engines ship
 * dozens of shader PROGRAMS plus material parameter systems whose combination
 * space is effectively infinite. This is exactly that pattern, in miniature,
 * and it is testable.
 */
'use strict';

/* ---------------- THE CODEX: real techniques, real math ---------------- */
const CODEX = [
  { id: 'gerstner-waves', field: 'water', name: 'Gerstner (trochoidal) waves',
    what: 'Vertices orbit as the wave passes — crests sharpen, troughs flatten, like real chop.',
    math: 'P += Σ Qi·Ai·Di·cos(ki(Di·p) − ωi·t); y = Σ Ai·sin(ki(Di·p) − ωi·t); sharpness Q ≤ 1/(kA) to avoid loops.',
    used: 'waterMesh wave profiles; 3–4 summed directions keep the ocean non-repeating.' },
  { id: 'sine-superposition', field: 'water', name: 'Sum-of-sines height field',
    what: 'The fast workhorse: height is a sum of sinusoids in position and time.',
    math: 'h(x,z,t) = Σ Ai·sin(ki·p + ωi·t + φi)',
    used: 'waveY() in engine3d — 3 sines, animated every frame.' },
  { id: 'phillips-spectrum', field: 'water', name: 'Phillips wind spectrum (FFT oceans)',
    what: 'The statistical model of a wind-driven sea; AAA oceans inverse-FFT it each frame (Tessendorf).',
    math: 'P(k) = A·e^(−1/(kL)²)/k⁴ · |k̂·ŵ|²',
    used: 'codex reference — the honest ceiling our sum-of-sines approximates.' },
  { id: 'sph-fluid', field: 'fluid', name: 'Smoothed Particle Hydrodynamics',
    what: 'Fluid as particles carrying mass/velocity/density; splash and free surfaces EMERGE. Invented 1977 for collapsing stars (Gingold & Monaghan), now runs in games.',
    math: 'ρi = Σ m·W(|ri−rj|,h); pressure + viscosity forces via Müller (2003) kernels.',
    used: 'splash particle bursts approximate the crown splash SPH would simulate fully.' },
  { id: 'spring-damper-slosh', field: 'fluid', name: 'Spring–mass–damper slosh (Dodge)',
    what: 'Liquid in a container — bottle, tank, held item — modelled as one damped oscillator: shake the bottle, the water surface tilts and settles.',
    math: 'a = −k·x − c·v + a_container; v += a·dt; x += v·dt (k≈42, c≈4.5)',
    used: 'engine3d newSlosh/stepSlosh → the carried water bottle: jab bottle hilti hai, andar ka paani hilta hai.' },
  { id: 'buoyancy', field: 'physics', name: 'Buoyancy + wave bob',
    what: 'Floating bodies ride the surface: sample wave height at the body position and lift it.',
    math: 'y_surface = base + h(x,z,t); F_buoy = ρ·g·V_submerged',
    used: 'player floats and BOBS with the waves when wading; sinking car camera drops.' },
  { id: 'fresnel-schlick', field: 'light', name: 'Fresnel reflectance (Schlick)',
    what: 'Water mirrors at glancing angles and turns transparent looking straight down.',
    math: 'F = F0 + (1−F0)(1−cosθ)⁵',
    used: 'codex reference — slope-specular glints approximate the same view-dependence.' },
  { id: 'snell-refraction', field: 'light', name: 'Snell refraction',
    what: 'Light bends entering water (n≈1.33) — submerged scenery shimmers and shifts.',
    math: 'n1·sinθ1 = n2·sinθ2',
    used: 'codex reference — refracted-look ripples use ring distortion instead.' },
  { id: 'caustics', field: 'light', name: 'Caustics',
    what: 'The woven light nets rippling on river beds: wave lenses focus sunlight.',
    math: 'layered domain-warped sine/voronoi cells, animated out of phase.',
    used: 'water wire-line glints stand in for the caustic web at our scale.' },
  { id: 'kelvin-wedge', field: 'water', name: 'Kelvin wake pattern',
    what: 'Anything moving through water trails a V-wake at a constant 39° total angle.',
    math: 'half-angle arcsin(1/3) ≈ 19.47°, independent of speed.',
    used: 'ripples spawned along movement read as the near-wake.' },
  { id: 'screen-ripples', field: 'water', name: 'Expanding damped ripples',
    what: 'Ring disturbances grow and fade; overlapping rings interfere like real water.',
    math: 'r(t) = r0 + v·t; a(t) = a0 − λ·t',
    used: 'engine3d spawnRipple/stepRipples → wading, splashes, thrown bodies.' },
  { id: 'splash-impulse', field: 'particle', name: 'Crown splash impulse',
    what: 'Entry speed becomes a radial particle burst + noise crack + camera shake.',
    math: 'v_particle = radial·f(v_entry); gravity pulls the crown back down.',
    used: 'burst() + audio.noise + shake() the frame the player/car hits water.' },
  { id: 'lambert-diffuse', field: 'light', name: 'Lambert diffuse',
    what: 'The base shading of every face in the renderer.',
    math: 'I = albedo · max(0, n̂·l̂)',
    used: 'renderScene() per-face shading.' },
  { id: 'specular-glint', field: 'light', name: 'Slope specular glint',
    what: 'Wave facets tilted toward the light flash brighter — crests sparkle as they roll.',
    math: 'color += max(0, slope_toward_light) · k',
    used: 'waterMesh() per-quad spec term, scaled by recipe waveAmp.' },
  { id: 'fog-extinction', field: 'screen', name: 'Distance fog (Beer–Lambert)',
    what: 'Atmospheric perspective: far geometry dissolves into fog colour.',
    math: 'f = clamp((d−near)/(far−near)); c = c·(1−f) + fog·f',
    used: 'renderScene() fogNear/fogFar from the atmosphere spec.' },
  { id: 'vignette', field: 'screen', name: 'Lens vignette',
    what: 'Radial edge darkening — tunnels vision, the horror staple.',
    math: 'α = smoothstep(r_in, r_out, dist_from_centre)',
    used: 'postFX() — heavier in dark worlds, boosted by FX recipes.' },
  { id: 'film-grain', field: 'screen', name: 'Deterministic film grain',
    what: 'Per-frame pseudo-random luminance speckle; analog texture that hides banding.',
    math: 'dot(i·P1 + frame·P2 mod W,H) at low alpha',
    used: 'postFX() grain count from recipe.' },
  { id: 'scanlines-crt', field: 'screen', name: 'CRT scanlines',
    what: 'Horizontal dark bars every 2–3 px — surveillance-camera dread.',
    math: 'y mod 3 == 0 → α',
    used: 'postFX() on mansion/horror worlds.' },
  { id: 'chromatic-tint', field: 'screen', name: 'Mood tint wash',
    what: 'A full-screen colour wash regrades the whole frame: toxic green, blood red, neon white.',
    math: 'c_screen = c_scene ⊗ tint',
    used: 'postFX() tint — set by the forged recipe.' },
  { id: 'lightning-flash', field: 'particle', name: 'Storm lightning',
    what: 'Random full-screen luminance spikes; thunder follows by distance.',
    math: 'flash frames = noise(frame) > θ; audio delayed d/c_sound',
    used: 'storm recipes in composed3d draw().' },
  { id: 'embers', field: 'particle', name: 'Rising embers / motes',
    what: 'Heat convection: points drift upward and flicker — lava fields, burning cities.',
    math: 'y = H − ((i·P + frame·v) mod H); flicker sin(i·φ + t)',
    used: 'embers recipes in composed3d draw().' },
  { id: 'rain-streaks', field: 'particle', name: 'Slanted rain streaks',
    what: 'Screen-space falling lines with per-drop speed variance; wind slants them.',
    math: 'pos = (i·P + frame·v) mod (W,H)',
    used: 'atmosphere.rain in composed3d.' },
  { id: 'foam-line', field: 'water', name: 'Foam / shore whiteness',
    what: 'Steep slopes and shorelines whiten — foam = smoothstep over wave gradient.',
    math: 'foam = smoothstep(θ0, θ1, |∇h|)',
    used: 'recipe foam param brightens crest quads.' },
  { id: 'depth-tint', field: 'water', name: 'Depth tint',
    what: 'Deeper water reads darker and less transparent — the river bed fades out.',
    math: 'α = ramp(depth); color lerps to deep tone',
    used: 'recipe waterBase sets the depth-darkness per world.' },
  { id: 'hairline-wire', field: 'screen', name: 'Hairline wire edges',
    what: 'Vector-edge overlay: the technical/blueprint look — and it kills quad seams.',
    math: 'stroke(face) at α = wire',
    used: 'renderScene per-face wire; water wire alpha from recipe.' },
  { id: 'drown-o2', field: 'physics', name: 'Breath-hold O₂ model',
    what: 'The real-life rule: underwater drains oxygen, zero oxygen starts drowning damage, surfacing restores it.',
    math: 'O₂ -= rate·dt (submerged); O₂ += recover·dt (air); hp -= dmg·dt at O₂=0',
    used: 'composed3d swimming/diving (C) and the sinking car.' },
  { id: 'shake-trauma', field: 'screen', name: 'Trauma screen-shake',
    what: 'Impacts add "trauma"; shake = trauma² noise, decaying exponentially — the juice technique.',
    math: 'offset = trauma² · noise(t) · max_px',
    used: 'g.shake() on splashes, hits, boss wakes.' },
  { id: 'camera-handbob', field: 'screen', name: 'Camera hand-bob',
    what: 'Vertical sway locked to step frequency sells weight and movement.',
    math: 'y += sin(2·f_step·t)·amp',
    used: 'wading slows and bobs the view (buoyancy coupling).' }
];

/* ---------------- THE FORGE: recipes the AI composes itself ---------------- */
const KINDS = {
  'clear-water': { tint: null, waterBase: 0.30, wire: 0.12, note: 'daylight water, honest glints' },
  'black-water': { tint: 'rgba(0,0,0,.10)', waterBase: 0.14, wire: 0.08, note: 'light-swallowing dark water' },
  'toxic':       { tint: 'rgba(120,255,140,.05)', waterBase: 0.34, wire: 0.20, note: 'poison-green sheen' },
  'blood':       { tint: 'rgba(255,40,40,.06)', waterBase: 0.20, wire: 0.16, note: 'crimson-dark water' },
  'neon':        { tint: 'rgba(235,235,255,.04)', waterBase: 0.42, wire: 0.26, note: 'bright vector lines, club-night glow' },
  'storm':       { tint: 'rgba(10,10,14,.08)', waterBase: 0.18, wire: 0.10, note: 'lightning over rough black water' },
  'lava-glow':   { tint: 'rgba(255,120,30,.06)', waterBase: 0.46, wire: 0.22, note: 'molten brightness + rising embers' },
  'frozen':      { tint: 'rgba(220,240,255,.05)', waterBase: 0.52, wire: 0.14, note: 'pale icy sheet, low slow waves' }
};
const KIND_IDS = Object.keys(KINDS);

// request words bias the kind (first match wins); everything else hashes
const KIND_BIAS = [
  { re: /lava|magma|volcano|molten/i, kind: 'lava-glow' },
  { re: /toxic|poison|radioactive|nuclear|mutant/i, kind: 'toxic' },
  { re: /blood|gore|red river/i, kind: 'blood' },
  { re: /neon|cyber|tron|synthwave|night ?club/i, kind: 'neon' },
  { re: /storm|thunder|lightning|tempest/i, kind: 'storm' },
  { re: /ice|frozen|glacier|snow|arctic/i, kind: 'frozen' },
  { re: /horror|dark|haunted|night|creepy|dread/i, kind: 'black-water' }
];

function hashText(text) { // mulberry32 over the string
  let h = 0x9e3779b9;
  for (let i = 0; i < text.length; i += 1) {
    h = Math.imul(h ^ text.charCodeAt(i), 0x85ebca6b);
    h = (h << 13) | (h >>> 19);
  }
  return function () {
    h = Math.imul(h ^ (h >>> 16), 0x22f05d);
    h = Math.imul(h ^ (h >>> 15), 0x93d765dd);
    const t = h ^ (h >>> 16);
    return ((t >>> 0) % 100000) / 100000;
  };
}

/** Compose a NEW effect recipe from any request text. Deterministic per text. */
function forgeFX(seedText) {
  const text = String(seedText || '');
  const rnd = hashText('fx|' + text);
  let kind = null;
  for (const b of KIND_BIAS) if (b.re.test(text)) { kind = b.kind; break; }
  if (!kind) kind = KIND_IDS[Math.floor(rnd() * KIND_IDS.length) % KIND_IDS.length];
  const base = KINDS[kind];
  const pick = (lo, hi, steps) => lo + Math.round(rnd() * (steps - 1)) * ((hi - lo) / (steps - 1));
  const params = {
    waveAmp: Number(pick(0.6, 1.6, 32).toFixed(3)),
    waterBase: Number(pick(Math.max(0.08, base.waterBase - 0.06), base.waterBase + 0.08, 16).toFixed(3)),
    wire: Number(pick(Math.max(0.04, base.wire - 0.04), base.wire + 0.10, 32).toFixed(3)),
    grain: Math.round(pick(20, 90, 16)),
    vignetteBoost: Number(pick(0, 0.22, 16).toFixed(3)),
    storm: kind === 'storm' ? true : rnd() < 0.12,
    embers: kind === 'lava-glow' ? true : rnd() < 0.10,
    foam: Number(pick(0.2, 0.9, 8).toFixed(3)),
    tint: base.tint
  };
  const codex = ['sine-superposition', 'specular-glint', 'screen-ripples', 'hairline-wire'];
  if (params.storm) codex.push('lightning-flash', 'rain-streaks');
  if (params.embers) codex.push('embers');
  if (params.foam > 0.6) codex.push('foam-line');
  codex.push('drown-o2', 'buoyancy', 'spring-damper-slosh');
  return {
    id: `${kind}-${Math.floor(rnd() * 90000 + 10000)}`,
    kind, params, codex,
    note: base.note
  };
}

/** Honest combination count: kinds × quantised parameter space. */
function combinations() {
  return KIND_IDS.length * 32 * 16 * 32 * 16 * 16 * 2 * 2 * 8; // 1,073,741,824 — over a BILLION recipes
}

/** Runtime guard: a recipe must be schema-valid before a game consumes it. */
function validateFX(recipe) {
  if (!recipe || typeof recipe !== 'object' || !recipe.kind || !KINDS[recipe.kind]) return false;
  const p = recipe.params || {};
  return Number.isFinite(p.waveAmp) && p.waveAmp >= 0.3 && p.waveAmp <= 2
    && Number.isFinite(p.waterBase) && p.waterBase >= 0.04 && p.waterBase <= 0.75
    && Number.isFinite(p.wire) && p.wire >= 0 && p.wire <= 0.5
    && Number.isFinite(p.grain) && p.grain >= 0 && p.grain <= 200
    && typeof p.storm === 'boolean' && typeof p.embers === 'boolean'
    && Array.isArray(recipe.codex) && recipe.codex.every((c) => CODEX.some((e) => e.id === c));
}

function describeFX(recipe) {
  if (!validateFX(recipe)) return 'no FX recipe';
  const p = recipe.params;
  return `${recipe.kind} FX (recipe ${recipe.id}): ${recipe.note} — waves ×${p.waveAmp}, water ${p.waterBase}, wire-lines ${p.wire}, grain ${p.grain}${p.storm ? ', storm lightning' : ''}${p.embers ? ', rising embers' : ''}, foam ${p.foam}`;
}

module.exports = { CODEX, KINDS, KIND_IDS, forgeFX, combinations, validateFX, describeFX };
