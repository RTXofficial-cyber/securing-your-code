/**
 * DETAIL CODEX (v1.21.0) — the scalable home for the "100,000 details".
 *
 * The user's point was right: real-game fidelity is a MOUNTAIN of details
 * (car doors that open, fridges whose contents really come out, traffic
 * that yields, pilots in cockpits…). You cannot pour 100k details into a
 * chat — so this codex is the system: every real-world detail gets a
 * catalogued entry with an HONEST impl flag ('done' = actually simulated
 * in the engine right now, 'planned' = catalogued, build pending). Air_you
 * answers from this codex, and every shipping turn flips more entries to
 * 'done'. That is how the mountain gets moved — batch by batch.
 */

const CODEX = {
  car: [
    { id: 'car.doors', name: 'Doors (4) — open/close, hinges, ajar state', real: 'har darwaza hinge par khulta hai, khula darwaza body se bahar swing karta hai', impl: 'done' },
    { id: 'car.trunk', name: 'Trunk (diggi) — open/close, storage', real: 'trunk upar uthta hai, andar space dikhta hai', impl: 'done' },
    { id: 'car.hood', name: 'Hood (bonnet) — open/close, engine bay', real: 'hood khulne par engine block nazar aata hai', impl: 'done' },
    { id: 'car.engine', name: 'Engine — on/off, rpm, temperature', real: 'start par rpm idle ~800, chalne par badhta hai; temp warm-up ke baad ~92°C', impl: 'done' },
    { id: 'car.fuelcap', name: 'Petrol cap — open, refuel, tank level', real: 'cap khole bina petrol nahi bhar sakti; bharte waqt level barhta hai, 100% par auto-stop', impl: 'done' },
    { id: 'car.mirrors', name: 'Side mirrors (2) — mounted on front doors', real: 'mirrors darwazon ke saath move/fold hote hain', impl: 'done' },
    { id: 'car.wheels', name: 'Wheels + tire deformation', real: 'drift/fast par tires compress + skid tracks (GTA-6 detail pack se live)', impl: 'done' },
    { id: 'car.interior', name: 'Interior: seats, dashboard, steering, duct-taped handle', real: 'cabin detail — GTA-6 trailer wala duct-taped door handle tak', impl: 'planned' },
    { id: 'car.lights', name: 'Head/brake lights: filament warm-up vs instant LED', real: 'purane bulbs filament garam hone par fade-in; LED instant; brake par red glow', impl: 'planned' },
    { id: 'car.suspension', name: 'Suspension bounce + chassis lean in corners', real: 'weight shift, cornering lean, bumps par bounce', impl: 'planned' }
  ],
  home: [
    { id: 'home.fridge', name: 'Fridge — open/close, items ALREADY inside', real: 'fridge ke andar bottle/cup/sabzi PEHLE se hoti hain (spawn nahi) — kholo, nikalo, haath mein uthao', impl: 'done' },
    { id: 'home.held', name: 'Held items — haath mein uthao, chale to hilte hain', real: 'bottle ka paani slosh karta hai (spring-damper physics), player ke saath move karta hai', impl: 'done' },
    { id: 'home.drop', name: 'Drop = REAL drop — item girta hai, zameen par tikta hai', real: 'gravity se girta hai, thud sound, wapas uthaya ja sakta hai — gayab nahi hota', impl: 'done' },
    { id: 'home.drink', name: 'Drink from cup/bottle — level girta hai', real: 'ghoont piyo to fill level kam, khaali ho to honest "khaali"', impl: 'done' },
    { id: 'home.kitchen', name: 'Kitchen: stove, sink, utensils, microwave doors', real: 'har appliance ke apne open/close + use states', impl: 'planned' },
    { id: 'home.lights', name: 'Ghar ke lights: switches, warm glow, tube-light flicker', real: 'switch par flicker ke baad start, warm-up', impl: 'planned' }
  ],
  traffic: [
    { id: 'traffic.cars', name: 'Road traffic — lanes, direction, wrapping', real: 'AI cars roads par chalti hain, kinare par wrap, bridge se river cross', impl: 'done' },
    { id: 'traffic.yield', name: 'Cars yield to the player', real: 'player qareeb ho to traffic slow — brake glow ke saath', impl: 'done' },
    { id: 'traffic.brakes', name: 'Brake lights glow when slowing', real: 'slow hote hi peeche red brake faces', impl: 'done' },
    { id: 'traffic.peds', name: 'Crowds cross roads, react to horns/gunfire', real: 'GTA-6 pack: gunfire/speeding car par bhaagte hain (live)', impl: 'done' },
    { id: 'traffic.signals', name: 'Traffic signals + intersection stops', real: 'signals cycle, cars intersection par rukti hain', impl: 'planned' }
  ],
  airport: [
    { id: 'airport.runway', name: 'Runway + centerline markings', real: 'flat strip, dashes, threshold markings', impl: 'done' },
    { id: 'airport.plane', name: 'Plane: parked → takeoff roll → rotate → cruise', real: 'throttle, speed build, rotate speed par lift, phir circling', impl: 'done' },
    { id: 'airport.engine', name: 'Plane engine + spinning propeller', real: 'throttle ke saath prop spin rate; engine ON tab hi takeoff', impl: 'done' },
    { id: 'airport.pilot', name: 'Pilot visible in the cockpit', real: 'cockpit mein pilot ka head+body dikhta hai', impl: 'done' },
    { id: 'airport.heli', name: 'Helicopter: main + tail rotor, hover circle, pilot', real: 'rotor spin, height hold with drift, sheher ke upar circle', impl: 'done' },
    { id: 'airport.landing', name: 'Landing gear + touchdown smoke', real: 'gear retract takeoff ke baad, touchdown par tire smoke', impl: 'planned' }
  ],
  beach: [
    { id: 'beach.umbrellas', name: 'Beach umbrellas + towels', real: 'kinare par umbrellas, towels bichhe', impl: 'done' },
    { id: 'beach.sunbathers', name: 'Sunbathers lying (not standing peds)', real: 'lete hue log — alag pose, bheed se separate', impl: 'done' },
    { id: 'beach.ball', name: 'Beach ball bouncing', real: 'ball hawa mein uchalta, shadow ke saath', impl: 'done' },
    { id: 'beach.sand', name: 'Wet→dry sand gradient + footprints on sand', real: 'GTA-6 pack: paani ke paas geela sand, footprints (live)', impl: 'done' },
    { id: 'beach.waves', name: 'Waves lapping the shoreline foam', real: 'kinare par foam line jo aage-peeche hoti hai', impl: 'planned' }
  ],
  gym: [
    { id: 'gym.zone', name: 'Gym building (open zone) with roof + posts', real: 'alag building jisme log workout karte hain', impl: 'done' },
    { id: 'gym.treadmill', name: 'Treadmill + weights rack inside', real: 'andar equipment dikhta hai', impl: 'done' },
    { id: 'gym.workout', name: 'Peds switch to workout state (bobbing reps)', real: 'zone mein aate hi walk → workout, reps ki tarah bob', impl: 'done' },
    { id: 'gym.exit', name: 'Workout stops when they leave / panic overrides', real: 'zone se bahar → walk; gunfire → flee (workout chhoot)', impl: 'done' }
  ],
  city: [
    { id: 'city.grid', name: 'City blocks + road corridors', real: 'grid buildings, roads corridors mein (live)', impl: 'done' },
    { id: 'city.river', name: 'River + bridges + bay', real: 'GTA-6 pack: river z 700-900, 2 bridges, bay east (live)', impl: 'done' },
    { id: 'city.weather', name: 'Drifting weather cell: rain, wind, fog, storm HUD', real: 'GTA-6 pack: intensity/wind drift, STORM HUD (live)', impl: 'done' },
    { id: 'city.wildlife', name: 'Alligators, seabirds, dolphins catalogued', real: 'gators + birds live; dolphins bay ke liye planned', impl: 'done' },
    { id: 'city.night', name: 'Night cycle: neon reflections on humid asphalt', real: 'raat ki neon, geeli sadak par reflection', impl: 'planned' }
  ]
};

function categories() { return Object.keys(CODEX); }

function count() {
  let total = 0; let done = 0;
  for (const k of Object.keys(CODEX)) for (const e of CODEX[k]) { total += 1; if (e.impl === 'done') done += 1; }
  return { total, done, planned: total - done, categories: Object.keys(CODEX).length };
}

function category(name) { return CODEX[String(name || '').toLowerCase()] || null; }

/* search across the whole codex — Air_you answers "car ki details" etc. from here */
function search(q) {
  const s = String(q || '').toLowerCase();
  const hits = [];
  for (const k of Object.keys(CODEX)) {
    for (const e of CODEX[k]) {
      if (k.includes(s) || e.name.toLowerCase().includes(s) || e.real.toLowerCase().includes(s) || e.id.includes(s)) hits.push({ cat: k, ...e });
    }
  }
  return hits;
}

module.exports = { CODEX, categories, count, category, search };
