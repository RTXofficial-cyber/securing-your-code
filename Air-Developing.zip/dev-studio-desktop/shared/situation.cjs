/**
 * SITUATION ENGINE — Air_you 3.0 (v1.20.0)
 *
 * The user's ask: "AI ko situation handling do — task, observation, fine
 * handling". This module turns ANY request into a structured situation
 * report before a single line of code is written:
 *
 *   OBSERVE (kya maujood hai) → TASKS (kaam ke tukde) → RISKS (kya toot
 *   sakta hai) → PLAN (kaise karenge) → REFINE (baad mein kya behtar karna)
 *
 * It is deterministic, offline, and honest: it never invents files that
 * were not listed, never claims a web check it did not run, and it folds in
 * REAL past lessons (experience journal) when they match the goal — that is
 * how learning gets faster time to time.
 */

function words(t) {
  return String(t || '').toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2);
}

/* One intent wins — order matters: an explicit research verb beats topic
   words ("latest gta 6 news RESEARCH karo" = research, not game), fix beats
   build, store beats website. */
function detectIntent(t) {
  const s = String(t || '').toLowerCase();
  if (/(?:\bfix\b|theek|kharab|bug|error|crash|toota|broken|nahi chal)/.test(s)) return 'fix';
  if (/(?:research|dhundo|search karo|data collect|jaankari|pata (?:karo|lagao)|\blatest\b|\bnews\b|information (?:chahiye|collect|gather))/.test(s)) return 'research';
  if (/(?:store|dukaan|shop|inventory|billing|cashier|sales counter|point of sale|\bpos\b)/.test(s)) return 'store';
  if (/(?:game|khel|arcade|shooter|\bfps\b|racing|driving|mission|gta|platformer)/.test(s)) return 'game';
  if (/(?:website|landing page|portfolio|webpage|site banao)/.test(s)) return 'website';
  if (/(?:\bapi\b|backend|server|endpoint|database)/.test(s)) return 'api';
  if (/(?:banao|banana|build|create|develop|likho|naya project)/.test(s)) return 'build';
  if (/\?$|\bkya\b|\bkaun\b|\bkaise\b|\bhow\b|\bwhat\b|\bwhy\b|kyun/.test(s)) return 'question';
  return 'other';
}

const TASKS_BY_INTENT = {
  store: [
    'Store ki current files/stock list OBSERVE karo (jo workspace mein hai)',
    'Data model: items, prices, stock, sales — ek saaf schema',
    'UI: catalog + cart/counter + admin (badlav ke liye simple rakho)',
    'Snapshot lo (STORE SNAPSHOT) — taake har future change ke baad rollback possible rahe',
    'Test: item add/update/sale + ek rollback drill',
    'Deploy notes + version journal — changes time to time safe rahen'
  ],
  game: [
    'Spec nikalo: world, player, controls, camera (2D ya 3D)',
    'Engine choose: GameKit3D (3D) / arcade canvas (2D)',
    'Core loop: input → update → draw, ek level/scene',
    'Detail pack: water/tracks/crowds/weather jo spec se match kare',
    'Headless run + FPS sanity + play.html link',
    'Polish pass: FX Forge recipe + sound hooks'
  ],
  fix: [
    'REPRODUCE: error ko pehle chal kar dekho (guess nahi)',
    'OBSERVE: stack trace / logs / recent changes padho',
    'Root cause: ek line mein likho',
    'Minimal patch — sirf wahi badlo jo toota hai',
    'VERIFY: wahi case dobara chalao + related tests',
    'Lesson journal mein save karo (agli baar tez fix)'
  ],
  research: [
    'Sawal ko 2-3 search queries mein todo',
    'Live web search chalao (search command / deep research)',
    'Sources collect: title + link + snippet (KNOWLEDGE BANK mein save)',
    'Cross-check: kam az kam 2 alag sources se confirm',
    'Cited summary likho — jo nahi mila, honestly "nahi mila" likho'
  ],
  website: [
    'Pages + sections ki list (landing, about, contact…)',
    'Design system: black/white, mono accents, responsive',
    'Content structure + assets',
    'Build: static ya framework — jo maintenance mein asaan ho',
    'Browser test (mobile + desktop widths)',
    'Deploy: hosting + domain notes'
  ],
  api: [
    'Endpoints ki list: method, path, request/response shape',
    'Data layer: storage + validation',
    'Error handling: honest codes + friendly messages',
    'Auth/permission gates (jahan zaroori ho)',
    'Tests: happy path + failure path',
    'Docs: README mein endpoint table'
  ],
  build: [
    'Goal ko ek line mein likho (kya banega, kiske liye)',
    'Chhote tasks mein todo (har task ka "done" define ho)',
    'Existing code OBSERVE karo — dobara mat banao jo maujood hai',
    'Step by step implement — har step ke baad verify',
    'Tests + run karke sabit karo',
    'Docs update + agla improvement note karo'
  ],
  question: [
    'Sawal ka scope samjho (kya poocha, kis level par)',
    'Apni KB + past lessons check karo',
    'Zaroorat ho to live search (needsWeb flag)',
    'Seedha, honest jawab — na ho to saaf "nahi pata"'
  ],
  other: [
    'Request ko apne words mein dohrao (confirm understanding)',
    'Missing info ki list banao',
    'Sabse chhota agla step decide karo',
    'Kar ke dikhao, phir verify'
  ]
};

const RISKS_BY_INTENT = {
  store: ['Bina snapshot ke change = data loss ka risk — pehle snapshot', 'Stock/price math galat hua to nuksan — tests zaroori'],
  game: ['Performance: bina FPS check ke heavy scene', 'Controls unclear = game "chalti nahi" lagti hai'],
  fix: ['Bina reproduce kiye patch = andhera teer', 'Ek fix doosri cheez tod de — related tests chalao'],
  research: ['Single source galat ho sakta hai — cross-check', 'Purana data — date/timestamp dekho'],
  website: ['Mobile par layout tootna', 'Bhari assets = slow load'],
  api: ['Validation ke bina corrupt data', 'Auth gate missing = security hole'],
  build: ['Scope creep — chhota shuru karo', 'Verify ke bina "done" bolna'],
  question: ['Bina soche jawab = galat confidence'],
  other: ['Assumption bina confirm kiye']
};

function observe(text, files) {
  const list = Array.isArray(files) ? files : null;
  if (!list) return 'workspace scan is waqt available nahi — pehla kaam: files list karo (ya Studio kholo)';
  if (!list.length) return 'workspace khaali hai — sab naya banega (greenfield)';
  const toks = words(text).filter((w) => w.length > 3).slice(0, 40);
  const hits = [];
  for (const f of list) {
    const base = String(f).toLowerCase();
    if (toks.some((t) => base.includes(t))) hits.push(f);
    if (hits.length >= 6) break;
  }
  const head = `workspace mein ${list.length} entries`;
  return hits.length ? `${head} — goal se milti hui: ${hits.join(', ')}` : `${head} — is goal se milti file nahi dikhi (naya banega)`;
}

function pickLessons(goal, lessons) {
  if (!Array.isArray(lessons) || !lessons.length) return [];
  const g = new Set(words(goal));
  const scored = lessons
    .map((l) => {
      const s = String(l || '');
      const shared = words(s).filter((w) => g.has(w)).length;
      return { s, shared };
    })
    .filter((x) => x.shared > 0)
    .sort((a, b) => b.shared - a.shared)
    .slice(0, 2);
  return scored.map((x) => x.s.slice(0, 160));
}

function needsWebCheck(text, intent) {
  if (intent === 'research') return true;
  return /(latest|202[5-9]|news|aaj kal|current price|market|real detail|asli detail)/i.test(String(text || ''));
}

/**
 * assess(text, { files, lessons }) → situation object
 */
function assess(text, opts = {}) {
  const goal = String(text || '').trim().slice(0, 240);
  const intent = detectIntent(goal);
  const tasks = TASKS_BY_INTENT[intent] || TASKS_BY_INTENT.other;
  return {
    intent,
    goal,
    tasks,
    observe: observe(goal, opts.files),
    risks: RISKS_BY_INTENT[intent] || RISKS_BY_INTENT.other,
    needsWeb: needsWebCheck(goal, intent),
    lessons: pickLessons(goal, opts.lessons),
    plan: 'OBSERVE → TASKS → ACT → VERIFY → REFINE'
  };
}

/** formatSituation(a) → user-facing report (Roman Urdu, honest, actionable) */
function formatSituation(a) {
  return [
    `🧭 SITUATION HANDLING (Air_you 3.0) — pehle samajh, phir kaam`,
    `intent: ${String(a.intent).toUpperCase()} · goal: "${a.goal}"`,
    `👁 OBSERVE: ${a.observe}`,
    '📋 TASKS:',
    ...a.tasks.map((t, i) => `  ${i + 1}. ${t}`),
    '⚠️ RISKS:',
    ...a.risks.map((r) => `  - ${r}`),
    `🎯 PLAN: ${a.plan}`,
    '⚡ REFINE: har task ke baad result check karo — galti mile to us task ko dohrao, aur seekha hua lesson experience journal mein save karo. Isi se main time ke saath TEZ aur BEHTAR hota hoon (one-way learning).',
    a.lessons.length ? `📚 PURANE LESSONS (isi goal se milte): \n${a.lessons.map((l) => `  • ${l}`).join('\n')}` : '',
    a.needsWeb ? '🌐 WEB: isme live search faida dega — "search <sawal>" chalao (AirMind) ya Deep mode. Results Knowledge Bank mein save hote hain — agli baar wahi sawal tez (bina dobara search).' : ''
  ].filter(Boolean).join('\n');
}

module.exports = { assess, formatSituation, detectIntent, words, pickLessons };
