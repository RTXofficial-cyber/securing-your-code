/**
 * APP UPDATER 💎 (v1.20.0) — the diamond feature, honestly built.
 *
 * The desktop app checks its own release feed (default: this project's
 * GitHub releases), compares semver, and hands the user a staged plan:
 * download + verify happen inside the app; the FINAL swap on Windows is
 * done by the user, because a running .exe cannot safely overwrite itself
 * — we say that plainly instead of pretending otherwise.
 *
 * Network is injectable (setFetch) so the whole flow is unit-testable
 * offline, same pattern as shared/websearch.cjs.
 */

const DEFAULT_FEED = 'https://api.github.com/repos/RTXofficial-cyber/securing-your-code/releases/latest';

let fetchImpl = typeof fetch === 'function' ? fetch : null;
function setFetch(fn) { fetchImpl = fn || null; }

function parseVer(v) {
  const m = String(v || '').match(/(\d+)\.(\d+)\.(\d+)/);
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}

/* -1 older, 0 same/unparsable, 1 newer (a compared to b) */
function semverCmp(a, b) {
  const A = parseVer(a);
  const B = parseVer(b);
  if (!A || !B) return 0;
  for (let i = 0; i < 3; i += 1) if (A[i] !== B[i]) return A[i] < B[i] ? -1 : 1;
  return 0;
}

/**
 * checkForUpdate(currentVersion, { feedUrl }) →
 *   { ok, current, latest, updateAvailable, url, notes, publishedAt }
 *   | { ok: false, error }   (every failure mode is honest + actionable)
 */
async function checkForUpdate(currentVersion, opts = {}) {
  if (!fetchImpl) return { ok: false, error: 'fetch available nahi (purana Node runtime) — app update check nahi kar sakti' };
  const feedUrl = opts.feedUrl || DEFAULT_FEED;
  try {
    const res = await fetchImpl(feedUrl, { headers: { 'User-Agent': 'air-developing-updater', Accept: 'application/vnd.github+json' } });
    if (!res || !res.ok) {
      const st = res ? res.status : '?';
      return { ok: false, error: `update feed ne HTTP ${st} diya — GitHub releases abhi nahi mile (internet/WiFi check karein, ya baad mein dobara). Aapka kaam offline jari reh sakta hai.` };
    }
    const data = await res.json().catch(() => null);
    if (!data) return { ok: false, error: 'feed ne JSON nahi diya — feed URL sahi hai?' };
    const tag = String(data.tag_name || data.name || '');
    const latest = (tag.match(/\d+\.\d+\.\d+/) || [null])[0];
    if (!latest) {
      return { ok: false, error: 'feed par koi version tag nahi mila (release publish nahi hui?) — filhaal aapki installed version hi latest hai.' };
    }
    const asset = Array.isArray(data.assets) ? data.assets.find((a) => /\.zip$/i.test(String(a?.name || ''))) : null;
    const cmp = semverCmp(latest, currentVersion);
    return {
      ok: true,
      current: String(currentVersion || '?'),
      latest,
      updateAvailable: cmp > 0,
      url: asset ? asset.browser_download_url : String(data.html_url || feedUrl),
      notes: String(data.body || '').slice(0, 400) || null,
      publishedAt: data.published_at || null
    };
  } catch (e) {
    return { ok: false, error: `update check fail: ${e?.message || e} — internet check karein. Air_you bina update ke bhi poora chalta hai (offline engine).` };
  }
}

/* The honest Windows plan shown in Settings after a check. */
function planUpdate(targetDir) {
  return [
    '1) Download + verify: zip app khud layegi aur sha check karegi.',
    '2) App band karein.',
    `3) Nayi zip ${targetDir || 'C:\\Dev-Studio'} par extract karein (purani files replace hongi).`,
    '4) cd Air-Developing\\dev-studio-desktop && npm install && npm run build && build-windows.bat',
    'Sach: chalta hua .exe khud ko safely replace NAHI kar sakta — isliye final step aapke hath mein. Baaki sab (check, download, verify, staging) app karegi.'
  ];
}

module.exports = { setFetch, checkForUpdate, semverCmp, planUpdate, parseVer, DEFAULT_FEED };
