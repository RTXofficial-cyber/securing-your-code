/* localai.cjs — download + run a GB-class AI on YOUR PC (Ollama).

  Honest architecture: Air_you (the built-in engine) ships inside this app and
  needs zero downloads. A GB-class model — billions of parameters, multi-gigabyte
  weights — can never be bundled inside a GitHub zip (GitHub caps files at 100MB),
  so the app downloads it straight from Ollama to your own disk and it then runs
  100% locally: no cloud, no API key, no credits, nothing leaves your PC.

  This module is pure parsing helpers (unit-testable); the IPC layer in
  electron/ipc.cjs wires them to `ollama --version | list | pull`.
*/
'use strict';

/* Curated GB-class models, smallest first. */
const MODELS = [
  { id: 'phi3:mini', gb: 2.2, note: 'Fast — runs on modest PCs' },
  { id: 'mistral:7b', gb: 4.1, note: 'Great all-rounder' },
  { id: 'llama3.1:8b', gb: 4.7, note: 'Recommended — strongest 8B coder' },
  { id: 'qwen2.5:7b', gb: 4.7, note: 'Excellent at code + reasoning' },
  { id: 'llama3.1:70b', gb: 40, note: 'Workstation-class — big GPU/RAM needed' }
];

/* Parse `ollama list` output (cols: NAME ID SIZE MODIFIED).
   Returns [{ id, size }] — size keeps the human unit ("4.7 GB"). */
function parseOllamaList(stdout) {
  const out = [];
  for (const line of String(stdout || '').split(/\r?\n/)) {
    if (/^\s*NAME/i.test(line) || !line.trim()) continue;
    const c = line.trim().split(/\s+/);
    // real output: NAME ID SIZE("4.7 GB" = two tokens) MODIFIED("2 days ago")
    if (c.length >= 4 && /^[\d.]+$/.test(c[2]) && /^[KMGT]?B$/i.test(c[3])) out.push({ id: c[0], size: `${c[2]} ${c[3]}` });
    else if (c.length >= 3) out.push({ id: c[0], size: c[2] || '' });
  }
  return out;
}

/* Parse one Ollama pull progress line (they are \r-separated):
   "pulling manifest", "34% ▕███  1.6 GB/4.7 GB  12 MB/s", "verifying sha256 digest", "success".
   Returns { pct, transferred, total, speed, done, text } or null. */
function parsePullProgress(line) {
  const text = String(line || '').trim();
  if (!text) return null;
  const m = text.match(/(\d+)%/);
  const size = text.match(/([\d.]+\s*[KMGT]?B)\s*\/\s*([\d.]+\s*[KMGT]?B)/i);
  const speed = text.match(/([\d.]+\s*[KMGT]?B\/s)/i);
  const done = /^success$/i.test(text) || /\bwriting manifest\b/i.test(text);
  if (!m && !done && !/pulling|verifying|extracting|digest|manifest/i.test(text)) return null;
  return {
    pct: m ? Math.min(100, parseInt(m[1], 10)) : (done ? 100 : null),
    transferred: size ? size[1] : '',
    total: size ? size[2] : '',
    speed: speed ? speed[1] : '',
    done,
    text
  };
}

/* The freshest progress entry from a captured chunk of pull output. */
function lastProgress(raw) {
  const lines = String(raw || '').split('\r').filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    const p = parsePullProgress(lines[i]);
    if (p && (p.pct !== null || p.done)) return p;
  }
  return null;
}

module.exports = { MODELS, parseOllamaList, parsePullProgress, lastProgress };
