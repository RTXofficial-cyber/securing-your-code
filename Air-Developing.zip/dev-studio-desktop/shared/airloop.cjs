/**
 * AIR LOOP (v1.22.0) — Air_you ka apna multi-step agent loop.
 *
 * The user's ask: "Air_you ko bilkul tumhari tarha kaam karne wala banao."
 * Ye wahi pattern hai jo ek bara coding agent use karta hai:
 *
 *   OBSERVE (asli files list) → FOCUS (goal se match) → READ (real content)
 *   → PLAN (situation engine) → WRITE (artifact) → VERIFY (read-back
 *   exact-match) → REFINE (lesson journal — situation engine isi se seekhta)
 *
 * Offline + permission-safe: writes SIRF `.dev-studio/air/` ke andar hote
 * hain (Air_you ka apna journal area) — user ki files untouched. Aur har
 * step honest hai: verify fail ho to "fail" hi report hota hai.
 */
const situation = require('./situation.cjs');

function slug(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'goal';
}

function runAirLoop(opts) {
  const goal = String((opts && opts.goal) || '').trim().slice(0, 240);
  const ws = opts && opts.ws;
  const maxSteps = (opts && opts.maxSteps) || 8;
  const steps = [];
  const push = (tool, ok, obs) => {
    if (steps.length < maxSteps) steps.push({ n: steps.length + 1, tool, ok, obs: String(obs).slice(0, 200) });
  };

  if (!goal) return { ok: false, steps, honest: 'goal khaali hai — "airloop <goal>" likho.' };
  if (!ws || typeof ws.read !== 'function') {
    return { ok: false, steps, honest: 'workspace nahi mila — AIR LOOP ko asli files chahiye. Desktop app (AirMind/Studio) mein chalao; browser preview mein files access nahi hota.' };
  }

  // 1) OBSERVE — real file list
  let files = [];
  try {
    files = (ws.listFlat() || []).slice(0, 400);
    push('list_files', true, `${files.length} files in workspace`);
  } catch (e) { push('list_files', false, e.message); }

  // 2) FOCUS — goal tokens se relevant files
  const toks = situation.words(goal).filter((w) => w.length > 3);
  const relevant = files.filter((f) => toks.some((t) => String(f).toLowerCase().includes(t))).slice(0, 5);
  push('focus', true, relevant.length ? `relevant: ${relevant.join(', ')}` : 'koi file goal words se match nahi hui — plan naya kaam banayega');

  // 3) READ — top relevant files ka real content observe
  const notes = [];
  for (const f of relevant.slice(0, 3)) {
    try {
      const c = String(ws.read(f));
      const lines = c.replace(/\n$/, '').split('\n');
      notes.push(`- ${f}: ${lines.length} lines, ${c.length} chars; head: ${lines.slice(0, 2).join(' / ').slice(0, 100)}`);
      push('read_file', true, `${f}: ${lines.length} lines`);
    } catch (e) { push('read_file', false, `${f}: ${e.message}`); }
  }

  // 4) PLAN — situation engine se structured plan
  const a = situation.assess(goal, { files });
  push('plan', true, `intent ${a.intent} — ${a.tasks.length} tasks`);

  // 5) WRITE — artifact Air_you ke apne journal area mein
  const rel = `.dev-studio/air/${slug(goal)}.md`;
  const body = [
    `# AIR LOOP — ${goal}`,
    `run: ${new Date().toISOString()}`,
    '',
    `## OBSERVE (${files.length} files)`,
    notes.length ? notes.join('\n') : '- workspace mein goal se milti file nahi',
    '',
    `## SITUATION (intent: ${a.intent})`,
    `- observe: ${a.observe}`,
    ...a.tasks.map((t, i) => `- task ${i + 1}: ${t}`),
    ...a.risks.map((r) => `- risk: ${r}`),
    `- plan: ${a.plan}`,
    '',
    '## REFINE',
    '- har task ke baad verify karo; seekha hua lesson journal mein jata hai'
  ].join('\n');
  let wrote = false;
  try {
    ws.write(rel, body);
    wrote = true;
    push('write_artifact', true, `${rel} (${body.split('\n').length} lines)`);
  } catch (e) { push('write_artifact', false, e.message); }

  // 6) VERIFY — read back karke exact compare (jhootha "done" nahi)
  let verified = false;
  if (wrote) {
    try {
      const back = String(ws.read(rel));
      verified = back.length === body.length;
      push('verify', verified, verified ? 'read-back exact match' : 'read-back MISMATCH — likha gaya lekin verify fail');
    } catch (e) { push('verify', false, e.message); }
  }

  // 7) REFINE — lesson journal (cap 30); situation engine + Air_you isi se seekhte hain
  const lesson = `${goal.slice(0, 80)} → intent ${a.intent}; ${notes.length} file(s) observed; artifact ${verified ? 'verified' : 'UNVERIFIED'}`;
  let journal = [];
  try { const p = JSON.parse(ws.read('.dev-studio/air/journal.json')); if (Array.isArray(p)) journal = p; } catch {}
  journal = [{ when: new Date().toISOString(), goal: goal.slice(0, 160), lesson, steps: steps.length }, ...journal].slice(0, 30);
  try { ws.write('.dev-studio/air/journal.json', JSON.stringify(journal, null, 1)); } catch {}

  return { ok: verified, steps, artifact: wrote ? rel : null, verified, lesson, tasks: a.tasks, intent: a.intent, observed: notes.length };
}

module.exports = { runAirLoop, slug };
