/**
 * KNOWLEDGE BANK (v1.20.0) — proper info & data collection about what the
 * user asks.
 *
 * Every live web answer is stored in <workspace>/.dev-studio/kbank.json
 * (cap 60 entries, newest first) with query, timestamp and the top results
 * (title/url/snippet). A similar question asked later is answered FROM THE
 * BANK first: no re-search, faster time to time, and the collected data
 * stays on the user's PC. Honest by design: a bank hit says how old it is
 * and offers a fresh search; nothing is invented.
 */

const CAP = 60;

function norm(q) {
  return String(q || '').toLowerCase().replace(/[^a-z0-9 ]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function sig(q) {
  return new Set(norm(q).split(' ').filter((w) => w.length > 2));
}

/* Dice coefficient over significant tokens — language-agnostic, cheap. */
function similarity(a, b) {
  const A = sig(a);
  const B = sig(b);
  if (!A.size || !B.size) return 0;
  let hit = 0;
  for (const t of A) if (B.has(t)) hit += 1;
  return (2 * hit) / (A.size + B.size);
}

function parse(rawBank) {
  try {
    const b = JSON.parse(rawBank);
    return Array.isArray(b) ? b.filter((e) => e && typeof e.query === 'string') : [];
  } catch {
    return [];
  }
}

/**
 * find(rawBank, q, { minSim, maxAgeDays }) → { entry, sim, ageH } | null
 */
function find(rawBank, q, opts = {}) {
  const minSim = opts.minSim ?? 0.62;
  const maxAgeDays = opts.maxAgeDays ?? 3;
  const bank = parse(rawBank);
  const now = Date.now();
  let best = null;
  let bestSim = 0;
  for (const e of bank) {
    if (now - (e.when || 0) > maxAgeDays * 864e5) continue;
    const s = similarity(e.query, q);
    if (s > bestSim) { bestSim = s; best = e; }
  }
  if (!best || bestSim < minSim) return null;
  return { entry: best, sim: Math.round(bestSim * 100), ageH: Math.max(0, Math.round((now - (best.when || now)) / 36e5)) };
}

/** record(rawBank, q, results, extra) → new bank JSON string (cap applied) */
function record(rawBank, q, results, extra = {}) {
  const bank = parse(rawBank);
  const query = norm(q);
  if (!query) return rawBank || '[]';
  const entry = {
    query,
    when: Date.now(),
    n: Array.isArray(results) ? results.length : 0,
    results: (Array.isArray(results) ? results : []).slice(0, 8).map((r) => ({
      title: String(r?.title || '').slice(0, 140),
      url: String(r?.url || '').slice(0, 300),
      snippet: String(r?.snippet || '').slice(0, 300)
    })),
    ...(extra && typeof extra === 'object' ? { summary: String(extra.summary || '').slice(0, 500), source: String(extra.source || '').slice(0, 40) } : {})
  };
  const out = [entry, ...bank.filter((e) => e.query !== query)].slice(0, CAP);
  return JSON.stringify(out, null, 1);
}

function stats(rawBank) {
  const b = parse(rawBank);
  return { entries: b.length, cap: CAP, latest: b[0]?.when || null, queries: b.slice(0, 5).map((e) => e.query) };
}

module.exports = { norm, similarity, find, record, stats, parse, CAP };
