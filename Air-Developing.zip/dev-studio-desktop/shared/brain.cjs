/**
 * AIR BRAIN MODULE (v1.26.0) — Air_you ka apna COGNITIVE ARCHITECTURE.
 *
 * User ka ask (Ask 41): "AI ka BRAIN MODULE design karo — jaise tum kaam
 * karte ho, jo info tum mujhe dete ho, sab kuch uske brain ko DESIGN kare,
 * na ke sirf feed."
 *
 * Honest baat pehle: ye neural network NAHI hai (wo Ollama weights ka kaam
 * hai). Ye ek EXPLICIT COGNITIVE ENGINE hai — wahi 7-region pipeline jo
 * bare coding agents use karte hain, ek LIVE KNOWLEDGE GRAPH ke saath:
 *
 *   PERCEIVE → RECALL → PLAN → REASON → ACT → VERIFY → LEARN
 *
 * Feed aur brain ka farq:
 *  - FEED  = dead data store (entries ginta hai, jawab rat-ta hai)
 *  - BRAIN = live structure — har interaction graph ke WEIGHTS badalti hai
 *            (Hebbian: fire together → wire together), unused connections
 *            DECAY hoti hain, confidence recall-strength se nikalti hai.
 *            Detail Codex + KB + user sawaal + AIR LOOP lessons — sab isi
 *            graph ki tarteeb (structure) banate hain.
 *
 * One-way rule yahan bhi: brain SIRF .dev-studio/air/ ke andar likhta hai;
 * connected AIs ko graph kabhi nahi milta.
 */
const situation = require('./situation.cjs');

const GRAPH_REL = '.dev-studio/air/brain-graph.json';
const REGIONS = [
  { id: 'perceive', role: 'input → tokens, intent, sawal-vs-kaam' },
  { id: 'recall', role: 'knowledge graph par spreading activation (top-k concepts)' },
  { id: 'plan', role: 'goal → steps, har step ki done-definition + risk' },
  { id: 'reason', role: 'step-by-step trace + honest confidence (kamzor recall = kam confidence)' },
  { id: 'act', role: 'motor cortex — AIR LOOP (asli files) ya offline trace' },
  { id: 'verify', role: 'self-check — read-back / done-defs; jhootha "done" nahi' },
  { id: 'learn', role: 'one-way — Hebbian weights, lesson distill, disk par persist' }
];
const STOP = new Set(['the','and','for','you','your','with','from','that','this','what','when','where','which','who','why','how','can','could','should','would','have','has','hai','hain','hoti','hota','ka','ki','ke','kya','kaise','kyun','kyon','kaun','kab','kitna','kitni','kitne','mein','main','aur','par','tak','bhi','nahi','nahi','ek','kar','karo','karta','karti','karte','karen','bana','banao','banao','chahiye','mujhe','mujh','tum','tumhara','tumhari','hum','ham','sab','sab kuch','kuch','bohat','bhoot','dshaan','wala','wali','wale','jaise','jaisa','agar','magar','lekin','phir','pehle','baad','now','then','please','tell','give','show','dikhao','batao','bata','samjhao','liye','wala','here','there']);

function toks(text) {
  return String(text || '').toLowerCase().replace(/[^a-z0-9_]+/g, ' ').trim().split(/\s+/)
    .filter((w) => w.length > 2 && !STOP.has(w));
}
function key(a, b) { return a < b ? `${a}|${b}` : `${b}|${a}`; }

function create(opts) {
  const o = opts || {};
  const getWs = typeof o.getWs === 'function' ? o.getWs : () => (o.ws || null);
  const nodes = {};           // id → { w, cat, hits }
  const edges = {};           // 'a|b' → weight
  let learned = 0;            // is session mein kitni baar LEARN chala
  let persisted = false;      // last save/load kamyab?
  let seeded = false;

  function addNode(id, cat, w) {
    if (!nodes[id]) nodes[id] = { w: w || 1, cat: cat || 'concept', hits: 0 };
    else if (w) nodes[id].w = Math.max(nodes[id].w, w);
    return nodes[id];
  }
  function addEdge(a, b, w) {
    if (a === b) return;
    const k = key(a, b);
    edges[k] = (edges[k] || 0) + (w || 1);
  }
  function edgeWeight(a, b) { return edges[key(a, b)] || 0; }

  /* ---------- SEED: jo info pehle se hai, wo brain ki TARTEEB banati hai ---------- */
  function seed(extra) {
    if (seeded) return stats();
    seeded = true;
    // region chain — pipeline khud graph ka hissa hai
    for (const r of REGIONS) addNode(`region:${r.id}`, 'region', 2);
    for (let i = 1; i < REGIONS.length; i += 1) addEdge(`region:${REGIONS[i - 1].id}`, `region:${REGIONS[i].id}`, 1.5);
    // Detail Codex — har category ek hub, har entry us hub se wired
    try {
      const codex = require('./gamekit/detailcodex.cjs');
      for (const cat of codex.categories()) {
        addNode(`cat:${cat}`, 'category', 2);
        for (const e of (codex.category(cat) || [])) {
          addNode(e.id, 'entry', e.impl === 'done' ? 1.25 : 0.75);
          addEdge(`cat:${cat}`, e.id, 1);
          for (const w of toks(e.name).slice(0, 4)) { addNode(`w:${w}`, 'word', 0.5); addEdge(e.id, `w:${w}`, 0.5); }
        }
      }
    } catch {}
    // KB topic titles (builtin se aate hain)
    for (const t of ((extra && extra.kbTitles) || [])) {
      const id = `topic:${String(t).toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 48)}`;
      addNode(id, 'topic', 1.5);
      for (const w of toks(t).slice(0, 6)) { addNode(`w:${w}`, 'word', 0.5); addEdge(id, `w:${w}`, 0.75); }
    }
    // intent hubs — situation engine ke intents graph ke hub bante hain
    for (const it of ['build', 'fix', 'research', 'game', 'question', 'store', 'plan']) { addNode(`intent:${it}`, 'intent', 1.5); addEdge(`intent:${it}`, 'region:perceive', 1); }
    return stats();
  }

  /* ---------- PERCEIVE ---------- */
  function perceive(text) {
    const t = String(text || '');
    const words = toks(t);
    let intent = 'question';
    try { intent = situation.detectIntent(t) || 'question'; } catch {}
    return { text: t.slice(0, 240), tokens: words, intent, isQ: /\?/.test(t) || /^(what|why|how|kya|kaise|kitn)/.test(words[0] || '') };
  }

  /* ---------- RECALL — spreading activation (2 hops) ---------- */
  function recall(text, k) {
    const words = toks(text);
    const act = {};
    const bump = (id, v) => { act[id] = (act[id] || 0) + v; };
    // seed: word nodes + ids jo token se match karte hain
    for (const w of words) {
      if (nodes[`w:${w}`]) bump(`w:${w}`, 1);
      for (const id of Object.keys(nodes)) {
        if (id.includes(w) && !id.startsWith('w:')) bump(id, 0.6);
      }
    }
    // hop 1 + hop 2 (edge weight ke hisaab se activation phailti hai)
    for (let hop = 0; hop < 2; hop += 1) {
      const cur = { ...act };
      for (const ek of Object.keys(edges)) {
        const [a, b] = ek.split('|');
        const w = edges[ek];
        if (cur[a]) bump(b, cur[a] * w * 0.35);
        if (cur[b]) bump(a, cur[b] * w * 0.35);
      }
    }
    return Object.keys(act)
      .filter((id) => !id.startsWith('w:'))
      .map((id) => ({ id, act: act[id] * (nodes[id] ? nodes[id].w : 1) }))
      .sort((x, y) => y.act - x.act)
      .slice(0, k || 6);
  }

  /* ---------- PLAN — har step ki done-definition ---------- */
  function plan(goal) {
    let a = null;
    try { a = situation.assess(String(goal || ''), { files: [] }); } catch {}
    const tasks = (a && a.tasks && a.tasks.length ? a.tasks : ['goal ko chhote steps mein todo', 'minimal version banao', 'chala kar verify karo']);
    const steps = tasks.slice(0, 8).map((t, i) => ({
      n: i + 1,
      what: t,
      done: `step ${i + 1} ka done: "${String(t).slice(0, 60)}" complete AUR verify (read-back/test) — warna honest fail`,
      risk: (a && a.risks && a.risks[i]) || null
    }));
    return { intent: (a && a.intent) || 'plan', steps, observe: (a && a.observe) || null };
  }

  /* ---------- LEARN — Hebbian: fire together, wire together ---------- */
  function learn(text, intentOverride) {
    seed();
    const p = perceive(text);
    const hub = `intent:${intentOverride || p.intent}`;
    addNode(hub, 'intent', 1.5);
    learned += 1;
    const fired = [];
    for (const w of p.tokens.slice(0, 8)) {
      addNode(`w:${w}`, 'word', 0.5);
      addEdge(`w:${w}`, hub, 0.25);            // sawal ke words intent se wire
      nodes[`w:${w}`].hits += 1;
      fired.push(`w:${w}`);
    }
    const rec = recall(text, 4);
    for (const r of rec) {                       // recalled concepts bhi wire — association mazboot
      addEdge(r.id, hub, 0.15);
      if (nodes[r.id]) nodes[r.id].hits += 1;
      for (const f of fired) addEdge(f, r.id, 0.1);
    }
    if (nodes[hub]) nodes[hub].hits += 1;
    return { intent: hub, tokens: p.tokens.length, wired: rec.length, learned };
  }

  /* ---------- decay + prune — honest forgetting ---------- */
  function prune(minW) {
    const min = minW || 0.12;
    let cut = 0;
    for (const k of Object.keys(edges)) { if (edges[k] < min) { delete edges[k]; cut += 1; } }
    return cut;
  }

  /* ---------- persist (one-way: sirf .dev-studio/air/) ---------- */
  function save() {
    const ws = getWs();
    if (!ws || typeof ws.write !== 'function') { persisted = false; return false; }
    try {
      ws.write(GRAPH_REL, JSON.stringify({ v: 1, updated: new Date().toISOString(), learned, nodes, edges }, null, 0));
      persisted = true;
      return true;
    } catch { persisted = false; return false; }
  }
  function load() {
    const ws = getWs();
    if (!ws || typeof ws.read !== 'function') return false;
    try {
      const raw = ws.read(GRAPH_REL);
      if (!raw) return false;
      const g = JSON.parse(raw);
      if (!g || typeof g !== 'object' || !g.nodes) return false;
      for (const id of Object.keys(g.nodes)) nodes[id] = g.nodes[id];
      for (const k of Object.keys(g.edges || {})) edges[k] = g.edges[k];
      learned = g.learned || 0;
      seeded = true;
      persisted = true;
      return true;
    } catch { return false; }
  }

  /* ---------- COGNIZE — poori pipeline, ek call ---------- */
  function cognize(goal, copts) {
    const c = copts || {};
    const trace = [];
    const T = (region, ok, obs) => trace.push({ region, ok, obs: String(obs).slice(0, 220) });
    if (!String(goal || '').trim()) return { ok: false, trace, honest: 'goal khaali hai — "brain socho: <goal>" likho.' };

    // 1 PERCEIVE
    const p = perceive(goal);
    T('perceive', true, `${p.tokens.length} tokens, intent ${p.intent}`);

    // 2 RECALL
    const rec = recall(goal, 5);
    const strength = rec.length ? Math.min(1, rec[0].act / 3) : 0;
    T('recall', rec.length > 0, rec.length ? `graph se ${rec.length} concepts activate: ${rec.slice(0, 3).map((r) => r.id).join(', ')}` : 'graph mein is goal ka koi strong connection NAHI — confidence kam, honest');

    // 3 PLAN
    const pl = plan(goal);
    T('plan', true, `${pl.steps.length} steps, har step ki done-definition`);

    // 4 REASON — confidence recall strength + lessons se
    const conf = Math.round((0.25 + strength * 0.6) * 100) / 100;
    T('reason', true, `confidence ${conf.toFixed(2)} — ${strength > 0.5 ? 'strong recall' : strength > 0.2 ? 'partial recall' : 'weak recall (jhootha bharosa nahi)'}`);

    // 5 ACT — motor cortex: ws mile to AIR LOOP, warna offline trace (honest)
    let act = null;
    const ws = c.ws || getWs();
    if (ws && typeof ws.read === 'function') {
      try {
        const airloop = require('./airloop.cjs');
        act = airloop.runAirLoop({ goal, ws });
        T('act', !!act.ok, `AIR LOOP chala: ${act.steps.length} steps, artifact ${act.artifact || 'nahi bana'}`);
      } catch (e) { act = null; T('act', false, `AIR LOOP error: ${e.message}`); }
    } else {
      T('act', true, 'offline trace-only mode (koi workspace nahi) — ACT ki jagah reasoning chali, ye honest hai');
    }

    // 6 VERIFY
    let verified = false;
    if (act) { verified = !!act.verified; T('verify', verified, verified ? 'artifact read-back exact match — done-defs addressed' : 'verify FAIL — jhootha done nahi bolunga'); }
    else verified = pl.steps.length >= 3; // offline: verify = plan complete + confidence honest
    if (!act) T('verify', verified, verified ? 'offline verify: plan complete, trace consistent' : 'offline verify fail');

    // 7 LEARN — one-way
    const L = learn(goal);
    T('learn', true, `Hebbian wiring: ${L.tokens} words → ${L.intent}, ${L.wired} concepts reinforced`);
    const saved = save();

    return { ok: verified, trace, perception: p, recall: rec, plan: pl, confidence: conf, act, verified, learned: L, saved };
  }

  /* ---------- STATS + strongest pathways ---------- */
  function stats() {
    const ek = Object.keys(edges).map((k) => ({ k, w: edges[k] })).sort((a, b) => b.w - a.w);
    return {
      nodes: Object.keys(nodes).length,
      edges: ek.length,
      learned,
      persisted,
      strongest: ek.slice(0, 3).map((e) => ({ path: e.k.split('|').join(' ↔ '), w: Math.round(e.w * 100) / 100 }))
    };
  }

  return { seed, perceive, recall, plan, cognize, learn, prune, save, load, stats, edgeWeight, regions: REGIONS, GRAPH_REL };
}

module.exports = { create, REGIONS, GRAPH_REL, toks };
