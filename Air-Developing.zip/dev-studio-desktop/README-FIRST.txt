=========================================================
 AIR DEVELOPING 1.19.0  —  SPLIT AIR MIND + VISION + KEYS
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.19.0:
  * AIR MIND 2.0 — SPLIT "VIBE-CODING" PAGE:
    LEFT  = Air_you chat (bubbles jaisi lines, session
            memory, connectors strip upar — har connector
            ka ready-dot; click karo to Settings usi
            connector par khulti hai).
    RIGHT = ASAL OS TERMINAL (apna input, live output) —
            "code yahan banta aur chalta hai".
    Upar wahi traffic-light dots 🔴🟡🟢 (red=back,
    yellow=theme, green=Air_you live). Chat se "!cmd"
    bhi right terminal mein hi chalta hai. Sirf Air_you —
    connected AIs is page par kaam NAHI karte.

  * IMAGE UPLOAD 📎 (jaise bari chat apps mein hota hai):
    Studio chat AUR AirMind dono mein attach button —
    max 3 images, 5 MB each. Vision wiring har provider
    ke OFFICIAL wire format mein:
    - ChatGPT/Groq/Perplexity → image_url content array
    - Claude → base64 image blocks
    - Gemini → inline_data parts
    - Air_you (offline) → HONEST jawab: "main dekh nahi
      sakta" + metadata + sahi provider ka rasta. Jhooth
      kahin nahi.

  * API KEY SYSTEM — AB PASTE KABHI FAIL NAHI HOGA:
    - Quotes, spaces, newlines — paste ki gandagi khud
      clean hoti hai (normalizeKey, backend mein ek jagah).
    - Key ka prefix pehchanta hai: sk-ant- → Claude,
      gsk_ → Groq, pplx- → Perplexity, AIza… → Gemini,
      sk- → ChatGPT. Galat connector mein paste kiya to
      WARNING + ek click mein "Move key → sahi connector".
    - "Save & Test" — save hote hi connection test khud
      chal jata hai, result saamne.
    - Key sirf isi PC par (dev-studio.env, mode 0600),
      renderer ko kabhi nahi dikhti, audit log mein entry.

  * AIR_you + INTERNET (WiFi): AirMind chat mein
    "search <sawal>" (ya "dhundo") — live web search
    (DuckDuckGo + Wikipedia deep research), links aur
    snippets ke saath. Deep mode/Autopilot pehle se live
    web use karte hain; ab Air_you ke apne page par bhi.

  * BACKEND CLEAN + PRECISE (vibe-coding nahi):
    har feature ka EK module (shared/providers.cjs =
    connectors+keys+vision, shared/builtin.cjs = Air_you,
    shared/websearch.cjs = internet, electron/ipc.cjs =
    saare handlers ek registry mein, permission-gated +
    audited). Renderer sirf preload bridge se baat karta
    hai — koi direct node access nahi. Naya logic pehle
    test hota hai: 111 logic + 16 UI tests green.

  * SAB PURANA SYSTEM LIVE (1.0 → 1.18 tak ka har
    upgrade is zip mein hai): Windows exe + landing,
    Team mode (AIs cooperate, ek editable result), VS
    Code-style panels, plugins, PIN/audit security,
    Chrome bridge (read-only + guest tokens), Air Vault,
    platform targets, Game Studio + 12 arcade games,
    GameKit3D + MONO CITY 3D + franchise games, RE
    detail pack, Autopilot, Deep mode (research→plan→
    execute→verify→check), Studio Agent v3 + ReAct,
    experience self-learning (one-way), GB-class local
    AI download (Ollama), FX Forge (1 arab+ shaders),
    real water (doobna/river/slosh), GTA-6 real detail
    pack (web-researched), Air_you powers (think/
    imagine/read/self-generate + recall), no-intro rule,
    friendly provider errors, done-tick, narration.

  * TESTS: 111 logic + 16 UI green (naye: key normalize
    + auto-detect, per-provider vision formats, honest
    builtin image reply, AirMind connectors strip +
    search command + terminal pane + 📎 button).

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
