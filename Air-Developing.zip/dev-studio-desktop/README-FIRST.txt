=========================================================
 AIR DEVELOPING 1.22.0  —  POWER TO EXISTING
 Air_you AGENT LOOP  +  DETAIL CODEX 2.0
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.22.0 (jo aapne manga: "Air_you bilkul agent ki
tarah kaam kare, Detail Codex engine ultra-level upgrade —
sirf MAJOODA features ko power aur tech do." Koi naya
feature surface nahi — har purani power andar se strong):

  * 🤖 AIR LOOP — Air_you ka apna agent loop:
      airloop <goal>
    Jaise bare coding agents kaam karte hain:
      OBSERVE  workspace ki asli files dekhta hai
      FOCUS    goal se relevant files chunta hai
      READ     unka REAL content padhta hai
      PLAN     situation engine se tasks banata hai
      WRITE    artifact likhta hai (.dev-studio/air/)
      VERIFY   read-back exact match — jhootha "done"
               KABHI nahi
      REFINE   lesson journal mein save — agli situation
               aur THINK usi se seekhte hain (compound
               learning)
    100% apna, offline — koi connected AI shamil nahi.

  * 📚 DETAIL CODEX 2.0 — "100,000 details" ka ghar bara:
      codex mein likho: <detail>
    Aapki detail PERMANENT store hoti hai (cap 200),
    category KHUD guess hoti hai (car/home/traffic/
    airport/beach/gym/city), aur har count jawab mein
    shipped + planned + aapki entries sab ginti hai.
    Ranked search: best match sabse upar.
    LIVE AUDIT: running game object do — codex batata
    hai kaunse systems ASLI mein zinda hain (car anatomy
    7 parts, fridge, traffic, plane pilot, heli rotors,
    gym, beach, weather, crowds) — kagazi dawe nahi.

  * ⚡ MAJOODA POWERS KO TECH:
    - THINK ab ASLI workspace observation karta hai
      (matching files + line counts, synthetic nahi)
    - GREP (naya): grep <file> <word> — line-numbered
      search, honest miss
    - SELFGEN recall BEST-scored — purani magar behtar
      yaad, nayi kamzor yaad par jeetti hai
    - bank dikhao — Knowledge Bank ke live stats
    - store diff v1 v2 — snapshots ka farq
      (CHANGE/ADD/REMOVE)
    - KB answers ab LAZY — counts har jawab par fresh

  * 1.21.0 (pichhli manzil, LIVE): DETAIL PACK 2 — car
    anatomy (doors/trunk/hood/mirrors/fuel cap/engine),
    REAL fridge (pre-placed items, haath mein slosh,
    gravity drop), traffic + bridge lanes, airport plane
    takeoff + pilot, heli rotors, gym workouts, beach.
    Controls: G interact · T take · H drop · V drink ·
    B engine.

  * SAB PURANA SYSTEM LIVE (1.0 → 1.21 tak har upgrade
    isi zip mein): Detail Pack 2 + Detail Codex, Air_you
    3.0 situation engine, Knowledge Bank, 💎 App Update +
    STORE DESK (snapshot/history/rollback/diff), AirMind
    2.0 split page, connectors strip, 📎 image upload +
    vision, paste-proof API keys, powers (think/imagine/
    read/self-generate), GTA-6 pack, FX Forge (1 arab+),
    real water, Ollama GB-class AI, Team mode, Autopilot/
    Deep, plugins, PIN security, Chrome bridge, Air
    Vault, Game Studio + 12 arcade games, GameKit3D,
    done-tick, narration, Windows exe pipeline.

  * TESTS: 120 logic + 20 UI green (3 stable runs) —
    naye asserts: agent loop steps + verify + journal,
    honest no-workspace fail, grep found/miss, THINK real
    observation, best-scored recall, codex user entries +
    cap + rank + live audit, KB live counts, bank stats,
    store diff.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
