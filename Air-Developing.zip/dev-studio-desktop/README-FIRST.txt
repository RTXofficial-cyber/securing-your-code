=========================================================
 AIR DEVELOPING 1.21.0  —  DETAIL PACK 2 + DETAIL CODEX
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.21.0 (jo aapne manga — cars, fridge, traffic,
airport, gym, beach — sab ASLI systems, sirf decoration
nahi; 100 days ka kaam shuru, ye uski dusri manzil):

  * CAR ANATOMY — sab kuch khulta hai:
    - 4 DOORS hinge par swing (animation, teleport nahi)
    - TRUNK (diggi) upar uthti hai
    - HOOD khulo to ENGINE BAY dikhta hai — live rpm +
      temperature ke saath (B = engine start/stop)
    - PETROL CAP khula + gaari ruki = REFUEL (100% par
      auto-stop; cap band = honest "nahi bharegi")
    - SIDE MIRRORS front doors par — darwaza khula to
      mirror fold
    - Chalti gaari par parts honest refuse: "pehle rok"
    - Drive HUD: FUEL% · ENGINE rpm/temp

  * FRIDGE WALI GTA DETAIL — asli tareeqe se:
    bottle/cup/sabzi fridge ke ANDAR PEHLE SE hote hain
    (spawn NAHI). G = kholo (door swing), T = nikalo →
    HAATH mein aata hai, fridge se jata hai. Bottle ka
    paani slosh karta hai (spring-damper). H = drop →
    GRAVITY se girta hai, thud, zameen par TIKTA hai,
    wapas uthao (G). V = piyo → level girta, khaali =
    honest "khaali".

  * ROAD TRAFFIC: 6 cars corridors par — 2 lanes river
    ke BRIDGES se cross; player qareeb → YIELD + brake
    glow.

  * AIRPORT: bay ke us paar runway + PLANE jo ASLI
    takeoff karti hai — parked → roll (throttle +
    spinning prop) → rotate → climb → cruise circle.
    COCKPIT mein PILOT dikhta hai.

  * HELICOPTER: sheher ke upar hover circle — main +
    tail rotor spin, pilot aboard.

  * GYM: khula building (treadmill + weights) — peds
    andar aate hi WORKOUT (reps bob), bahar = walk,
    gunfire = bhaago (override).

  * BEACH: umbrellas, towels, LETE hue sunbathers,
    bouncing beach ball (geela sand + footprints pehle
    se live).

  * DETAIL CODEX — aapke "100,000 details" ka SYSTEM:
    chat bharne ki zaroorat nahi. 7 categories, 41
    entries catalogued — 32 abhi engine mein ASLI
    simulated (done), 9 planned. Air_you isi se jawab
    deta hai: poocho "car ki kya details hain?" /
    "fridge wali detail?" / "kitni details hain?".
    Har agla turn aur entries 'done' mein flip karega —
    100-day roadmap isi codex se track hoga.

  * CONTROLS (fps/swing/drive sab worlds):
    G — fridge/car interact (+ gira item uthao)
    T — fridge se item nikalo · H — drop · V — drink
    B — engine start/stop

  * SAB PURANA SYSTEM LIVE (1.0 → 1.20 tak har upgrade
    isi zip mein): Air_you 3.0 situation engine,
    Knowledge Bank (search reuse), 💎 App Update +
    STORE DESK (snapshot/history/rollback), AirMind 2.0
    split page, connectors strip, 📎 image upload +
    vision, paste-proof API keys, powers (think/imagine/
    read/self-generate), GTA-6 pack, FX Forge (1 arab+),
    real water, Ollama GB-class AI, Team mode, Autopilot/
    Deep, plugins, PIN security, Chrome bridge, Air
    Vault, Game Studio + 12 arcade games, GameKit3D,
    done-tick, narration, Windows exe pipeline.

  * TESTS: 117 logic + 20 UI green (3 stable runs) —
    naye 30+ asserts: hinge animation, mirror fold,
    pre-placed fridge items, slosh handoff, gravity drop
    + re-pickup, honest refusals, plane takeoff, gym
    state machine, codex counts + KB answers.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
