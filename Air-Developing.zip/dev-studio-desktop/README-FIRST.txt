=========================================================
 AIR DEVELOPING 1.20.0  —  AIR_you 3.0 + 💎 DIAMOND UPDATE
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.20.0 (jo aapne maanga, wahi):
  * SITUATION HANDLING (Air_you 3.0):
    "situation <goal>" ya "halat <goal>" — Air_you pehle
    poori situation samajhta hai, phir kaam karta hai:
      👁 OBSERVE  — workspace ki ASLI files jo goal se
                    milti hain (jhoothi list nahi)
      📋 TASKS    — kaam ke tukde, har task ka "done"
                    define
      ⚠️ RISKS    — kya toot sakta hai
      🎯 PLAN     — OBSERVE → TASKS → ACT → VERIFY →
                    REFINE
      ⚡ REFINE   — har task ke baad check; galti se
                    seekha lesson journal mein save
    Purane MILTE-JULTE lessons khud plan mein aate hain —
    matlab time ke saath TEZ aur BEHTAR (one-way learning,
    sirf aapke PC par).

  * PROPER WEB SEARCH + DATA COLLECTION (KNOWLEDGE BANK):
    har live search ka data (title/link/snippet/summary +
    time) .dev-studio/kbank.json mein SAVE hota hai (cap
    60). Milta-julta sawal 3 din ke andar dobara poocha to
    jawab BANK se — dobara search nahi = FAST, time to
    time faster. AirMind honestly batata hai: "BANK se
    jawab (kitna % match, kitne ghante purana)". Naya hi
    chahiye to: "search fresh <sawal>".

  * 💎 DIAMOND — APP KHUD APNI UPDATE CHECK KARTI HAI:
    Settings → "💎 App Update" → Check for update:
    live release feed se version compare, update mili to
    download link + notes + honest Windows install plan.
    Sach: chalta hua .exe khud ko safely replace nahi kar
    sakta — final extract step aapka, baaki sab app ka.
    Feed down ho to jhootha "up to date" NAHI — saaf error.

  * 💎 STORE DESK — aapki store, time to time changes,
    kabhi kuch khota nahi:
      "store ka snapshot lo"  → versioned backup (v1, v2…)
      "store history"         → snapshots + change journal
      "rollback v1"           → ek command mein purani
                                state wapas
    Snapshots workspace mein (.dev-studio/store/) — aapki
    dukaan ka har badlav versioned + journal ke saath.

  * FINE HANDLING / PRECISION: headless game tests ab
    SEEDED random par chalte hain — har run identical
    world, koi flake nahi. Ped-flee test isolate kiya.
    Nateeja: 115 logic + 20 UI tests, teen runs stable.

  * SAB PURANA SYSTEM LIVE (1.0 → 1.19 tak ka har upgrade
    isi zip mein hai): AirMind 2.0 split page (chat +
    terminal, connectors strip, 🔴🟡🟢), 📎 image upload +
    asli vision (ChatGPT/Claude/Gemini/Groq) + honest
    Air_you, paste-proof API keys (auto-clean + prefix
    detect + Move + Save & Test), Air_you powers (think/
    imagine/read/self-generate), game DNA feed, no-intro
    rule, GTA-6 detail pack, FX Forge (1 arab+), real
    water (doobna/slosh), Ollama GB-class AI, Team mode,
    Autopilot/Deep, plugins, PIN/audit security, Chrome
    bridge, Air Vault, Game Studio + 12 arcade games,
    GameKit3D, done-tick, narration, Windows exe pipeline.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
