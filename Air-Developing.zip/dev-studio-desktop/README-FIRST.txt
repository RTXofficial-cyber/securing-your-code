=========================================================
 AIR DEVELOPING 1.24.0  —  ORGANIZED GYM (GTA-6 rule)
 exercise SIRF apni MACHINE par — kahin bhi nahi
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.24.0 (jo aapne kaha: "gym mein ja kar SPECIFIC
MACHINE se gym karunga, har jagah nahi — GTA 6 full
organize karo"):

  * 🏋️ GYM ke andar 6 ASLI MACHINES (apni shape + apni
    busy animation):
    - BENCH PRESS — barbell press cycle (chest/triceps/
      delts)
    - SQUAT RACK — bar squat DEPTH tak utarta hai (quads/
      glutes/hamstrings)
    - PULL-UP BAR — ooncha frame + crossbar (lats/biceps/
      forearms)
    - TREADMILL — chalta belt + console; NAYA cardio
      exercise: TREADMILL RUN (calves/quads/hamstrings)
    - DEADLIFT PLATFORM — bar zameen se uthta hai
      (hamstrings/glutes/lats/forearms)
    - PLANK MAT — core hold (wobble ke saath)

  * 📏 ORGANIZED RULE: X (ya G) SIRF machine ke paas kaam
    karta hai. Door se dabaya to honest jawab: "MACHINE ke
    paas jao — exercise kahin bhi nahi hoti." Har machine
    ka apna exercise, apne muscles — bench par squats
    NAHI hote (asli gym, honest anatomy).

  * 🧍 MACHINE CLAIM: ek machine = ek user. Koi ped use
    kar raha ho to: "OCCUPIED — wait karo ya dusri pakdo"
    (asli gym ka rule). Peds ab machines CLAIM karke
    workout karte hain — machine unke saath animate hoti
    hai. Gunshot → ped flee → machine TURANT free.

  * 🚶 MACHINE CHHOD DI = set ADHOORA: beech mein chale
    gaye to honest stop, machine free, jitne reps hue
    utna hi XP (jhootha credit nahi).

  * ⚡ Baaki BODY system waisa hi zinda: 11 muscles
    (stretch + fatigue), eccentric STRETCH → concentric
    RELAX (HUD bars), thakan rep speed kam karti hai,
    93% = MUSCLE FAILURE honest stop + soreness, STRENGTH
    ISTA ISTA NEXT LEVEL (XP → level → +1.5), ambient
    loads: chalna/daudna/tairna/wazan uthana/recoil/
    steering — ye bina machine ke bhi (body hamesha sath).

  * 📚 DETAIL CODEX bara: gym category 4 → 7 entries
    (machines, claim, walk-off) → 64 total · 55 done ·
    9 categories.

  * SAB PURANA SYSTEM LIVE (1.0 → 1.23 tak har upgrade
    isi zip mein): BODY & CITY LIFE PACK (named shops +
    gun shops, motorway + buses, ships, shipyard, mine,
    landmarks, NPC AI), AIR LOOP (agent loop), CODEX 2.0,
    THINK real observation, GREP, bank dikhao, store
    diff, Detail Pack 2 (car anatomy, REAL fridge,
    traffic, airport, heli, beach), situation engine,
    Knowledge Bank, 💎 App Update + STORE DESK, AirMind
    2.0, connectors, 📎 vision, paste-proof API keys,
    powers, GTA-6 pack, FX Forge (1 arab+), real water,
    Ollama GB-class AI, Team mode, Autopilot/Deep,
    plugins, PIN security, Chrome bridge, Air Vault,
    Game Studio + 12 arcade games, GameKit3D, done-tick,
    narration, Windows exe pipeline.

  * TESTS: 122 logic + 20 UI green (3 stable runs) +
    organized-gym smoke (11/11): machine placement,
    honest refuse door se, bench claim + reps + barbell
    animation, occupied wait, treadmill cardio, walk-off
    adhoora set, progressive strength, muscle failure +
    release, ambient carry, ped claim + flee release,
    KeyX fuzz-safe.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
