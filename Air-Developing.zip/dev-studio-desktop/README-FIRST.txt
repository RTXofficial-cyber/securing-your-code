=========================================================
 AIR DEVELOPING 1.25.0  —  WORLD ORGANIZE PACK
 poori duniya ki exercises + hospital + har shop
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.25.0 (jo aapne kaha: "poori duniya ma jitni bi
exercises ha sab ku organize karo animation ju bi ha gym
ka lihaza sa sab add kro", "gospitals ma ju kuch staff
stratuers medicens all iver", "har shop ki thing dalo
real life sa jitni bi shop milti ha un ku organize karo
feed karo", aur GitHub par AIR DEVELOPING dikhna chahiye):

  * 🏋️ IRON BODY GYM ab 26 STATIONS (6 se 26) — har
    station apni machine shape + apni busy animation +
    apne ASLI prime movers ke saath:
    - Chest row: BENCH PRESS (barbell cycle), INCLINE
      BENCH (slanted board), CHEST FLY (pads swing),
      SHOULDER PRESS (dumbbells upar-dhake), CURL STATION
      (biceps), CABLE PUSHDOWN (triceps, cable + stack)
    - Back row: PULL-UP BAR, LAT PULLDOWN (bar + weight
      stack neeche khinchta hai), SEATED CABLE ROW (seat
      slide), SHRUG STAND (traps)
    - Cardio row: TREADMILL (chalta belt), STATIONARY
      CYCLE (pedal wheel ghoomti), ROWING ERG (seat aage-
      peeche slide + handle pull)
    - Leg row: SQUAT RACK (bar depth tak utarta hai),
      LEG PRESS (sled incline), LEG EXTENSION (shin pad
      kick), LEG CURL (hamstring curl), CALF RAISE
      (pedestal), DEADLIFT PLATFORM (bar zameen se uthti)
    - FUNCTIONAL TURF (open-air floor box, roof ke
      bagal): PLANK MAT (wobble), AB CRUNCH MAT,
      KETTLEBELL RACK (swing arc), LUNGE FLOOR, BURPEE
      FLOOR, STRETCH CORNER — 13th muscle: FOREARMS +
      naye TRAPS/OBLIQUES = 13 MUSCLES total.
    - ORGANIZED RULE waisa hi: X/G SIRF station par;
      door se = honest refuse; occupied = wait; walk-off
      = adhoora set. Peds claim + flee-release live.

  * 🏥 VICE GENERAL HOSPITAL (naya named building):
    - Bada H-cross roof ke upar, ward BEDS (patient lete
      hue), MEDICINE SHELF (3 rows × 4 dawaiyan), aur
      PHARMACY COUNTER — "G: dawa $25 (heal 40)".
    - STRETCHERS ×2: roll FSM — entrance se ward tak
      wheels ke saath chalti hain, 5s wait, wapas.
    - STAFF AI: 1 DOCTOR + 2 NURSES (role labels ke
      saath, duty points par attend; gunfire = flee).
      Visitors pharmacy counter par QUEUE karte hain.
    - Dawa honest: hp full = paisa nahi katta; broke =
      honest jawab.

  * 🏪 19 NAMED SHOPS — real life ki har dukaan apne
    stock board + apne rate ke saath (HUD par stock):
    GUN SHOPS ×2 ($40 ammo) · KWIK-24 MART ($10 bottle)
    · ROSE BAKERY ($12 heal 15) · FADE CITY BARBER ($15
    naya look) · BAYSIDE CAFE ($8 heal 10) · SLICE HAVEN
    PIZZA ($20 heal 25) · PAGE & PROTEIN BOOKS ($20
    TRAINING MANUAL = +25 BODY XP — level ab rest mein
    bhi chadhta hai) · TORQUE & CO MECHANIC ($30 refuel)
    · FULL TANK PETROL PUMP ($25) · VOLTAIC ELECTRONICS
    ($60) · VELVET VAULT JEWELS ($120 gold chain) ·
    PETAL STREET FLORIST ($8) · BOARDWALK OUTFITTERS
    ($15) · INK ANCHOR TATTOO ($35) · SUDS CITY
    LAUNDROMAT ($6) · RINGTONE MOBILE ($45) · IRONHAND
    HARDWARE ($30 toolbox) · VICE PHARMACY ($25 heal 40)
    — har shop ka stock board alag, rate alag, aur Air_you
    ko FEED.

  * 📚 DETAIL CODEX FEED: +34 entries (exercises 26,
    hospital 8, shops update) → 98 total · 88 done ·
    11 categories. guessCategory hospital/exercises.
    KB answers live: "hospital mein kya hai?" /
    "kitni exercises hain?" → poora organized jawab.

  * 🐙 GitHub par AIR DEVELOPING: sandbox token ko repo
    rename/edit permission nahi (403 — honest), is liye
    aap khud 30 second mein kar sakte ho: github.com →
    repo → ⚙ Settings (ya repo ke naam ke bagal pencil) →
    "Repository name" = air-developing → Rename. GitHub
    purane links REDIRECT karta hai (raw download link
    zinda rahega).

  * SAB PURANA SYSTEM LIVE (1.0 → 1.24 tak har upgrade
    isi zip mein): ORGANIZED GYM, BODY & CITY LIFE PACK,
    AIR LOOP, CODEX 2.0, THINK, GREP, bank dikhao, store
    diff, Detail Pack 2 (car anatomy, REAL fridge,
    traffic, airport, heli, beach), situation engine,
    Knowledge Bank, 💎 App Update + STORE DESK, AirMind
    2.0, connectors, 📎 vision, paste-proof API keys,
    powers, GTA-6 pack, FX Forge (1 arab+), real water,
    Ollama GB-class AI, Team mode, Autopilot/Deep,
    plugins, PIN security, Chrome bridge, Air Vault,
    Game Studio + 12 arcade games, GameKit3D, done-tick,
    narration, Windows exe pipeline.

  * TESTS: 123 logic + 20 UI green (3 stable runs) —
    World organize smoke: 26 stations gym zone ke andar,
    honest muscles per machine (leg press = quads, lat
    pulldown = lats, kettlebell = glutes), stretcher FSM,
    staff + pharmacy heal/broke/full honest, books XP +
    level rest mein, gas pump refuel, barber outfit,
    19 shops stock, codex categories, KB answers.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
