=========================================================
 AIR DEVELOPING 1.23.0  —  BODY & CITY LIFE PACK
 real muscle anatomy + named shops + buses + ships +
 shipyard + mine + NPC AI
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.23.0 (jo aapne manga — sab ASLI systems):

  * 🏋️ REAL BODY ANATOMY — X = exercise (har world mein):
    - 11 MUSCLES (chest, lats, delts, biceps, triceps,
      forearms, core, quads, hamstrings, glutes, calves) —
      har ek ka apna STRETCH + FATIGUE state
    - 6 EXERCISES ke ASLI prime movers: PUSH-UPS =
      chest/triceps/delts · SQUATS = quads/glutes/
      hamstrings · PULL-UPS = lats/biceps/forearms ·
      LUNGES · PLANK · DEADLIFTS
    - Rep cycle: neeche jate waqt STRETCH barhti hai,
      upar ate waqt RELAX — HUD par live bars dikhte hain
    - THAKAN asli hai: fatigue rep speed kam karti hai;
      93% par MUSCLE FAILURE — exercise honest RUK jati
      hai, soreness chadhti hai (jhoothi taqat nahi)
    - RECOVERY: aaram mein tez, kaam mein dheemi
    - STRENGTH ISTA ISTA NEXT LEVEL: har rep/set XP deta
      hai, level par strength +1.5 — progressive overload,
      ek jhatke mein Superman nahi
    - KOI BI KAAM karte waqt body respond karti hai:
      chalna/daudna = calves/quads · tairna = delts/lats ·
      wazan uthana = forearms/biceps · goli ka recoil =
      delts/triceps · steering = forearms

  * 🏙️ NAMED SHOPS — har dukaan ka apna NAAM (3D label):
    - AMMU-VICE GUNS + BOOMSTICK DEPOT (GUN SHOPS):
      ammo $40 · KWIK-24 MART: bottle $10 (slosh ke
      saath) · BAYSIDE CAFE: cup $8 · TORQUE & CO
      MECHANIC: refuel $30 · BOARDWALK OUTFITTERS:
      outfit $15
    - Cash = score. Paisa kam = honest "broke". Full
      mag/full tank = paisa NAHI katta (jhoothi sale nahi)

  * 🚌 VICE MOTORWAY + BUSES: wide road, dashes, 3 bus
    stops (shelters), 2 buses — stop par halt 3.5s, DOORS
    KHULTI hain, phir band hokar chalti hain; player ko
    yield (brake)

  * 🚢 SEA/OCEAN + SHIPS + SHIPYARD:
    - River BARGES: containers ke saath chalti hain, wake
      chhodti hain — tairte hue takraye to ASLI damage
    - MV IRONKEEL: ocean ship bay ke paar (mast deewar
      ke upar se dikhta hai)
    - IRONKEEL SHIPYARD: 2 hulls rib-by-rib ASLI mein
      BANTE hain (0%→100% live), crane ghumta hai,
      cable + hook jhulta hai

  * ⛏️ BLACKVEIN MINE: descending pit terraces, andhera
    entrance (timber head), gravel piles, 2 carts RAIL
    LOOP par raat din chalti hain

  * 🏢 NAMED BUILDINGS: HARBOR TOWER · MERIDIAN PLAZA ·
    CIVIC CENTER · NORTHGATE TOWER · OLD UNION DEPOT

  * 🧠 NPC AI INTELLIGENCE: har ped ka apna DESTINATION —
    shop par QUEUE (khade hokar browse), gym mein
    WORKOUT, beach par BAITHNA, wander; do ped mile to
    ruk kar FACE-TO-FACE CHAT; goli chali to pehle jaisa
    panic flee

  * 📚 DETAIL CODEX bara: +20 entries (body 10, citylife
    10) → 61 total · 52 done · 9 categories

  * SAB PURANA SYSTEM LIVE (1.0 → 1.22 tak har upgrade
    isi zip mein): AIR LOOP (agent loop), CODEX 2.0
    (codex mein likho), THINK real observation, GREP,
    bank dikhao, store diff, Detail Pack 2 (car anatomy,
    REAL fridge, traffic, airport, heli, gym, beach),
    situation engine, Knowledge Bank, 💎 App Update +
    STORE DESK, AirMind 2.0, connectors, 📎 vision,
    paste-proof API keys, powers (think/imagine/read/
    self-generate), GTA-6 pack, FX Forge (1 arab+), real
    water, Ollama GB-class AI, Team mode, Autopilot/Deep,
    plugins, PIN security, Chrome bridge, Air Vault, Game
    Studio + 12 arcade games, GameKit3D, done-tick,
    narration, Windows exe pipeline.

  * TESTS: 122 logic + 20 UI green (3 stable runs) —
    naye asserts: 11-muscle anatomy, honest prime movers
    (quads pushup mein NAHI), relax decay, progressive
    strength, muscle failure, ambient carry, shop buys +
    broke/full honesty, bus halt FSM + doors, barge slam
    damage, hull stage growth, mine carts, NPC queue/chat/
    sit, flee intact, landmarks, KB + codex counts.

RUN IT:
  1) npm install
  2) npm run dev          (development)
     npm run build        (production dist/)
  3) Windows .exe: build-windows.bat (ya CI)

  Docs: README.md  |  Play: public/play/play.html
