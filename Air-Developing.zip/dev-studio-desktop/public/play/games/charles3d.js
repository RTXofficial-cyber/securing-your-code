const GAME_SPEC3D = {"control":"train","enemy":"stalker","weapon":"hitscan","goal":"collect","world":"rails","atmosphere":{"fogNear":26,"fogFar":210,"ambient":0.16,"rain":true},"title":"CHOO CHARLES TRAIN","seedText":"choo-choo charles style train horror game","fx":{"id":"black-water-25902","kind":"black-water","params":{"waveAmp":1.568,"waterBase":0.155,"wire":0.058,"grain":85,"vignetteBoost":0.029,"storm":false,"embers":true,"foam":0.3,"tint":"rgba(0,0,0,.10)"},"codex":["sine-superposition","specular-glint","screen-ripples","hairline-wire","embers","drown-o2","buoyancy","spring-damper-slosh"],"note":"light-swallowing dark water"}};
/**
 * COMPOSED3D — the any-3D-game runtime, built on GameKit3D.
 *
 * A GAME_SPEC3D (from spec3d.cjs parseSpec3d) decides EVERYTHING:
 *   control  : fps | swing | train | drive     (how you move)
 *   enemy    : zombie | soldier | stalker | police | none
 *   weapon   : hitscan | none                  (click/F to shoot, R reload)
 *   goal     : waves | escape | collect | deliver
 *   world    : city | mansion | rails | arena  (geometry generator)
 *   atmosphere: fog distances, ambient light, rain
 *
 * Resident Evil => dark mansion, zombies, escape. Spider-Man => bright city,
 * web-swinging, tokens. Choo-Choo Charles => rails in the dark, a monster
 * hunting your train, scraps. GTA5 => drive the city, deliveries, police.
 * COD => arena, soldier waves, hitscan. Different games, one runtime.
 */
const SPEC = (typeof GAME_SPEC3D !== 'undefined' && GAME_SPEC3D) || {
  control: 'fps', enemy: 'soldier', weapon: 'hitscan', goal: 'waves', world: 'arena',
  atmosphere: { fogNear: 170, fogFar: 900, ambient: 0.34, rain: false },
  title: 'MONO OPS 3D', seedText: ''
};

const CONTROLS_HELP = {
  fps: ['WASD — move · Shift — sprint', 'drag mouse / ←→ — look · ↑↓ — pitch', 'click or F — shoot · R — reload', 'in water: hold C — dive · release — surface & breathe', 'G — fridge/car/shops interact · T — item uthao · H — drop · V — drink · B — engine', 'X (ya G) — GYM MACHINE use karo: bench/rack/bar/treadmill ke paas jao — exercise SIRF machine par, kahin bhi nahi'],
  swing: ['WASD — run · SPACE (hold) — web-swing', 'release at the right moment to fly', 'in water: hold C — dive · carried bottles slosh as you move', 'G — fridge/car/shops interact · T — item uthao · H — drop · V — drink', 'X (ya G) — GYM MACHINE par exercise (organized gym rule)'],
  train: ['W/S — throttle / brake · A/D — switch track', 'click or F — shoot at whatever hunts you', 'X — body exercise (machine par — stretch/relax + strength)'],
  drive: ['W/S — gas / brake · A/D — steer', 'SPACE — handbrake · reach markers to deliver', 'river: the car SINKS — reverse out (S) before you drown', 'B — engine on/off · G — hood/trunk/doors/fuel-cap/shops (gaari rok kar) · cap khula + ruki = refuel', 'X — utar kar GYM MACHINE par exercise (strength ista ista next level)']
};

const g = new GameKit({
  title: String(SPEC.title || 'COMPOSED 3D').slice(0, 28).toUpperCase(),
  width: 960, height: 540, accent: '#ffffff',
  titleCard: {
    tagline: `${SPEC.control} · ${SPEC.enemy} · ${SPEC.goal} · ${SPEC.world}${SPEC.fx ? ' · ' + SPEC.fx.kind + ' FX' : ''}${SPEC.atmosphere && SPEC.atmosphere.ambient < 0.25 ? ' · DARK' : ''}`,
    controls: CONTROLS_HELP[SPEC.control] || CONTROLS_HELP.fps
  }
});

const WORLD_SIZE = { city: 1600, mansion: 960, arena: 800, rails: 4000 };
const EYE = 17;

/* ---- BODY & CITY LIFE PACK (v1.23.0) ----
   Real exercise anatomy: har exercise ke apne prime movers + stabilizers hote
   hain — eccentric phase mein STRETCH, concentric mein RELAX, fatigue asli
   mein accumulate hoti hai, recovery mein utarti hai, aur strength ISTA ISTA
   (progressive overload) next level jati hai — jhoothi instant power nahi. */
const MUSCLE_LIST = ['chest', 'lats', 'traps', 'delts', 'biceps', 'triceps', 'forearms', 'core', 'obliques', 'quads', 'hamstrings', 'glutes', 'calves'];
/* POORI DUNIYA KI EXERCISES, ORGANIZED (v1.25.0): har exercise apni station/
   machine par hoti hai — 26 stations, har ek ki apni animation aur apne ASLI
   prime movers + stabilizers. Floor work open-air FUNCTIONAL TURF par. */
const EXERCISES = [
  { id: 'benchpress', name: 'BENCH PRESS', prime: ['chest', 'triceps', 'delts'], stab: ['core', 'forearms'], rate: 1.05 },
  { id: 'inclinepress', name: 'INCLINE PRESS', prime: ['chest', 'delts', 'triceps'], stab: ['core'], rate: 1.0 },
  { id: 'chestfly', name: 'CHEST FLY', prime: ['chest', 'delts'], stab: ['biceps', 'core'], rate: 0.9 },
  { id: 'shoulderpress', name: 'SHOULDER PRESS', prime: ['delts', 'triceps', 'traps'], stab: ['core'], rate: 0.95 },
  { id: 'bicepcurl', name: 'BICEP CURLS', prime: ['biceps', 'forearms'], stab: ['delts', 'core'], rate: 1.1 },
  { id: 'pushdown', name: 'TRICEPS PUSHDOWN', prime: ['triceps', 'forearms'], stab: ['core', 'delts'], rate: 1.15 },
  { id: 'pullup', name: 'PULL-UPS', prime: ['lats', 'biceps', 'forearms'], stab: ['core'], rate: 0.8 },
  { id: 'latpulldown', name: 'LAT PULLDOWN', prime: ['lats', 'biceps'], stab: ['core', 'forearms'], rate: 0.9 },
  { id: 'seatedrow', name: 'SEATED CABLE ROW', prime: ['lats', 'traps', 'biceps'], stab: ['core', 'hamstrings'], rate: 0.95 },
  { id: 'shrug', name: 'BARBELL SHRUGS', prime: ['traps', 'forearms'], stab: ['core'], rate: 1.0 },
  { id: 'treadrun', name: 'TREADMILL RUN', prime: ['calves', 'quads', 'hamstrings'], stab: ['core'], rate: 1.7 },
  { id: 'cycle', name: 'STATIONARY CYCLE', prime: ['quads', 'calves', 'glutes'], stab: ['core', 'hamstrings'], rate: 1.6 },
  { id: 'rowerg', name: 'ROWING ERG (cardio)', prime: ['lats', 'quads', 'hamstrings'], stab: ['core', 'biceps'], rate: 1.4 },
  { id: 'squat', name: 'SQUATS', prime: ['quads', 'glutes', 'hamstrings'], stab: ['core', 'calves'], rate: 0.9 },
  { id: 'legpress', name: 'LEG PRESS', prime: ['quads', 'glutes', 'calves'], stab: ['hamstrings', 'core'], rate: 1.0 },
  { id: 'legext', name: 'LEG EXTENSION', prime: ['quads'], stab: ['core'], rate: 1.1 },
  { id: 'legcurl', name: 'LEG CURL', prime: ['hamstrings', 'calves'], stab: ['glutes'], rate: 1.0 },
  { id: 'calfraise', name: 'CALF RAISE', prime: ['calves'], stab: ['quads', 'core'], rate: 1.3 },
  { id: 'deadlift', name: 'DEADLIFTS', prime: ['hamstrings', 'glutes', 'lats', 'forearms'], stab: ['quads', 'core', 'traps'], rate: 0.7 },
  { id: 'dips', name: 'DIPS', prime: ['triceps', 'chest', 'delts'], stab: ['core'], rate: 0.85 },
  { id: 'plank', name: 'PLANK (iso)', prime: ['core', 'obliques'], stab: ['delts', 'quads'], rate: 0.6 },
  { id: 'crunch', name: 'AB CRUNCHES', prime: ['core', 'obliques'], stab: ['quads'], rate: 1.3 },
  { id: 'kettlebell', name: 'KETTLEBELL SWINGS', prime: ['glutes', 'hamstrings', 'core'], stab: ['forearms', 'quads'], rate: 1.2 },
  { id: 'lunge', name: 'LUNGES', prime: ['quads', 'glutes', 'calves'], stab: ['hamstrings', 'core'], rate: 1.0 },
  { id: 'burpee', name: 'BURPEES', prime: ['quads', 'chest', 'calves'], stab: ['core', 'delts'], rate: 1.35 },
  { id: 'stretch', name: 'COOLDOWN STRETCH', prime: ['hamstrings', 'calves', 'chest'], stab: ['core'], rate: 0.5 }
];

g.start({
  init(g) {
    g.state = 'play';
    const WS0 = WORLD_SIZE[SPEC.world] || 800;
    g.ws = WS0;
    g.solids = [];   // collision boxes {x0,z0,w,d,h,base}
    g.rails = SPEC.world === 'rails';

    /* ---- world geometry ---- */
    if (SPEC.world === 'city') {
      for (let bx = 0; bx < 5; bx += 1) for (let bz = 0; bz < 5; bz += 1) {
        if (bz === 2) continue; // river valley band — no buildings on the water
        const inset = g.rand(14, 34);
        const x0 = bx * 320 + 80 + inset; const z0 = bz * 320 + 80 + inset;
        g.solids.push({ x0, z0, w: 320 - 80 - inset * 2, d: 320 - 80 - inset * 2, h: g.rand(70, 240), base: g.rand(0.46, 0.7) });
      }
    } else if (SPEC.world === 'mansion') {
      // outer walls + interior corridor walls with doorways
      const S = WS0;
      const wall = (x, z, w, d) => g.solids.push({ x0: x, z0: z, w, d, h: 64, base: 0.5 });
      wall(0, 0, S, 16); wall(0, S - 16, S, 16); wall(0, 0, 16, S); wall(S - 16, 0, 16, S);
      for (let i = 1; i <= 2; i += 1) {
        const p = i * (S / 3);
        wall(p - 8, 0, 16, S / 3 - 70); wall(p - 8, S / 3 + 70, 16, S / 3 - 70); wall(p - 8, 2 * S / 3 + 70, 16, S / 3 - 70);
        wall(0, p - 8, S / 3 - 70, 16); wall(S / 3 + 70, p - 8, S / 3 - 70, 16); wall(2 * S / 3 + 70, p - 8, S / 3 - 70, 16);
      }
      for (let i = 0; i < 6; i += 1) { // furniture crates
        g.solids.push({ x0: g.rand(60, S - 120), z0: g.rand(60, S - 120), w: g.rand(30, 70), d: g.rand(30, 70), h: g.rand(20, 44), base: 0.4 });
      }
    } else if (SPEC.world === 'arena') {
      for (let i = 0; i < 12; i += 1) {
        g.solids.push({ x0: g.rand(60, WS0 - 160), z0: g.rand(60, WS0 - 160), w: g.rand(40, 110), d: g.rand(40, 110), h: g.rand(26, 60), base: g.rand(0.4, 0.62) });
      }
    } else if (g.rails) {
      for (let z = 0; z < WS0; z += 300) { // trackside ruins
        if (Math.random() < 0.7) g.solids.push({ x0: -380 + g.rand(-60, 60), z0: z + g.rand(0, 120), w: g.rand(60, 140), d: g.rand(60, 140), h: g.rand(50, 180), base: g.rand(0.3, 0.5) });
        if (Math.random() < 0.7) g.solids.push({ x0: 220 + g.rand(-60, 60), z0: z + g.rand(0, 120), w: g.rand(60, 140), d: g.rand(60, 140), h: g.rand(50, 180), base: g.rand(0.3, 0.5) });
      }
    }

    /* ---- waters: rivers/bays with real-life rules — splash, bob, drown ---- */
    g.waters = []; g.bridges = []; g.ripples = [];
    if (SPEC.world === 'city') {
      g.waters.push({ x0: 0, z0: 700, w: g.ws, d: 200, kind: 'river' });        // river crossing the city
      g.waters.push({ x0: g.ws, z0: -300, w: 760, d: g.ws + 900, kind: 'bay' }); // bay past the east edge
      g.bridges.push({ x0: 360, z0: 700, w: 80, d: 200 });
      g.bridges.push({ x0: 1080, z0: 700, w: 80, d: 200 });
    } else if (g.rails) {
      g.waters.push({ x0: -760, z0: -2000, w: 600, d: 8000, kind: 'river' });
      g.waters.push({ x0: 160, z0: -2000, w: 600, d: 8000, kind: 'river' });
    }

    /* ---- ground tiles ---- */
    g.tiles3 = [];
    if (g.rails) {
      for (let z = 0; z < WS0; z += 200) g.tiles3.push({ x: -240, z, s: 480, color: 0.07 });
    } else {
      const n = Math.ceil(WS0 / 160);
      for (let tx = 0; tx < n; tx += 1) for (let tz = 0; tz < n; tz += 1) {
        g.tiles3.push({ x: tx * 160, z: tz * 160, s: 160, color: SPEC.world === 'city' && (tx % 2 === 0 || tz % 2 === 0) ? 0.15 : 0.085 });
      }
    }

    /* ---- player ---- */
    const spawn = g.rails ? { x: 0, z: 200 } : SPEC.world === 'mansion' ? { x: WS0 / 2, z: WS0 / 2 } : { x: WS0 / 2, z: WS0 * 0.7 };
    g.P3 = {
      x: spawn.x, y: EYE, z: spawn.z, yaw: g.rails ? Math.PI : g.rand(Math.PI * 2), pitch: 0,
      hp: 100, hitT: 0, msg: '', msgT: 0, vx: 0, vy: 0, vz: 0,
      swinging: false, anchor: null, ammo: 12, reload: 0, fireT: 0,
      lane: 0, speed: g.rails ? 90 : 0, carAngle: 0,
      o2: 100, inWater: false, onBridge: false, diving: false, bottle: null, ripT: 0
    };
    g.lookPrev = null;

    /* ---- goal state ---- */
    g.goal = { wave: 1, kills: 0, collected: 0, delivered: 0, crests: 0, timer: 0, phase: 'go' };
    g.items = []; g.marker = null; g.dropoff = null;
    g.crests = []; g.pickups = []; g.boss = null; g.heartT = 0;
    if (SPEC.goal === 'collect') {
      for (let i = 0; i < (g.rails ? 15 : 12); i += 1) g.items.push(this.spawnPoint(g, true));
    } else if (SPEC.goal === 'escape') {
      g.marker = { x: g.rand(40, 120), z: g.rand(40, 120) }; // far corner from centre spawn
      g.goal.dist = Math.hypot(g.marker.x - g.P3.x, g.marker.z - g.P3.z);
      /* survival-horror detail: 3 crests unseal the gate, supplies are scarce */
      for (let i = 0; i < 3; i += 1) g.crests.push(this.openPoint(g, true));
      for (let i = 0; i < 5; i += 1) g.pickups.push({ ...this.openPoint(g, false), kind: 'herb' });
      for (let i = 0; i < 4; i += 1) g.pickups.push({ ...this.openPoint(g, false), kind: 'ammo' });
    } else if (SPEC.goal === 'deliver') {
      g.marker = this.spawnPoint(g, true);
    }
    /* water bottles: slosh as you move, refill in rivers, buy breath when low */
    if (SPEC.world === 'city' || SPEC.world === 'mansion') {
      const nb = SPEC.world === 'city' ? 3 : 2;
      for (let i = 0; i < nb; i += 1) g.pickups.push({ ...this.openPoint(g, false), kind: 'bottle' });
    }

    /* ---- living-world detail pack (GTA-6-class, miniature + honest) ----
       mud/tire tracks, reactive crowds, river alligators, wheeling seabirds,
       and a drifting weather cell — each detail is a real system, test-pinned. */
    g.tracks = [];  // footprints + tire tracks: the ground remembers you
    g.peds = [];    // crowds that wander, then REACT
    g.gators = [];  // river wildlife
    g.birds = [];   // gulls overhead
    g.weather = { t: g.rand(0, 40), intensity: 0, wind: 0.3 };
    if (SPEC.world === 'city') {
      for (let i = 0; i < 9; i += 1) {
        const pp = this.openPoint(g, false);
        g.peds.push({ x: pp.x, z: pp.z, dir: g.rand(Math.PI * 2), spd: g.rand(16, 26), state: 'walk', t: g.rand(6), fleeT: 0 });
      }
      for (let i = 0; i < 2; i += 1) g.gators.push({ x: g.rand(240, g.ws - 240), z: g.rand(740, 860), dir: g.rand(Math.PI * 2), biteT: 0, t: g.rand(10), ripT: 0 });
    }
    for (let i = 0; i < 5; i += 1) g.birds.push({ ang: g.rand(Math.PI * 2), r: g.rand(140, 320), h: g.rand(90, 170), spd: g.rand(0.5, 0.9) });

    /* ---- DETAIL PACK 2 (v1.21.0): car anatomy (doors/trunk/hood/mirrors/
       engine/fuel cap), REAL fridge props (items ANDAR pehle se hote hain —
       nikalo to haath mein aate hain, giren to gravity se girte hain),
       road traffic jo player ko yield karti hai, airport (runway + plane:
       engine, prop, pilot, takeoff roll → cruise), helicopter (main+tail
       rotor, pilot), gym (workout state), beach (umbrellas, towels,
       sunbathers, bouncing ball). Har system stateful + test-pinned. ---- */
    g.dropped = [];
    g.P3.held = null;
    /* BODY: har kaam ke waqt muscles stretch/relax — ye system SAB worlds mein
       zinda hai (koi bhi kaam karo, body respond karti hai) */
    g.body = {
      muscles: {}, exercise: 0, active: false, repT: 0, repNext: 1, reps: 0,
      xp: 0, level: 1, strength: 10, soreness: 0, ambient: '', t: 0, levelMsgT: 0
    };
    for (const mn of MUSCLE_LIST) g.body.muscles[mn] = { s: 0, f: 0, target: 0 };
    g.car = {
      parkedAt: SPEC.control === 'drive' ? null : { x: spawn.x + 26, z: spawn.z + 12, ang: g.rand(Math.PI * 2) },
      parts: {
        doorLF: { open: 0, target: 0 }, doorRF: { open: 0, target: 0 },
        doorLR: { open: 0, target: 0 }, doorRR: { open: 0, target: 0 },
        trunk: { open: 0, target: 0 }, hood: { open: 0, target: 0 },
        fuelCap: { open: 0, target: 0 }
      },
      partOrder: ['doorLF', 'hood', 'trunk', 'fuelCap', 'doorRF', 'doorLR', 'doorRR'],
      partCursor: 0,
      mirrors: { L: { fold: 0 }, R: { fold: 0 } },
      engine: { on: SPEC.control === 'drive', rpm: SPEC.control === 'drive' ? 820 : 0, temp: 20 },
      fuel: 62, refuelMsgT: 0
    };
    g.props = [{
      kind: 'fridge', x: spawn.x + 18, z: spawn.z - 20, open: 0, target: 0,
      items: [
        { kind: 'bottle', taken: false, fill: 1 },
        { kind: 'cup', taken: false, fill: 100 },
        { kind: 'veg', taken: false }
      ]
    }];
    g.traffic = []; g.planes = []; g.helis = []; g.gym = null; g.beach = null; g.airport = null;
    g.shops = []; g.buses = []; g.ships = []; g.shipyard = null; g.mine = null; g.motorway = null; g.machines = []; g.hospital = null; g.stretchers = [];
    if (SPEC.world === 'city') {
      // traffic: 6 cars, road corridors par — 2 lanes river BRIDGES (x≈400, x≈1120) se cross karti hain
      const lanes = [
        { axis: 'z', at: 40, dir: 1 }, { axis: 'z', at: 400, dir: -1 },
        { axis: 'z', at: 1120, dir: 1 }, { axis: 'z', at: 1560, dir: -1 },
        { axis: 'x', at: 40, dir: 1 }, { axis: 'x', at: 1320, dir: -1 }
      ];
      lanes.forEach((ln, i) => g.traffic.push({
        axis: ln.axis, at: ln.at, dir: ln.dir, pos: (i * 271 + 130) % WS0,
        base: 34 + i * 4, brake: 0
      }));
      // airport: bay ke us paar runway + ek plane jo ASLI takeoff karti hai
      g.airport = { x0: 2450, z0: 220, len: 900 };
      g.planes.push({ x: g.airport.x0 + 60, y: 0, z: g.airport.z0 + 30, spd: 0, throttle: 0, state: 'parked', parkT: 3, prop: 0, ang: 0, pilot: true });
      // helicopter: downtown ke upar hover circle — main + tail rotor, pilot aboard
      g.helis.push({ ang: 0, r: 300, h: 120, rotor: 0, tail: 0, pilot: true, cx: WS0 / 2, cz: WS0 * 0.32, x: WS0 / 2 + 300, z: WS0 * 0.32, y: 120 });
      // gym: river ke north bank par bara ORGANIZED gym + open-air functional
      // turf (solid NAHI — peds andar aa kar machine claim karke workout karte hain)
      g.gym = { x0: 420, z0: 632, w: 440, d: 64, roofW: 340 };
      /* GYM MACHINES (v1.25.0) — POORI DUNIYA KI EXERCISES ORGANIZED: 26
         stations, har ek apni machine + apni animation + apne ASLI muscles.
         Exercise SIRF station par (G/X), occupied = honest wait. */
      const ST = (id, name, ex, x, z) => ({ id, name, ex, x, z, busy: null, phase: 0 });
      g.machines = [
        // row 1 (z=644) — upper body machines
        ST('bench', 'BENCH PRESS', 0, 428, 644),
        ST('incline', 'INCLINE BENCH', 1, 464, 644),
        ST('fly', 'CHEST FLY MACHINE', 2, 500, 644),
        ST('press', 'SHOULDER PRESS RACK', 3, 536, 644),
        ST('curl', 'CURL STATION', 4, 572, 644),
        ST('pushdown', 'CABLE PUSHDOWN', 5, 608, 644),
        ST('pullbar', 'PULL-UP BAR', 6, 644, 644),
        ST('lat', 'LAT PULLDOWN', 7, 680, 644),
        ST('row', 'SEATED CABLE ROW', 8, 716, 644),
        ST('shrug', 'SHRUG STAND', 9, 752, 644),
        // row 2 (z=676) — cardio + legs
        ST('tread', 'TREADMILL', 10, 428, 676),
        ST('cycle', 'STATIONARY CYCLE', 11, 464, 676),
        ST('rower', 'ROWING ERG', 12, 500, 676),
        ST('rack', 'SQUAT RACK', 13, 536, 676),
        ST('legpress', 'LEG PRESS', 14, 572, 676),
        ST('legext', 'LEG EXTENSION', 15, 608, 676),
        ST('legcurl', 'LEG CURL', 16, 644, 676),
        ST('calf', 'CALF RAISE MACHINE', 17, 680, 676),
        ST('dlplatform', 'DEADLIFT PLATFORM', 18, 716, 676),
        ST('dip', 'DIP STATION', 19, 752, 676),
        // FUNCTIONAL TURF (open-air, z rows wahi) — floor work
        ST('plankmat', 'PLANK MAT', 20, 782, 644),
        ST('crunchmat', 'AB CRUNCH MAT', 21, 818, 644),
        ST('kbell', 'KETTLEBELL RACK', 22, 782, 676),
        ST('lunge', 'LUNGE FLOOR', 23, 818, 676),
        ST('burpee', 'BURPEE FLOOR', 24, 850, 644),
        ST('stretchmat', 'STRETCH CORNER', 25, 850, 676)
      ];
      // beach: gym ke ORGANIZED hone ke baad thora east shift (north bank sand strip)
      g.beach = {
        x0: 880, z0: 636,
        umbrellas: [{ x: 910, z: 650 }, { x: 980, z: 664 }, { x: 1060, z: 648 }],
        towels: [{ x: 940, z: 656 }, { x: 1030, z: 670 }],
        sunbathers: [{ x: 942, z: 657, t: 0 }, { x: 1032, z: 671, t: 3 }],
        ball: { x: 1120, z: 660, t: 0, y: 0 }
      };

      /* ---- BODY & CITY LIFE PACK (v1.23.0): named shops (gun shops alag),
         motorway + buses (stop FSM), river barges + ocean ship, shipyard
         (hulls ASLI mein bante hain), mine (carts chalti hain), named
         landmark buildings, aur NPC AI — peds destinations chunte hain:
         shop queue, gym workout, beach sit, aapas mein chat. ---- */
      g.shops = [
        { name: 'AMMU-VICE GUNS', kind: 'guns', stock: 'AMMO $40', x: 346, z: 330, dx: 346, dz: 352 },
        { name: 'BOOMSTICK DEPOT', kind: 'guns', stock: 'AMMO $40', x: 378, z: 392, dx: 378, dz: 370 },
        { name: 'KWIK-24 MART', kind: 'mart', stock: 'BOTTLE $10', x: 680, z: 352, dx: 680, dz: 374 },
        { name: 'ROSE BAKERY', kind: 'bakery', stock: 'CUPCAKE $12 (heal 15)', x: 708, z: 338, dx: 708, dz: 360 },
        { name: 'FADE CITY BARBER', kind: 'barber', stock: 'NAYA LOOK $15', x: 652, z: 388, dx: 652, dz: 366 },
        { name: 'BAYSIDE CAFE', kind: 'cafe', stock: 'CUP $8 (heal 10)', x: 1000, z: 360, dx: 1000, dz: 382 },
        { name: 'SLICE HAVEN PIZZA', kind: 'pizza', stock: 'PIZZA $20 (heal 25)', x: 968, z: 338, dx: 968, dz: 360 },
        { name: 'PAGE & PROTEIN BOOKS', kind: 'books', stock: 'TRAINING MANUAL $20 (+25 XP)', x: 1032, z: 388, dx: 1032, dz: 366 },
        { name: 'TORQUE & CO MECHANIC', kind: 'mechanic', stock: 'REFUEL $30', x: 1320, z: 352, dx: 1320, dz: 374 },
        { name: 'FULL TANK PETROL PUMP', kind: 'gas', stock: 'PETROL $25', x: 1288, z: 388, dx: 1288, dz: 366 },
        { name: 'VOLTAIC ELECTRONICS', kind: 'electronics', stock: 'RADIO-GADGET $60', x: 1352, z: 338, dx: 1352, dz: 360 },
        { name: 'VELVET VAULT JEWELS', kind: 'jewelry', stock: 'GOLD CHAIN $120', x: 480, z: 940, dx: 480, dz: 962 },
        { name: 'PETAL STREET FLORIST', kind: 'flowers', stock: 'GULDASTA $8', x: 560, z: 940, dx: 560, dz: 962 },
        { name: 'BOARDWALK OUTFITTERS', kind: 'clothes', stock: 'OUTFIT $15', x: 680, z: 940, dx: 680, dz: 962 },
        { name: 'INK ANCHOR TATTOO', kind: 'tattoo', stock: 'TATTOO $35', x: 760, z: 940, dx: 760, dz: 962 },
        { name: 'SUDS CITY LAUNDROMAT', kind: 'laundry', stock: 'KAPRE DHULAI $6', x: 840, z: 940, dx: 840, dz: 962 },
        { name: 'RINGTONE MOBILE', kind: 'mobile', stock: 'PHONE $45', x: 920, z: 940, dx: 920, dz: 962 },
        { name: 'IRONHAND HARDWARE', kind: 'hardware', stock: 'TOOLBOX $30', x: 1000, z: 940, dx: 1000, dz: 962 },
        { name: 'VICE PHARMACY (HOSPITAL)', kind: 'pharmacy', stock: 'DAWA $25 (heal 40)', x: 280, z: 1004, dx: 280, dz: 1004 }
      ];
      g.motorway = { z0: 316, z1: 404, stops: [300, 900, 1400] };
      g.buses = [
        { z: 344, dir: 1, pos: 120, spd: 52, state: 'run', haltT: 0, doors: 0, nextStop: 0 },
        { z: 380, dir: -1, pos: 1480, spd: 48, state: 'run', haltT: 0, doors: 0, nextStop: 2 }
      ];
      g.ships = [
        { kind: 'barge', x: 300, z: 780, dir: 1, spd: 9, ripT: 0 },
        { kind: 'barge', x: 1250, z: 856, dir: -1, spd: 7.5, ripT: 0.6 },
        { kind: 'ocean', x: g.ws + 380, z: -100, dir: 1, spd: 6, ripT: 0 }
      ];
      g.shipyard = {
        x0: 1300, z0: 606, w: 270, d: 82,
        hulls: [{ x: 1362, z: 648, stage: 0.35 }, { x: 1482, z: 648, stage: 0.65 }],
        crane: { x: 1424, z: 614, ang: 0.4 }
      };
      g.mine = {
        x0: 1180, z0: 934, w: 300, d: 190,
        entrance: { x: 1206, z: 1024 },
        carts: [{ t: 0 }, { t: 0.5 }],
        loop: [{ x: 1250, z: 960 }, { x: 1430, z: 960 }, { x: 1430, z: 1090 }, { x: 1250, z: 1090 }]
      };
      /* HOSPITAL (v1.25.0): building + beds + medicine shelf + pharmacy
         counter + chalne wale STRETCHERS (roll FSM) + staff peds (doctor/
         nurses apni duty par — attend/walk AI, gunfire par sab ki tarah flee) */
      g.hospital = {
        x0: 180, z0: 916, w: 200, d: 80,
        beds: [{ x: 212, z: 938, pat: true }, { x: 262, z: 938, pat: false }, { x: 312, z: 938, pat: true }],
        shelf: { x: 352, z: 930 },
        counter: { x: 280, z: 988 }
      };
      g.stretchers = [
        { x: 236, z: 992, zA: 992, zB: 950, dir: -1, spd: 13, state: 'roll', waitT: 0, patient: true },
        { x: 330, z: 954, zA: 992, zB: 954, dir: 1, spd: 11, state: 'wait', waitT: 3, patient: false }
      ];
      for (let si = 0; si < 3; si += 1) {
        g.peds.push({
          x: 200 + si * 70, z: 964, dir: g.rand(Math.PI * 2), spd: 13,
          state: 'attend', t: g.rand(6), fleeT: 0, timer: g.rand(2, 5),
          role: si === 0 ? 'doctor' : 'nurse', dest: null
        });
      }
      // landmark buildings — har ek ka apna NAAM (projected label ke saath)
      const LANDMARKS = ['HARBOR TOWER', 'MERIDIAN PLAZA', 'CIVIC CENTER', 'NORTHGATE TOWER', 'OLD UNION DEPOT'];
      let li = 0;
      for (const b of g.solids) { if (li < LANDMARKS.length && b.h > 120) { b.name = LANDMARKS[li]; li += 1; } }
    }

    /* ---- enemies ---- */
    g.foes = [];
    g.spawnT = 1.5;
    g.hunter = null; // the single stalker on rails
    if (g.rails && SPEC.enemy !== 'none') g.hunter = { gap: 420, hp: 8, weave: 0 };
    if (SPEC.goal === 'waves' && SPEC.enemy !== 'none') this.spawnWave(g);
  },

  /* ---------- helpers ---------- */
  spawnPoint(g, awayFromPlayer) {
    if (g.rails) {
      const z = (g.P3.z + g.rand(300, 1600)) % g.ws;
      return { x: (g.randInt(0, 2) - 1) * 44, z };
    }
    let p = { x: g.rand(50, g.ws - 50), z: g.rand(50, g.ws - 50) };
    if (awayFromPlayer) {
      let tries = 0;
      while (g.dist(p.x, p.z, g.P3.x, g.P3.z) < 260 && tries < 14) { p = { x: g.rand(50, g.ws - 50), z: g.rand(50, g.ws - 50) }; tries += 1; }
    }
    return p;
  },

  spawnWave(g) {
    const n = 3 + g.goal.wave * 2;
    for (let i = 0; i < n; i += 1) this.spawnFoe(g);
  },

  openPoint(g, away) {
    // spawnPoint can land inside a building — sample until the spot is open
    for (let t = 0; t < 40; t += 1) {
      const p = this.spawnPoint(g, away);
      let ok = true;
      for (const b of g.solids) {
        if (p.x > b.x0 - 16 && p.x < b.x0 + b.w + 16 && p.z > b.z0 - 16 && p.z < b.z0 + b.d + 16) { ok = false; break; }
      }
      if (ok) for (const w of (g.waters || [])) {
        if (p.x > w.x0 - 14 && p.x < w.x0 + w.w + 14 && p.z > w.z0 - 14 && p.z < w.z0 + w.d + 14) { ok = false; break; }
      }
      if (ok) return p;
    }
    return this.spawnPoint(g, away);
  },

  spawnBoss(g) {
    const p = this.openPoint(g, true);
    g.boss = { x: p.x, z: p.z, hp: 10, spd: 58, dmg: 30, h: 40, w: 18, base: 1.0, kind: 'boss', t: 0, fireT: 0 };
    g.foes.push(g.boss);
    g.shake(14);
    g.audio.noise(0.55, 0.35, 110); // something enormous wakes up
  },

  spawnFoe(g) {
    const p = this.spawnPoint(g, true);
    let kind = SPEC.enemy;
    if (SPEC.goal === 'escape' && kind === 'zombie' && g.rand(0, 1) < 0.3) kind = 'dog'; // zombie dogs mix the horde
    const stats = {
      zombie: { hp: 2, spd: g.rand(30, 50), dmg: 12, h: 20, w: 9, base: 0.34 },
      dog: { hp: 1, spd: g.rand(78, 96), dmg: 9, h: 10, w: 16, base: 0.5 },
      soldier: { hp: 2, spd: g.rand(72, 95), dmg: 8, h: 20, w: 9, base: 0.72 },
      stalker: { hp: 3, spd: g.rand(112, 140), dmg: 18, h: 26, w: 13, base: 0.92 },
      police: { hp: 3, spd: g.rand(95, 120), dmg: 14, h: 14, w: 20, base: 0.85 }
    }[kind] || { hp: 2, spd: 60, dmg: 10, h: 20, w: 9, base: 0.6 };
    g.foes.push({ x: p.x, z: p.z, ...stats, kind, t: g.rand(10), fireT: g.rand(1) });
  },

  collideWorld(g, r) {
    const P = g.P3;
    for (const b of g.solids) {
      const nx = g.clamp(P.x, b.x0, b.x0 + b.w);
      const nz = g.clamp(P.z, b.z0, b.z0 + b.d);
      let dx = P.x - nx; let dz = P.z - nz;
      let d2 = dx * dx + dz * dz;
      if (d2 >= r * r) continue;
      if (d2 < 0.0001) { dx = 0; dz = -1; d2 = 1; }
      const d = Math.sqrt(d2);
      P.x = nx + (dx / d) * r; P.z = nz + (dz / d) * r;
    }
    if (!g.rails) { P.x = g.clamp(P.x, 8, g.ws - 8); P.z = g.clamp(P.z, 8, g.ws - 8); }
  },

  /* ---- DETAIL PACK 2 interactions (scene methods — headless-testable) ---- */
  interact(g) {
    const P = g.P3;
    // 1) gira hua item uthao — jo ASLI mein gira tha, wahi wapas (spawn nahi)
    for (let i = g.dropped.length - 1; i >= 0; i -= 1) {
      const d = g.dropped[i];
      if (d.rest && g.dist(d.x, d.z, P.x, P.z) < 20) {
        g.dropped.splice(i, 1);
        P.held = { kind: d.kind, fill: d.fill };
        if (d.kind === 'bottle') P.bottle = { x: 0, v: 0, k: 42, c: 4.5, fill: d.fill ?? 1, drinkT: 0 };
        P.msg = `${d.kind.toUpperCase()} wapas utha liya (gira hua tha — gayab nahi hua tha)`; P.msgT = 2;
        return 'pickup';
      }
    }
    // 2) GYM MACHINE (v1.24.0): paas ki machine par G = wahi jo X karta hai
    for (const mc of (g.machines || [])) {
      if (g.dist(mc.x, mc.z, P.x, P.z) < 30) return this.useMachine(g);
    }
    // 3) SHOPS (v1.23.0): darwaze ke qareeb G — har shop ka apna stock + rate
    for (const sh of (g.shops || [])) {
      if (g.dist(sh.dx, sh.dz, P.x, P.z) < 26) return this.shopBuy(g, sh);
    }
    // 4) fridge kholo/band karo
    for (const pr of g.props) {
      if (pr.kind === 'fridge' && g.dist(pr.x, pr.z, P.x, P.z) < 30) {
        pr.target = pr.target ? 0 : 1;
        P.msg = pr.target ? 'FRIDGE khul raha hai — saaman ANDAR pehle se hai (T = uthao)' : 'FRIDGE band'; P.msgT = 2.4;
        g.audio.noise(0.05, 0.12, 520);
        return 'fridge';
      }
    }
    // 5) car ka agla part (cycle) — chalti gaari par honest refuse
    const CAR = g.car;
    const carPos = SPEC.control === 'drive' ? { x: P.x, z: P.z } : CAR.parkedAt;
    if (carPos && g.dist(carPos.x, carPos.z, P.x, P.z) < (SPEC.control === 'drive' ? 60 : 36)) {
      if (SPEC.control === 'drive' && Math.abs(P.speed) > 5) {
        P.msg = 'GAARI CHAL RAHI HAI — pehle rok (S/brake), phir G se parts kholo'; P.msgT = 2.2;
        return 'refused-moving';
      }
      const name = CAR.partOrder[CAR.partCursor % CAR.partOrder.length];
      CAR.partCursor += 1;
      this.togglePart(g, name);
      return 'car:' + name;
    }
    P.msg = 'paas mein karne layak kuch nahi — GYM MACHINE, fridge, car ya kisi SHOP ke darwaze ke qareeb jao'; P.msgT = 1.8;
    return null;
  },

  togglePart(g, name) {
    const CAR = g.car; const P = g.P3;
    const pt = CAR.parts[name];
    if (!pt) return false;
    if (SPEC.control === 'drive' && Math.abs(P.speed) > 5) {
      P.msg = 'GAARI CHAL RAHI HAI — pehle rok'; P.msgT = 2;
      return false;
    }
    pt.target = pt.target ? 0 : 1;
    const names = {
      doorLF: 'DRIVER DOOR', doorRF: 'PASSENGER DOOR', doorLR: 'REAR DOOR (L)', doorRR: 'REAR DOOR (R)',
      trunk: 'TRUNK (diggi)', hood: 'HOOD (bonnet) — engine bay dikhega', fuelCap: 'PETROL CAP'
    };
    P.msg = `${names[name] || name} ${pt.target ? 'KHUL' : 'BAND'} raha hai`; P.msgT = 2;
    g.audio.noise(0.05, 0.09, pt.target ? 640 : 420);
    return true;
  },

  takeItem(g) {
    const P = g.P3;
    if (P.held) { P.msg = 'haath pehle se bhara hai — H se drop karo'; P.msgT = 1.6; return null; }
    for (const pr of g.props) {
      if (pr.kind !== 'fridge' || g.dist(pr.x, pr.z, P.x, P.z) >= 30) continue;
      if (pr.open < 0.5) { P.msg = 'fridge BAND hai — G se kholo pehle'; P.msgT = 1.8; return null; }
      const it = pr.items.find((x) => !x.taken);
      if (!it) { P.msg = 'fridge khaali hai — sab nikal chuka (jhootha refill nahi)'; P.msgT = 1.8; return null; }
      it.taken = true;
      P.held = { kind: it.kind, fill: it.fill };
      if (it.kind === 'bottle') P.bottle = { x: 0, v: 0, k: 42, c: 4.5, fill: it.fill ?? 1, drinkT: 0 };
      P.msg = it.kind === 'bottle' ? 'BOTTLE fridge se NIKLI — haath mein hai, paani andar slosh karega'
        : it.kind === 'cup' ? 'CUP utha liya (V = piyo)' : 'SABZI utha li';
      P.msgT = 2.4;
      g.audio.chord([523, 784], 0.09, 'sine', 0.08);
      return it.kind;
    }
    return null;
  },

  dropHeld(g) {
    const P = g.P3;
    if (!P.held) return false;
    const kind = P.held.kind; const fill = P.held.fill;
    g.dropped.push({ kind, fill, x: P.x + Math.sin(P.yaw) * 10, y: P.y - 10, z: P.z - Math.cos(P.yaw) * 10, vy: 0, rest: false });
    P.held = null;
    if (kind === 'bottle') P.bottle = null;
    P.msg = `${kind.toUpperCase()} chhoda — ASLI mein girega, zameen par tikega, wapas uthaya ja sakta hai`; P.msgT = 2.4;
    return true;
  },

  drinkHeld(g) {
    const P = g.P3;
    if (!P.held || (P.held.kind !== 'cup' && P.held.kind !== 'bottle')) { P.msg = 'peene layak kuch haath mein nahi'; P.msgT = 1.6; return false; }
    if ((P.held.fill ?? 0) <= 0) { P.msg = 'khaali hai — honestly khaali, refill dhundo'; P.msgT = 1.6; return false; }
    if (P.held.kind === 'bottle') {
      P.held.fill = Math.max(0, (P.held.fill ?? 1) - 0.25);
      if (P.bottle) { P.bottle.fill = P.held.fill; P.bottle.v += 5.5; } // ghoont = slosh kick
    } else {
      P.held.fill = Math.max(0, (P.held.fill ?? 100) - 30);
    }
    P.msg = P.held.fill <= 0 ? 'PI LIYA — ab khaali' : 'ghoont piya — andar ka paani hila'; P.msgT = 1.8;
    return true;
  },

  /* SHOP (v1.23.0): har shop ka apna stock, apna rate — cash SCORE se kat-ta
     hai. Paisa kam ho to honest "paisa nahi" — chupke se udhaar nahi. */
  shopBuy(g, sh) {
    const P = g.P3;
    const cost = {
      guns: 40, mart: 10, cafe: 8, mechanic: 30, clothes: 15, pharmacy: 25,
      bakery: 12, pizza: 20, books: 20, gas: 25, barber: 15, tattoo: 35,
      jewelry: 120, electronics: 60, hardware: 30, flowers: 8, laundry: 6, mobile: 45
    }[sh.kind] || 0;
    const buy = (msg) => {
      g.addScore(-cost);
      P.msg = `${sh.name}: ${msg} — $${cost} cash se kata (score = cash)`; P.msgT = 3;
      g.audio.chord([523, 659], 0.1, 'sine', 0.09);
      return 'shop:' + sh.kind;
    };
    const broke = () => {
      P.msg = `${sh.name}: $${cost} chahiye — tumhare paas $${g.score}. Cash banao phir aao (honest, udhaar nahi).`;
      P.msgT = 3;
      return 'shop-broke';
    };
    if (sh.kind === 'guns') {
      if (SPEC.weapon !== 'hitscan') { P.msg = `${sh.name}: "is dukaan par sirf shooter license walon ko ammo milta hai" (is mission mein weapon nahi)`; P.msgT = 3; return 'shop-refused'; }
      if (P.ammo >= 12) { P.msg = `${sh.name}: magazine pehle se FULL (12/12) — paisa nahi kata (jhoothi sale nahi)`; P.msgT = 2.6; return 'shop-honest'; }
      if (g.score < cost) return broke();
      P.ammo = 12; P.reload = 0;
      return buy('AMMO 12/12 bhara (GUN SHOP — har shop ka naam, apna rate)');
    }
    if (sh.kind === 'mart' || sh.kind === 'cafe') {
      if (P.held) { P.msg = `${sh.name}: haath pehle se bhare hain — H se drop karke phir aao`; P.msgT = 2.4; return 'shop-honest'; }
      if (g.score < cost) return broke();
      if (sh.kind === 'mart') { P.held = { kind: 'bottle', fill: 1 }; P.bottle = { x: 0, v: 0, k: 42, c: 4.5, fill: 1, drinkT: 0 }; return buy('BOTTLE haath mein (slosh ke saath)'); }
      P.held = { kind: 'cup', fill: 100 };
      P.hp = Math.min(100, P.hp + 10);
      return buy('CUP bhara (V = piyo) + halka heal 10');
    }
    if (sh.kind === 'pharmacy' || sh.kind === 'bakery' || sh.kind === 'pizza') {
      if (P.hp >= 100) { P.msg = `${sh.name}: hp pehle se 100% — dawa/khana bekaar, paisa nahi kata (honest)`; P.msgT = 2.6; return 'shop-honest'; }
      if (g.score < cost) return broke();
      const heal = sh.kind === 'pharmacy' ? 40 : sh.kind === 'pizza' ? 25 : 15;
      P.hp = Math.min(100, P.hp + heal);
      const what = sh.kind === 'pharmacy' ? `DAWA li — healing +${heal} (hospital pharmacy, asli medicine shelf se)` : sh.kind === 'pizza' ? `PIZZA khaya — +${heal} hp` : `CUPCAKE khaya — +${heal} hp (fresh batch)`;
      return buy(what);
    }
    if (sh.kind === 'books') {
      if (g.score < cost) return broke();
      if (g.body) g.body.xp += 25;
      return buy('TRAINING MANUAL padha — BODY XP +25 (knowledge bhi taqat hai; level exercise/rest ke waqt check hota hai)');
    }
    if (sh.kind === 'mechanic' || sh.kind === 'gas') {
      if (g.car.fuel >= 100) { P.msg = `${sh.name}: tank pehle se FULL — paisa nahi kata`; P.msgT = 2.4; return 'shop-honest'; }
      if (g.score < cost) return broke();
      g.car.fuel = 100;
      return buy(sh.kind === 'gas' ? 'PETROL PUMP ne tank 100% kar diya' : 'TORQUE & CO ne tank 100% kar diya (cap kholne ki mehnat bach gayi)');
    }
    if (sh.kind === 'clothes' || sh.kind === 'barber' || sh.kind === 'tattoo' || sh.kind === 'jewelry'
      || sh.kind === 'electronics' || sh.kind === 'hardware' || sh.kind === 'flowers' || sh.kind === 'laundry' || sh.kind === 'mobile') {
      if (g.score < cost) return broke();
      P.outfit = (P.outfit || 0) + 1;
      const flavor = {
        clothes: `naya outfit #${P.outfit} pehan liya`,
        barber: 'naya FADE katwa liya — sheher tumhe naye look mein dekhega',
        tattoo: 'naya TATTOO banwa liya (ink anchor, honest needle-time)',
        jewelry: 'GOLD CHAIN pehan li — VELVET VAULT ka sabse mehnga item',
        electronics: 'pocket RADIO-GADGET liya (beep!) — voltaic ka best seller',
        hardware: 'TOOLBOX utha liya — agle mission mein kaam aayega',
        flowers: 'GULDASTA khareeda — kisi ko doge? (sweet gesture)',
        laundry: 'kapre dhul gaye — saaf outfit, fresh feel',
        mobile: 'naya PHONE liya — ringtone set (beep beep)'
      }[sh.kind];
      if (sh.kind === 'electronics' || sh.kind === 'mobile') g.audio.beep(880, 0.08, 'square', 0.07, -200);
      return buy(flavor);
    }
    P.msg = `${sh.name}: abhi stock khatam — agle update mein bharega (honest, khali dukaan khali hi dikhegi)`; P.msgT = 2.6;
    return 'shop-honest';
  },

  /* MACHINE (v1.24.0) — ORGANIZED GYM: exercise SIRF apni machine par.
     G ya X dono se chalta hai. Machine busy ho to honest wait. */
  useMachine(g) {
    const P = g.P3; const B = g.body;
    if (!B) return null;
    if (!B.active) {
      if (!g.machines || !g.machines.length) {
        P.msg = 'is world mein GYM MACHINE nahi — city ke GYM jao (river ke kinare); bench press, squat rack, pull-up bar, treadmill, deadlift platform, plank mat — har exercise ki APNI machine';
        P.msgT = 3.2;
        return 'no-gym';
      }
      let mc = null; let md = 30;
      for (const m of g.machines) { const d = g.dist(m.x, m.z, P.x, P.z); if (d < md) { md = d; mc = m; } }
      if (!mc) {
        P.msg = 'MACHINE ke paas jao (G/X) — exercise kahin bhi nahi hoti, SIRF apni machine par. ORGANIZED GYM: bench/rack/bar/treadmill/platform/mat';
        P.msgT = 3;
        return 'too-far';
      }
      if (mc.busy && mc.busy !== 'player') {
        P.msg = `${mc.name} OCCUPIED hai — ek ped workout kar raha hai. Wait karo ya dusri machine pakdo (asli gym ka rule)`;
        P.msgT = 2.6;
        return 'occupied';
      }
      mc.busy = 'player'; B.machine = mc; B.active = true;
      B.repT = 0; B.reps = 0; B.repNext = 1; B.lastSet = 0; B.exercise = mc.ex;
      const ex = EXERCISES[mc.ex];
      const worn = ex.prime.concat(ex.stab).filter((m) => B.muscles[m].f > 0.9);
      const nm = mc.name === ex.name ? mc.name : `${mc.name} par ${ex.name}`;
      P.msg = worn.length
        ? `${nm} shuru — magar ${worn.join(', ')} abhi THAKE hue hain (${Math.round(B.muscles[worn[0]].f * 100)}%); jaldi failure aayegi`
        : `${nm} shuru — ${ex.prime.join(' + ')} STRETCH honge (eccentric), RELAX (concentric). Machine tab tak tumhari hai.`;
      P.msgT = 3.2;
      g.audio.beep(330, 0.1, 'triangle', 0.08, 60);
      return 'machine:' + mc.id;
    }
    B.active = false;
    if (B.machine) { B.machine.busy = null; B.machine = null; }
    P.msg = `SET KHATAM — ${B.reps} reps, machine free kar di. Ab muscles RELAX + recover honge (asli body ka rule).`;
    P.msgT = 3;
    return 'machine-stop';
  },

  hurt(g, dmg, why) {
    const P = g.P3;
    if (P.hitT > 0) return;
    P.hp -= dmg; P.hitT = 0.85;
    g.shake(10); g.audio.noise(0.2, 0.26, 600);
    g.burst(g.width / 2, g.height / 2, 12, '#ffffff', 300);
    P.msg = why; P.msgT = 1.8;
    if (P.hp <= 0) g.gameOver(`${why} — ${g.goal.kills} kills, ${g.goal.collected} collected, ${g.goal.delivered} delivered`);
  },

  shoot(g) {
    const P = g.P3;
    if (SPEC.weapon !== 'hitscan' || P.reload > 0 || P.fireT > 0) return;
    if (P.ammo <= 0) { P.reload = 1.2; g.audio.beep(200, 0.08, 'square', 0.08); return; }
    P.ammo -= 1; P.fireT = 0.16;
    g.shotT = 0.35; // the shot rings out — nearby crowds will hear it
    g.audio.beep(900, 0.04, 'square', 0.07, -500);
    g.shake(2);
    const fx = Math.sin(P.yaw) * Math.cos(P.pitch); const fz = -Math.cos(P.yaw) * Math.cos(P.pitch);
    let best = null; let bestD = 520;
    const targets = g.foes.slice();
    if (g.hunter) targets.push({ x: g.P3.x, z: g.P3.z - g.hunter.gap, hunter: true, hp: g.hunter.hp });
    for (const f of targets) {
      const dx = f.x - P.x; const dz = f.z - P.z;
      const d = Math.hypot(dx, dz);
      if (d > bestD) continue;
      const cosAng = (dx * fx + dz * fz) / (d || 1);
      if (cosAng < 0.93) continue; // ~21° cone
      best = f; bestD = d;
    }
    if (best) {
      if (best.hunter) {
        g.hunter.hp -= 1; g.hunter.gap += 150;
        g.audio.noise(0.25, 0.3, 800);
        if (g.hunter.hp <= 0) { g.hunter = null; g.addScore(400); g.P3.msg = 'THE HUNTER IS DOWN +$400'; g.P3.msgT = 3; }
      } else {
        best.hp -= 1;
        const i = g.foes.indexOf(best);
        if (best.hp <= 0 && i >= 0) {
          g.foes.splice(i, 1);
          g.goal.kills += 1;
          if (best.kind === 'boss') {
            g.boss = null; g.addScore(500);
            g.P3.msg = 'THE TYRANT FALLS +$500'; g.P3.msgT = 3;
          } else g.addScore(best.kind === 'stalker' ? 40 : best.kind === 'dog' ? 15 : 25);
          g.audio.noise(0.14, 0.2, 1200);
        }
      }
    }
  },

  update(g, dt) {
    if (g.input.hit('KeyP', 'Escape')) g.togglePause();
    if (g.state === 'pause') return;
    if (g.state === 'over') { if (g.input.hit('Enter')) g.start(this); return; }
    const P = g.P3;
    P.hitT = Math.max(0, P.hitT - dt);
    P.fireT = Math.max(0, P.fireT - dt);
    P.msgT = Math.max(0, P.msgT - dt);
    if (P.reload > 0) { P.reload -= dt; if (P.reload <= 0) P.ammo = 12; }
    if (g.input.hit('KeyR') && P.ammo < 12 && P.reload <= 0) P.reload = 1.2;

    /* ---- look ---- */
    if (g.input.mouse.down) {
      if (g.lookPrev) {
        P.yaw += (g.input.mouse.x - g.lookPrev.x) * 0.005;
        P.pitch = g.clamp(P.pitch + (g.input.mouse.y - g.lookPrev.y) * 0.004, -1.1, 1.1);
      }
      g.lookPrev = { x: g.input.mouse.x, y: g.input.mouse.y };
    } else g.lookPrev = null;
    const yawLimit = g.rails ? 2.6 : null; // train: you CAN look back at the hunter
    if (g.input.down('ArrowLeft', 'KeyQ')) P.yaw -= 2.1 * dt;
    if (g.input.down('ArrowRight', 'KeyE')) P.yaw += 2.1 * dt;
    if (g.input.down('ArrowUp')) P.pitch = g.clamp(P.pitch - 1.2 * dt, -1.1, 1.1);
    if (g.input.down('ArrowDown')) P.pitch = g.clamp(P.pitch + 1.2 * dt, -1.1, 1.1);
    if (yawLimit !== null) { // train camera springs back to the track
      const target = Math.PI; let dA = target - P.yaw;
      while (dA > Math.PI) dA -= Math.PI * 2; while (dA < -Math.PI) dA += Math.PI * 2;
      if (Math.abs(dA) > yawLimit) P.yaw += Math.sign(dA) * 1.4 * dt;
    }

    const ax = g.input.axis();

    /* ---- water query (position from last frame): in a river/bay or on a bridge? ---- */
    const K3u = globalThis.GameKit3D || (typeof window !== 'undefined' ? window.GameKit3D : null);
    const wasIn = P.inWater;
    P.inWater = false; P.onBridge = false;
    for (const b of g.bridges) {
      if (P.x > b.x0 && P.x < b.x0 + b.w && P.z > b.z0 && P.z < b.z0 + b.d) { P.onBridge = true; break; }
    }
    if (!P.onBridge) {
      for (const w of g.waters) {
        if (P.x > w.x0 && P.x < w.x0 + w.w && P.z > w.z0 && P.z < w.z0 + w.d) { P.inWater = true; break; }
      }
    }
    if (P.inWater && !wasIn) { // crown splash: particles + noise + shake + wake rings
      g.audio.noise(0.32, 0.32, 280);
      g.shake(7);
      g.burst(g.width / 2, g.height * 0.62, 20, '#ffffff', 250);
      if (K3u && K3u.spawnRipple) { K3u.spawnRipple(g.ripples, P.x, P.z, 1); K3u.spawnRipple(g.ripples, P.x, P.z, 0.6); }
      P.msg = SPEC.control === 'drive' ? 'THE CAR SPLASHES INTO THE RIVER — reverse out (S)!' : 'YOU HIT THE WATER';
      P.msgT = 2.2;
    }
    const ox = P.x; const oz = P.z;

    /* ---- dynamic weather: a drifting system, not a static toggle.
       GTA 6 builds weather as its own physics system (mud traction, NPC routes,
       storm visibility) — ours drifts intensity + wind and touches rain, fog, grip. ---- */
    const WX = g.weather;
    WX.t += dt;
    const stormBase = (SPEC.atmosphere && SPEC.atmosphere.rain) ? 0.7 : 0.1;
    WX.intensity = g.clamp(stormBase + 0.3 * Math.sin(WX.t * 0.06), 0, 1);
    WX.wind = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(WX.t * 0.037 + 2));

    /* ---- movement per control scheme ---- */
    if (SPEC.control === 'fps') {
      const sprint = (g.input.down('ShiftLeft', 'ShiftRight') ? 215 : 118) * (P.inWater ? 0.52 : 1); // wading is slow
      const fx = Math.sin(P.yaw); const fz = -Math.cos(P.yaw);
      const rx = Math.cos(P.yaw); const rz = Math.sin(P.yaw);
      let mvx = fx * -ax.y + rx * ax.x; let mvz = fz * -ax.y + rz * ax.x;
      const ml = Math.hypot(mvx, mvz);
      if (ml > 0.01) { P.x += (mvx / ml) * sprint * dt; P.z += (mvz / ml) * sprint * dt; }
      this.collideWorld(g, 9);
    } else if (SPEC.control === 'swing') {
      const GRAV = 34;
      if (g.input.down('Space')) {
        if (!P.swinging) {
          P.swinging = true;
          const fx = Math.sin(P.yaw); const fz = -Math.cos(P.yaw);
          P.anchor = { x: P.x + fx * 110, y: P.y + 75, z: P.z + fz * 110 };
          g.audio.beep(1200, 0.05, 'sine', 0.06, 300);
        }
        // rope constraint + forward pump
        const ax2 = P.anchor.x - P.x; const ay2 = P.anchor.y - P.y; const az2 = P.anchor.z - P.z;
        const L = Math.hypot(ax2, ay2, az2) || 1;
        if (L > 130) { const pull = (L - 130) * 6; P.vx += (ax2 / L) * pull * dt; P.vy += (ay2 / L) * pull * dt; P.vz += (az2 / L) * pull * dt; }
        const fx = Math.sin(P.yaw); const fz = -Math.cos(P.yaw);
        P.vx += fx * 300 * dt; P.vz += fz * 300 * dt;
      } else if (P.swinging) { P.swinging = false; P.anchor = null; }
      if (P.swinging) { P.vy -= GRAV * 0.45 * dt; } // lighter gravity mid-swing
      else {
        P.vy -= GRAV * dt;
        const sprint = g.input.down('ShiftLeft', 'ShiftRight') ? 215 : 118;
        const fx = Math.sin(P.yaw); const fz = -Math.cos(P.yaw);
        const rx = Math.cos(P.yaw); const rz = Math.sin(P.yaw);
        const ctrl = P.y > EYE + 2 ? 70 : sprint;
        P.vx += (fx * -ax.y + rx * ax.x) * ctrl * (P.y > EYE + 2 ? dt * 3 : dt * 8);
        P.vz += (fz * -ax.y + rz * ax.x) * ctrl * (P.y > EYE + 2 ? dt * 3 : dt * 8);
      }
      P.vx *= Math.max(0, 1 - (P.swinging ? 0.25 : 6) * dt);
      P.vz *= Math.max(0, 1 - (P.swinging ? 0.25 : 6) * dt);
      P.x += P.vx * dt; P.y += P.vy * dt; P.z += P.vz * dt;
      if (P.y <= EYE && !P.inWater) { P.y = EYE; P.vy = 0; if (P.swinging) { P.swinging = false; P.anchor = null; } }
      this.collideWorld(g, 9);
    } else if (SPEC.control === 'train') {
      P.speed = g.clamp(P.speed + (g.input.down('KeyW') ? 70 : g.input.down('KeyS') ? -90 : -6) * dt, 35, 175);
      P.z += P.speed * dt;
      if (P.z > g.ws) P.z -= g.ws;
      if (g.input.hit('KeyA', 'ArrowLeft')) P.lane = Math.max(-1, P.lane - 1);
      if (g.input.hit('KeyD', 'ArrowRight')) P.lane = Math.min(1, P.lane + 1);
      const targetX = P.lane * 44;
      P.x += (targetX - P.x) * Math.min(1, 5 * dt);
      P.y = 26;
    } else if (SPEC.control === 'drive') {
      const throttle = g.input.down('KeyW', 'ArrowUp') ? 1 : g.input.down('KeyS', 'ArrowDown') ? -1 : 0;
      P.speed += throttle * 380 * dt;
      if (g.input.down('Space')) P.speed *= Math.max(0, 1 - 4.5 * dt);
      // rain-soaked tarmac bleeds traction (GTA 6: wetness/mud changes handling)
      if (g.weather.intensity > 0.55 && Math.abs(P.speed) > 60) P.carAngle += Math.sin(g.time * 3.1) * 0.05 * dt * (P.speed / 200);
      P.speed *= Math.max(0, 1 - (P.inWater ? 3.4 : 1.1) * dt); // water swallows momentum
      P.speed = g.clamp(P.speed, -150, 430);
      P.carAngle += (g.input.down('KeyD', 'ArrowRight') ? 1 : g.input.down('KeyA', 'ArrowLeft') ? -1 : 0) * 2.4 * dt * g.clamp(P.speed / 140, -1, 1);
      P.x += Math.sin(P.carAngle) * P.speed * dt;
      P.z += -Math.cos(P.carAngle) * P.speed * dt;
      const bx = P.x; const bz = P.z;
      this.collideWorld(g, 20);
      if (bx !== P.x || bz !== P.z) { if (Math.abs(P.speed) > 230) { g.shake(9); g.audio.noise(0.16, 0.22, 500); } P.speed *= -0.25; }
      if (P.inWater) P.y += (15 - P.y) * Math.min(1, 1.1 * dt); // the car settles into the river
      else P.y += (22 - P.y) * Math.min(1, 6 * dt);
      P.yaw += ((P.carAngle - P.yaw + Math.PI * 3) % (Math.PI * 2) - Math.PI) * Math.min(1, 6 * dt); // camera follows car
    }

    /* ---- swimming, diving, buoyancy: bodies ride the waves (real-life rules) ---- */
    if (P.inWater && (SPEC.control === 'fps' || SPEC.control === 'swing')) {
      P.diving = g.input.down('KeyC');
      const surf = 12 + (K3u ? K3u.waveY(P.x, P.z, g.time) * 0.8 : 0); // bob with the swell
      if (P.diving) P.y += (5.5 - P.y) * Math.min(1, 2.4 * dt);
      else P.y += (surf - P.y) * Math.min(1, 6 * dt);
      P.vy = 0;
      if (P.swinging) { P.swinging = false; P.anchor = null; } // water ends the swing
    } else {
      P.diving = false;
      if (SPEC.control === 'fps') P.y += (EYE - P.y) * Math.min(1, 8 * dt);
    }

    /* ---- breath: O₂ drains underwater; at zero you drown, like real life ---- */
    const submerged = P.inWater && (P.diving || SPEC.control === 'drive');
    if (submerged) {
      P.o2 -= (SPEC.control === 'drive' ? 9 : 7) * dt;
      if (P.o2 <= 0) {
        P.o2 = 0;
        P.hp -= 13 * dt;
        if (P.msgT <= 0) {
          P.msg = SPEC.control === 'drive' ? 'DROWNING IN THE CAR — reverse out (S)!' : 'DROWNING — GET TO AIR';
          P.msgT = 0.9;
        }
        if (P.hp <= 0) {
          g.gameOver(`YOU DROWNED — ${g.goal.kills} kills, ${g.goal.collected} collected, ${g.goal.delivered} delivered`);
          return;
        }
      }
    } else P.o2 = Math.min(100, P.o2 + (P.inWater ? 4 : 16) * dt);

    /* ---- water bottles: pickup, spring–damper slosh, river refill, drinking ---- */
    for (let i = g.pickups.length - 1; i >= 0; i -= 1) {
      const pk = g.pickups[i];
      if (pk.kind !== 'bottle' || g.dist(pk.x, pk.z, P.x, P.z) >= 22) continue;
      g.pickups.splice(i, 1);
      P.bottle = { x: 0, v: 0, k: 42, c: 4.5, fill: 1, drinkT: 0 };
      g.addScore(10);
      P.msg = 'WATER BOTTLE — hilti hai to andar ka paani bhi hilta hai'; P.msgT = 2.6;
      g.audio.chord([659, 880], 0.1, 'sine', 0.09);
    }
    if (P.bottle) {
      const B = P.bottle;
      // container acceleration: lateral movement + yaw rate shake the water inside
      const rx = Math.cos(P.yaw); const rz = Math.sin(P.yaw);
      const accel = ((P.x - ox) * rx + (P.z - oz) * rz) * 34 + (P.yaw - (P.pyaw === undefined ? P.yaw : P.pyaw)) * 90;
      P.pyaw = P.yaw;
      if (K3u && K3u.stepSlosh) K3u.stepSlosh(B, accel, dt);
      else { B.v += (-B.k * B.x - B.c * B.v + accel) * dt; B.x += B.v * dt; }
      B.drinkT = Math.max(0, B.drinkT - dt);
      if (P.inWater && B.fill < 1) {
        B.fill = Math.min(1, B.fill + 0.35 * dt); // rivers refill the bottle
        if (P.msgT <= 0) { P.msg = 'bottle river se refill ho rahi hai'; P.msgT = 0.8; }
      } else if (B.drinkT <= 0 && B.fill >= 0.25 && (P.o2 < 50 || P.hp < 45)) {
        B.drinkT = 4; B.fill -= 0.25;
        P.o2 = Math.min(100, P.o2 + 34); P.hp = Math.min(100, P.hp + 6);
        B.v += 5.5; // drinking tilts the bottle — the water sloshes hard
        P.msg = 'YOU DRINK — the water sloshes inside the bottle'; P.msgT = 2;
        g.audio.beep(480, 0.08, 'sine', 0.08, -160);
      }
    }

    /* ---- ripples: wading trails expanding damped rings (Kelvin-style wake) ---- */
    if (P.inWater && !P.onBridge) {
      P.ripT -= dt;
      if (P.ripT <= 0 && Math.hypot(P.x - ox, P.z - oz) > 0.3) {
        P.ripT = 0.45;
        if (K3u && K3u.spawnRipple) K3u.spawnRipple(g.ripples, P.x, P.z, P.diving ? 0.9 : 0.5);
      }
    }
    if (K3u && K3u.stepRipples) K3u.stepRipples(g.ripples, dt);

    /* ---- mud & tracks: the ground remembers you (GTA 6's reactive mud, miniature) ---- */
    if ((SPEC.control === 'fps' || SPEC.control === 'swing') && !P.inWater && P.y <= EYE + 2) {
      P.stepT = (P.stepT || 0) - dt;
      if (P.stepT <= 0 && Math.hypot(P.x - ox, P.z - oz) > 0.5) {
        P.stepT = 0.32;
        P.stepSide = -(P.stepSide || 1); // left, right, left…
        g.tracks.push({ x: P.x + Math.cos(P.yaw) * 4 * P.stepSide, z: P.z + Math.sin(P.yaw) * 4 * P.stepSide, ang: P.yaw, a: 0.5, w: 3, len: 7 });
      }
    }
    if (SPEC.control === 'drive') {
      const steerHeld = g.input.down('KeyD', 'ArrowRight') || g.input.down('KeyA', 'ArrowLeft');
      const handbrake = g.input.down('Space');
      const wet = g.weather.intensity > 0.5;
      P.skidding = (handbrake && Math.abs(P.speed) > 50) || (steerHeld && Math.abs(P.speed) > (wet ? 110 : 150));
      P.skidT = (P.skidT || 0) - dt;
      P.screechT = (P.screechT || 0) - dt;
      if (P.skidding && P.skidT <= 0 && !P.inWater) {
        P.skidT = 0.06;
        const px = Math.cos(P.carAngle) * 8; const pz = Math.sin(P.carAngle) * 8;
        g.tracks.push({ x: P.x + px, z: P.z + pz, ang: P.carAngle, a: 0.6, w: 4, len: 12 });
        g.tracks.push({ x: P.x - px, z: P.z - pz, ang: P.carAngle, a: 0.6, w: 4, len: 12 });
        if (P.screechT <= 0) { P.screechT = 0.45; g.audio.noise(0.1, 0.22, 1700); } // tire screech
      }
    }
    for (let i = g.tracks.length - 1; i >= 0; i -= 1) {
      g.tracks[i].a -= 0.045 * dt; // tracks fade like real disturbed mud
      if (g.tracks[i].a <= 0) g.tracks.splice(i, 1);
    }
    if (g.tracks.length > 140) g.tracks.splice(0, g.tracks.length - 140);

    /* ---- crowds: pedestrians wander, then REACT to gunfire and speeding cars ---- */
    if (g.peds.length) {
      g.shotT = Math.max(0, (g.shotT || 0) - dt);
      for (let i = g.peds.length - 1; i >= 0; i -= 1) {
        const pd = g.peds[i];
        pd.t += dt;
        const dp = g.dist(pd.x, pd.z, P.x, P.z);
        if (g.shotT > 0 && dp < 520) { if (pd.machine) { pd.machine.busy = null; pd.machine = null; } pd.state = 'flee'; pd.fleeT = 4.5; pd.dir = Math.atan2(pd.x - P.x, -(pd.z - P.z)); }
        if (SPEC.control === 'drive' && Math.abs(P.speed) > 90 && dp < 130) { if (pd.machine) { pd.machine.busy = null; pd.machine = null; } pd.state = 'flee'; pd.fleeT = 4; pd.dir = Math.atan2(pd.x - P.x, -(pd.z - P.z)); }
        if (pd.fleeT > 0) { pd.fleeT -= dt; if (pd.fleeT <= 0) { pd.state = 'walk'; pd.dest = null; } }
        /* NPC AI (v1.23.0): peds be-maqsad nahi ghoomte — har ped ka apna
           destination hota hai: shop queue, gym workout, beach sit, ya wander.
          Pahunch kar asli behaviour: queue mein khade hokar browse, do ped
          qareeb mile to CHAT (ek dusre ko face karte hain), beach par baithna. */
        if (pd.state === 'walk') {
          if (!pd.dest || g.dist(pd.x, pd.z, pd.dest.x, pd.dest.z) < 14) {
            const r = g.rand(0, 1);
            if (pd.role && g.hospital) pd.dest = { x: g.hospital.x0 + g.rand(16, g.hospital.w - 16), z: g.hospital.z0 + g.rand(14, g.hospital.d - 14), act: 'attend' };
            else if (r < 0.3 && g.shops.length) { const sh = g.shops[Math.floor(g.rand(0, g.shops.length - 0.001)) % g.shops.length]; pd.dest = { x: sh.dx, z: sh.dz, act: 'queue' }; }
            else if (r < 0.42 && g.hospital) pd.dest = { x: g.hospital.counter.x + g.rand(-24, 24), z: g.hospital.z0 + g.hospital.d + 14, act: 'queue' };
            else if (r < 0.56 && g.gym) pd.dest = { x: g.gym.x0 + g.rand(10, g.gym.w - 10), z: g.gym.z0 + g.rand(8, g.gym.d - 8), act: 'gym' };
            else if (r < 0.66 && g.beach) pd.dest = { x: g.beach.x0 + g.rand(20, 220), z: g.beach.z0 + g.rand(14, 30), act: 'sit' };
            else pd.dest = { x: g.rand(40, g.ws - 40), z: g.rand(40, g.ws - 40), act: 'wander' };
          }
          const want = Math.atan2(pd.dest.x - pd.x, -(pd.dest.z - pd.z));
          let dd = want - pd.dir;
          while (dd > Math.PI) dd -= Math.PI * 2; while (dd < -Math.PI) dd += Math.PI * 2;
          pd.dir += g.clamp(dd, -2.6 * dt, 2.6 * dt);
          if (g.dist(pd.x, pd.z, pd.dest.x, pd.dest.z) < 14) {
            if (pd.dest.act === 'queue') { pd.state = 'queue'; pd.timer = g.rand(3, 6.5); pd.dir = want + Math.PI; }
            else if (pd.dest.act === 'attend') { pd.state = 'attend'; pd.timer = g.rand(2.5, 6); }
            else if (pd.dest.act === 'sit') { pd.state = 'sit'; pd.timer = g.rand(5, 11); }
            else if (pd.dest.act === 'wander') pd.dest = null;
            // gym: zone logic workout state khud lagata hai
          }
        } else if (pd.state === 'queue' || pd.state === 'sit' || pd.state === 'chat' || pd.state === 'attend') {
          pd.timer -= dt;
          if (pd.timer <= 0) { pd.state = 'walk'; pd.dest = null; }
        }
        // CHAT: do ped qareeb aur dono free — ruk kar ek dusre ko face karo
        if (pd.state === 'walk' && !pd.chatT) {
          for (const od of g.peds) {
            if (od !== pd && (od.state === 'walk') && g.dist(pd.x, pd.z, od.x, od.z) < 18) {
              pd.state = 'chat'; od.state = 'chat';
              pd.timer = g.rand(2, 4.5); od.timer = pd.timer;
              pd.dir = Math.atan2(od.x - pd.x, -(od.z - pd.z));
              od.dir = Math.atan2(pd.x - od.x, -(pd.z - od.z));
              break;
            }
          }
        }
        const spd = pd.state === 'flee' ? pd.spd * 3.2 : (pd.state === 'workout' || pd.state === 'queue' || pd.state === 'sit' || pd.state === 'chat' || pd.state === 'attend') ? 0 : pd.spd;
        pd.x += Math.sin(pd.dir) * spd * dt; pd.z += -Math.cos(pd.dir) * spd * dt;
        pd.x = g.clamp(pd.x, 12, g.ws - 12); pd.z = g.clamp(pd.z, 12, g.ws - 12);
        for (const b of g.solids) { // cheap push-out, same as foes
          const nx = g.clamp(pd.x, b.x0, b.x0 + b.w); const nz = g.clamp(pd.z, b.z0, b.z0 + b.d);
          const ddx = pd.x - nx; const ddz = pd.z - nz; const dd2 = ddx * ddx + ddz * ddz;
          if (dd2 < 81 && dd2 > 0.0001) { const dd = Math.sqrt(dd2); pd.x = nx + (ddx / dd) * 9; pd.z = nz + (ddz / dd) * 9; }
        }
        for (const w of g.waters) { // peds don't swim — turn back at the bank
          if (pd.x > w.x0 - 6 && pd.x < w.x0 + w.w + 6 && pd.z > w.z0 - 6 && pd.z < w.z0 + w.d + 6) {
            pd.dir += Math.PI; pd.x += Math.sin(pd.dir) * 12; pd.z += -Math.cos(pd.dir) * 12;
          }
        }
        if (SPEC.control === 'drive' && Math.abs(P.speed) > 40 && dp < 24) { // struck — the crowd panics
          g.peds.splice(i, 1);
          g.shotT = 0.5;
          P.msg = 'PED STRUCK — the crowd panics'; P.msgT = 2;
          g.burst(g.width / 2, g.height * 0.6, 10, '#ffffff', 200);
          g.audio.noise(0.2, 0.2, 300);
        }
      }
    }

    /* ---- wildlife: river alligators smell you in the water (iconic Leonida detail) ---- */
    for (const ga of g.gators) {
      ga.t += dt;
      ga.biteT = Math.max(0, ga.biteT - dt);
      ga.ripT -= dt;
      const dp = g.dist(ga.x, ga.z, P.x, P.z);
      if (P.inWater && dp < 300) { // it hunts only what's IN the water
        ga.dir = Math.atan2(P.x - ga.x, -(P.z - ga.z));
        ga.x += Math.sin(ga.dir) * 62 * dt; ga.z += -Math.cos(ga.dir) * 62 * dt;
        if (dp < 26 && ga.biteT <= 0) { ga.biteT = 1.4; this.hurt(g, 16, 'AN ALLIGATOR ROLLS ON YOU'); }
      } else {
        ga.x += Math.sin(ga.dir) * 14 * dt; ga.z += -Math.cos(ga.dir) * 14 * dt; // lazy patrol
        if (Math.sin(ga.t * 0.4) > 0.99) ga.dir += Math.PI / 2;
        ga.x = g.clamp(ga.x, 60, g.ws - 60); ga.z = g.clamp(ga.z, 712, 888);
      }
      if (ga.ripT <= 0) { ga.ripT = 0.9; if (K3u && K3u.spawnRipple) K3u.spawnRipple(g.ripples, ga.x, ga.z, 0.4); } // swimming gators leave their own wake
    }

    /* ---- DETAIL PACK 2 update: real state machines, no fakery ---- */
    {
      const CAR = g.car;
      // hinges move at real speed (parts teleport nahi hote)
      for (const k of Object.keys(CAR.parts)) {
        const pt = CAR.parts[k];
        if (pt.open !== pt.target) {
          const s = 2.2 * dt;
          pt.open = pt.open < pt.target ? Math.min(pt.target, pt.open + s) : Math.max(pt.target, pt.open - s);
        }
      }
      // side mirrors FRONT DOORS par lagte hain — darwaza khula to mirror fold
      CAR.mirrors.L.fold += ((CAR.parts.doorLF.open > 0.4 ? CAR.parts.doorLF.open : 0) - CAR.mirrors.L.fold) * Math.min(1, 6 * dt);
      CAR.mirrors.R.fold += ((CAR.parts.doorRF.open > 0.4 ? CAR.parts.doorRF.open : 0) - CAR.mirrors.R.fold) * Math.min(1, 6 * dt);
      // engine: rpm + temp real states hain
      const carStopped = SPEC.control !== 'drive' || Math.abs(P.speed) < 5;
      if (CAR.engine.on) {
        CAR.engine.rpm += ((800 + (SPEC.control === 'drive' ? Math.abs(P.speed) * 22 : 0)) - CAR.engine.rpm) * Math.min(1, 2 * dt);
        CAR.engine.temp = Math.min(105, CAR.engine.temp + 9 * dt);
        if (CAR.engine.temp >= 104 && P.msgT <= 0) { P.msg = 'ENGINE OVERHEAT — hood kholo (G), engine band karo (B)'; P.msgT = 3; }
      } else {
        CAR.engine.rpm = Math.max(0, CAR.engine.rpm - 900 * dt);
        CAR.engine.temp = Math.max(20, CAR.engine.temp - 6 * dt);
      }
      // refuel: cap khula + gaari ruki + tank < 100 — warna honest no-op
      if (CAR.parts.fuelCap.open > 0.6 && carStopped && CAR.fuel < 100) {
        CAR.fuel = Math.min(100, CAR.fuel + 9 * dt);
        CAR.refuelMsgT -= dt;
        if (CAR.refuelMsgT <= 0) {
          CAR.refuelMsgT = 4;
          P.msg = CAR.fuel >= 100 ? 'TANK FULL — 100%' : 'PETROL BHAR RAHA HAI… (cap khula, gaari ruki)';
          P.msgT = 2;
        }
      }
      // interaction keys — shoot/dive/steer se kabhi clash nahi karte
      if (g.input.hit('KeyB')) {
        CAR.engine.on = !CAR.engine.on;
        P.msg = CAR.engine.on ? 'ENGINE START — rpm idle par, temp badhegi' : 'ENGINE OFF'; P.msgT = 2;
        g.audio.beep(CAR.engine.on ? 220 : 140, 0.12, 'sawtooth', 0.1, CAR.engine.on ? 60 : -80);
      }
      if (g.input.hit('KeyG')) this.interact(g);
      if (g.input.hit('KeyT')) this.takeItem(g);
      if (g.input.hit('KeyH')) this.dropHeld(g);
      if (g.input.hit('KeyV')) this.drinkHeld(g);
      // fridge door animation
      for (const pr of g.props) {
        if (pr.kind === 'fridge' && pr.open !== pr.target) {
          const s = 2.4 * dt;
          pr.open = pr.open < pr.target ? Math.min(pr.target, pr.open + s) : Math.max(pr.target, pr.open - s);
        }
      }
      // dropped items: REAL gravity — girte hain, zameen par tikte hain, wapas uthaye ja sakte hain
      for (const d of g.dropped) {
        if (d.rest) continue;
        d.vy -= 55 * dt; d.y += d.vy * dt;
        if (d.y <= 3) { d.y = 3; d.vy = 0; d.rest = true; g.audio.noise(0.06, 0.05, 240); }
      }
      // traffic: lanes par chalti cars, player ke qareeb YIELD (brake glow)
      for (const tc of g.traffic) {
        const tx = tc.axis === 'z' ? tc.at : tc.pos;
        const tz = tc.axis === 'z' ? tc.pos : tc.at;
        const dp = g.dist(tx, tz, P.x, P.z);
        const yield_ = dp < 70 ? 0.3 : 1;
        tc.brake = yield_ < 1 ? 1 : Math.max(0, tc.brake - 2 * dt);
        tc.pos += tc.dir * tc.base * yield_ * dt;
        if (tc.pos > g.ws + 40) tc.pos = -40;
        if (tc.pos < -40) tc.pos = g.ws + 40;
      }
      // plane: parked → takeoff roll → rotate/climb → cruise (engine, prop, pilot)
      for (const pl of g.planes) {
        if (pl.state === 'parked') {
          pl.parkT -= dt; pl.throttle = 0;
          if (pl.parkT <= 0) { pl.state = 'roll'; pl.throttle = 1; }
        } else if (pl.state === 'roll') {
          pl.throttle = 1; pl.spd += 28 * dt; pl.x += pl.spd * dt;
          if (pl.spd >= 150) pl.state = 'air';
        } else if (pl.state === 'air') {
          pl.y = Math.min(150, pl.y + 22 * dt); pl.x += pl.spd * dt;
          if (pl.y >= 150 || pl.x > g.airport.x0 + g.airport.len) { pl.state = 'cruise'; pl.ang = 0; }
        } else {
          pl.ang += 0.25 * dt;
          pl.x = g.airport.x0 + g.airport.len / 2 + Math.cos(pl.ang) * 380;
          pl.z = g.airport.z0 + Math.sin(pl.ang) * 380;
          pl.y = 150 + Math.sin(pl.ang * 2) * 8;
        }
        pl.prop += (pl.throttle * 45 + (pl.state === 'cruise' ? 40 : 0)) * dt;
      }
      // heli: rotors spin, hover circle with gentle height drift
      for (const he of g.helis) {
        he.rotor += 26 * dt; he.tail += 40 * dt; he.ang += 0.18 * dt;
        he.x = he.cx + Math.cos(he.ang) * he.r;
        he.z = he.cz + Math.sin(he.ang) * he.r;
        he.y = he.h + Math.sin(g.time * 0.8) * 6;
      }
      // gym (ORGANIZED, v1.24.0): ped andar aaye to KHALI MACHINE claim kare —
      // machine na mile to workout nahi (wait/browse); bahar gaya = machine free
      if (g.gym) {
        for (const pd of g.peds) {
          const inside = pd.x > g.gym.x0 && pd.x < g.gym.x0 + g.gym.w && pd.z > g.gym.z0 && pd.z < g.gym.z0 + g.gym.d;
          if (inside && pd.state === 'walk') {
            let free = null; let fd = 1e9;
            for (const m of (g.machines || [])) {
              if (m.busy) continue;
              const d = g.dist(m.x, m.z, pd.x, pd.z);
              if (d < fd) { fd = d; free = m; }
            }
            if (free) { if (pd.machine && pd.machine !== free) pd.machine.busy = null; free.busy = pd; pd.machine = free; pd.state = 'workout'; pd.x = free.x; pd.z = free.z + 8; pd.dir = Math.PI; }
          }
          if (pd.state === 'workout' && (!inside || pd.fleeT > 0)) {
            if (pd.machine) { pd.machine.busy = null; pd.machine = null; }
            pd.state = pd.fleeT > 0 ? 'flee' : 'walk';
          }
        }
        // machine phases: busy machines animate (player = apni rep rate se, ped = steady)
        for (const m of (g.machines || [])) {
          if (!m.busy) { m.phase += (0 - m.phase % 1) * Math.min(1, 4 * dt); continue; }
          const rate = m.busy === 'player' ? EXERCISES[m.ex].rate * (1 - 0.4 * (g.body.muscles[EXERCISES[m.ex].prime[0]]?.f || 0)) : 1.15;
          m.phase += rate * dt;
        }
      }
      // beach: ball uchalta hai, sunbathers tan karte hain
      if (g.beach) {
        g.beach.ball.t += dt;
        g.beach.ball.y = Math.abs(Math.sin(g.beach.ball.t * 2.4)) * 16;
        for (const sb of g.beach.sunbathers) sb.t += dt;
      }
    }

    /* ---- BODY & CITY LIFE PACK update (v1.23.0) — real systems ---- */
    {
      const B = g.body;
      B.t += dt;
      B.levelMsgT = Math.max(0, B.levelMsgT - dt);
      // X = machine use karo — ORGANIZED GYM (v1.24.0): exercise SIRF apni
      // machine par hoti hai, kahin bhi nahi. G bhi yahi karta hai.
      if (g.input.hit('KeyX')) this.useMachine(g);
      const ex = EXERCISES[B.exercise % EXERCISES.length];
      if (B.active) {
        // fatigue rep speed kam karti hai — asli thakan ka asli asar
        let avgF = 0; for (const m of ex.prime) avgF += B.muscles[m].f;
        avgF /= ex.prime.length;
        B.repT += dt * ex.rate * (1 - 0.4 * avgF);
        while (B.repT >= B.repNext) {
          B.repNext += 1; B.reps += 1; B.xp += 1;
          for (const m of ex.prime) B.muscles[m].f = Math.min(1, B.muscles[m].f + 0.05);
          for (const m of ex.stab) B.muscles[m].f = Math.min(1, B.muscles[m].f + 0.02);
          g.audio.noise(0.03, 0.03, 200 + B.reps * 4);
        }
        const phase = B.repT % 1;
        // eccentric (0→0.5) = STRETCH barhta hai; concentric (0.5→1) = RELAX
        const stretchNow = phase < 0.5 ? phase * 2 : Math.max(0, 2 - phase * 2);
        for (const m of ex.prime) B.muscles[m].target = stretchNow;
        for (const m of ex.stab) B.muscles[m].target = stretchNow * 0.4;
        // har 10 reps = set; XP milta hai; muscle failure par honest stop
        if (B.reps > 0 && B.reps % 10 === 0 && B.reps !== B.lastSet) {
          B.lastSet = B.reps; B.xp += 15;
          P.msg = `SET ${Math.floor(B.reps / 10)} complete — ${B.reps} reps, +15 XP. ${ex.prime.join('+')} stretch/relax cycle chal raha hai.`;
          P.msgT = 2.4;
        }
        let failed = null;
        for (const m of ex.prime) if (B.muscles[m].f > 0.93) { failed = m; break; }
        if (failed) {
          B.active = false; B.soreness = Math.min(1, B.soreness + 0.5);
          if (B.machine) { B.machine.busy = null; B.machine = null; } // machine free — agla ped use kar sakta hai
          P.msg = `MUSCLE FAILURE — ${failed.toUpperCase()} ne jawab de diya. Exercise RUK gayi (jhoothi taqat nahi): REST karo, fatigue khud utaregi. Machine khali kar di.`;
          P.msgT = 3.4;
          g.audio.beep(120, 0.25, 'sawtooth', 0.09, -40);
        }
        // machine chhod kar chale gaye = set ADHOORA (organized gym, honest)
        if (B.active && B.machine && g.dist(P.x, P.z, B.machine.x, B.machine.z) > 44) {
          B.active = false; B.machine.busy = null; B.machine = null;
          P.msg = `MACHINE CHHOD DI — set adhoora (${B.reps} reps gine gaye, utna hi XP). Wapas ${EXERCISES[B.exercise].name} karne machine par jao.`;
          P.msgT = 3;
        }
      } else {
        for (const mn of MUSCLE_LIST) B.muscles[mn].target = 0;
      }
      // STRENGTH ISTA ISTA NEXT LEVEL — progressive overload, instant nahi.
      // XP kahin se bhi aaye (reps, sets, ya BOOKS se) — level check hamesha chalta hai
      while (B.xp >= B.level * 80) {
        B.xp -= B.level * 80; B.level += 1; B.strength = Math.round((10 + (B.level - 1) * 1.5) * 10) / 10;
        B.levelMsgT = 4;
        P.msg = `STRENGTH LEVEL ${B.level} — strength ${B.strength}. Ista ista bara (progressive overload), ek jhatke mein nahi.`;
        P.msgT = 3.4;
        g.audio.chord([392, 523, 659], 0.18, 'triangle', 0.1);
      }
      /* AMBIENT BODY: "koi bi kam karta waqat" — chalna, daudna, tairna,
         goli chalana, wazan uthana, steering pakadna — sab ka asli asar */
      const moving = SPEC.control === 'drive' ? Math.abs(P.speed) : Math.hypot(P.vx, P.vz);
      let amb = '';
      if (P.inWater) {
        amb = 'swim';
        B.muscles.delts.target = Math.max(B.muscles.delts.target, 0.34);
        B.muscles.lats.target = Math.max(B.muscles.lats.target, 0.3);
        B.muscles.delts.f = Math.min(1, B.muscles.delts.f + (P.diving ? 0.02 : 0.014) * dt);
      } else if (moving > 8) {
        amb = moving > 26 ? 'sprint' : 'walk';
        B.muscles.calves.target = Math.max(B.muscles.calves.target, moving > 26 ? 0.42 : 0.24);
        B.muscles.quads.target = Math.max(B.muscles.quads.target, moving > 26 ? 0.34 : 0.16);
        if (moving > 26) for (const m of ['calves', 'quads']) B.muscles[m].f = Math.min(1, B.muscles[m].f + 0.012 * dt);
      } else if (SPEC.control === 'drive' && moving > 2) {
        amb = 'drive';
        B.muscles.forearms.target = Math.max(B.muscles.forearms.target, 0.14);
      }
      if (P.held) {
        B.muscles.forearms.target = Math.max(B.muscles.forearms.target, 0.3);
        B.muscles.biceps.target = Math.max(B.muscles.biceps.target, 0.22);
        B.muscles.forearms.f = Math.min(1, B.muscles.forearms.f + 0.01 * dt);
        amb = amb || 'carry';
      }
      if (P.fireT > 0.02) { // recoil ka jhatka — shoulders/forearms stretch
        B.muscles.delts.target = Math.max(B.muscles.delts.target, 0.5);
        B.muscles.triceps.target = Math.max(B.muscles.triceps.target, 0.42);
        amb = amb || 'shoot';
      }
      B.ambient = amb;
      // stretch smoothing + RECOVERY: relax phase asli hai — fatigue utarti hai
      const resting = moving < 6 && !B.active;
      for (const mn of MUSCLE_LIST) {
        const mu = B.muscles[mn];
        mu.s += (mu.target - mu.s) * Math.min(1, 6 * dt);
        if (mu.s < 0.005) mu.s = 0;
        mu.f = Math.max(0, mu.f - (resting ? 0.075 : 0.04) * dt * (1 - mu.s * 0.5));
      }
      B.soreness = Math.max(0, B.soreness - 0.02 * dt);

      // BUSES: motorway par route + stops — ASLI halt FSM, doors khulti hain
      for (const bu of g.buses) {
        if (bu.state === 'halt') {
          bu.haltT -= dt;
          bu.doors = Math.min(1, bu.doors + 1.5 * dt);
          if (bu.haltT <= 0) { bu.state = 'doors'; }
        } else if (bu.state === 'doors') {
          bu.doors = Math.max(0, bu.doors - 1.5 * dt);
          if (bu.doors <= 0) { bu.state = 'run'; bu.nextStop = (bu.nextStop + 1) % g.motorway.stops.length; }
        } else {
          const dpb = g.dist(bu.pos, bu.z, P.x, P.z);
          const yield_ = dpb < 54 ? 0.35 : 1;
          bu.pos += bu.dir * bu.spd * yield_ * dt;
          const stopX = g.motorway.stops[bu.nextStop % g.motorway.stops.length];
          if ((bu.dir > 0 && bu.pos >= stopX && bu.pos < stopX + bu.spd * dt + 2) || (bu.dir < 0 && bu.pos <= stopX && bu.pos > stopX - bu.spd * dt - 2)) {
            bu.pos = stopX; bu.state = 'halt'; bu.haltT = 3.5;
          }
          if (bu.pos > g.ws + 80) bu.pos = -80;
          if (bu.pos < -80) bu.pos = g.ws + 80;
        }
      }

      // SHIPS: river barges + ocean ship — chalte hain, wake chhodte hain
      for (const sh of g.ships) {
        if (sh.kind === 'barge') {
          sh.x += sh.dir * sh.spd * dt;
          if (sh.x > g.ws + 120) sh.x = -120;
          if (sh.x < -120) sh.x = g.ws + 120;
          // hull se takrao = asli nuqsan (paani mein ho to)
          if (P.inWater && Math.abs(P.z - sh.z) < 26 && Math.abs(P.x - sh.x) < 46) this.hurt(g, 22, 'A BARGE HULL SLAMS INTO YOU');
        } else {
          sh.z += sh.dir * sh.spd * dt;
          if (sh.z > g.ws + 700) sh.z = -300;
          if (sh.z < -300) sh.z = g.ws + 700;
        }
        sh.ripT -= dt;
        if (sh.ripT <= 0) { sh.ripT = 1.1; if (K3u && K3u.spawnRipple) K3u.spawnRipple(g.ripples, sh.x - sh.dir * 40, sh.z, 0.5); }
      }

      // SHIPYARD: hulls ASLI mein dheere dheere bante hain (stage barhti hai)
      if (g.shipyard) {
        g.shipyard.crane.ang += 0.12 * dt;
        for (const h of g.shipyard.hulls) {
          if (h.stage < 1) {
            h.stage = Math.min(1, h.stage + 0.004 * dt);
            if (h.stage >= 1 && !h.doneMsg) { h.doneMsg = true; if (g.dist(P.x, P.z, h.x, h.z) < 400) { P.msg = 'IRONKEEL SHIPYARD: ek hull mukammal — crane ab agle kaam par'; P.msgT = 3; } }
          }
        }
      }

      // MINE: carts loop par chalti hain — raat din kaam
      if (g.mine) {
        const L = g.mine.loop;
        for (const ct of g.mine.carts) {
          ct.t = (ct.t + 0.06 * dt) % 1;
          const seg = ct.t * L.length; const i0 = Math.floor(seg) % L.length; const i1 = (i0 + 1) % L.length;
          const f = seg - Math.floor(seg);
          ct.x = L[i0].x + (L[i1].x - L[i0].x) * f;
          ct.z = L[i0].z + (L[i1].z - L[i0].z) * f;
        }
      }

      // HOSPITAL STRETCHERS (v1.25.0): entrance ↔ ward roll, wait, wapas —
      // asli FSM, teleport nahi; patient wale stretcher ward mein rukte hain
      for (const st of (g.stretchers || [])) {
        st.t += dt;
        if (st.state === 'roll') {
          st.z += st.dir * st.spd * dt;
          if (st.dir < 0 && st.z <= st.zB) { st.z = st.zB; st.state = 'wait'; st.waitT = st.patient ? 5 : 3; st.dir = 1; }
          else if (st.dir > 0 && st.z >= st.zA) { st.z = st.zA; st.state = 'wait'; st.waitT = 2.5; st.dir = -1; }
        } else {
          st.waitT -= dt;
          if (st.waitT <= 0) st.state = 'roll';
        }
      }
    }

    /* ---- weapon ---- */
    if (SPEC.weapon === 'hitscan' && (g.input.mouse.clicked || g.input.hit('KeyF'))) this.shoot(g);

    /* ---- enemies ---- */
    if (g.rails && g.hunter) {
      const h = g.hunter;
      h.gap = Math.max(24, h.gap - (14 + g.goal.collected * 1.6) * dt); // it keeps closing in
      h.weave += dt;
      if (h.gap <= 26) this.hurt(g, 18, 'THE HUNTER TEARS AT YOUR TRAIN');
    } else if (SPEC.enemy !== 'none' && !g.rails) {
      // ambient spawning for non-wave goals
      if (SPEC.goal !== 'waves') {
        g.spawnT -= dt;
        const cap = SPEC.enemy === 'police' ? 3 : 8;
        if (g.spawnT <= 0 && g.foes.length < cap) { g.spawnT = SPEC.enemy === 'police' ? 5 : 3.2; this.spawnFoe(g); }
      }
      for (let i = g.foes.length - 1; i >= 0; i -= 1) {
        const f = g.foes[i];
        f.t += dt;
        const dx = P.x - f.x; const dz = P.z - f.z;
        const d = Math.hypot(dx, dz) || 1;
        let mx = (dx / d) * f.spd; let mz = (dz / d) * f.spd;
        if (f.kind === 'stalker') { const wv = Math.sin(f.t * 3.4) * 46; mx += (-dz / d) * wv; mz += (dx / d) * wv; } // weaving charge
        f.x += mx * dt; f.z += mz * dt;
        if (!g.rails) {
          // keep foes out of solids (cheap push-out)
          for (const b of g.solids) {
            const nx = g.clamp(f.x, b.x0, b.x0 + b.w); const nz = g.clamp(f.z, b.z0, b.z0 + b.d);
            const ddx = f.x - nx; const ddz = f.z - nz; const dd2 = ddx * ddx + ddz * ddz;
            if (dd2 < 64 && dd2 > 0.0001) { const dd = Math.sqrt(dd2); f.x = nx + (ddx / dd) * 8; f.z = nz + (ddz / dd) * 8; }
          }
        }
        if (f.kind === 'soldier' && d < 260) { // ranged poke
          f.fireT -= dt;
          if (f.fireT <= 0) { f.fireT = 1.15; this.hurt(g, 6, 'UNDER FIRE'); }
        }
        if (d < (f.kind === 'police' ? 34 : f.kind === 'boss' ? 30 : 22)) {
          const why = f.kind === 'zombie' ? 'A ZOMBIE TEARS AT YOU' : f.kind === 'dog' ? 'A DOG LUNGES AT YOU' : f.kind === 'boss' ? 'THE TYRANT SWIPES' : f.kind === 'stalker' ? 'THE STALKER STRIKES' : f.kind === 'police' ? 'BUSTED BY THE COPS' : 'ENEMY CONTACT';
          this.hurt(g, f.dmg, why);
        }
      }
      // waves goal: clear the wave to advance
      if (SPEC.goal === 'waves' && g.foes.length === 0) {
        g.goal.wave += 1;
        g.addScore(100 * (g.goal.wave - 1));
        P.msg = `WAVE ${g.goal.wave} INCOMING`; P.msgT = 2.4;
        g.audio.chord([392, 523, 659], 0.16, 'triangle', 0.12);
        this.spawnWave(g);
      }
    }

    /* ---- goals ---- */
    if (SPEC.goal === 'collect') {
      for (let i = g.items.length - 1; i >= 0; i -= 1) {
        const it = g.items[i];
        if (g.dist(it.x, it.z, P.x, P.z) < 26) {
          g.items.splice(i, 1);
          g.goal.collected += 1; g.addScore(50);
          g.audio.chord([523, 659, 784], 0.12, 'triangle', 0.1);
          g.burst(g.width / 2, g.height * 0.55, 16, '#ffffff', 260);
          P.msg = g.rails ? `SCRAP ${g.goal.collected}/15 (+$50)` : `SECURED ${g.goal.collected}/12 (+$50)`;
          P.msgT = 1.6;
          if ((g.rails && g.goal.collected >= 15) || (!g.rails && g.goal.collected >= 12)) {
            g.addScore(500); g.gameOver(`ALL CARGO SECURED — the ${g.rails ? 'train rolls on' : 'city is yours'}`); return;
          }
          g.items.push(this.spawnPoint(g, true));
        }
      }
    } else if (SPEC.goal === 'escape' && g.marker) {
      /* crests: the gate stays sealed until all three are found */
      for (let i = g.crests.length - 1; i >= 0; i -= 1) {
        const cr = g.crests[i];
        if (g.dist(cr.x, cr.z, P.x, P.z) < 26) {
          g.crests.splice(i, 1);
          g.goal.crests += 1; g.addScore(80);
          g.audio.chord([659, 784, 988], 0.16, 'triangle', 0.12);
          g.burst(g.width / 2, g.height * 0.55, 18, '#ffffff', 300);
          if (g.goal.crests >= 3) {
            this.spawnBoss(g);
            P.msg = 'THE GATE IS UNSEALED — and something enormous just woke up'; P.msgT = 3.4;
          } else {
            P.msg = `CREST ${g.goal.crests}/3 (+$80) — the gate needs all three`; P.msgT = 2.2;
          }
        }
      }
      /* scarce supplies: herbs bind wounds, ammo boxes refill the magazine */
      for (let i = g.pickups.length - 1; i >= 0; i -= 1) {
        const pk = g.pickups[i];
        if (g.dist(pk.x, pk.z, P.x, P.z) < 22) {
          g.pickups.splice(i, 1);
          if (pk.kind === 'herb') { P.hp = Math.min(100, P.hp + 30); P.msg = 'GREEN HERB — wounds bound (+30 HP)'; }
          else { P.ammo = 12; P.reload = 0; P.msg = 'AMMO BOX — magazine refilled'; }
          g.addScore(10); P.msgT = 1.8;
          g.audio.chord([523, 659], 0.1, 'triangle', 0.09);
        }
      }
      const d = g.dist(g.marker.x, g.marker.z, P.x, P.z);
      if (d < 34) {
        if (g.goal.crests >= 3) { g.addScore(700); g.gameOver('YOU ESCAPED THE DARK — the gate slams behind you'); return; }
        if (P.msgT <= 0) {
          P.msg = `THE GATE IS SEALED — ${3 - g.goal.crests} CREST${3 - g.goal.crests === 1 ? '' : 'S'} MISSING`; P.msgT = 1.2;
          g.audio.beep(140, 0.15, 'sawtooth', 0.09, -40);
        }
      } else if (Math.floor(g.time * 2) % 2 === 0 && P.msgT <= 0) { P.msg = `EXIT ${Math.round(d)}m — run`; P.msgT = 0.4; }
      /* heartbeat when the tyrant is near */
      if (g.boss && g.foes.indexOf(g.boss) >= 0) {
        g.heartT -= dt;
        const bd = g.dist(g.boss.x, g.boss.z, P.x, P.z);
        if (bd < 260 && g.heartT <= 0) { g.heartT = bd < 120 ? 0.45 : 0.9; g.audio.beep(70, 0.07, 'sine', 0.12); }
      }
    } else if (SPEC.goal === 'deliver') {
      const M = g.goal;
      if (M.phase === 'go' && g.marker) {
        if (g.dist(g.marker.x, g.marker.z, P.x, P.z) < 40) {
          M.phase = 'drop';
          g.dropoff = this.spawnPoint(g, true);
          M.timer = 30 + g.dist(g.marker.x, g.marker.z, g.dropoff.x, g.dropoff.z) / 26;
          g.audio.chord([523, 659], 0.12, 'triangle', 0.1);
          P.msg = 'CARGO ABOARD — reach the drop, clock is running'; P.msgT = 2.4;
        }
      } else if (M.phase === 'drop' && g.dropoff) {
        M.timer -= dt;
        if (g.dist(g.dropoff.x, g.dropoff.z, P.x, P.z) < 40) {
          M.delivered += 1;
          const reward = 120 + (M.delivered - 1) * 80;
          g.addScore(reward);
          g.audio.chord([523, 659, 784], 0.16, 'triangle', 0.12);
          P.msg = `DELIVERED +$${reward} (${M.delivered}/3)`; P.msgT = 2.4;
          if (M.delivered >= 3) { g.addScore(600); g.gameOver('ALL DELIVERIES COMPLETE — the city belongs to you'); return; }
          M.phase = 'go'; g.marker = this.spawnPoint(g, true); g.dropoff = null;
        } else if (M.timer <= 0) {
          P.msg = 'MISSED — the buyer walked'; P.msgT = 2.4;
          g.audio.beep(160, 0.2, 'sawtooth', 0.1, -60);
          M.phase = 'go'; g.marker = this.spawnPoint(g, true); g.dropoff = null;
        }
      }
    }
  },

  draw(g) {
    const P = g.P3;
    const K3 = globalThis.GameKit3D || (typeof window !== 'undefined' ? window.GameKit3D : null);
    if (g.state === 'over') { g.drawGameOver(); return; }
    if (!K3) { g.text('engine3d.js missing', g.width / 2, g.height / 2, 18, '#fff', 'center'); return; }

    const camera = {
      pos: [P.x, P.y, P.z], yaw: P.yaw, pitch: P.pitch,
      fov: 74, aspect: g.width / g.height, near: 5, far: 2400,
      width: g.width, height: g.height
    };
    const faces = [];
    const near = (x, z, r) => {
      const dz = g.rails ? Math.min(Math.abs(z - P.z), g.ws - Math.abs(z - P.z)) : Math.abs(z - P.z);
      return Math.hypot(x - P.x, dz) < r;
    };

    /* world */
    for (const t of g.tiles3) if (near(t.x + t.s / 2, t.z + t.s / 2, 1200)) faces.push(K3.groundFace(t.x, t.z, t.s, t.color));
    for (const b of g.solids) if (near(b.x0 + b.w / 2, b.z0 + b.d / 2, 1100)) faces.push(...K3.boxFaces(b.x0, 0, b.z0, b.w, b.h, b.d, b.base));
    if (g.rails) {
      for (let i = -4; i < 16; i += 1) { // sleepers around the player (wrapped)
        let z = (Math.floor(P.z / 40) + i) * 40;
        const zz = ((z % g.ws) + g.ws) % g.ws;
        if (!near(0, zz, 700)) continue;
        faces.push(...K3.boxFaces(-72, 0.5, zz - 4, 144, 1.5, 8, 0.3));
        faces.push(...K3.boxFaces(-56, 1.5, zz - 2.5, 4, 3, 5, 0.5)); // rails
        faces.push(...K3.boxFaces(52, 1.5, zz - 2.5, 4, 3, 5, 0.5));
      }
      // the player's train engine
      faces.push(...K3.boxFaces(P.x - 22, 4, P.z - 46, 44, 30, 92, 0.8));
      faces.push(...K3.boxFaces(P.x - 14, 34, P.z - 20, 28, 14, 34, 0.62));
    }

    /* items + markers */
    for (const it of g.items) {
      if (!near(it.x, it.z, 620)) continue;
      const bob = 16 + Math.sin(g.time * 3 + it.x) * 3;
      for (const f of K3.boxFaces(it.x - 6, bob, it.z - 6, 12, 12, 12, 0.98)) faces.push(K3.rotateFaceY(f, it.x, it.z, g.time * 2));
    }
    for (const cr of g.crests) { // key items: spinning bright shards
      if (!near(cr.x, cr.z, 620)) continue;
      const bob = 14 + Math.sin(g.time * 2.4 + cr.z) * 3;
      for (const f of K3.boxFaces(cr.x - 5, bob, cr.z - 5, 10, 16, 10, 1.0)) faces.push(K3.rotateFaceY(f, cr.x, cr.z, g.time * 3));
    }
    for (const pk of g.pickups) { // herbs (small) and ammo boxes (flat)
      if (!near(pk.x, pk.z, 520)) continue;
      if (pk.kind === 'herb') faces.push(...K3.boxFaces(pk.x - 4, 2, pk.z - 4, 8, 8, 8, 0.55));
      else if (pk.kind === 'bottle') faces.push(...K3.boxFaces(pk.x - 3, 2, pk.z - 3, 6, 15, 6, 0.92));
      else faces.push(...K3.boxFaces(pk.x - 5, 2, pk.z - 5, 10, 7, 10, 0.8));
    }
    const mark = SPEC.goal === 'deliver' && g.goal.phase === 'drop' ? g.dropoff : g.marker;
    if (mark) {
      if (near(mark.x, mark.z, 1400)) {
        const sealed = SPEC.goal === 'escape' && g.goal.crests < 3; // a sealed gate barely reflects light
        faces.push(...K3.boxFaces(mark.x - 7, 0, mark.z - 7, 14, 74 + Math.sin(g.time * 4) * 5, 14, sealed ? 0.32 : 0.95));
      }
    }

    /* enemies */
    for (const f of g.foes) {
      if (!near(f.x, f.z, 700)) continue;
      const bob = f.kind === 'zombie' ? Math.sin(f.t * 6) * 1.4 : 0;
      if (f.kind === 'police') faces.push(...K3.boxFaces(f.x - f.w / 2, 1, f.z - f.w / 2, f.w, f.h, f.w * 1.9, f.base));
      else if (f.kind === 'dog') faces.push(...K3.boxFaces(f.x - f.w / 2, 1 + Math.abs(Math.sin(f.t * 9)) * 2, f.z - f.w * 0.8, f.w, f.h, f.w * 1.6, f.base));
      else faces.push(...K3.boxFaces(f.x - f.w / 2, bob, f.z - f.w / 2, f.w, f.h, f.w, f.base));
    }
    if (g.hunter) { // the rail stalker: a big weaving horror behind the train
      const hz = P.z - g.hunter.gap;
      const wx = Math.sin(g.hunter.weave * 2.2) * 26;
      faces.push(...K3.boxFaces(wx - 34, 6, hz - 50, 68, 46, 100, 0.9));
      faces.push(...K3.boxFaces(wx - 14, 52, hz - 20, 28, 22, 34, 0.98));
      for (let leg = 0; leg < 4; leg += 1) {
        const lx = wx + (leg < 2 ? -46 : 46); const lz = hz - (leg % 2 === 0 ? 34 : 10);
        faces.push(...K3.boxFaces(lx - 4, 0, lz - 4, 8, 40, 8, 0.5));
      }
    }

    /* mud & tire tracks on the ground — winding matches groundFace so they never cull */
    for (const t of g.tracks) {
      if (!near(t.x, t.z, 700)) continue;
      const ca = Math.cos(t.ang); const sa = Math.sin(t.ang);
      const hw = t.w / 2; const hl = t.len / 2;
      const q = (dx, dz) => [t.x + dx * ca - dz * sa, 0.06, t.z + dx * sa + dz * ca];
      faces.push({ verts: [q(-hw, hl), q(hw, hl), q(hw, -hl), q(-hw, -hl)], color: Math.max(0.01, t.a * 0.18), wire: 0 });
    }

    /* crowds + wildlife */
    for (const pd of g.peds) {
      if (!near(pd.x, pd.z, 700)) continue;
      const step = pd.state === 'flee' ? Math.abs(Math.sin(pd.t * 10)) * 1.6 : pd.state === 'workout' ? Math.abs(Math.sin(pd.t * 6)) * 2.2 : (pd.state === 'queue' || pd.state === 'chat' || pd.state === 'attend') ? Math.abs(Math.sin(pd.t * 2)) * 0.3 : Math.abs(Math.sin(pd.t * 4)) * 0.8;
      if (pd.state === 'sit') { // beach par BAITHA ped —leta nahi, baitha hua silhouette
        faces.push(...K3.boxFaces(pd.x - 4, 1, pd.z - 4, 8, 9, 8, 0.6));
        faces.push(...K3.boxFaces(pd.x - 3, 1, pd.z + 3, 6, 4, 9, 0.55));
      } else {
        faces.push(...K3.boxFaces(pd.x - 3.5, step, pd.z - 3.5, 7, 17, 7, pd.state === 'flee' ? 0.82 : pd.role ? 0.95 : 0.62));
      }
    }
    for (const ga of g.gators) {
      if (!near(ga.x, ga.z, 800)) continue;
      const ride = 0.4 + Math.sin(ga.t * 2) * 0.3; // it rides the swell
      for (const f of K3.boxFaces(ga.x - 5, ride, ga.z - 17, 10, 6, 34, 0.42)) faces.push(K3.rotateFaceY(f, ga.x, ga.z, ga.dir));
      for (const f of K3.boxFaces(ga.x - 4, ride + 0.8, ga.z - 27, 8, 5, 10, 0.5)) faces.push(K3.rotateFaceY(f, ga.x, ga.z, ga.dir));
    }

    /* ---- BODY & CITY LIFE PACK draw (v1.23.0): motorway + buses, named
       shops, landmark names, ships, shipyard (bante hue hulls + crane),
       mine (pit + chalti carts) — sab projected 3D labels ke saath ---- */
    {
      const pendingLabels = [];
      const label = (x, y, z, txt, size, alpha) => { pendingLabels.push([x, y, z, txt, size, alpha]); };
      // MOTORWAY: wide dark strip + dashes + bus shelters
      if (g.motorway && SPEC.world === 'city') {
        const MW = g.motorway;
        const x0m = g.clamp(P.x - 700, 0, g.ws - 200);
        faces.push({ verts: [[x0m, 0.05, MW.z0], [x0m + 900, 0.05, MW.z0], [x0m + 900, 0.05, MW.z1], [x0m, 0.05, MW.z1]], color: 0.16, wire: 0 });
        for (let dx = Math.floor(x0m / 90) * 90; dx < x0m + 900; dx += 90) {
          faces.push({ verts: [[dx, 0.07, 357], [dx + 34, 0.07, 357], [dx + 34, 0.07, 363], [dx, 0.07, 363]], color: 0.42, wire: 0 });
        }
        label(g.clamp(P.x, 200, g.ws - 200), 30, 360, 'VICE MOTORWAY — bus route', 12, 0.5);
        for (const sx of MW.stops) {
          if (!near(sx, 360, 800)) continue;
          faces.push(...K3.boxFaces(sx - 16, 1, 316 - 14, 32, 16, 10, 0.5)); // shelter north side
          faces.push(...K3.boxFaces(sx - 18, 17, 316 - 15, 36, 2, 12, 0.62));
          label(sx, 26, 310, 'BUS STOP', 9, 0.55);
        }
      }
      // BUSES: lambi body, window band, doors (halt par khulti hain)
      for (const bu of (g.buses || [])) {
        if (!near(bu.pos, bu.z, 900)) continue;
        const bl = 58; const bx = bu.pos - bl / 2;
        faces.push(...K3.boxFaces(bx, 6, bu.z - 8, bl, 18, 16, 0.72));
        faces.push(...K3.boxFaces(bx + 4, 16, bu.z - 7.4, bl - 8, 6, 0.6, 0.95)); // window band
        faces.push(...K3.boxFaces(bx + 4, 16, bu.z + 6.8, bl - 8, 6, 0.6, 0.95));
        faces.push(...K3.boxFaces(bx + 4, 1, bu.z - 9, 9, 6, 4, 0.25));
        faces.push(...K3.boxFaces(bx + bl - 13, 1, bu.z - 9, 9, 6, 4, 0.25));
        faces.push(...K3.boxFaces(bx + 4, 1, bu.z + 5, 9, 6, 4, 0.25));
        faces.push(...K3.boxFaces(bx + bl - 13, 1, bu.z + 5, 9, 6, 4, 0.25));
        if (bu.doors > 0.05) faces.push(...K3.boxFaces(bx + 16, 6, bu.z + 8 + bu.doors * 3, 12, 14, 0.8, 0.3)); // khulti doors
        if (bu.state !== 'run') label(bu.pos, 34, bu.z, bu.state === 'halt' ? 'BUS — doors khuli (3s halt)' : 'BUS — doors band ho rahi', 10, 0.7);
        else label(bu.pos, 34, bu.z, 'VICE CITY BUS', 9, 0.45);
      }
      // SHIPS: river barges (containers ke saath) + ocean ship (mast ooncha)
      for (const sh of (g.ships || [])) {
        if (!near(sh.x, sh.z, sh.kind === 'ocean' ? 2600 : 1000)) continue;
        const ride = 0.5 + Math.sin(g.time * 1.4 + sh.x * 0.02) * 0.5;
        if (sh.kind === 'barge') {
          faces.push(...K3.boxFaces(sh.x - 44, 2 + ride, sh.z - 11, 88, 7, 22, 0.4));
          for (let ci = 0; ci < 4; ci += 1) faces.push(...K3.boxFaces(sh.x - 36 + ci * 20, 9 + ride, sh.z - 8, 16, 9, 16, 0.62 + (ci % 2) * 0.1));
          faces.push(...K3.boxFaces(sh.x + (sh.dir > 0 ? 34 : -44), 9 + ride, sh.z - 7, 10, 12, 14, 0.8)); // wheelhouse
        } else {
          faces.push(...K3.boxFaces(sh.x - 90, 3 + ride, sh.z - 16, 180, 16, 32, 0.34));
          for (let ci = 0; ci < 6; ci += 1) faces.push(...K3.boxFaces(sh.x - 78 + ci * 28, 19 + ride, sh.z - 12, 22, 14, 24, 0.55 + (ci % 3) * 0.08));
          faces.push(...K3.boxFaces(sh.x + 58, 19 + ride, sh.z - 10, 24, 26, 20, 0.78));
          faces.push(...K3.boxFaces(sh.x + 68, 45 + ride, sh.z - 2, 3, 55, 3, 0.9)); // mast — deewar ke upar se dikhta hai
          label(sh.x, 108, sh.z, 'MV IRONKEEL — open ocean lane', 11, 0.5);
        }
      }
      // SHIPYARD: drydock, bante hue hulls (stage jitni, utni ribs), crane
      if (g.shipyard && near(g.shipyard.x0 + 135, g.shipyard.z0 + 41, 1400)) {
        const SY = g.shipyard;
        faces.push(...K3.boxFaces(SY.x0, 0.4, SY.z0, SY.w, 1.2, SY.d, 0.2)); // yard floor
        for (const h of SY.hulls) {
          faces.push(...K3.boxFaces(h.x - 62, 1, h.z - 15, 124, 3, 30, 0.3)); // keel block
          const ribs = Math.max(1, Math.round(h.stage * 9));
          for (let ri = 0; ri < ribs; ri += 1) faces.push(...K3.boxFaces(h.x - 58 + ri * 13, 4, h.z - 13, 3, 8 + h.stage * 14, 26, 0.5 + h.stage * 0.2));
          if (h.stage >= 1) faces.push(...K3.boxFaces(h.x - 60, 4, h.z - 14, 120, 22, 28, 0.66)); // mukammal hull
          label(h.x, 34 + h.stage * 20, h.z, `HULL ${h.stage >= 1 ? 'MUKAMMAL' : Math.round(h.stage * 100) + '% bana'}`, 10, 0.7);
        }
        const CR = SY.crane;
        faces.push(...K3.boxFaces(CR.x - 4, 1, CR.z - 4, 8, 96, 8, 0.55)); // tower
        const jx = CR.x + Math.cos(CR.ang) * 56; const jz = CR.z + Math.sin(CR.ang) * 56;
        faces.push(...K3.boxFaces(Math.min(CR.x, jx) - 3, 92, Math.min(CR.z, jz) - 3, Math.abs(jx - CR.x) + 6, 5, Math.abs(jz - CR.z) + 6, 0.6));
        faces.push(...K3.boxFaces(jx - 4, 62 + Math.sin(g.time * 0.7) * 3, jz - 4, 8, 30, 8, 0.35)); // cable + hook block
        label(CR.x, 108, CR.z, 'IRONKEEL SHIPYARD — hulls ASLI mein bante hain', 11, 0.6);
      }
      // MINE: descending pit rings, entrance, gravel, chalti carts on loop
      if (g.mine && near(g.mine.x0 + 150, g.mine.z0 + 95, 1300)) {
        const MN = g.mine;
        faces.push(...K3.boxFaces(MN.x0, 0.3, MN.z0, MN.w, 0.8, MN.d, 0.18)); // yard
        const rings = [[40, 130, 110, 0.28], [70, 150, 130, 0.22], [100, 170, 150, 0.16]];
        for (let ri = 0; ri < rings.length; ri += 1) {
          const [dx, w, d, col] = rings[ri];
          faces.push(...K3.boxFaces(MN.x0 + dx, -ri * 7, MN.z0 + dx * 0.7, w, 7, d, col)); // terrace walls
        }
        faces.push(...K3.boxFaces(MN.entrance.x - 14, 1, MN.entrance.z - 6, 28, 24, 12, 0.1)); // dark mouth
        faces.push(...K3.boxFaces(MN.entrance.x - 16, 24, MN.entrance.z - 8, 32, 4, 16, 0.45)); // timber head
        label(MN.entrance.x, 42, MN.entrance.z, 'BLACKVEIN MINE — andar carts ka kaam chalta hai', 11, 0.65);
        for (let pi = 0; pi < 3; pi += 1) faces.push(...K3.boxFaces(MN.x0 + 200 + pi * 22, 1, MN.z0 + 20 + (pi % 2) * 16, 18, 6 + pi * 2, 18, 0.3)); // gravel piles
        for (const ct of MN.carts) {
          if (ct.x === undefined) continue;
          faces.push(...K3.boxFaces(ct.x - 7, 3, ct.z - 5, 14, 8, 10, 0.7));
          faces.push(...K3.boxFaces(ct.x - 5, 11, ct.z - 4, 10, 5, 8, 0.5)); // ore load
        }
        for (let li = 0; li < MN.loop.length; li += 1) { // cart rails
          const a = MN.loop[li]; const b = MN.loop[(li + 1) % MN.loop.length];
          const rx = Math.min(a.x, b.x); const rz = Math.min(a.z, b.z);
          faces.push(...K3.boxFaces(rx - 1, 0.6, rz - 1, Math.abs(b.x - a.x) + 2, 0.6, Math.abs(b.z - a.z) + 2, 0.24));
        }
      }
      // HOSPITAL (v1.25.0): shell + BADA cross + beds + medicine shelf +
      // pharmacy counter + chalne wale stretchers (roll FSM)
      if (g.hospital && near(g.hospital.x0 + g.hospital.w / 2, g.hospital.z0 + g.hospital.d / 2, 1300)) {
        const H = g.hospital;
        faces.push(...K3.boxFaces(H.x0, 44, H.z0, H.w, 4, H.d, 0.62)); // roof
        faces.push(...K3.boxFaces(H.x0, 0, H.z0, 6, 44, 6, 0.52));
        faces.push(...K3.boxFaces(H.x0 + H.w - 6, 0, H.z0, 6, 44, 6, 0.52));
        faces.push(...K3.boxFaces(H.x0, 0, H.z0 + H.d - 6, 6, 44, 6, 0.52));
        faces.push(...K3.boxFaces(H.x0 + H.w - 6, 0, H.z0 + H.d - 6, 6, 44, 6, 0.52));
        // BADA H-cross (door ke upar)
        faces.push(...K3.boxFaces(H.x0 + H.w / 2 - 4, 50, H.z0 + H.d / 2 - 13, 8, 26, 8, 0.98));
        faces.push(...K3.boxFaces(H.x0 + H.w / 2 - 13, 59, H.z0 + H.d / 2 - 4, 26, 8, 8, 0.98));
        // beds (patient wale par leta hua shape)
        for (const bd of H.beds) {
          faces.push(...K3.boxFaces(bd.x - 10, 4, bd.z - 18, 20, 4, 36, 0.5));
          faces.push(...K3.boxFaces(bd.x - 10, 8, bd.z - 18, 20, 8, 4, 0.6)); // headrest
          if (bd.pat) faces.push(...K3.boxFaces(bd.x - 4, 8.5, bd.z - 10, 8, 4, 24, 0.68)); // patient leta hua
        }
        // MEDICINE SHELF — dawaiyon ki rows
        faces.push(...K3.boxFaces(H.shelf.x - 14, 1, H.shelf.z - 4, 28, 34, 8, 0.45));
        for (let si = 0; si < 3; si += 1) for (let sj = 0; sj < 4; sj += 1) {
          faces.push(...K3.boxFaces(H.shelf.x - 12 + sj * 7, 6 + si * 10, H.shelf.z - 6, 4, 5, 3, 0.9 - ((si + sj) % 3) * 0.12));
        }
        // pharmacy counter
        faces.push(...K3.boxFaces(H.counter.x - 20, 1, H.counter.z - 4, 40, 12, 8, 0.55));
        faces.push(...K3.boxFaces(H.counter.x - 14, 13, H.counter.z - 3, 28, 3, 6, 0.75));
        label(H.x0 + H.w / 2, 74, H.z0 + H.d / 2, 'VICE GENERAL HOSPITAL', 12, 0.8);
        label(H.counter.x, 24, H.counter.z, 'PHARMACY COUNTER — G: dawa $25 (heal 40)', 9, 0.65);
      }
      // STRETCHERS: wheels + patient (jo hai) — roll FSM ki position draw
      for (const st of (g.stretchers || [])) {
        if (!near(st.x, st.z, 900)) continue;
        faces.push(...K3.boxFaces(st.x - 9, 9, st.z - 18, 18, 3, 36, 0.6));
        faces.push(...K3.boxFaces(st.x - 7, 1, st.z - 15, 2, 8, 2, 0.3));
        faces.push(...K3.boxFaces(st.x + 5, 1, st.z - 15, 2, 8, 2, 0.3));
        faces.push(...K3.boxFaces(st.x - 7, 1, st.z + 13, 2, 8, 2, 0.3));
        faces.push(...K3.boxFaces(st.x + 5, 1, st.z + 13, 2, 8, 2, 0.3));
        if (st.patient) faces.push(...K3.boxFaces(st.x - 4, 12, st.z - 12, 8, 4, 24, 0.72));
      }
      // SHOPS: facade + awning + darwaza + NAAM (har shop ka apna naam)
      for (const sh of (g.shops || [])) {
        if (!near(sh.x, sh.z, 800)) continue;
        faces.push(...K3.boxFaces(sh.x - 13, 1, sh.z - 10, 26, 26, 20, 0.55));
        faces.push(...K3.boxFaces(sh.x - 15, 25, sh.z - 12, 30, 3, 24, 0.7)); // awning slab
        faces.push(...K3.boxFaces(sh.x - 4, 1, sh.z + 9.4, 8, 15, 1.2, 0.12)); // door
        faces.push(...K3.boxFaces(sh.x - 11, 14, sh.z + 9.6, 6, 8, 0.8, 0.85)); // lit window
        faces.push(...K3.boxFaces(sh.x + 5, 14, sh.z + 9.6, 6, 8, 0.8, 0.85));
        label(sh.x, 40, sh.z, sh.name, 12, 0.85);
        if (sh.kind === 'guns') label(sh.x, 31, sh.z, 'GUN SHOP · ammo $40', 9, 0.6);
      }
      // GYM MACHINES ke naam (qareeb hone par) — busy/free saaf dikhta hai
      for (const m of (g.machines || [])) {
        if (near(m.x, m.z, 460)) label(m.x, 80, m.z, m.busy ? `${m.name} — BUSY` : m.name, 10, 0.7);
      }
      if (g.gym && near(g.gym.x0 + 170, g.gym.z0 + 32, 900)) {
        label(g.gym.x0 + 170, 46, g.gym.z0 - 6, 'IRON BODY GYM — 26 machines/stations (G/X = use karo)', 12, 0.75);
        label(g.gym.x0 + 400, 30, g.gym.z0 + 32, 'FUNCTIONAL TURF (floor work)', 9, 0.5);
      }
      // hospital STAFF ke role labels (doctor/nurse)
      for (const pd of g.peds) {
        if (pd.role && near(pd.x, pd.z, 300)) label(pd.x, 26, pd.z, pd.role === 'doctor' ? 'DOCTOR' : 'NURSE', 8, 0.6);
      }
      // LANDMARK buildings ke naam
      for (const b of g.solids) {
        if (b.name && near(b.x0 + b.w / 2, b.z0 + b.d / 2, 760)) label(b.x0 + b.w / 2, b.h + 14, b.z0 + b.d / 2, b.name, 11, 0.6);
      }
      g.__labels = pendingLabels; // renderScene ke BAAD draw honge (depth sort ke saath)
    }

    /* ---- DETAIL PACK 2 draw: car anatomy, fridge + held + dropped, traffic,
       airport (plane with prop + pilot), heli with rotors, gym, beach ---- */
    {
      const CAR = g.car;
      const isDrive = SPEC.control === 'drive';
      const cx = isDrive ? P.x : CAR.parkedAt.x;
      const cz = isDrive ? P.z : CAR.parkedAt.z;
      if (near(cx, cz, 1000)) {
        if (!isDrive) { // walk worlds: poori parked car (drive worlds mein body pehle se banti hai)
          faces.push(...K3.boxFaces(cx - 22, 4, cz - 46, 44, 30, 92, 0.8));
          faces.push(...K3.boxFaces(cx - 14, 34, cz - 20, 28, 14, 34, 0.62));
        }
        const hoodOpen = CAR.parts.hood.open;
        // HOOD: khulta hua uth kar peeche jhukta hai
        faces.push(...K3.boxFaces(cx - 16, 30 + hoodOpen * 16, cz - 46 + hoodOpen * 6, 32, 4, 30 - hoodOpen * 8, 0.7));
        if (hoodOpen > 0.5) { // ENGINE — chalta engine bright, band engine dull
          faces.push(...K3.boxFaces(cx - 11, 24, cz - 42, 22, 12, 24, CAR.engine.on ? 0.95 : 0.35));
          faces.push(...K3.boxFaces(cx - 4, 36, cz - 36, 8, 5, 8, CAR.engine.on ? 0.9 : 0.3));
        }
        // TRUNK
        faces.push(...K3.boxFaces(cx - 16, 30 + CAR.parts.trunk.open * 18, cz + 30 - CAR.parts.trunk.open * 4, 32, 4, 18, 0.66));
        // DOORS: khuli = bahar swing
        const dL = CAR.parts.doorLF.open; const dR = CAR.parts.doorRF.open;
        faces.push(...K3.boxFaces(cx - 24 - dL * 10, 8, cz - 26, 3, 20, 26, 0.55 + dL * 0.2));
        faces.push(...K3.boxFaces(cx + 21 + dR * 10, 8, cz - 26, 3, 20, 26, 0.55 + dR * 0.2));
        faces.push(...K3.boxFaces(cx - 24 - CAR.parts.doorLR.open * 10, 8, cz + 2, 3, 20, 26, 0.55));
        faces.push(...K3.boxFaces(cx + 21 + CAR.parts.doorRR.open * 10, 8, cz + 2, 3, 20, 26, 0.55));
        // SIDE MIRRORS front doors par — fold ke saath
        faces.push(...K3.boxFaces(cx - 27 - dL * 12, 26, cz - 22, 5, 4, 8, 0.85 - CAR.mirrors.L.fold * 0.2));
        faces.push(...K3.boxFaces(cx + 22 + dR * 12, 26, cz - 22, 5, 4, 8, 0.85 - CAR.mirrors.R.fold * 0.2));
        // FUEL CAP: khula flap = bright
        faces.push(...K3.boxFaces(cx + 18, 22, cz + 24, 5 + CAR.parts.fuelCap.open * 3, 5, 5, CAR.parts.fuelCap.open > 0.5 ? 0.9 : 0.4));
        // 4 wheels
        faces.push(...K3.boxFaces(cx - 22, 1, cz - 36, 8, 9, 8, 0.2));
        faces.push(...K3.boxFaces(cx + 14, 1, cz - 36, 8, 9, 8, 0.2));
        faces.push(...K3.boxFaces(cx - 22, 1, cz + 26, 8, 9, 8, 0.2));
        faces.push(...K3.boxFaces(cx + 14, 1, cz + 26, 8, 9, 8, 0.2));
      }
      // FRIDGE: body + swing door; khuli ho to ANDAR ka saaman dikhta hai
      for (const pr of g.props) {
        if (pr.kind !== 'fridge' || !near(pr.x, pr.z, 700)) continue;
        faces.push(...K3.boxFaces(pr.x - 14, 1, pr.z - 14, 28, 52, 28, 0.75));
        faces.push(...K3.boxFaces(pr.x - 14 - pr.open * 22, 1, pr.z - 15, 4 + pr.open * 10, 52, 30, 0.85));
        if (pr.open > 0.4) {
          pr.items.forEach((it, ii) => {
            if (it.taken) return; // jo nikal chuka wo andar NAHI dikhta — honest
            const iy = 8 + ii * 14;
            if (it.kind === 'bottle') faces.push(...K3.boxFaces(pr.x - 3, iy, pr.z - 3, 6, 13, 6, 0.92));
            else if (it.kind === 'cup') faces.push(...K3.boxFaces(pr.x - 3, iy, pr.z - 3, 7, 8, 7, 0.88));
            else faces.push(...K3.boxFaces(pr.x - 5, iy, pr.z - 5, 10, 8, 10, 0.5));
          });
        }
      }
      // HELD item: haath ke saath, yaw follow, bottle ka slosh jhukao
      if (P.held) {
        const hx = P.x + Math.sin(P.yaw + 1.9) * 10;
        const hz = P.z - Math.cos(P.yaw + 1.9) * 10;
        const hy = P.y - 18 + (P.bottle ? g.clamp(P.bottle.x, -1.2, 1.2) * 3 : 0);
        if (P.held.kind === 'bottle') faces.push(...K3.boxFaces(hx - 3, hy, hz - 3, 6, 15, 6, 0.92));
        else if (P.held.kind === 'cup') faces.push(...K3.boxFaces(hx - 3, hy + 4, hz - 3, 7, 9, 7, 0.88));
        else faces.push(...K3.boxFaces(hx - 4, hy + 4, hz - 4, 9, 8, 9, 0.5));
      }
      // DROPPED items: zameen par pare REAL objects
      for (const d of g.dropped) {
        if (!near(d.x, d.z, 700)) continue;
        if (d.kind === 'bottle') faces.push(...K3.boxFaces(d.x - 3, d.y, d.z - 3, 6, 15, 6, 0.92));
        else if (d.kind === 'cup') faces.push(...K3.boxFaces(d.x - 3, d.y, d.z - 3, 7, 9, 7, 0.88));
        else faces.push(...K3.boxFaces(d.x - 4, d.y, d.z - 4, 9, 8, 9, 0.5));
      }
      // TRAFFIC
      for (const tc of g.traffic) {
        const tx = tc.axis === 'z' ? tc.at : tc.pos;
        const tz = tc.axis === 'z' ? tc.pos : tc.at;
        if (!near(tx, tz, 950)) continue;
        const shade = 0.5 + (tc.at % 7) * 0.03;
        if (tc.axis === 'z') faces.push(...K3.boxFaces(tx - 9, 3, tz - 20, 18, 12, 40, shade));
        else faces.push(...K3.boxFaces(tx - 20, 3, tz - 9, 40, 12, 18, shade));
        faces.push(...K3.boxFaces(tx - 6, 15, tz - 8, 12, 8, 16, 0.7));
        if (tc.brake > 0) faces.push(...K3.boxFaces(tx - 8, 6, tz + (tc.dir > 0 ? -21 : 19), 16, 4, 3, 0.95)); // brake glow
      }
      // AIRPORT: runway + plane (fuselage, wings, tail, spinning prop, PILOT)
      if (g.airport && near(g.airport.x0 + g.airport.len / 2, g.airport.z0, 4200)) {
        faces.push(...K3.boxFaces(g.airport.x0, 0.4, g.airport.z0, g.airport.len, 1, 90, 0.28));
        for (let dx = 40; dx < g.airport.len; dx += 120) faces.push(...K3.boxFaces(g.airport.x0 + dx, 1, g.airport.z0 + 42, 50, 0.6, 6, 0.8));
        for (const pl of g.planes) {
          faces.push(...K3.boxFaces(pl.x - 10, 6 + pl.y, pl.z - 44, 20, 18, 88, 0.9));
          faces.push(...K3.boxFaces(pl.x - 52, 10 + pl.y, pl.z - 8, 104, 5, 16, 0.82));
          faces.push(...K3.boxFaces(pl.x - 3, 22 + pl.y, pl.z + 34, 6, 16, 10, 0.8));
          faces.push(...K3.boxFaces(pl.x - 2, 12 + pl.y, pl.z - 50, 4 + Math.abs(Math.sin(pl.prop)) * 30, 3, 4, 0.95)); // prop disc
          faces.push(...K3.boxFaces(pl.x - 4, 16 + pl.y, pl.z - 24, 8, 9, 8, 0.6)); // pilot
        }
      }
      // HELI: body + tail boom + main rotor blur + pilot
      for (const he of g.helis) {
        const hx = he.x; const hz = he.z; const hy = he.y;
        if (!near(hx, hz, 1800)) continue;
        faces.push(...K3.boxFaces(hx - 12, hy, hz - 20, 24, 20, 40, 0.85));
        faces.push(...K3.boxFaces(hx - 3, hy + 8, hz + 18, 6, 6, 34, 0.7));
        const rb = Math.abs(Math.cos(he.rotor)) * 54 + 8;
        faces.push(...K3.boxFaces(hx - rb, hy + 22, hz - 2, rb * 2, 2, 4, 0.9));
        faces.push(...K3.boxFaces(hx - 2, hy + 22, hz - rb * 0.5, 4, 2, rb, 0.9));
        faces.push(...K3.boxFaces(hx - 5, hy + 8, hz - 12, 10, 10, 10, 0.55)); // pilot
      }
      // GYM: khula building — roof + posts + treadmill + weights rack
      if (g.gym && near(g.gym.x0 + g.gym.w / 2, g.gym.z0 + g.gym.d / 2, 1400)) {
        const GY = g.gym;
        const RW = GY.roofW || GY.w;
        faces.push(...K3.boxFaces(GY.x0, 34, GY.z0, RW, 4, GY.d, 0.6));
        faces.push(...K3.boxFaces(GY.x0, 0, GY.z0, 6, 34, 6, 0.5));
        faces.push(...K3.boxFaces(GY.x0 + RW - 6, 0, GY.z0, 6, 34, 6, 0.5));
        faces.push(...K3.boxFaces(GY.x0, 0, GY.z0 + GY.d - 6, 6, 34, 6, 0.5));
        faces.push(...K3.boxFaces(GY.x0 + RW - 6, 0, GY.z0 + GY.d - 6, 6, 34, 6, 0.5));
        faces.push(...K3.boxFaces(GY.x0 + RW, 0.4, GY.z0, GY.w - RW, 0.8, GY.d, 0.22)); // open-air functional turf floor
        // GYM MACHINES (v1.25.0): 26 stations — har ek ki APNI shape + APNI
        // busy animation (poori duniya ki gym, organized)
        for (const m of (g.machines || [])) {
          const ph = m.phase % 1;
          const sw = m.busy ? Math.sin(ph * Math.PI * 2) : 0; // busy = chalti machine
          const asw = Math.abs(sw);
          if (m.id === 'bench' || m.id === 'incline') { // press: barbell up-down
            faces.push(...K3.boxFaces(m.x - 12, 7, m.z - 5, 24, 5, 10, 0.45));
            if (m.id === 'incline') faces.push(...K3.boxFaces(m.x - 12, 12, m.z - 9, 24, 4, 6, 0.5));
            faces.push(...K3.boxFaces(m.x - 14, 0, m.z - 8, 3, 20, 3, 0.55));
            faces.push(...K3.boxFaces(m.x + 11, 0, m.z - 8, 3, 20, 3, 0.55));
            const by = 22 + sw * 8;
            faces.push(...K3.boxFaces(m.x - 16, by, m.z - 9, 32, 2, 2, 0.85));
            faces.push(...K3.boxFaces(m.x - 19, by - 2, m.z - 10, 4, 6, 4, 0.95));
            faces.push(...K3.boxFaces(m.x + 15, by - 2, m.z - 10, 4, 6, 4, 0.95));
          } else if (m.id === 'fly') { // arm pads swing open/close
            faces.push(...K3.boxFaces(m.x - 6, 6, m.z - 6, 12, 10, 12, 0.4));
            faces.push(...K3.boxFaces(m.x - 14 - asw * 7, 18, m.z - 3, 5, 16, 6, 0.62));
            faces.push(...K3.boxFaces(m.x + 9 + asw * 7, 18, m.z - 3, 5, 16, 6, 0.62));
          } else if (m.id === 'press') { // dumbbells overhead press
            faces.push(...K3.boxFaces(m.x - 8, 8, m.z - 5, 16, 6, 10, 0.42));
            const py = 28 + sw * 12;
            faces.push(...K3.boxFaces(m.x - 12, py, m.z - 2, 6, 6, 6, 0.9));
            faces.push(...K3.boxFaces(m.x + 6, py, m.z - 2, 6, 6, 6, 0.9));
          } else if (m.id === 'curl') { // barbell curls
            faces.push(...K3.boxFaces(m.x - 9, 0, m.z - 4, 18, 3, 8, 0.3));
            const cy = 14 + asw * 14;
            faces.push(...K3.boxFaces(m.x - 13, cy, m.z - 2 + asw * 5, 26, 2, 2, 0.85));
          } else if (m.id === 'pushdown') { // cable handle neeche
            faces.push(...K3.boxFaces(m.x - 3, 0, m.z - 3, 6, 58, 6, 0.5));
            const hy = 48 - asw * 26;
            faces.push(...K3.boxFaces(m.x - 10, hy, m.z - 1, 20, 2, 2, 0.9));
            faces.push(...K3.boxFaces(m.x - 0.6, hy, m.z - 0.6, 1.2, 58 - hy, 1.2, 0.3));
          } else if (m.id === 'pullbar') { // ooncha frame + crossbar
            faces.push(...K3.boxFaces(m.x - 12, 0, m.z - 4, 4, 68, 4, 0.5));
            faces.push(...K3.boxFaces(m.x + 8, 0, m.z - 4, 4, 68, 4, 0.5));
            faces.push(...K3.boxFaces(m.x - 12, 64, m.z - 5, 24, 3, 3, 0.88));
          } else if (m.id === 'lat') { // overhead bar seene tak + weight stack
            faces.push(...K3.boxFaces(m.x - 3, 0, m.z - 6, 6, 62, 6, 0.5));
            faces.push(...K3.boxFaces(m.x - 10, 8, m.z - 2, 20, 8, 8, 0.4));
            const ly = 56 - asw * 24;
            faces.push(...K3.boxFaces(m.x - 14, ly, m.z + 2, 28, 2, 2, 0.9));
            faces.push(...K3.boxFaces(m.x + 5, 10, m.z - 8, 8, 40, 5, 0.55)); // stack
          } else if (m.id === 'row') { // seated cable row — handle peeche kheencha
            faces.push(...K3.boxFaces(m.x - 8, 6, m.z + 2, 16, 6, 12, 0.42));
            faces.push(...K3.boxFaces(m.x - 3, 0, m.z - 14, 6, 34, 6, 0.5));
            faces.push(...K3.boxFaces(m.x - 9, 20 + sw * 3, m.z + 4 + asw * 8, 18, 2, 2, 0.9));
          } else if (m.id === 'shrug') { // barbell shrugs — chhoti lift
            faces.push(...K3.boxFaces(m.x - 8, 0, m.z - 4, 16, 3, 8, 0.3));
            const sy = 22 + asw * 8;
            faces.push(...K3.boxFaces(m.x - 15, sy, m.z - 1, 30, 2, 2, 0.85));
            faces.push(...K3.boxFaces(m.x - 18, sy - 3, m.z - 2, 4, 8, 4, 0.95));
            faces.push(...K3.boxFaces(m.x + 14, sy - 3, m.z - 2, 4, 8, 4, 0.95));
          } else if (m.id === 'tread') { // base + console + chalta belt
            faces.push(...K3.boxFaces(m.x - 10, 2, m.z - 20, 20, 4, 40, 0.4));
            faces.push(...K3.boxFaces(m.x - 8, 6.4, m.z - 18, 16, 0.8, 36, 0.28));
            for (let bi = 0; bi < 3; bi += 1) {
              const boff = m.busy ? ((ph * 36 + bi * 12) % 36) - 18 : bi * 12 - 18;
              faces.push(...K3.boxFaces(m.x - 7, 7.4, m.z + boff, 14, 0.6, 3, 0.62));
            }
            faces.push(...K3.boxFaces(m.x - 9, 6, m.z - 24, 3, 26, 3, 0.5));
            faces.push(...K3.boxFaces(m.x + 6, 6, m.z - 24, 3, 26, 3, 0.5));
            faces.push(...K3.boxFaces(m.x - 9, 30, m.z - 26, 18, 6, 3, m.busy ? 0.9 : 0.55));
          } else if (m.id === 'cycle') { // stationary bike — pedal wheel ghoomta
            faces.push(...K3.boxFaces(m.x - 3, 4, m.z - 12, 6, 4, 26, 0.45));
            faces.push(...K3.boxFaces(m.x - 6, 16, m.z - 6, 12, 4, 8, 0.55));
            faces.push(...K3.boxFaces(m.x - 2, 14, m.z - 16, 4, 14, 4, 0.5));
            faces.push(...K3.boxFaces(m.x - 8, 26, m.z - 18, 16, 5, 3, m.busy ? 0.9 : 0.5));
            const wa = ph * Math.PI * 2;
            faces.push(...K3.boxFaces(m.x - 2 + Math.cos(wa) * 6, 6, m.z + 10 + Math.sin(wa) * 6, 4, 4, 4, 0.85));
          } else if (m.id === 'rower') { // rowing erg — seat rail par slide
            faces.push(...K3.boxFaces(m.x - 3, 5, m.z - 20, 6, 2, 40, 0.4));
            faces.push(...K3.boxFaces(m.x - 6, 7, m.z - 8 + asw * 12, 12, 4, 10, 0.7));
            faces.push(...K3.boxFaces(m.x - 4, 10, m.z - 22, 8, 18, 4, 0.55));
            faces.push(...K3.boxFaces(m.x - 8, 20 - asw * 4, m.z - 12 + asw * 10, 16, 2, 2, 0.9));
          } else if (m.id === 'rack') { // squat rack — bar depth tak
            faces.push(...K3.boxFaces(m.x - 14, 0, m.z - 6, 4, 52, 4, 0.5));
            faces.push(...K3.boxFaces(m.x + 10, 0, m.z - 6, 4, 52, 4, 0.5));
            const ry = 44 - asw * 18;
            faces.push(...K3.boxFaces(m.x - 15, ry, m.z - 7, 30, 2, 2, 0.85));
            faces.push(...K3.boxFaces(m.x - 18, ry - 2, m.z - 8, 4, 6, 4, 0.95));
            faces.push(...K3.boxFaces(m.x + 14, ry - 2, m.z - 8, 4, 6, 4, 0.95));
          } else if (m.id === 'legpress') { // inclined sled slide
            faces.push(...K3.boxFaces(m.x - 10, 4, m.z - 10, 20, 8, 14, 0.42));
            faces.push(...K3.boxFaces(m.x - 9, 14 + asw * 8, m.z + 2 + asw * 8, 18, 3, 16, 0.72));
            faces.push(...K3.boxFaces(m.x + 9, 8, m.z + 2, 6, 30, 6, 0.55));
          } else if (m.id === 'legext') { // shin pad swing
            faces.push(...K3.boxFaces(m.x - 8, 8, m.z - 6, 16, 8, 12, 0.42));
            faces.push(...K3.boxFaces(m.x - 9, 12 + asw * 10, m.z + 6 - asw * 6, 18, 3, 4, 0.8));
          } else if (m.id === 'legcurl') { // prone curl pad
            faces.push(...K3.boxFaces(m.x - 12, 8, m.z - 5, 24, 5, 10, 0.42));
            faces.push(...K3.boxFaces(m.x + 8, 13 + asw * 9, m.z - 4, 5, 3, 8, 0.8));
          } else if (m.id === 'calf') { // standing heel raise
            faces.push(...K3.boxFaces(m.x - 8, 2, m.z - 6, 16, 2, 12, 0.35));
            faces.push(...K3.boxFaces(m.x - 10, 4 + asw * 6, m.z - 2, 20, 3, 3, 0.8));
            faces.push(...K3.boxFaces(m.x - 2, 7, m.z - 4, 4, 44, 4, 0.5));
            faces.push(...K3.boxFaces(m.x - 10, 48, m.z - 4, 20, 4, 8, 0.6));
          } else if (m.id === 'dlplatform') { // platform + zameen se uthta bar
            faces.push(...K3.boxFaces(m.x - 16, 0.5, m.z - 12, 32, 1.5, 24, 0.3));
            const dy = 4 + Math.max(0, sw) * 26;
            faces.push(...K3.boxFaces(m.x - 18, dy, m.z - 2, 36, 2, 2, 0.85));
            faces.push(...K3.boxFaces(m.x - 21, dy - 3, m.z - 3, 5, 8, 5, 0.95));
            faces.push(...K3.boxFaces(m.x + 16, dy - 3, m.z - 3, 5, 8, 5, 0.95));
          } else if (m.id === 'dip') { // parallel bars + body dip
            faces.push(...K3.boxFaces(m.x - 9, 0, m.z - 8, 3, 30, 3, 0.5));
            faces.push(...K3.boxFaces(m.x + 6, 0, m.z - 8, 3, 30, 3, 0.5));
            faces.push(...K3.boxFaces(m.x - 9, 28, m.z - 8, 3, 2, 20, 0.7));
            faces.push(...K3.boxFaces(m.x + 6, 28, m.z - 8, 3, 2, 20, 0.7));
            if (m.busy) faces.push(...K3.boxFaces(m.x - 4, 18 - asw * 9, m.z - 2, 8, 12, 8, 0.85));
          } else if (m.id === 'plankmat' || m.id === 'stretchmat') { // mat + hold wobble
            faces.push(...K3.boxFaces(m.x - 14, 0.8 + asw * 0.4, m.z - 7, 28, 1.4, 14, 0.42));
            if (m.id === 'stretchmat') faces.push(...K3.boxFaces(m.x - 2, 2.4, m.z - 5, 4, 0.8, 10, 0.7));
          } else if (m.id === 'crunchmat') { // hinge pad uthna
            faces.push(...K3.boxFaces(m.x - 14, 0.8, m.z - 7, 28, 1.4, 14, 0.4));
            faces.push(...K3.boxFaces(m.x - 12, 2 + asw * 10, m.z - 6, 10, 2 + asw * 2, 12, 0.62));
          } else if (m.id === 'kbell') { // rack + ek kettlebell swing
            faces.push(...K3.boxFaces(m.x - 12, 1, m.z - 4, 24, 4, 8, 0.4));
            for (let ki = 0; ki < 3; ki += 1) faces.push(...K3.boxFaces(m.x - 10 + ki * 8, 5, m.z - 2, 5, 6, 5, 0.6));
            const kx = m.x + sw * 10; const ky = 8 + (1 - asw) * 14;
            faces.push(...K3.boxFaces(kx - 3, ky, m.z + 4, 6, 7, 6, 0.9));
          } else if (m.id === 'lunge') { // floor markers + stride box
            faces.push(...K3.boxFaces(m.x - 6, 0.4, m.z - 16, 12, 0.8, 32, 0.3));
            faces.push(...K3.boxFaces(m.x - 4, 2 + asw * 3, m.z - 6 + sw * 9, 8, 10, 8, 0.7));
          } else if (m.id === 'burpee') { // floor → jump
            faces.push(...K3.boxFaces(m.x - 10, 0.4, m.z - 10, 20, 0.8, 20, 0.3));
            if (m.busy) faces.push(...K3.boxFaces(m.x - 4, 1 + Math.max(0, sw) * 22, m.z - 4, 8, 14, 8, 0.85));
          }
        }
      }
      // BEACH: umbrellas, towels, LETE hue sunbathers, bouncing ball
      if (g.beach && near(g.beach.x0, g.beach.z0, 1200)) {
        for (const u of g.beach.umbrellas) {
          faces.push(...K3.boxFaces(u.x - 2, 0, u.z - 2, 4, 40, 4, 0.5));
          faces.push(...K3.boxFaces(u.x - 22, 40, u.z - 22, 44, 5, 44, 0.9));
          faces.push(...K3.boxFaces(u.x - 14, 45, u.z - 14, 28, 4, 28, 0.95));
        }
        for (const t of g.beach.towels) faces.push(...K3.boxFaces(t.x - 12, 0.6, t.z - 6, 24, 1.4, 12, 0.88));
        for (const sb of g.beach.sunbathers) faces.push(...K3.boxFaces(sb.x - 4, 1.6, sb.z - 12, 8, 4, 24, 0.6 + Math.sin(sb.t) * 0.05));
        faces.push(...K3.boxFaces(g.beach.ball.x - 5, 2 + g.beach.ball.y, g.beach.ball.z - 5, 10, 10, 10, 0.95));
      }
    }

    /* water + waves — real vertex displacement, tuned by the forged FX recipe */
    const fxp = (SPEC.fx && SPEC.fx.params) || {};
    const wopts = {
      base: fxp.waterBase === undefined ? 0.26 : fxp.waterBase,
      amp: fxp.waveAmp === undefined ? 1 : fxp.waveAmp,
      wire: fxp.wire === undefined ? 0.12 : fxp.wire
    };
    if (g.rails) { // black water rolls past both sides of the track
      faces.push(...K3.waterMesh(-760, P.z - 500, 600, 1000, 10, g.time, wopts));
      faces.push(...K3.waterMesh(160, P.z - 500, 600, 1000, 10, g.time, wopts));
    } else if (SPEC.world === 'city') {
      // the river crossing the city (swim it, dive it, drown in it) + the bay beyond the skyline
      faces.push(...K3.waterMesh(g.clamp(P.x - 480, -160, g.ws - 320), 700, 960, 200, 12, g.time, wopts));
      faces.push(...K3.waterMesh(g.ws, P.z - 600, 760, 1200, 8, g.time, wopts));
      for (const b of g.bridges) {
        if (near(b.x0 + b.w / 2, b.z0 + b.d / 2, 900)) faces.push(...K3.boxFaces(b.x0, 0.5, b.z0, b.w, 3, b.d, 0.5));
      }
    }

    const atm = SPEC.atmosphere || {};
    K3.renderScene(g.ctx, {
      camera, faces,
      fogNear: atm.fogNear === undefined ? 170 : atm.fogNear,
      fogFar: (atm.fogFar === undefined ? 900 : atm.fogFar) * (1 - 0.18 * g.weather.intensity), // storms close the world in
      ambient: atm.ambient === undefined ? 0.34 : atm.ambient,
      light: atm.ambient < 0.25 ? [-0.3, 0.55, -0.45] : [-0.45, 0.82, -0.38]
    });

    /* city-life 3D labels — shop/landmark/bus/ship NAAM, scene ke baad draw
       (faces ke neeche dabte nahi), depth ke hisab se size, door = fade */
    if (g.__labels && g.__labels.length) {
      const shots = [];
      for (const L of g.__labels) {
        const lp = K3.projectPoint(camera, [L[0], L[1], L[2]]);
        if (!lp || lp.depth > 640) continue;
        shots.push({ d: lp.depth, x: lp.x, y: lp.y, txt: L[3], size: L[4], alpha: L[5] });
      }
      shots.sort((a, b) => b.d - a.d); // door wale pehle, qareebi naam upar
      for (const s of shots) {
        const sc = Math.max(7, Math.min(s.size || 12, 340 / s.d * 9));
        const a = Math.max(0.15, Math.min(1, (s.alpha === undefined ? 0.75 : s.alpha) * (1 - s.d / 900)));
        g.text(s.txt, s.x, s.y, sc, `rgba(245,244,240,${a.toFixed(2)})`, 'center', 700);
      }
    }

    /* ripple rings — projected onto the water plane, damped as they expand */
    if (g.ripples && g.ripples.length) {
      const rc = g.ctx;
      for (const r of g.ripples) {
        const rp = K3.projectPoint(camera, [r.x, 0.7, r.z]);
        if (!rp) continue;
        const rad = Math.max(1.5, r.r * 300 / rp.depth);
        rc.strokeStyle = `rgba(245,244,240,${Math.max(0, Math.min(0.6, r.a)).toFixed(3)})`;
        rc.beginPath();
        if (rc.ellipse) rc.ellipse(rp.x, rp.y, rad, rad * 0.38, 0, 0, Math.PI * 2);
        else rc.arc(rp.x, rp.y, rad, 0, Math.PI * 2);
        rc.stroke();
      }
    }

    /* post FX — the software "shader" pass, tuned by the forged recipe */
    if (K3.postFX) {
      const dark = atm.ambient !== undefined && atm.ambient < 0.25;
      K3.postFX(g.ctx, g.width, g.height, {
        vignette: (SPEC.world === 'mansion' ? 0.5 : SPEC.world === 'rails' ? 0.4 : 0.22) + (fxp.vignetteBoost || 0),
        grain: (dark ? 80 : 26) + Math.round((fxp.grain || 0) / 3),
        scanlines: SPEC.world === 'mansion' ? 0.05 : 0,
        tint: fxp.tint || null,
        frame: g.frame
      });
      /* storm lightning — recipe-driven full-frame flashes + delayed thunder */
      if (fxp.storm && g.frame % 173 < 2) {
        g.ctx.fillStyle = 'rgba(245,244,240,.14)';
        g.ctx.fillRect(0, 0, g.width, g.height);
        if (g.flashT === undefined || g.time - g.flashT > 4) { g.flashT = g.time; g.audio.noise(0.5, 0.5, 70); }
      }
      /* rising embers — heat convection motes for lava/storm recipes */
      if (fxp.embers) {
        g.ctx.fillStyle = 'rgba(245,244,240,.18)';
        for (let i = 0; i < 26; i += 1) {
          const ex = (i * 173 + g.frame * 0.9 + Math.sin(i * 2.3 + g.time) * 14) % g.width;
          const ey = g.height - ((i * 97 + g.frame * 1.7) % g.height);
          g.ctx.fillRect(ex, ey, 1.6, 1.6);
        }
      }
    }

    /* rain — driven by the weather cell: intensity sets the count, wind slants the streaks */
    if ((atm.rain && g.weather.intensity > 0.08) || g.weather.intensity > 0.35) {
      const c = g.ctx;
      const drops = Math.round(14 + g.weather.intensity * 62);
      const slant = (g.weather.wind - 0.4) * 14;
      c.strokeStyle = `rgba(245,244,240,${(0.12 + g.weather.intensity * 0.22).toFixed(3)})`;
      for (let i = 0; i < drops; i += 1) {
        const rx = ((i * 173 + g.frame * 13) % g.width);
        const ry = ((i * 337 + g.frame * (21 + Math.round(g.weather.intensity * 16))) % g.height);
        c.beginPath(); c.moveTo(rx, ry); c.lineTo(rx - 2 + slant, ry + 13); c.stroke();
      }
    }

    /* seabirds wheeling overhead — even the sky is alive */
    {
      const bc = g.ctx;
      bc.strokeStyle = 'rgba(245,244,240,.5)';
      for (const b of g.birds) {
        const bx = P.x + Math.cos(b.ang + g.time * b.spd) * b.r;
        const bz = P.z + Math.sin(b.ang + g.time * b.spd) * b.r;
        const bp = K3.projectPoint(camera, [bx, b.h, bz]);
        if (!bp) continue;
        const flap = Math.sin(g.time * 9 + b.ang * 5) * 3;
        const bs = Math.max(1.5, 240 / bp.depth);
        bc.beginPath();
        bc.moveTo(bp.x - bs, bp.y + flap); bc.lineTo(bp.x, bp.y); bc.lineTo(bp.x + bs, bp.y + flap);
        bc.stroke();
      }
    }

    /* web line while swinging */
    if (P.swinging && P.anchor) {
      const K3p = K3.projectPoint(camera, [P.anchor.x, P.anchor.y, P.anchor.z]);
      if (K3p) {
        g.ctx.strokeStyle = 'rgba(245,244,240,.9)';
        g.ctx.beginPath(); g.ctx.moveTo(g.width / 2, g.height / 2 + 40); g.ctx.lineTo(K3p.x, K3p.y); g.ctx.stroke();
      }
    }

    /* ---- HUD ---- */
    const c = g.ctx;
    c.strokeStyle = 'rgba(245,244,240,.85)';
    c.beginPath();
    c.moveTo(g.width / 2 - 9, g.height / 2); c.lineTo(g.width / 2 + 9, g.height / 2);
    c.moveTo(g.width / 2, g.height / 2 - 9); c.lineTo(g.width / 2, g.height / 2 + 9);
    c.stroke();
    for (let i = 0; i < 10; i += 1) g.rect(16 + i * 13, g.height - 24, 10, 12, i * 10 < P.hp ? '#ffffff' : 'rgba(245,244,240,.16)');
    if (P.inWater || P.o2 < 100) { // breath meter
      for (let i = 0; i < 8; i += 1) g.rect(16 + i * 11, g.height - 42, 8, 5, i * 12.5 < P.o2 ? 'rgba(245,244,240,.85)' : 'rgba(245,244,240,.14)');
      g.text(P.diving ? 'DIVING — release C for air' : P.inWater ? 'IN WATER — hold C to dive' : 'BREATH', 16, g.height - 54, 9, 'rgba(245,244,240,.6)', 'left', 600);
    }
    if (P.bottle) { // the carried bottle: its waterline TILTS with the slosh spring
      const bx = g.width - 74; const by = g.height - 128; const bw = 32; const bh = 58;
      c.strokeStyle = 'rgba(245,244,240,.75)';
      c.strokeRect(bx + 0.5, by + 0.5, bw, bh);
      const lvl = by + bh * (1 - 0.72 * P.bottle.fill);
      const tilt = g.clamp(P.bottle.x, -1.2, 1.2) * (bw * 0.45);
      c.save();
      c.beginPath(); c.rect(bx + 1, by + 1, bw - 2, bh - 2); c.clip();
      c.fillStyle = 'rgba(245,244,240,.45)';
      c.beginPath();
      c.moveTo(bx, lvl + tilt); c.lineTo(bx + bw, lvl - tilt);
      c.lineTo(bx + bw, by + bh); c.lineTo(bx, by + bh); c.closePath(); c.fill();
      c.restore();
      g.text(`BOTTLE ${Math.round(P.bottle.fill * 100)}%`, bx + bw / 2, by - 9, 9, 'rgba(245,244,240,.55)', 'center', 600);
    }
    let goalText = '';
    if (SPEC.goal === 'waves') goalText = `WAVE ${g.goal.wave} · FOES ${g.foes.length} · KILLS ${g.goal.kills}`;
    if (SPEC.goal === 'collect') goalText = g.rails ? `SCRAP ${g.goal.collected}/15` : `CARGO ${g.goal.collected}/12`;
    if (SPEC.goal === 'escape' && g.marker) goalText = g.goal.crests >= 3 ? `GATE OPEN — RUN ${Math.round(g.dist(g.marker.x, g.marker.z, P.x, P.z))}m` : `CRESTS ${g.goal.crests}/3 · EXIT ${Math.round(g.dist(g.marker.x, g.marker.z, P.x, P.z))}m`;
    if (SPEC.goal === 'deliver') goalText = g.goal.phase === 'drop' ? `DELIVER ${Math.ceil(Math.max(0, g.goal.timer))}s · ${g.goal.delivered}/3` : `REACH PICKUP · ${g.goal.delivered}/3`;
    g.text(goalText, g.width / 2, g.height - 20, 13, 'rgba(245,244,240,.85)', 'center', 700);
    g.text(`${SPEC.control.toUpperCase()} · ${SPEC.enemy.toUpperCase()}`, 16, g.height - 42, 11, 'rgba(245,244,240,.55)', 'left', 600);
    if (SPEC.weapon === 'hitscan') {
      g.text(P.reload > 0 ? 'RELOADING…' : `AMMO ${P.ammo}/12`, g.width - 16, g.height - 24, 14, '#ffffff', 'right', 800);
    }
    if (SPEC.control === 'train' || SPEC.control === 'drive') g.text(`${Math.round(Math.abs(P.speed))} km/h`, g.width - 16, g.height - 46, 12, 'rgba(245,244,240,.7)', 'right', 600);
    if (g.weather.intensity > 0.55) g.text(`STORM ${Math.round(g.weather.intensity * 100)}% · WIND`, g.width / 2, 24, 11, 'rgba(245,244,240,.6)', 'center', 600);
    /* Detail Pack 2 HUD: fuel/engine (drive), held item, fridge hint */
    if (SPEC.control === 'drive') {
      const CARH = g.car;
      g.text(`FUEL ${Math.round(CARH.fuel)}% · ENGINE ${CARH.engine.on ? `${Math.round(CARH.engine.rpm)} rpm ${Math.round(CARH.engine.temp)}C` : 'OFF'}`, 16, 24, 11, 'rgba(245,244,240,.65)', 'left', 600);
    }
    if (P.held) {
      const f = P.held.kind === 'bottle' ? `${Math.round((P.held.fill ?? 0) * 100)}%` : P.held.kind === 'cup' ? `${Math.round(P.held.fill ?? 0)}` : '';
      g.text(`HAATH: ${P.held.kind.toUpperCase()} ${f} · H=drop V=drink`, g.width - 16, 64, 10, 'rgba(245,244,240,.6)', 'right', 600);
    }
    if (g.props.some((pr) => pr.kind === 'fridge' && g.dist(pr.x, pr.z, P.x, P.z) < 34)) {
      g.text('G — fridge kholo/band · T — item uthao (saaman ANDAR pehle se hai)', g.width / 2, 64, 11, 'rgba(245,244,240,.7)', 'center', 600);
    }
    /* BODY & CITY LIFE HUD (v1.23.0): muscle map + strength + shop hint */
    if (g.body) {
      const BH = g.body;
      const exNow = EXERCISES[BH.exercise % EXERCISES.length];
      const mode = BH.active ? `${exNow.name} rep ${BH.reps}` : BH.ambient ? BH.ambient.toUpperCase() : 'REST (recovery)';
      g.text(`BODY LV${BH.level} · STR ${BH.strength} · XP ${Math.round(BH.xp)}/${BH.level * 80} · ${mode}`, 16, 44, 10, 'rgba(245,244,240,.68)', 'left', 600);
      const ranked = MUSCLE_LIST.map((mn) => ({ mn, mu: BH.muscles[mn] })).sort((a, b) => (b.mu.s + b.mu.f) - (a.mu.s + a.mu.f)).slice(0, 3);
      ranked.forEach((r, i) => {
        const n = Math.round(r.mu.s * 8);
        const bar = '[' + '#'.repeat(Math.max(0, Math.min(8, n))) + '-'.repeat(Math.max(0, 8 - Math.max(0, Math.min(8, n)))) + ']';
        g.text(`${r.mn} STRETCH ${bar} ${Math.round(r.mu.s * 100)}% · FATIGUE ${Math.round(r.mu.f * 100)}%`, 16, 58 + i * 12, 9, 'rgba(245,244,240,.55)', 'left', 600);
      });
      if (BH.active) g.text('X — set BAND karo → relax + recovery (fatigue utarti hai)', 16, 96, 9, 'rgba(245,244,240,.5)', 'left', 600);
    }
    {
      const nearShop = (g.shops || []).find((sh) => g.dist(sh.dx, sh.dz, P.x, P.z) < 30);
      if (nearShop) {
        const stock = nearShop.stock || { guns: 'AMMO $40', mart: 'BOTTLE $10', cafe: 'CUP $8', mechanic: 'REFUEL $30', clothes: 'OUTFIT $15' }[nearShop.kind] || 'stock';
        g.text(`G — ${nearShop.name}: ${stock} (cash = score)`, g.width / 2, 84, 11, 'rgba(245,244,240,.78)', 'center', 600);
      }
      const nearM = (g.machines || []).find((mm) => g.dist(mm.x, mm.z, P.x, P.z) < 30);
      if (nearM) {
        const exM = EXERCISES[nearM.ex];
        const occ = nearM.busy && nearM.busy !== 'player' ? ' — OCCUPIED (wait karo)' : '';
        g.text(`G/X — ${nearM.name}: ${exM.name} → ${exM.prime.join(' + ')} stretch/relax${occ}`, g.width / 2, 100, 10, 'rgba(245,244,240,.75)', 'center', 600);
      }
    }
    if (g.hunter) g.text(`HUNTER ${Math.round(g.hunter.gap)}m BEHIND`, g.width / 2, 44, 13, '#ffffff', 'center', 800);
    if (g.boss && g.foes.indexOf(g.boss) >= 0) g.text('THE TYRANT IS AWAKE', g.width / 2, 44, 13, '#ffffff', 'center', 800);
    if (P.msgT > 0) g.text(P.msg, g.width / 2, g.height - 60, 13, '#ffffff', 'center', 700);

    /* minimap for open worlds */
    if (!g.rails) {
      const mw = 120; const mh = 120; const mx = g.width - mw - 14; const my = g.height - mh - 40;
      const s = mw / g.ws;
      c.fillStyle = 'rgba(0,0,0,.6)'; c.fillRect(mx, my, mw, mh);
      c.strokeStyle = 'rgba(245,244,240,.5)'; c.strokeRect(mx + 0.5, my + 0.5, mw - 1, mh - 1);
      c.fillStyle = 'rgba(245,244,240,.13)';
      for (const w of g.waters) if (w.x0 >= 0 && w.x0 < g.ws) c.fillRect(mx + w.x0 * s, my + Math.max(0, w.z0) * s, Math.max(1, w.w * s), Math.max(1, w.d * s));
      c.fillStyle = 'rgba(245,244,240,.25)';
      for (const b of g.solids) c.fillRect(mx + b.x0 * s, my + b.z0 * s, Math.max(1, b.w * s), Math.max(1, b.d * s));
      c.fillStyle = 'rgba(245,244,240,.9)';
      for (const it of g.items) c.fillRect(mx + it.x * s - 1.5, my + it.z * s - 1.5, 3, 3);
      for (const cr of g.crests) c.fillRect(mx + cr.x * s - 1.5, my + cr.z * s - 1.5, 3, 3);
      c.fillStyle = 'rgba(245,244,240,.55)';
      for (const pk of g.pickups) c.fillRect(mx + pk.x * s - 1, my + pk.z * s - 1, 2, 2);
      for (const pd of g.peds) c.fillRect(mx + pd.x * s - 1, my + pd.z * s - 1, 2, 2);
      for (const ga of g.gators) c.fillRect(mx + ga.x * s - 1.5, my + ga.z * s - 1.5, 3, 3);
      c.fillStyle = 'rgba(245,244,240,.9)';
      if (mark) c.fillRect(mx + mark.x * s - 2, my + mark.z * s - 2, 4, 4);
      for (const f of g.foes) c.fillRect(mx + f.x * s - 1, my + f.z * s - 1, 2.5, 2.5);
      c.save(); c.translate(mx + P.x * s, my + P.z * s); c.rotate(P.yaw);
      c.fillStyle = '#ffffff'; c.beginPath(); c.moveTo(0, -5); c.lineTo(3.4, 4); c.lineTo(-3.4, 4); c.closePath(); c.fill();
      c.restore();
    }
  }
});

if (typeof window !== 'undefined') window.__composed3d = g; // test hook
g.__SPEC = SPEC;
