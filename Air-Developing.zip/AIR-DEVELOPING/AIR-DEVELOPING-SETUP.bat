@echo off
setlocal
title AIR DEVELOPING - SETUP
color 0F
cd /d "%~dp0app"
echo.
echo   ==============================================
echo    AIR DEVELOPING 1.26.0  -  SETUP  (Air_you)
echo   ==============================================
echo.
where node >nul 2>nul || (
  echo   [!] Node.js install nahi hai - nodejs.org se LTS install karo,
  echo       phir ye file dobara double-click karo.
  pause
  exit /b 1
)
if not exist node_modules (
  echo   [1/2] Pehli baar: dependencies install ho rahi hain ^(2-4 minute^)...
  call npm install --no-audit --no-fund
) else (
  echo   [1/2] Dependencies pehle se majood hain - skip.
)
echo   [2/2] Sab tayyar.
echo.
echo   Kya karna hai?
echo     [1] AIR DEVELOPING app abhi chalao ^(desktop window^)
echo     [2] Windows .exe installer banao ^(release\ folder mein^)
echo     [3] Browser mein kholo ^(localhost preview^)
echo     [Q] Band karo
echo.
set /p CHOICE=  Apna choice likho ^(1/2/3/Q^): 
if /i "%CHOICE%"=="1" goto runapp
if /i "%CHOICE%"=="2" goto makexe
if /i "%CHOICE%"=="3" goto browser
goto end
:runapp
echo.
echo   App build + desktop window khul rahi hai...
call npm start
goto end
:makexe
echo.
echo   .exe installer ban rahi hai (pehli baar 5-10 minute, Electron download)...
call npm run dist:win
echo.
echo   DONE - release\ folder mein .exe installer hai. Us par double-click karo.
pause
goto end
:browser
start "AIR preview" cmd /c "npx vite preview --port 4173 --host 127.0.0.1"
timeout /t 4 >nul
start "" http://127.0.0.1:4173
goto end
:end
endlocal
