@echo off
setlocal EnableDelayedExpansion
title AIR DEVELOPING - SETUP
color 0F
cd /d "%~dp0app"
echo.
echo   ====================================================
echo    AIR DEVELOPING 1.30.0  -  SETUP WIZARD  (Air_you)
echo   ====================================================
echo.
where node >nul 2>nul || (
  echo   [!] Node.js install nahi hai - nodejs.org se LTS install karo,
  echo       phir ye file dobara double-click karo.
  pause
  exit /b 1
)
echo   INSTALL OPTIONS - kya kya enable karna chahte ho?
echo     [1] FULL INSTALL  - C:\AIR-DEVELOPING mein copy + DESKTOP
echo         shortcut + Start Menu shortcut + app launch
echo     [2] PORTABLE RUN  - kahin copy nahi, abhi isi folder se chalao
echo     [3] BUILD NATIVE .EXE INSTALLER - release\ mein Setup.exe
echo         (electron-builder; pehli baar 5-10 minute)
echo     [4] BROWSER PREVIEW - localhost par kholo
echo     [Q] Band karo
echo.
set /p CHOICE=  Apna choice likho (1/2/3/4/Q): 
if /i "%CHOICE%"=="1" goto install
if /i "%CHOICE%"=="2" goto portable
if /i "%CHOICE%"=="3" goto makexe
if /i "%CHOICE%"=="4" goto browser
goto end

:install
set "DEST=C:\AIR-DEVELOPING"
echo.
echo   [1/4] Files copy ho rahi hain: %DEST%
if not exist "%DEST%" mkdir "%DEST%"
xcopy /E /I /Y /Q "%~dp0app" "%DEST%\app" >nul
copy /Y "%~dp0packaging\AIR-DEVELOPING-START.bat" "%DEST%\AIR-DEVELOPING-START.bat" >nul 2>nul || (
  echo setlocal> "%DEST%\AIR-DEVELOPING-START.bat"
  echo cd /d "%DEST%\app">> "%DEST%\AIR-DEVELOPING-START.bat"
  echo if not exist node_modules call npm install --no-audit --no-fund>> "%DEST%\AIR-DEVELOPING-START.bat"
  echo call npm start>> "%DEST%\AIR-DEVELOPING-START.bat"
)
echo   [2/4] Dependencies (pehli baar 2-4 minute)...
pushd "%DEST%\app"
if not exist node_modules call npm install --no-audit --no-fund
popd
echo   [3/4] DESKTOP + START MENU shortcuts ban rahe hain...
powershell -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\AIR DEVELOPING.lnk'); $s.TargetPath='C:\AIR-DEVELOPING\AIR-DEVELOPING-START.bat'; $s.WorkingDirectory='C:\AIR-DEVELOPING\app'; $s.Description='AIR DEVELOPING - Air_you desktop app'; $s.Save(); $m=$ws.CreateShortcut([Environment]::GetFolderPath('StartMenu')+'\Programs\AIR DEVELOPING.lnk'); $m.TargetPath='C:\AIR-DEVELOPING\AIR-DEVELOPING-START.bat'; $m.WorkingDirectory='C:\AIR-DEVELOPING\app'; $m.Save()"
echo   [4/4] INSTALL FINISH - app desktop shortcut se chal rahi hai...
start "" "%DEST%\AIR-DEVELOPING-START.bat"
echo.
echo   DONE. Desktop par "AIR DEVELOPING" shortcut hai - ab hamesha
echo   wahan se double-click karke chalao.
pause
goto end

:portable
echo.
echo   Dependencies check...
if not exist node_modules call npm install --no-audit --no-fund
call npm start
goto end

:makexe
echo.
echo   Native Windows .exe installer ban rahi hai...
if not exist node_modules call npm install --no-audit --no-fund
call npm run dist:win
echo.
echo   DONE - release\ folder mein Setup.exe hai. Us par double-click:
echo   wizard options (install directory, desktop shortcut) ke saath.
pause
goto end

:browser
start "AIR preview" cmd /c "npx vite preview --port 4173 --host 127.0.0.1"
timeout /t 4 >nul
start "" http://127.0.0.1:4173
goto end

:end
endlocal
