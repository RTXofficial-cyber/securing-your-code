/**
 * Logic tests that run WITHOUT Electron, so they can be verified anywhere.
 * Covers: agent action parsing, path-escape protection, cross-platform
 * command execution, provider registry, and key handling.
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

const agent = require('../shared/agent.cjs');
const providers = require('../shared/providers.cjs');
const { makeWorkspaceHelpers } = require('../electron/workspace.cjs');
const { Terminal } = require('../electron/terminal.cjs');
const orchestrator = require('../shared/orchestrator.cjs');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ds-test-'));
const ws = makeWorkspaceHelpers({ value: tmp });

let pass = 0;
let fail = 0;

async function test(name, fn) {
  try {
    await fn();
    console.log(`  ✓ ${name}`);
    pass++;
  } catch (e) {
    console.log(`  ✗ ${name}\n      ${e.message}`);
    fail++;
  }
}

(async () => {
  console.log('\nAir Developing — logic tests\n');

  console.log('Agent action parsing');
  await test('parses write_file action blocks', () => {
    const acts = agent.parseActions('hi\n```action:write_file\n{"path":"a.js","content":"x"}\n```\nbye');
    assert.strictEqual(acts.length, 1);
    assert.strictEqual(acts[0].type, 'write_file');
    assert.strictEqual(acts[0].path, 'a.js');
  });

  await test('parses multiple actions in order', () => {
    const acts = agent.parseActions(
      '```action:write_file\n{"path":"a.js","content":"1"}\n```\n```action:run_command\n{"command":"node a.js"}\n```'
    );
    assert.strictEqual(acts.length, 2);
    assert.strictEqual(acts[1].type, 'run_command');
    assert.strictEqual(acts[1].command, 'node a.js');
  });

  await test('reports invalid JSON instead of throwing', () => {
    const acts = agent.parseActions('```action:write_file\n{bad json}\n```');
    assert.strictEqual(acts[0].type, 'error');
  });

  await test('stripActions removes blocks but keeps prose', () => {
    const out = agent.stripActions('Hello\n```action:run_command\n{"command":"ls"}\n```\nDone');
    assert.strictEqual(out, 'Hello\n\nDone');
  });

  await test('plain chat yields zero actions', () => {
    assert.strictEqual(agent.parseActions('Just a normal reply with ```js code``` blocks').length, 0);
  });

  console.log('\nWorkspace safety');
  await test('writes and reads a file', () => {
    ws.write('sub/dir/file.txt', 'hello');
    assert.strictEqual(ws.read('sub/dir/file.txt'), 'hello');
  });

  await test('blocks path traversal (../)', () => {
    assert.throws(() => ws.read('../../etc/passwd'), /outside the workspace/);
  });

  await test('blocks absolute path escape', () => {
    assert.throws(() => ws.write(os.tmpdir() + '/evil.txt', 'x'), /outside the workspace/);
  });

  await test('refuses to delete workspace root', () => {
    assert.throws(() => ws.remove('.'), /Cannot delete the workspace root/);
  });

  await test('tree lists nested files and ignores node_modules', () => {
    ws.write('node_modules/junk/index.js', 'x');
    ws.write('keep.js', 'x');
    const t = ws.tree();
    assert.ok(t.some((n) => n.name === 'keep.js'));
    assert.ok(!t.some((n) => n.name === 'node_modules'));
  });

  console.log('\nCommand execution');
  await test('runs a shell command and captures stdout', async () => {
    const r = await agent.runShell(agent.IS_WIN ? 'echo RUN_OK' : 'echo RUN_OK', tmp);
    assert.strictEqual(r.code, 0);
    assert.match(r.stdout, /RUN_OK/);
  });

  await test('reports non-zero exit codes', async () => {
    const r = await agent.runShell(agent.IS_WIN ? 'exit /b 3' : 'exit 3', tmp);
    assert.notStrictEqual(r.code, 0);
  });

  await test('enforces timeouts', async () => {
    const r = await agent.runShell(agent.IS_WIN ? 'ping -n 6 127.0.0.1' : 'sleep 5', tmp, 400);
    assert.ok(r.timedOut || r.code !== 0, 'expected timeout or failure');
  });

  await test('executeActions writes then runs the file', async () => {
    const results = await agent.executeActions(
      [
        { type: 'write_file', path: 'run-me.js', content: "console.log('AGENT_RAN_OK');" },
        { type: 'run_command', command: 'node run-me.js' }
      ],
      ws
    );
    assert.strictEqual(results[0].ok, true);
    assert.strictEqual(results[1].ok, true, results[1].stderr);
    assert.match(results[1].stdout, /AGENT_RAN_OK/);
  });

  console.log('\nTerminal shell');
  await test('persistent shell keeps cwd between commands', async () => {
    const t = new Terminal({ cwd: tmp });
    t.start();
    const mkdir = agent.IS_WIN ? 'mkdir tdir' : 'mkdir -p tdir';
    await t.run(mkdir);
    const r = await t.run(agent.IS_WIN ? 'cd tdir' : 'cd tdir');
    assert.ok(r.cwd.includes('tdir'), `cwd was ${r.cwd}`);
    const r2 = await t.run(agent.IS_WIN ? 'echo HERE' : 'echo HERE');
    assert.strictEqual(r2.exitCode, 0, 'sentinel/exit code not parsed');
    t.dispose();
  });

  await test('terminal reports exit codes', async () => {
    const t = new Terminal({ cwd: tmp });
    t.start();
    const r = await t.run(agent.IS_WIN ? 'exit /b 7' : 'exit 7');
    // `exit` closes the shell; either the code is captured or the shell exits cleanly
    assert.ok(r.exitCode === 7 || r.killed || r.exitCode === -1, `got ${JSON.stringify(r)}`);
    t.dispose();
  });

  console.log('\nProviders');
  await test('registry exposes 6 providers', () => {
    const list = providers.listProviders();
    assert.strictEqual(list.length, 6);
  });

  await test('built-in engine needs no key and is ready', () => {
    const b = providers.listProviders().find((p) => p.id === 'builtin');
    assert.strictEqual(b.ready, true);
    assert.strictEqual(b.keyEnv, null);
  });

  await test('keyed providers are not ready without a key', () => {
    const a = providers.listProviders().find((p) => p.id === 'anthropic');
    assert.strictEqual(a.ready, Boolean(providers.getKey('ANTHROPIC_API_KEY')));
  });

  await test('chat refuses a provider with no key', async () => {
    providers.setKey('OPENAI_API_KEY', '');
    await assert.rejects(() => providers.chat('openai', 'gpt-4o', [{ role: 'user', content: 'hi' }]), /not connected/);
    // raw HTTP blobs must become human guidance, not JSON walls
    const q = providers.friendlyProviderError(429, '{"error":{"message":"You have no credits remaining.","code":"credit_balance_exhausted"}}');
    assert.match(q, /credits khatam/);
    assert.match(q, /platform\.openai\.com\/settings\/organization\/billing/);
    assert.match(q, /Groq/);
    assert.match(q, /Ollama/);
    const k = providers.friendlyProviderError(401, '{"error":{"message":"Incorrect API key provided","type":"invalid_request_error"}}');
    assert.match(k, /Key invalid/);
    const m = providers.friendlyProviderError(404, '{"error":{"message":"The model `gpt-9` does not exist"}}');
    assert.match(m, /model ID provider par nahi mila/);
    const r = providers.friendlyProviderError(429, '{"error":{"message":"Rate limit reached"}}');
    assert.match(r, /Rate limit/);
  });

  await test('setKey makes a provider ready', () => {
    providers.setKey('OPENAI_API_KEY', 'sk-test-123');
    const p = providers.listProviders().find((x) => x.id === 'openai');
    assert.strictEqual(p.ready, true);
    providers.setKey('OPENAI_API_KEY', '');
  });

  await test('env file loading parses KEY=value lines', () => {
    const f = path.join(tmp, 'dev-studio.env');
    fs.writeFileSync(f, '# comment\nGROQ_API_KEY="gsk_abc"\n\nEMPTY=\n');
    providers.loadKeysFromEnvFile(f);
    assert.strictEqual(providers.getKey('GROQ_API_KEY'), 'gsk_abc');
    providers.setKey('GROQ_API_KEY', '');
  });

  await test('built-in engine returns a real action for a coding request', async () => {
    const reply = await providers.chat('builtin', 'studio-agent-1', [
      { role: 'user', content: 'write a node script that greets me' }
    ]);
    const acts = agent.parseActions(reply);
    assert.ok(acts.some((a) => a.type === 'write_file'), 'expected a write_file action');
  });

  await test('every provider declares models with id+name', () => {
    for (const p of providers.PROVIDERS) {
      assert.ok(Array.isArray(p.models) && p.models.length > 0, `${p.id} has no models`);
      for (const m of p.models) {
        assert.ok(m.id && m.name, `${p.id} model missing id/name`);
      }
    }
  });

  console.log('\nAir_you scaffolds');
  await test('website intent writes a 3-file static site', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'build me a website' }]);
    const acts = agent.parseActions(reply);
    const files = acts.filter((a) => a.type === 'write_file').map((a) => a.path);
    assert.deepStrictEqual(files.sort(), ['app.js', 'index.html', 'styles.css']);
    assert.ok(acts.some((a) => a.type === 'run_command'), 'should verify with a command');
  });

  await test('api intent writes server.js and syntax-checks it', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'create a rest api' }]);
    const acts = agent.parseActions(reply);
    assert.ok(acts.some((a) => a.type === 'write_file' && a.path === 'server.js'));
    assert.ok(acts.some((a) => a.type === 'run_command' && /node --check server\.js/.test(a.command)));
  });

  await test('python intent byte-compiles to verify', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'make a python server' }]);
    const acts = agent.parseActions(reply);
    assert.ok(acts.some((a) => a.type === 'write_file' && a.path === 'app.py'));
    assert.ok(acts.some((a) => a.type === 'run_command' && /py_compile/.test(a.command)));
  });

  await test('cli intent runs the tool after writing it', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'write a cli tool' }]);
    const acts = agent.parseActions(reply);
    assert.ok(acts.some((a) => a.type === 'write_file' && a.path === 'cli.js'));
    assert.ok(acts.filter((a) => a.type === 'run_command').length >= 2, 'expected help + real run');
  });

  await test('games scaffold via Game Studio; todo stays single-file', async () => {
    const g = agent.parseActions(await providers.chat('builtin', null, [{ role: 'user', content: 'make a game' }]));
    const t = agent.parseActions(await providers.chat('builtin', null, [{ role: 'user', content: 'make a todo app' }]));
    assert.ok(g.some((a) => a.type === 'game_new' && a.dir === 'game'), 'games use the Game Studio plugin');
    assert.ok(t.some((a) => a.path === 'todo.html'));
  });

  await test('scaffolded JS is syntactically valid (node --check)', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'build me a website' }]);
    const acts = agent.parseActions(reply);
    const results = await agent.executeActions(acts.filter((a) => a.type === 'write_file'), ws);
    assert.ok(results.every((r) => r.ok));
    const check = await agent.runShell('node --check app.js', tmp);
    assert.strictEqual(check.code, 0, check.stderr);
  });

  await test('scaffolded python compiles', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'make a python server' }]);
    const acts = agent.parseActions(reply);
    await agent.executeActions(acts.filter((a) => a.type === 'write_file'), ws);
    const py = agent.IS_WIN ? 'py' : 'python3';
    const check = await agent.runShell(`${py} -m py_compile app.py`, tmp);
    assert.strictEqual(check.code, 0, check.stderr);
  });

  console.log('\nEnsemble / AI team');
  await test('exposes the four team roles', () => {
    assert.deepStrictEqual(orchestrator.ROLES.map((r) => r.id), ['research', 'plan', 'code', 'review']);
  });

  await test('role provider falls back to builtin when nothing is connected', () => {
    providers.setKey('OPENAI_API_KEY', '');
    providers.setKey('PERPLEXITY_API_KEY', '');
    const p = orchestrator.resolveProvider('research', {});
    assert.strictEqual(p.id, 'builtin');
  });

  await test('role provider honours an explicit override when connected', () => {
    providers.setKey('GROQ_API_KEY', 'gsk_test');
    const p = orchestrator.resolveProvider('code', { code: 'groq' });
    assert.strictEqual(p.id, 'groq');
    providers.setKey('GROQ_API_KEY', '');
  });

  await test('projectContext includes tree and file contents', () => {
    ws.write('ctx-probe.js', 'console.log(1);');
    const ctx = orchestrator.projectContext(ws);
    assert.match(ctx, /FILE TREE/);
    assert.match(ctx, /ctx-probe\.js/);
    assert.match(ctx, /console\.log\(1\)/);
  });

  await test('offline team run completes all four steps and writes code', async () => {
    const r = await orchestrator.runEnsemble({ userText: 'build me a website', ws });
    assert.strictEqual(r.steps.length, 4);
    assert.ok(r.steps.every((s) => s.ok), JSON.stringify(r.steps.map((s) => s.error)));
    assert.deepStrictEqual(r.steps.map((s) => s.role), ['research', 'plan', 'code', 'review']);
    assert.ok(r.actionResults.some((a) => a.type === 'write_file' && a.ok), 'coder should have written files');
    assert.ok(r.actionResults.some((a) => a.type === 'run_command'), 'team should verify by running');
    assert.ok(r.summary.length > 0);
  });

  await test('permissions gate the team coder', async () => {
    const r = await orchestrator.runEnsemble({
      userText: 'build me a website',
      ws,
      permissions: { runCommands: false, writeFiles: false }
    });
    const mutating = r.actionResults.filter((a) => a.type === 'write_file' || a.type === 'run_command');
    assert.strictEqual(mutating.length, 0, 'no writes/runs should execute when blocked');
    assert.strictEqual(r.steps.length, 4);
  });

  await test('team training loop: AI watches other AIs and keeps the lessons', async () => {
    const { ExperienceStore } = require('../shared/experience.cjs');
    const store = new ExperienceStore(path.join(tmp, 'exp-team.json'));
    const goal = 'build me a website with tests';

    // run 1 — offline team only: the run itself is journaled
    await orchestrator.runEnsemble({ userText: goal, ws, experience: store });
    const teamEntry = store.get().find((e) => e.engine === 'team');
    assert.ok(teamEntry, 'team run journaled');
    assert.ok(/research@builtin -> plan@builtin -> code@builtin -> review@builtin/.test(teamEntry.lesson), `role chain journaled: ${teamEntry.lesson}`);
    assert.match(teamEntry.lesson, /reviewer (APPROVED|demanded fixes)/);
    assert.ok(teamEntry.files.length > 0, 'written files journaled');
    assert.strictEqual(teamEntry.ok, true);

    // run 2 — a connected outside model joins: the built-in distills what it did not know
    providers.registerProvider({
      id: 'faketeam', name: 'Fake Team AI', models: [{ id: 'fake-1', name: 'Fake 1' }],
      chat: async () => 'Facts: use zeromq for transport and zeromq queues; playwright for e2e, playwright fixtures; APPROVED. '
        + '```action:write_file\n{"path":"faketeam-probe.js","content":"// probe"}\n```'
    });
    const outsideSys = [];
    const origChat2 = providers.chat;
    providers.chat = async (pid, model, messages) => {
      if (pid === 'faketeam') outsideSys.push(String(messages[0].content));
      return origChat2(pid, model, messages);
    };
    try {
      const r2 = await orchestrator.runEnsemble({
        userText: goal, ws, experience: store,
        overrides: { research: 'faketeam', plan: 'faketeam', code: 'faketeam', review: 'faketeam' }
      });
      assert.ok(r2.steps.every((st) => st.ok), JSON.stringify(r2.steps.map((st) => st.error)));
      // ONE-WAY learning: outsider models must never receive Air_you's lesson journal
      assert.ok(outsideSys.length >= 4, 'the outside model played all four roles');
      assert.ok(outsideSys.every((sys) => !/Lessons from previous missions/.test(sys)), 'lessons never leak to other AIs — only Air_you learns');
      const distill = store.get().find((e) => e.engine === 'team-distill');
      assert.ok(distill, 'distillation entry recorded');
      assert.match(distill.lesson, /studied faketeam/);
      assert.match(distill.lesson, /zeromq|playwright/, 'novel terms the built-in lacked are captured');
      const team2 = store.get().find((e) => e.engine === 'team');
      assert.ok(/research@faketeam/.test(team2.lesson), 'outside provider recorded in the chain');
    } finally { providers.chat = origChat2; providers.unregisterProvider('faketeam'); }

    // run 3 — the accumulated lessons are injected into EVERY role prompt
    const captured = [];
    const origChat = providers.chat;
    providers.chat = async (pid, model, messages) => { captured.push(String(messages[0].content)); return origChat(pid, model, messages); };
    try {
      await orchestrator.runEnsemble({ userText: goal, ws, experience: store });
    } finally { providers.chat = origChat; }
    assert.ok(captured.length >= 4, 'all four roles called');
    assert.ok(captured.every((sys) => /Lessons from previous missions/.test(sys)), 'lessons injected into every role prompt');
    assert.ok(captured.some((sys) => /studied faketeam/.test(sys)), 'the distilled cross-AI knowledge travels with the team');

    // and the built-in can explain its own learning honestly
    const ans = await providers.chat('builtin', null, [{ role: 'user', content: 'how does the AI learn from other AIs over time?' }]);
    assert.match(ans, /team training loop|experience\.json/i);
    assert.match(ans, /distill/i);
    assert.match(ans, /no model weights|not marketing/i);
  });

  console.log('\nPlugin system');
  const { PluginManager } = require('../shared/plugins.cjs');
  const officialDir = path.join(__dirname, '..', 'plugins');
  const userDir = path.join(tmp, 'user-plugins');
  fs.mkdirSync(userDir, { recursive: true });

  // a user plugin that adds a provider + a tool
  fs.mkdirSync(path.join(userDir, 'demo'), { recursive: true });
  // enabledByDefault:true opts a USER plugin in (the new secure default is off)
  fs.writeFileSync(path.join(userDir, 'demo', 'plugin.json'), JSON.stringify({
    id: 'demo', name: 'Demo plugin', version: '1.0.0', entry: 'index.cjs', type: 'bundle', enabledByDefault: true
  }));
  fs.writeFileSync(path.join(userDir, 'demo', 'index.cjs'), `
    module.exports = {
      provider: {
        id: 'demo-ai', name: 'Demo AI', vendor: 'Demo', keyEnv: null,
        models: [{ id: 'demo-1', name: 'Demo 1' }],
        async chat() { return 'demo reply'; }
      },
      tools: [{ name: 'demo_tool', description: 'demo', async run() { return { ok: true, output: 'tool ran' }; } }]
    };
  `);

  // a deliberately broken plugin — must be isolated, never fatal
  fs.mkdirSync(path.join(userDir, 'broken'), { recursive: true });
  fs.writeFileSync(path.join(userDir, 'broken', 'plugin.json'), JSON.stringify({
    id: 'broken', name: 'Broken', version: '1.0.0', entry: 'index.cjs'
  }));
  fs.writeFileSync(path.join(userDir, 'broken', 'index.cjs'), 'throw new Error("boom on load");');

  const pm = new PluginManager({ dirs: [officialDir, userDir], persistFile: path.join(tmp, 'plugins.json') });

  await test('scan discovers official + user plugins', () => {
    const list = pm.scan();
    const ids = list.map((p) => p.id).sort();
    assert.deepStrictEqual(ids, ['broken', 'demo', 'game-studio', 'git-tools', 'ollama', 'openrouter', 'workspace-inspector']);
  });

  await test('loadAll registers plugin providers and tools', () => {
    pm.loadAll();
    assert.ok(providers.hasProvider('ollama'), 'ollama provider registered');
    assert.ok(providers.hasProvider('openrouter'), 'openrouter provider registered');
    assert.ok(providers.hasProvider('demo-ai'), 'demo provider registered');
    assert.ok(agent.hasTool('git_status'), 'git tools registered');
    assert.ok(agent.hasTool('demo_tool'), 'demo tool registered');
  });

  await test('broken plugin is isolated with status error when enabled', () => {
    // disabled by default (user dir) -> no load attempted
    assert.strictEqual(pm.list().find((p) => p.id === 'broken').status, 'disabled');
    // enabling it surfaces the crash as status:error, and the app survives
    pm.setEnabled('broken', true);
    const b = pm.list().find((p) => p.id === 'broken');
    assert.strictEqual(b.status, 'error');
    assert.match(b.error, /boom on load/);
    pm.setEnabled('broken', false);
  });

  await test('plugin provider answers chat', async () => {
    const r = await providers.chat('demo-ai', null, [{ role: 'user', content: 'hi' }]);
    assert.strictEqual(r, 'demo reply');
  });

  await test('plugin tool runs as an agent action', async () => {
    const res = await agent.executeActions([{ type: 'demo_tool' }], ws);
    assert.strictEqual(res[0].ok, true);
    assert.match(res[0].output, /tool ran/);
  });

  await test('git tools work end to end', async () => {
    const init = await agent.executeActions([{ type: 'git_init' }], ws);
    assert.strictEqual(init[0].ok, true, init[0].output);
    await agent.runShell('git config user.email "test@dev.studio" && git config user.name "Test"', tmp);
    ws.write('tracked.txt', 'x');
    const st = await agent.executeActions([{ type: 'git_status' }], ws);
    assert.strictEqual(st[0].ok, true, st[0].output);
    assert.match(st[0].output, /tracked\.txt/);
    const cm = await agent.executeActions([{ type: 'git_commit', message: 'plugin test' }], ws);
    assert.strictEqual(cm[0].ok, true, cm[0].output);
  });

  await test('systemPrompt advertises plugin tools', () => {
    const sp = agent.systemPrompt();
    assert.match(sp, /git_commit/);
    assert.match(sp, /demo_tool/);
  });

  await test('disabling a plugin unregisters it', () => {
    const r = pm.setEnabled('demo', false);
    assert.strictEqual(r.ok, true);
    assert.ok(!providers.hasProvider('demo-ai'), 'provider removed');
    assert.ok(!agent.hasTool('demo_tool'), 'tool removed');
    const v = pm.list().find((p) => p.id === 'demo');
    assert.strictEqual(v.status, 'disabled');
    pm.setEnabled('demo', true);
    assert.ok(providers.hasProvider('demo-ai'), 'provider back after re-enable');
  });

  await test('enable state persists to disk', () => {
    pm.setEnabled('ollama', false);
    const pm2 = new PluginManager({ dirs: [officialDir, userDir], persistFile: path.join(tmp, 'plugins.json') });
    pm2.scan();
    assert.strictEqual(pm2.list().find((p) => p.id === 'ollama').enabled, false);
    pm2.setEnabled('ollama', true);
  });

  console.log('\nAir_you conversation');

  await test('builtin answers each question differently (no canned intro)', async () => {
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);

    const hi = await ask('hello');
    // Ask-30 (user): greetings must NOT self-introduce — intro only WHEN ASKED
    assert.ok(!/built-in offline AI hoon|Main \*\*Air_you\*\* hoon|Air Developing ka built-in/i.test(hi), 'greeting does not self-introduce');
    assert.ok(hi.length < 160 && /boliye|banana|pooch/i.test(hi), 'greeting is short and invites the ask');

    const who = await ask('who are you?');
    assert.match(who, /offline/i);
    assert.match(who, /Air_you/);

    const rec = await ask('what is recursion?');
    assert.match(rec, /Recursion/);
    assert.match(rec, /base case/i);

    const css = await ask('how do i center a div with css?');
    assert.match(css, /flex/i);

    const fn = await ask('what is a closure in javascript?');
    assert.match(fn, /closure/i);

    const math = await ask('what is 2+2*10?');
    assert.match(math, /= 22/);

    const thanks = await ask('thank you!');
    assert.match(thanks, /welcome/i);

    const q1 = await ask('explain blockchain consensus simply');
    const q2 = await ask('why is the sky blue at noon?');
    assert.notStrictEqual(q1, q2, 'two questions must not get identical replies');
    assert.ok(q1.includes('blockchain'), 'fallback quotes the question keywords');
    assert.ok(q2.includes('sky'), 'fallback quotes the question keywords');
    assert.ok(!q1.includes("I'm **Air_you**, Air Developing's built-in offline engine. I plan"), 'fallback is not the intro');

    // build-shaped questions still scaffold real files
    const build = await ask('can you write a cli tool for me?');
    const acts = agent.parseActions(build);
    assert.ok(acts.some((a) => a.type === 'write_file'), 'build-shaped question still builds');
  });

  console.log('\nGame Studio');
  const vm = require('node:vm');

  await test('GameKit engine + all genre templates are valid JavaScript', () => {
    const files = [
      'shared/gamekit/engine.js',
      ...['arena', 'platformer', 'shmup', 'runner'].map((g) => `shared/gamekit/templates/${g}.js`)
    ];
    for (const f of files) {
      const src = fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
      new vm.Script(src, { filename: f }); // throws on any syntax error
    }
  });

  await test('game_new scaffolds engine + template + page into the workspace', () => {
    const entry = require('../plugins/game-studio/index.cjs');
    const written = {};
    const ctx = {
      ws: { write: (rel, content) => { written[rel] = content; }, tree: () => [], read: () => '' },
      runShell: async () => ({ ok: true, output: '' }),
      workspace: tmp
    };
    const tool = entry.tools.find((t) => t.name === 'game_new');
    const r = tool.run({ genre: 'space shooter', dir: 'game' }, ctx);
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.spec.control, 'space', 'request words become a spec');
    assert.ok(written['game/engine.js'].includes('class GameKit'));
    assert.ok(written['game/game.js'].includes('GAME_SPEC'), 'composed games carry their DNA');
    assert.ok(written['game/index.html'].includes('<canvas'));
    // explicit preset still uses the hand-tuned template
    const r2 = tool.run({ genre: 'platformer', dir: 'game2' }, ctx);
    assert.strictEqual(r2.genre, 'platformer');
    assert.ok(written['game2/game.js'].includes('MONO JUMP'));
    // city preset scaffolds the mini open-world game
    const r3 = tool.run({ genre: 'city', dir: 'game3' }, ctx);
    assert.strictEqual(r3.genre, 'city');
    assert.ok(written['game3/game.js'].includes('__cityGame'), 'city template landed intact');
    assert.ok(written['game3/index.html'].includes('GRAND THEFT MONO'));
    // city3d preset scaffolds the 3D engine alongside
    const r4 = tool.run({ genre: 'city3d', dir: 'game4' }, ctx);
    assert.strictEqual(r4.genre, 'city3d');
    assert.ok(written['game4/engine3d.js'].includes('GameKit3D'), 'engine3d lands with the game');
    assert.ok(written['game4/game.js'].includes('__city3d'));
    assert.ok(written['game4/index.html'].includes('engine3d.js'), 'page loads the 3D engine');
    assert.ok(written['game4/index.html'].includes('MONO CITY 3D'));
    // genre word-matching routes GTA-ish asks to city, 3D asks to city3d
    assert.strictEqual(entry.genreOf('a gta clone'), 'city');
    assert.strictEqual(entry.genreOf('open world crime game'), 'city');
    assert.strictEqual(entry.genreOf('a first person 3d city'), 'city3d');
    // spec3d payloads scaffold the composed-3D runtime + engine3d
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const r5 = tool.run({ spec3d: parseSpec3d('resident evil style survival horror'), dir: 'game5' }, ctx);
    assert.strictEqual(r5.ok, true);
    assert.strictEqual(r5.genre, '3d:fps');
    assert.ok(written['game5/engine3d.js'].includes('GameKit3D'));
    assert.ok(written['game5/game.js'].includes('GAME_SPEC3D'));
    assert.ok(written['game5/index.html'].includes('engine3d.js'));
    assert.match(r5.mechanics, /dark\/horror/);
    // platform systems: har target ka apna scaffold
    const rA = tool.run({ genre: 'arena', dir: 'gAnd', platform: 'android' }, ctx);
    assert.strictEqual(rA.ok, true);
    assert.strictEqual(rA.genre, 'arena@android');
    assert.ok(written['gAnd/capacitor.config.json'].includes('air.developing.'));
    assert.match(written['gAnd/mobile/README-ANDROID.md'], /Android Studio/);
    const rW = tool.run({ genre: 'arena', dir: 'gWin', platform: 'windows' }, ctx);
    assert.strictEqual(rW.genre, 'arena@windows');
    assert.ok(written['gWin/desktop/main.cjs'].includes('Electron shell'));
    assert.match(written['gWin/desktop/README-DESKTOP.md'], /electron-builder/);
    const rI = tool.run({ genre: 'arena', dir: 'gIos', platform: 'ios' }, ctx);
    assert.match(written['gIos/mobile/README-IOS.md'], /Xcode/);
    const list = entry.tools.find((t) => t.name === 'game_list');
    ctx.ws.tree = () => [{ name: 'game', path: 'game', type: 'dir', children: [
      { name: 'game.js', path: 'game/game.js', type: 'file' },
      { name: 'engine.js', path: 'game/engine.js', type: 'file' }
    ] }];
    ctx.ws.read = () => written['game/game.js'];
    const l = list.run({}, ctx);
    assert.strictEqual(l.games.length, 1);
    assert.strictEqual(l.games[0].dir, 'game');
  });

  await test('builtin routes game requests to the Game Studio plugin', async () => {
    const mk = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const a1 = agent.parseActions(await mk('make a space shooter game with bombs'));
    const s1 = a1.find((a) => a.type === 'game_new');
    assert.ok(s1, 'game_new emitted');
    assert.strictEqual(s1.spec.control, 'space');
    assert.ok(s1.spec.modifiers.includes('bomb'));
    const a2 = agent.parseActions(await mk('make a platformer game'));
    assert.ok(a2.some((a) => a.type === 'game_new' && a.genre === 'platformer'));
    const a3 = agent.parseActions(await mk('make a game'));
    assert.ok(a3.some((a) => a.type === 'game_new' && a.dir === 'game'));
    assert.ok(a3.some((a) => a.type === 'game_check'), 'game is verified after scaffolding');
    const gtaReply = await mk('make me a game like gta');
    assert.match(gtaReply, /GRAND THEFT MONO/);
    const a4 = agent.parseActions(gtaReply);
    assert.ok(a4.some((a) => a.type === 'game_new' && a.genre === 'city'));
    // question-shaped GTA query hits the knowledge base, not the scaffold
    const kb = await mk('how are gta style open-world games made?');
    assert.match(kb, /pillars|streamed world/i);
    assert.ok(!agent.parseActions(kb).some((a) => a.type === 'game_new'), 'questions must not scaffold');
    // 3D asks route to the composed-3D runtime with real DNA
    const d3 = await mk('make me a 3d city game with traffic');
    const a3d = agent.parseActions(d3).find((a) => a.type === 'game_new');
    assert.ok(a3d && a3d.spec3d, 'spec3d emitted for 3D asks');
    assert.equal(a3d.spec3d.world, 'city');
    assert.equal(a3d.spec3d.control, 'drive', 'traffic -> driving');
    assert.match(d3, /3D game DNA/);
    // AAA question -> honest knowledge, no scaffold
    const aaa = await mk('how do aaa games like gta 6 get made?');
    assert.match(aaa, /2000 people|billions/i);
    assert.ok(!agent.parseActions(aaa).some((a) => a.type === 'game_new'), 'AAA question must not scaffold');
  });

  await test('city (mini-GTA) mechanics work under the hood', () => {
    const { runGame } = require('./harness/headless.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const city = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'city.js'), 'utf8');
    const sb = runGame({ engineSrc: engine, gameSrc: city, frames: 600 });
    const G = sb.__cityGame;
    assert.ok(G, 'test hook exposed');
    assert.ok(G.buildings.length > 20 && G.cars.length >= 12 && G.peds.length >= 12);
    assert.equal(typeof G.wanted, 'number');
    // hit-and-run raises the wanted level
    G.state = 'play';
    const car = G.cars[0];
    G.player.inCar = car; G.player.x = car.x; G.player.y = car.y;
    car.angle = 0; car.speed = 200;
    const ped = G.peds[0]; ped.x = car.x + 18; ped.y = car.y;
    const w0 = G.wanted;
    G.scene.update(G, 1 / 60);
    assert.ok(G.wanted > w0, 'running over a ped is a crime');
    // wanted level brings the police
    G.wanted = 4; G.spawnT = 0.05;
    for (let i = 0; i < 150; i += 1) G.scene.update(G, 1 / 60);
    assert.ok(G.cops.length >= 1, 'cops spawn for wanted players');
    // on foot and cornered -> BUSTED (the ramming phase may have WASTED him: reset,
    // and stage it at an open intersection so building push-out cannot flake)
    G.state = 'play'; G.player.hp = 100;
    G.player.inCar = null; G.player.arrestT = 0;
    G.player.x = 848; G.player.y = 848;
    G.cops.length = 0;
    G.cops.push({ x: 860, y: 848, w: 46, h: 24, angle: Math.PI, speed: 0, hp: 50, flash: 0 });
    for (let i = 0; i < 240; i += 1) G.scene.update(G, 1 / 60); // generous window: even a chase oscillation nets the 0.7s arrest
    assert.equal(G.state, 'over', 'arrest ends the run');
    assert.match(String(G._overReason || ''), /BUSTED/);
  });

  await test('every shipped game runs 600 simulated frames headlessly', () => {
    const { runGame } = require('./harness/headless.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    for (const t of ['arena', 'platformer', 'shmup', 'runner', 'composed', 'city', 'city3d', 'composed3d']) {
      const game = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', `${t}.js`), 'utf8');
      runGame({ engineSrc: engine, gameSrc: game, frames: 600, extraSrcs: (t === 'city3d' || t === 'composed3d') ? [engine3d] : [] }); // throws on any runtime error
    }
  });

  await test('composed games from very different requests all run headlessly', () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec } = require('../shared/gamekit/spec.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const composed = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed.js'), 'utf8');
    const requests = [
      'make a zombie survival game with dash',
      'flappy bird style pipe runner',
      'space shooter with bombs and rapid fire',
      'platformer reach the flag with double jump',
      'collect gems topdown unarmed with magnet and shield'
    ];
    const seen = new Set();
    for (const r of requests) {
      const spec = parseSpec(r);
      seen.add(JSON.stringify([spec.control, spec.enemies, spec.goal]));
      const src = `const GAME_SPEC = ${JSON.stringify(spec)};\n` + composed;
      runGame({ engineSrc: engine, gameSrc: src, frames: 400 });
    }
    assert.ok(seen.size >= 4, `requests must produce different DNA, got ${seen.size}`);
  });

  await test('parseSpec turns sentences into different game DNA', () => {
    const { parseSpec, describeSpec } = require('../shared/gamekit/spec.cjs');
    const a = parseSpec('zombie survival arena with dash');
    const b = parseSpec('flappy pipe runner');
    const c = parseSpec('space shooter with bombs');
    assert.strictEqual(a.control, 'topdown');
    assert.ok(a.enemies.includes('chaser'));
    assert.ok(a.modifiers.includes('dash'));
    assert.strictEqual(b.control, 'flap');
    assert.ok(b.enemies.includes('pipes'));
    assert.strictEqual(c.control, 'space');
    assert.ok(c.modifiers.includes('bomb'));
    assert.notStrictEqual(describeSpec(a), describeSpec(b));
    assert.strictEqual(parseSpec('collect gems, no weapons, pacifist').weapon, 'none');
    assert.strictEqual(parseSpec('neon cyber survival').theme, 'neon');
  });

  console.log('\nWorkspace Inspector');

  await test('project_analyze reports stack, sizes and TODOs; find_code greps', () => {
    const entry = require('../plugins/workspace-inspector/index.cjs');
    const dir = path.join(tmp, 'proj');
    fs.mkdirSync(path.join(dir, 'src'), { recursive: true });
    fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({ name: 'p', dependencies: { react: '1' } }));
    fs.writeFileSync(path.join(dir, 'src', 'app.jsx'), 'import React from "react";\n// TODO: fix this\nconst x = 1;\n'.repeat(3));
    fs.writeFileSync(path.join(dir, 'src', 'big.txt'), 'x'.repeat(5000));
    const ctx = { workspace: dir, ws: { tree: () => [] }, runShell: async () => ({ ok: true }) };
    const an = entry.tools.find((t) => t.name === 'project_analyze').run({}, ctx);
    assert.strictEqual(an.ok, true);
    assert.match(an.report, /PROJECT AUDIT/);
    assert.ok(an.todos >= 3, 'TODO markers counted');
    assert.ok(an.signals.includes('React'), 'stack detected');
    const fc = entry.tools.find((t) => t.name === 'find_code').run({ query: 'TODO' }, ctx);
    assert.ok(fc.count >= 3);
    assert.match(fc.hits[0], /app\.jsx:\d+:/);
  });

  await test('builtin emits analyze and find actions for project questions', async () => {
    const mk = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const a1 = agent.parseActions(await mk('analyze my project'));
    assert.ok(a1.some((a) => a.type === 'project_analyze'));
    const a2 = agent.parseActions(await mk('find "TODO" in my code'));
    const f = a2.find((a) => a.type === 'find_code');
    assert.ok(f, 'find_code emitted');
    assert.strictEqual(f.query, 'TODO');
  });

  console.log('\nAir_you brain');
  const brain = require('../shared/builtin.cjs');

  await test('brain reads real workspace files to explain them', async () => {
    const dir = path.join(tmp, 'brainws');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'logic.js'),
      'const fs = require("fs");\nfunction add(a, b) { return a + b; }\nfunction mul(a, b) { return a * b; }\nmodule.exports = { add, mul };\n// TODO: div\n');
    brain.setWorkspace(makeWorkspaceHelpers({ value: dir }));
    const r = await brain.chat('studio-agent-2', [{ role: 'user', content: 'explain logic.js' }]);
    assert.match(r, /add/);
    assert.match(r, /mul/);
    assert.match(r, /TODO/);
    assert.match(r, /lines/);
    const show = await brain.chat('studio-agent-2', [{ role: 'user', content: 'show logic.js' }]);
    assert.match(show, /function add/);
  });

  await test('error doctor diagnoses pasted traces with concrete fixes', async () => {
    const r1 = await brain.chat('x', [{ role: 'user', content: "node server.js\nError: Cannot find module 'express'\n    at require (node.js:1:1)" }]);
    assert.match(r1, /missing module/i);
    assert.match(r1, /npm install express/);
    const acts = agent.parseActions(r1);
    assert.ok(acts.some((a) => a.type === 'run_command' && /npm install express/.test(a.command)));
    const r2 = await brain.chat('x', [{ role: 'user', content: 'listen EADDRINUSE: address already in use :::8080' }]);
    assert.match(r2, /port/i);
    const r3 = await brain.chat('x', [{ role: 'user', content: "TypeError: app.listen is not a function" }]);
    assert.match(r3, /type error/i);
  });

  await test('refactor splits a real file into modules and the result runs', async () => {
    const dir = path.join(tmp, 'brainws');
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'util.js'), [
      'const fs = require("fs");',
      '',
      'function add(a, b) {',
      '  const tricky = "unbalanced } brace in string";',
      '  return a + b + tricky.length;',
      '}',
      '',
      'function greet(name) {',
      '  // a comment with a } brace',
      '  return `Hello ${name}!`;',
      '}',
      '',
      'function main() {',
      '  console.log(greet("world"), add(1, 2), fs.existsSync("."));',
      '}',
      '',
      'main();',
      ''
    ].join('\n'));
    const reply = await brain.chat('x', [{ role: 'user', content: 'refactor util.js' }]);
    assert.match(reply, /util-lib\.js/);
    const acts = agent.parseActions(reply);
    const writes = acts.filter((a) => a.type === 'write_file');
    assert.ok(writes.some((w) => w.path === 'util-lib.js' && /module\.exports/.test(w.content) && /function add/.test(w.content)));
    assert.ok(writes.some((w) => w.path === 'util.js' && /require\('.\/util-lib\.js'\)/.test(w.content)));
    assert.ok(acts.some((a) => a.type === 'run_command' && /node --check/.test(a.command)));
    // main() calls greet/add, so it must STAY in util.js (dependency guard)
    const lib = writes.find((w) => w.path === 'util-lib.js');
    assert.ok(/function greet/.test(lib.content) && /function add/.test(lib.content));
    assert.ok(!/function main/.test(lib.content));
    // execute for real, then run — behaviour must be unchanged
    const wsR = makeWorkspaceHelpers({ value: dir });
    await agent.executeActions(acts, wsR);
    const check = await agent.runShell('node --check util-lib.js && node --check util.js && node util.js', dir, 30000);
    assert.equal(check.code, 0, 'refactored project must pass --check and run: ' + check.stderr);
    assert.match(check.stdout, /Hello world!/);
    // guards: refusing to overwrite an existing target, and ESM files
    const again = await brain.chat('x', [{ role: 'user', content: 'split util.js into util-lib.js' }]);
    assert.match(again, /pehle se maujood/);
    fs.writeFileSync(path.join(dir, 'esm.js'), 'export function a() {}\nexport function b() {}\n');
    const esm = await brain.chat('x', [{ role: 'user', content: 'refactor esm.js' }]);
    assert.match(esm, /ES modules/);
  });

  await test('follow-ups work: run it, fix it, rename, guarded delete', async () => {
    fs.writeFileSync(path.join(tmp, 'brainws', 'hello.js'), 'console.log(1);\n');
    await brain.chat('x', [{ role: 'user', content: 'write a node script that greets me' }]);
    const run = await brain.chat('x', [{ role: 'user', content: 'run it' }]);
    const acts = agent.parseActions(run);
    assert.ok(acts.some((a) => a.type === 'run_command' && /node hello\.js/.test(a.command)), 'runs the last scaffolded file');

    await brain.chat('x', [{ role: 'user', content: "Error: Cannot find module 'left-pad'" }]);
    const fix = await brain.chat('x', [{ role: 'user', content: 'fix it' }]);
    assert.ok(agent.parseActions(fix).some((a) => /npm install left-pad/.test(a.command || '')), 'replays the stored fix');

    const ren = await brain.chat('x', [{ role: 'user', content: 'rename hello.js to greet.js' }]);
    assert.ok(agent.parseActions(ren).some((a) => a.type === 'run_command' && /(mv|move)/.test(a.command)));

    const guard = await brain.chat('x', [{ role: 'user', content: 'delete hello.js' }]);
    assert.match(guard, /confirm/i);
    assert.strictEqual(agent.parseActions(guard).length, 0, 'delete needs explicit confirmation');
    const conf = await brain.chat('x', [{ role: 'user', content: 'yes delete hello.js' }]);
    assert.ok(agent.parseActions(conf).some((a) => /(rm|del)/.test(a.command)));
  });

  console.log('\nAutopilot');
  const autopilot = require('../shared/autopilot.cjs');

  await test('autopilot runs a JSON plan and verifies it in one pass', async () => {
    const dir = path.join(tmp, 'auto1');
    fs.mkdirSync(dir, { recursive: true });
    const wsAuto = makeWorkspaceHelpers({ value: dir });
    let calls = 0;
    const chat = async () => {
      calls += 1;
      return JSON.stringify({
        summary: 'add util', done: 'a.js verified',
        steps: [{ title: 'write a.js', actions: [{ type: 'write_file', path: 'a.js', content: 'console.log(1);\n' }] }],
        verify: ['node --check a.js']
      });
    };
    const r = await autopilot.runMission({ goal: 'add util', provider: 'frontier', ws: wsAuto, permissions: { writeFiles: true, runCommands: true }, chat, maxIterations: 2 });
    assert.strictEqual(r.ok, true);
    assert.strictEqual(calls, 1, 'no fix loop when verify passes');
    assert.ok(fs.existsSync(path.join(dir, 'a.js')));
    assert.deepStrictEqual(r.files, ['a.js']);
  });

  await test('autopilot fix loop recovers from a failing verify', async () => {
    const dir = path.join(tmp, 'auto2');
    fs.mkdirSync(dir, { recursive: true });
    const wsAuto = makeWorkspaceHelpers({ value: dir });
    let calls = 0;
    const chat = async () => {
      calls += 1;
      const broken = calls === 1;
      return JSON.stringify({
        summary: broken ? 'first try' : 'fix', done: 'fixed',
        steps: [{ title: 'write', actions: [{ type: 'write_file', path: 'b.js', content: broken ? 'console.log(;\n' : 'console.log(2);\n' }] }],
        verify: ['node --check b.js']
      });
    };
    const r = await autopilot.runMission({ goal: 'fix', provider: 'frontier', ws: wsAuto, permissions: { writeFiles: true, runCommands: true }, chat, maxIterations: 3 });
    assert.strictEqual(r.ok, true);
    assert.strictEqual(r.iterations.length, 2, 'one failing iteration, then a fix');
    assert.strictEqual(calls, 2);
  });

  await test('autopilot respects permission gates and reports skips', async () => {
    const dir = path.join(tmp, 'auto3');
    fs.mkdirSync(dir, { recursive: true });
    const wsAuto = makeWorkspaceHelpers({ value: dir });
    const chat = async () => JSON.stringify({
      summary: 'write', done: '',
      steps: [{ title: 'w', actions: [{ type: 'write_file', path: 'c.js', content: 'x\n' }] }],
      verify: []
    });
    const r = await autopilot.runMission({ goal: 'g', provider: 'frontier', ws: wsAuto, permissions: { writeFiles: false, runCommands: false }, chat, maxIterations: 1 });
    assert.ok(!fs.existsSync(path.join(dir, 'c.js')), 'write must be refused');
    assert.ok(r.iterations[0].skipped.some((s) => s.includes('write c.js')));
    assert.strictEqual(r.ok, true, 'nothing to verify -> ok, but skips stay visible');
  });

  await test('autopilot with the offline built-in planner scaffolds and verifies', async () => {
    const dir = path.join(tmp, 'auto4');
    fs.mkdirSync(dir, { recursive: true });
    const wsAuto = makeWorkspaceHelpers({ value: dir });
    const r = await autopilot.runMission({
      goal: 'build me a website',
      provider: 'builtin',
      ws: wsAuto,
      permissions: { writeFiles: true, runCommands: true },
      chat: (pr, md, messages) => providers.chat(pr, md, messages),
      maxIterations: 2
    });
    assert.strictEqual(r.ok, true, r.error || 'builtin mission should verify');
    assert.ok(fs.existsSync(path.join(dir, 'index.html')));
  });

  console.log('\nDeep agent (web research + build + check)');
  const websearch = require('../shared/websearch.cjs');
  const deep = require('../shared/deep.cjs');
  const brainD = require('../shared/builtin.cjs');

  const DDG_HTML = [
    '<div class="result"><a rel="nofollow" class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fnodejs.org%2Fen%2Fblog&rut=abc">Node.js &mdash; Latest Releases</a>',
    '<a class="result__snippet" rel="nofollow" href="#">The latest <b>version</b> of Node.js ships weekly.</a></div>',
    '<div class="result"><a rel="nofollow" class="result__a" href="https://example.com/two">Second &amp; result</a>',
    '<a class="result__snippet" rel="nofollow" href="#">Another snippet here.</a></div>'
  ].join('\n');
  const WIKI_OPEN = JSON.stringify(['express', ['Express (web framework)'], ['Express is a back-end web framework for Node.js.'], ['https://en.wikipedia.org/wiki/Express_(web_framework)']]);
  const WIKI_EXTRACT = JSON.stringify({ query: { pages: { '1': { extract: 'Express is a minimal and flexible Node.js web application framework.' } } } });

  function mockFetch(map) {
    return async (url) => {
      for (const k of Object.keys(map)) {
        if (String(url).includes(k)) return { ok: true, status: 200, text: async () => map[k] };
      }
      return { ok: false, status: 404, text: async () => '' };
    };
  }

  await test('websearch parses DuckDuckGo and falls back to Wikipedia', async () => {
    const ddg = await websearch.deepResearch('node latest version', { fetchImpl: mockFetch({ 'duckduckgo.com/html': DDG_HTML }) });
    assert.equal(ddg.source, 'duckduckgo');
    assert.equal(ddg.results.length, 2);
    assert.equal(ddg.results[0].url, 'https://nodejs.org/en/blog'); // uddg redirect unwrapped
    assert.match(ddg.results[0].title, /Node\.js — Latest Releases/); // entities decoded, tags stripped
    assert.match(ddg.results[1].title, /Second & result/);
    assert.match(ddg.results[0].snippet, /latest version of Node\.js/);
    const wiki = await websearch.deepResearch('express framework', { fetchImpl: mockFetch({ 'action=opensearch': WIKI_OPEN, 'prop=extracts': WIKI_EXTRACT }) });
    assert.equal(wiki.source, 'wikipedia');
    assert.equal(wiki.results[0].url, 'https://en.wikipedia.org/wiki/Express_(web_framework)');
    assert.match(wiki.summary, /minimal and flexible/);
    const dead = await websearch.deepResearch('anything', { fetchImpl: mockFetch({}) });
    assert.equal(dead.offline, true);
    assert.equal(dead.results.length, 0);
  });

  await test('built-in brain answers "search X" with cited live results', async () => {
    websearch.setFetch(mockFetch({ 'duckduckgo.com/html': DDG_HTML }));
    try {
      const r = await brainD.chat('x', [{ role: 'user', content: 'search node js latest version' }]);
      assert.match(r, /live web se \(duckduckgo\)/);
      assert.match(r, /\[Node\.js — Latest Releases\]\(https:\/\/nodejs\.org\/en\/blog\)/);
      const offline = await websearch.deepResearch('x', { fetchImpl: mockFetch({}) });
      assert.equal(offline.offline, true);
    } finally { websearch.setFetch(null); }
    websearch.setFetch(mockFetch({})); // no network at all
    const honest = await brainD.chat('x', [{ role: 'user', content: 'search quantum news' }]);
    assert.match(honest, /kuch nahi mila/);
    websearch.setFetch(null);
  });

  await test('deep answer mode: research question gets a cited answer, no writes', async () => {
    const dir = path.join(tmp, 'deepws');
    fs.mkdirSync(dir, { recursive: true });
    const r = await deep.deepRun({
      goal: 'what is express in node.js?',
      ws: makeWorkspaceHelpers({ value: dir }),
      chat: (pr, md, msgs) => brainD.chat(md, msgs),
      fetchImpl: mockFetch({ 'action=opensearch': WIKI_OPEN, 'prop=extracts': WIKI_EXTRACT })
    });
    assert.equal(r.mode, 'answer');
    assert.equal(r.ok, true);
    assert.match(r.answer, /wikipedia\.org\/wiki\/Express/);
    assert.match(r.answer, /minimal and flexible/);
    assert.equal(r.mission, null);
    assert.equal(r.checks.length, 0);
    assert.equal(fs.readdirSync(dir).length, 0); // nothing was written
  });

  await test('deep build mode: research rides along, mission runs, checks prove files', async () => {
    const dir = path.join(tmp, 'deepws2');
    fs.mkdirSync(dir, { recursive: true });
    const wsB = makeWorkspaceHelpers({ value: dir });
    brainD.setWorkspace(wsB);
    const r = await deep.deepRun({
      goal: 'research the latest css framework and build me a website',
      ws: wsB,
      permissions: { writeFiles: true, runCommands: true },
      chat: (pr, md, msgs) => brainD.chat(md, msgs),
      fetchImpl: mockFetch({ 'duckduckgo.com/html': DDG_HTML })
    });
    assert.equal(r.mode, 'build');
    assert.ok(r.research && r.research.count >= 2, 'live sources were gathered first');
    assert.equal(r.mission.ok, true, 'mission verified: ' + JSON.stringify(r.mission.iterations));
    assert.ok(r.mission.files.length > 0);
    assert.ok(fs.existsSync(path.join(dir, 'index.html')));
    for (const c of r.checks) assert.equal(c.code, 0, 'check must pass: ' + c.cmd + ' ' + c.out);
    assert.equal(r.ok, true);
  });

  await test('deep offline fallback answers honestly and gates permissions', async () => {
    const dir = path.join(tmp, 'deepws3');
    fs.mkdirSync(dir, { recursive: true });
    const off = await deep.deepRun({
      goal: 'what is recursion?',
      ws: makeWorkspaceHelpers({ value: dir }),
      chat: (pr, md, msgs) => brainD.chat(md, msgs),
      fetchImpl: mockFetch({}) // every source dead
    });
    assert.equal(off.mode, 'answer');
    assert.match(off.answer, /built-in knowledge se/);
    const gated = await deep.deepRun({
      goal: 'build me a website',
      ws: makeWorkspaceHelpers({ value: dir }),
      permissions: { writeFiles: false, runCommands: false },
      chat: (pr, md, msgs) => brainD.chat(md, msgs),
      fetchImpl: mockFetch({})
    });
    assert.equal(gated.mode, 'build');
    assert.ok(gated.mission.iterations.some((it) => it.skipped && it.skipped.length > 0), 'skips must be visible');
    assert.equal(gated.checks.length, 0, 'no runCommands -> no check commands');
    assert.equal(fs.readdirSync(dir).length, 0, 'gated mission wrote nothing');
  });

  console.log('\nReAct agent (step-by-step tool loop)');
  const react = require('../shared/react.cjs');

  function scripted(replies) {
    let i = 0;
    return async () => replies[Math.min(i, replies.length - 1)] && replies[i++] || replies[replies.length - 1];
  }

  await test('parseToolCall is fence-tolerant and rejects rambling', async () => {
    assert.deepEqual(react.parseToolCall('```tool\n{"tool":"done","answer":"hi"}\n```'), { tool: 'done', answer: 'hi' });
    assert.deepEqual(react.parseToolCall('Sure! ```json {"tool":"list_files"} ``` Let me look.'), { tool: 'list_files' });
    assert.deepEqual(react.parseToolCall('{"tool":"read_file","path":"a.js"}'), { tool: 'read_file', path: 'a.js' });
    assert.equal(react.parseToolCall('I think we should consider many options here'), null);
    assert.equal(react.parseToolCall('{"nope": true}'), null);
  });

  await test('react loop: search -> write -> verify -> done, all observed for real', async () => {
    const dir = path.join(tmp, 'reactws');
    fs.mkdirSync(dir, { recursive: true });
    const wsR = makeWorkspaceHelpers({ value: dir });
    const chat = scripted([
      '```tool\n{"tool":"web_search","query":"node js hello world best practice"}\n```',
      'Let me write the file. ```tool\n{"tool":"write_file","path":"hello.js","content":"console.log(\'hello react\');\\n"}\n```',
      '```tool\n{"tool":"run_command","command":"node --check hello.js && node hello.js"}\n```',
      '```tool\n{"tool":"done","answer":"hello.js likh diya aur verify kar liya.","files":["hello.js"]}\n```'
    ]);
    const r = await react.runAgent({
      goal: 'write and verify hello.js',
      provider: 'openai', model: 'gpt-test', ws: wsR,
      permissions: { writeFiles: true, runCommands: true },
      chat,
      fetchImpl: mockFetch({ 'duckduckgo.com/html': DDG_HTML })
    });
    assert.equal(r.ok, true);
    assert.equal(r.engine, 'react');
    assert.match(r.answer, /verify kar liya/);
    assert.deepEqual(r.files, ['hello.js']);
    assert.equal(r.steps.length, 4);
    assert.equal(r.steps[0].tool, 'web_search');
    assert.match(r.steps[0].observation, /nodejs\.org/); // live results reached the model
    assert.match(r.steps[1].observation, /wrote hello\.js/);
    assert.match(r.steps[2].observation, /exit 0/);
    assert.match(r.steps[2].observation, /hello react/); // real stdout observed
    assert.equal(fs.readFileSync(path.join(dir, 'hello.js'), 'utf8'), "console.log('hello react');\n");
  });

  await test('react gates writes/commands and reports skips back to the model', async () => {
    const dir = path.join(tmp, 'reactws2');
    fs.mkdirSync(dir, { recursive: true });
    const chat = scripted([
      '{"tool":"write_file","path":"x.js","content":"1"}',
      '{"tool":"run_command","command":"node x.js"}',
      '{"tool":"done","answer":"permissions ki wajah se kuch nahi likha."}'
    ]);
    const r = await react.runAgent({
      goal: 'make something', provider: 'openai', ws: makeWorkspaceHelpers({ value: dir }),
      permissions: { writeFiles: false, runCommands: false }, chat, fetchImpl: mockFetch({})
    });
    assert.equal(r.steps[0].skipped, true);
    assert.match(r.steps[0].observation, /SKIPPED by permissions/);
    assert.equal(r.steps[1].skipped, true);
    assert.deepEqual(r.files, []);
    assert.equal(fs.readdirSync(dir).length, 0);
  });

  await test('react nudges rambling models and caps the loop', async () => {
    const dir = path.join(tmp, 'reactws3');
    fs.mkdirSync(dir, { recursive: true });
    const chat = scripted(['Hmm, let me think about the best approach here...']);
    const r = await react.runAgent({
      goal: 'anything', provider: 'openai', ws: makeWorkspaceHelpers({ value: dir }), chat, maxSteps: 3, fetchImpl: mockFetch({})
    });
    assert.equal(r.steps.length, 2); // nudge once, then the second ramble becomes the answer
    assert.match(r.steps[0].observation, /nudged/);
    assert.match(r.answer, /best approach/); // second ramble becomes the answer
  });

  await test('deep build mode uses the react loop for connected providers and checks files', async () => {
    const dir = path.join(tmp, 'reactws4');
    fs.mkdirSync(dir, { recursive: true });
    const chat = scripted([
      '```tool\n{"tool":"list_files"}\n```',
      '```tool\n{"tool":"write_file","path":"app.js","content":"const x = 41 + 1;\\nconsole.log(x);\\n"}\n```',
      '```tool\n{"tool":"run_command","command":"node --check app.js"}\n```',
      '```tool\n{"tool":"done","answer":"app.js ready and verified."}\n```'
    ]);
    const r = await deep.deepRun({
      goal: 'build a tiny script that prints 42',
      provider: 'openai', model: 'gpt-test',
      ws: makeWorkspaceHelpers({ value: dir }),
      permissions: { writeFiles: true, runCommands: true },
      chat, fetchImpl: mockFetch({})
    });
    assert.equal(r.mode, 'build');
    assert.equal(r.engine, 'react');
    assert.equal(r.ok, true);
    assert.deepEqual(r.mission.files, ['app.js']);
    assert.equal(r.checks.length, 1);
    assert.equal(r.checks[0].code, 0); // CHECK phase re-proved the file locally
    assert.match(r.react.answer, /verified/);
  });

  console.log('\nMission experience (agent learns from past runs)');
  const { ExperienceStore } = require('../shared/experience.cjs');

  await test('experience store persists, ranks relevance, caps and clears', async () => {
    const dir = path.join(tmp, 'expws');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, '.dev-studio', 'experience.json');
    const store = new ExperienceStore(file);
    store.record({ goal: 'build me a landing page with a navbar', engine: 'react', ok: true, files: ['index.html'], lesson: 'verified with node --check; navbar css grid worked' });
    store.record({ goal: 'write a snake game in python', engine: 'mission', ok: false, files: [], failures: ['VERIFY FAILED: python syntax'], lesson: 'py_compile caught an indentation error' });
    assert.equal(fs.existsSync(file), true);
    const reloaded = new ExperienceStore(file);
    assert.equal(reloaded.stats().total, 2);
    assert.equal(reloaded.stats().failures, 1);
    const rel = reloaded.relevant('build a landing page for my portfolio');
    assert.ok(rel.length >= 1 && /landing page/.test(rel[0].goal)); // token overlap wins
    const block = reloaded.contextBlock('add a navbar to my page');
    assert.match(block, /Lessons from previous missions/);
    assert.match(block, /navbar/);
    for (let i = 0; i < 45; i += 1) reloaded.record({ goal: `filler task number ${i}`, ok: true, lesson: 'filler' });
    assert.equal(reloaded.get().length, 40); // capped
    assert.equal(reloaded.clear('failures').failures, 0);
    assert.equal(reloaded.clear().total, 0);
  });

  await test('deepRun injects relevant lessons into the plan prompt and records the outcome', async () => {
    const dir = path.join(tmp, 'expws2');
    fs.mkdirSync(dir, { recursive: true });
    const store = new ExperienceStore(path.join(dir, '.dev-studio', 'experience.json'));
    store.record({ goal: 'build me a website about tea', engine: 'mission', ok: false, failures: ['VERIFY FAILED (1): node --check script.js'], lesson: 'script.js had a stray comma; run node --check before done' });
    const seen = [];
    const r = await deep.deepRun({
      goal: 'build me a website about coffee',
      ws: makeWorkspaceHelpers({ value: dir }),
      permissions: { writeFiles: true, runCommands: true },
      chat: async (pr, md, msgs) => { seen.push(msgs); return brainD.chat(md, msgs); },
      fetchImpl: mockFetch({}),
      experience: store
    });
    assert.equal(r.mode, 'build');
    assert.ok(r.priorCount >= 1, 'lessons were injected');
    const sysPrompt = seen[0].find((m) => m.role === 'system').content;
    assert.match(sysPrompt, /Lessons from previous missions/);
    assert.match(sysPrompt, /stray comma/); // the actual scar tissue reached the planner
    assert.equal(r.ok, true);
    const after = store.get();
    assert.ok(after.length >= 2);
    assert.match(after[0].goal, /coffee/); // this mission was recorded for next time
    assert.equal(after[0].ok, true);
    assert.match(after[0].lesson, /verify passed/);
  });

  await test('react agents get lessons in their system prompt; failed checks are remembered', async () => {
    const dir = path.join(tmp, 'expws3');
    fs.mkdirSync(dir, { recursive: true });
    const store = new ExperienceStore(path.join(dir, '.dev-studio', 'experience.json'));
    store.record({ goal: 'build a tiny script that prints numbers', engine: 'react', ok: false, failures: ['run_command: exit 1 SyntaxError'], lesson: 'always node --check after writing' });
    const seen = [];
    const badChat = scripted([
      '```tool\n{"tool":"write_file","path":"bad.js","content":"const = ;\\n"}\n```',
      '```tool\n{"tool":"done","answer":"done"}\n```'
    ]);
    const bad = await deep.deepRun({
      goal: 'build a tiny script that prints hello',
      provider: 'openai', model: 'gpt-test',
      ws: makeWorkspaceHelpers({ value: dir }),
      permissions: { writeFiles: true, runCommands: true },
      chat: async (pr, md, msgs) => { seen.push(msgs); return badChat(pr, md, msgs); },
      fetchImpl: mockFetch({}),
      experience: store
    });
    const sysPrompt = seen[0].find((m) => m.role === 'system').content;
    assert.match(sysPrompt, /always node --check after writing/); // lesson reached the ReAct agent
    assert.equal(bad.engine, 'react');
    assert.equal(bad.ok, false); // CHECK phase caught the broken file locally
    assert.match(bad.error, /CHECK FAILED/);
    const newest = store.get()[0];
    assert.equal(newest.ok, false);
    assert.match(newest.failures.join(' '), /CHECK FAILED/);
    assert.match(newest.lesson, /tools: write_file → done/);
  });

  console.log('\nGameKit3D — real 3D pipeline');
  const { makeCtx } = require('./harness/headless.cjs');

  await test('GameKit3D math is real math (matrices, projection, culling)', async () => {
    const K3 = (() => {
      const vm2 = require('vm');
      const sb = { Math, console }; sb.globalThis = sb;
      vm2.createContext(sb);
      vm2.runInContext(fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8'), sb);
      return sb.GameKit3D;
    })();
    const M = K3.M4;
    assert.deepEqual(M.mul(M.ident(), M.ident()), M.ident());
    assert.deepEqual(M.transformPoint(M.translation(10, 0, 0), [1, 2, 3]), [11, 2, 3, 1]);
    // rotY(90°) must send +x to -z (right-handed, y up)
    const rv = M.transformPoint(M.rotY(Math.PI / 2), [1, 0, 0]);
    assert.ok(Math.abs(rv[0]) < 1e-9 && Math.abs(rv[2] + 1) < 1e-9, `rotY wrong: ${rv}`);
    const cam = { pos: [0, 17, 100], yaw: 0, pitch: 0, fov: 72, aspect: 960 / 540, near: 5, far: 2200, width: 960, height: 540 };
    const ahead = K3.projectPoint(cam, [0, 17, 0]);
    assert.ok(Math.abs(ahead.x - 480) < 2 && Math.abs(ahead.y - 270) < 2, 'dead-ahead point projects to screen centre');
    const right = K3.projectPoint(cam, [30, 17, 0]);
    assert.ok(right.x > 480 && Math.abs(right.y - 270) < 2, 'right-of-centre projects right');
    assert.equal(K3.projectPoint(cam, [0, 17, 200]), null, 'behind the camera is rejected');
    // renderer: a lone box draws some faces, culls the rest, never crashes
    const faces = K3.boxFaces(-30, 0, -30, 60, 80, 60, 0.6);
    const stats = K3.renderScene(makeCtx(), { camera: cam, faces, width: 960, height: 540 });
    assert.ok(stats.drawn > 0 && stats.drawn + stats.culled === 5);
  });

  await test('GameKit3D water: real vertex waves, animated, wired, visible', async () => {
    const K3 = (() => {
      const vm2 = require('vm');
      const sb = { Math, console }; sb.globalThis = sb;
      vm2.createContext(sb);
      vm2.runInContext(fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8'), sb);
      return sb.GameKit3D;
    })();
    const cam = { pos: [0, 17, 100], yaw: 0, pitch: 0, fov: 72, aspect: 960 / 540, near: 5, far: 2200, width: 960, height: 540 };
    const w1 = K3.waterMesh(0, 0, 100, 100, 8, 0);
    assert.equal(w1.length, 64, 'segs×segs quads');
    let maxAmp = 0;
    for (const f of w1) for (const v of f.verts) maxAmp = Math.max(maxAmp, Math.abs(v[1]));
    assert.ok(maxAmp > 0.2 && maxAmp < 2.5, `real wave amplitude (${maxAmp.toFixed(2)})`);
    const w2 = K3.waterMesh(0, 0, 100, 100, 8, 1.7);
    let moved = 0;
    for (let i = 0; i < w1.length; i += 1) for (let j = 0; j < 4; j += 1) if (Math.abs(w1[i].verts[j][1] - w2[i].verts[j][1]) > 1e-9) moved += 1;
    assert.ok(moved > w1.length * 3, 'waves animate over time');
    assert.ok(w1.every((f) => f.wire > 0), 'water carries its own hairline wire (lines effect)');
    const stats = K3.renderScene(makeCtx(), { camera: cam, faces: w1, width: 960, height: 540 });
    assert.ok(stats.drawn > 0, 'up-facing water survives backface culling');
    // post FX pass must not throw on the stubbed ctx, with or without options
    K3.postFX(makeCtx(), 960, 540, { vignette: 0.5, grain: 40, scanlines: 0.05, frame: 2 });
    K3.postFX(makeCtx(), 960, 540, {});
    K3.postFX(makeCtx(), 960, 540);
  });

  await test('localai: GB-class catalog + Ollama list & pull-progress parsers', async () => {
    const la = require('../shared/localai.cjs');
    assert.ok(la.MODELS.length >= 5, 'curated GB-class catalog');
    assert.ok(la.MODELS.every((m) => m.id && m.gb > 0 && m.note), 'every model has id + GB size + note');
    assert.ok(la.MODELS.some((m) => m.id === 'llama3.1:8b' && m.gb >= 4), 'the recommended 8B is ~4.7GB class');
    // `ollama list` — SIZE is two tokens ("4.7 GB"), MODIFIED is three ("2 days ago")
    const list = la.parseOllamaList('NAME              ID            SIZE      MODIFIED\nllama3.1:8b       4219          4.7 GB    2 days ago\nmistral:7b        f974a74358d6    4.1 GB    5 weeks ago\n');
    assert.equal(list.length, 2);
    assert.deepEqual(list[0], { id: 'llama3.1:8b', size: '4.7 GB' });
    assert.deepEqual(list[1], { id: 'mistral:7b', size: '4.1 GB' });
    assert.deepEqual(la.parseOllamaList(''), [], 'empty output parses to nothing');
    // pull progress lines (\r-separated in real Ollama output)
    const pr = la.parsePullProgress('34% \u2595██\u258f       1.6 GB/4.7 GB   12 MB/s     4m0s');
    assert.equal(pr.pct, 34);
    assert.equal(pr.transferred, '1.6 GB');
    assert.equal(pr.total, '4.7 GB');
    assert.equal(pr.speed, '12 MB/s');
    assert.equal(pr.done, false);
    assert.ok(la.parsePullProgress('pulling manifest'), 'stage lines parse');
    const done = la.parsePullProgress('success');
    assert.equal(done.done, true);
    assert.equal(la.parsePullProgress('random junk line'), null, 'junk rejected');
    const last = la.lastProgress('pulling manifest\r2% \u2595 0.1 GB/4.7 GB 5 MB/s\r34% \u2595██\u258f 1.6 GB/4.7 GB 12 MB/s\r');
    assert.equal(last.pct, 34, 'lastProgress finds the freshest percentage');
  });

  await test('FX Forge: AI composes effect recipes itself — a billion combinations', async () => {
    const { CODEX, forgeFX, combinations, validateFX, describeFX } = require('../shared/gamekit/fxcodex.cjs');
    // the codex is real technique literature, not filler
    assert.ok(CODEX.length >= 24, `codex has ${CODEX.length} techniques`);
    for (const e of CODEX) assert.ok(e.id && e.name && e.what && e.math && e.used, `codex entry complete: ${e.id}`);
    assert.ok(CODEX.some((e) => e.id === 'gerstner-waves' && /cos/.test(e.math)), 'Gerstner math present');
    assert.ok(CODEX.some((e) => e.id === 'spring-damper-slosh' && /k·x/.test(e.math)), 'Dodge slosh math present');
    assert.ok(combinations() >= 1e9, `combination space: ${combinations().toLocaleString()}`);
    // deterministic per seed text
    assert.deepEqual(forgeFX('abc game'), forgeFX('abc game'), 'same words → same recipe');
    // different words → genuinely different recipes
    const kinds = new Set(); const params = new Set();
    for (const t of ['fps game', 'swing game', 'train game', 'drive game', 'horror game', 'ocean game', 'desert game', 'arctic game']) {
      const fx = forgeFX(t);
      assert.ok(validateFX(fx), `recipe valid for "${t}"`);
      kinds.add(fx.kind); params.add(JSON.stringify(fx.params));
    }
    assert.ok(kinds.size >= 3, `varied kinds: ${[...kinds].join(',')}`);
    assert.ok(params.size >= 7, 'varied params across texts');
    // request words bias the recipe
    assert.equal(forgeFX('lava river survival game').kind, 'lava-glow');
    assert.equal(forgeFX('toxic swamp zombie game').kind, 'toxic');
    assert.equal(forgeFX('storm thunder sailing game').kind, 'storm');
    assert.equal(forgeFX('frozen arctic fishing game').kind, 'frozen');
    assert.equal(forgeFX('creepy horror night game').kind, 'black-water');
    assert.match(describeFX(forgeFX('lava river survival game')), /lava-glow FX/);
    assert.equal(validateFX({ kind: 'nope', params: {} }), false, 'junk recipes rejected');
  });

  await test('every 3D spec carries a forged FX recipe, consumed by the runtime', async () => {
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const { validateFX } = require('../shared/gamekit/fxcodex.cjs');
    const reqs = ['resident evil style survival horror game', 'spider-man swinging through the city', 'choo-choo charles train horror', 'gta 5 open world crime driving game', 'call of duty fps waves'];
    for (const r of reqs) {
      const spec = parseSpec3d(r);
      assert.ok(spec.fx && validateFX(spec.fx), `fx recipe rides along: ${r}`);
    }
    assert.equal(parseSpec3d('make a 3d lava river game').fx.kind, 'lava-glow');
  });

  await test('engine3d slosh: spring–mass–damper water inside a moved container', async () => {
    const K3 = (() => {
      const vm2 = require('vm');
      const sb = { Math, console }; sb.globalThis = sb;
      vm2.createContext(sb);
      vm2.runInContext(fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8'), sb);
      return sb.GameKit3D;
    })();
    const sl = K3.newSlosh();
    for (let i = 0; i < 12; i += 1) K3.stepSlosh(sl, 7, 1 / 60); // shake the bottle
    assert.ok(Math.abs(sl.x) > 0.01, `water moved: x=${sl.x.toFixed(3)}`);
    for (let i = 0; i < 300; i += 1) K3.stepSlosh(sl, 0, 1 / 60); // stand still
    assert.ok(Math.abs(sl.x) < 0.01 && Math.abs(sl.v) < 0.05, 'slosh settles (damped spring)');
    // hard shove clamps at the wall and bounces
    const sl2 = K3.newSlosh();
    for (let i = 0; i < 240; i += 1) K3.stepSlosh(sl2, 900, 1 / 60);
    assert.ok(Math.abs(sl2.x) <= 1.21, 'water cannot leave the bottle');
    // ripples expand and fade
    const rl = [];
    K3.spawnRipple(rl, 10, 10, 1);
    const r0 = rl[0].r; const a0 = rl[0].a;
    K3.stepRipples(rl, 0.5);
    assert.ok(rl[0].r > r0 && rl[0].a < a0, 'ring expands, alpha fades');
    for (let i = 0; i < 200; i += 1) K3.stepRipples(rl, 0.1);
    assert.equal(rl.length, 0, 'dead ripples removed');
  });

  await test('river drowning + bottle slosh live in the composed city game', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const spec = parseSpec3d('swat fps mission in the city');
    assert.equal(spec.world, 'city');
    const mk = () => runGame({ engineSrc: engine, gameSrc: `const GAME_SPEC3D = ${JSON.stringify(spec)};\n` + c3d, frames: 5, extraSrcs: [engine3d] });

    // the city has a river with bridges and bottles in the world
    const sb1 = mk(); const G = sb1.__composed3d;
    assert.ok(G.waters.some((w) => w.kind === 'river'), 'river crosses the city');
    assert.equal(G.bridges.length, 2, 'two bridges over the river');
    assert.ok(G.pickups.filter((pk) => pk.kind === 'bottle').length >= 1, 'water bottles spawn');

    // walk into the river: splash + ripples
    G.state = 'play';
    G.P3.x = 800; G.P3.z = 800; G.P3.o2 = 100; G.P3.hp = 100;
    G.scene.update(G, 1 / 60);
    assert.ok(G.P3.inWater, 'player is in the river');
    assert.ok(G.ripples.length >= 1, 'entry spawned wake rings');
    assert.match(G.P3.msg, /HIT THE WATER/);

    // dive with C: oxygen drains; at zero you drown (real-life rules)
    const o0 = G.P3.o2;
    for (let i = 0; i < 90; i += 1) { G.input.keys.add('KeyC'); G.scene.update(G, 1 / 60); }
    assert.ok(G.P3.diving, 'C dives');
    assert.ok(G.P3.o2 < o0, `oxygen drains underwater (${G.P3.o2.toFixed(1)})`);
    let n = 0;
    while (G.state === 'play' && n < 2400) { G.input.keys.add('KeyC'); G.scene.update(G, 1 / 60); n += 1; }
    assert.equal(G.state, 'over', 'staying under drowns the player');

    // bottle: sloshes when the player moves, settles when still, drinks when breath is low
    const sb2 = mk(); const G2 = sb2.__composed3d;
    G2.state = 'play';
    G2.P3.bottle = { x: 0, v: 0, k: 42, c: 4.5, fill: 1, drinkT: 0 };
    G2.P3.x = 200; G2.P3.z = 200;
    for (let i = 0; i < 20; i += 1) { G2.P3.x += 2.2; G2.scene.update(G2, 1 / 60); } // run east
    assert.ok(Math.abs(G2.P3.bottle.x) > 0.05, `bottle water tilts while running (x=${G2.P3.bottle.x.toFixed(3)})`);
    for (let i = 0; i < 300; i += 1) G2.scene.update(G2, 1 / 60); // stand still
    assert.ok(Math.abs(G2.P3.bottle.x) < 0.02, 'bottle water settles');
    G2.P3.o2 = 20; G2.P3.bottle.drinkT = 0; G2.P3.bottle.fill = 1;
    G2.scene.update(G2, 1 / 60);
    assert.equal(G2.P3.bottle.fill, 0.75, 'drinking costs a quarter bottle');
    assert.ok(G2.P3.o2 > 40, 'drinking buys breath back');
    // river refills the bottle
    G2.P3.x = 800; G2.P3.z = 800; G2.P3.bottle.fill = 0.4;
    for (let i = 0; i < 60; i += 1) G2.scene.update(G2, 1 / 60);
    assert.ok(G2.P3.bottle.fill > 0.5, 'river water refills the bottle');
  });

  await test('FX codex questions hit the KB; wordy text never hits the calculator', async () => {
    const r1 = await providers.chat('builtin', null, [{ role: 'user', content: 'shaders kaise kaam karte hain?' }]);
    assert.match(r1, /FX Forge/);
    assert.match(r1, /Gerstner/, 'real technique math is taught');
    const r2 = await providers.chat('builtin', null, [{ role: 'user', content: 'game mein paani ka physics kaise chalta hai?' }]);
    assert.match(r2, /Real water physics/);
    assert.match(r2, /DROWNED|doob/i, 'drowning rules explained');
    assert.match(r2, /spring–mass–damper|Dodge/, 'slosh model explained');
    // regression: hyphenated words are NOT arithmetic ("spider-man 3d game" used to calc "- 3")
    const r3 = await providers.chat('builtin', null, [{ role: 'user', content: 'spider-man 3d game' }]);
    assert.ok(!/Calculated locally/.test(r3), 'game request is not hijacked by the calculator');
    assert.match(r3, /3D game DNA|Plan:/);
    // real arithmetic still computes
    assert.match(await providers.chat('builtin', null, [{ role: 'user', content: '234*891' }]), /208494/);
    assert.match(await providers.chat('builtin', null, [{ role: 'user', content: '(2+3)*4%7' }]), /= 6/);
    assert.match(await providers.chat('builtin', null, [{ role: 'user', content: '2^10' }]), /1024/);
  });

  await test('GTA-6 detail pack: tracks, crowds, gators, weather live in the composed game', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d, describeSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const mk = (req, frames = 5) => {
      const spec = parseSpec3d(req);
      const sb = runGame({ engineSrc: engine, gameSrc: `const GAME_SPEC3D = ${JSON.stringify(spec)};\n` + c3d, frames, extraSrcs: [engine3d] });
      return sb.__composed3d;
    };
    const G = mk('swat fps mission in the city');
    assert.equal(G.peds.length, 12, 'a crowd lives in the city (9 civilians + 3 hospital staff)');
    assert.equal(G.gators.length, 2, 'alligators patrol the river');
    assert.equal(G.birds.length, 5, 'seabirds wheel overhead');
    assert.ok(G.weather && Number.isFinite(G.weather.intensity), 'a weather cell exists');

    // footprints: walking leaves tracks that fade like disturbed mud
    G.state = 'play';
    G.P3.x = 300; G.P3.z = 300; G.P3.y = 17; G.P3.yaw = 0;
    for (let i = 0; i < 60; i += 1) { G.input.keys.add('KeyW'); G.scene.update(G, 1 / 60); }
    assert.ok(G.tracks.length >= 3, `footprints left: ${G.tracks.length}`);
    for (let i = 0; i < 1200; i += 1) G.scene.update(G, 1 / 60);
    assert.equal(G.tracks.length, 0, 'mud settles — tracks fade out');

    // crowd reacts to gunfire (v1.20: isolate the ped logic — reset the
    // player to a deterministic safe state so the assert tests peds, not
    // wherever 21 seconds of held-KeyW wandering happened to end)
    G.input.keys.clear();
    G.state = 'play';
    G.P3.x = 300; G.P3.z = 300; G.P3.y = 17; G.P3.hp = 100; G.P3.inWater = false; G.P3.o2 = 100;
    G.peds[0].x = G.P3.x + 40; G.peds[0].z = G.P3.z;
    G.peds[0].state = 'walk'; G.peds[0].fleeT = 0;
    G.shotT = 0.3;
    G.scene.update(G, 1 / 60);
    assert.equal(G.peds[0].state, 'flee', 'gunfire makes pedestrians run');

    // alligators hunt what is IN the water
    const Gb = mk('swat fps mission in the city');
    Gb.state = 'play';
    Gb.gators[0].x = 810; Gb.gators[0].z = 800; Gb.gators[0].biteT = 0;
    Gb.P3.x = 800; Gb.P3.z = 800; Gb.P3.hp = 100; Gb.P3.hitT = 0;
    Gb.scene.update(Gb, 1 / 60);
    assert.ok(Gb.P3.inWater && Gb.P3.hp <= 84, `gator rolled on the swimmer (hp ${Gb.P3.hp})`);
    assert.match(Gb.P3.msg, /ALLIGATOR/);

    // tire tracks: handbrake skid in the open river-valley corridor
    const Gd = mk('gta 5 open world crime driving game');
    Gd.state = 'play';
    Gd.P3.x = 700; Gd.P3.z = 970; Gd.P3.carAngle = Math.PI / 2; Gd.P3.yaw = Math.PI / 2; Gd.P3.speed = 220;
    for (let i = 0; i < 12; i += 1) { Gd.input.keys.add('Space'); Gd.scene.update(Gd, 1 / 60); }
    assert.ok(Gd.P3.skidding, 'handbrake at speed skids');
    assert.ok(Gd.tracks.length >= 2, `tire tracks left: ${Gd.tracks.length}`);
    // struck by the car: knockdown + crowd panic
    const pd = Gd.peds[0]; pd.x = Gd.P3.x + 4; pd.z = Gd.P3.z;
    const n0 = Gd.peds.length;
    Gd.P3.speed = 120;
    Gd.scene.update(Gd, 1 / 60);
    assert.equal(Gd.peds.length, n0 - 1, 'struck ped knocked down');
    assert.match(Gd.P3.msg, /PED STRUCK/);

    // weather drifts with time (rails ships rain)
    const Gr = mk('choo-choo charles style train horror game', 2);
    const i0 = Gr.weather.intensity;
    for (let i = 0; i < 400; i += 1) Gr.scene.update(Gr, 1 / 60);
    assert.ok(Math.abs(Gr.weather.intensity - i0) > 0.02, `weather cell drifts (${i0.toFixed(2)} -> ${Gr.weather.intensity.toFixed(2)})`);

    // the reply advertises the living world for city specs
    assert.match(describeSpec3d(parseSpec3d('gta 5 game')), /alligators|crowds flee/i);
  });

  await test('GTA 6 details question hits the research KB topic (no AAA hijack)', async () => {
    const r = await providers.chat('builtin', null, [{ role: 'user', content: 'GTA 6 mein kya kya real details hain?' }]);
    assert.match(r, /GTA 6 ke real minor details/);
    assert.match(r, /ALLIGATOR|alligator/i);
    assert.match(r, /MUD|mud|keechad/i);
    assert.match(r, /NAHI banaya|jhooth nahi/, 'honest about what is not built');
    const r2 = await providers.chat('builtin', null, [{ role: 'user', content: 'gta 6 kitne bare budget ka project hai?' }]);
    assert.match(r2, /AAA game development actually takes/, 'budget questions still hit the AAA topic');
  });

  await test('Air_you mind: no unsolicited intro, powers, think, imagine, read, self-generate', async () => {
    const builtin = require('../shared/builtin.cjs');
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);

    // greetings must NOT self-introduce (user rule: intro sirf poochne par)
    const hi = await ask('hi');
    assert.ok(!/built-in offline AI hoon|Main \*\*Air_you\*\* hoon|Air Developing ka built-in/i.test(hi), `greeting is intro-free: "${hi}"`);
    assert.ok(hi.length < 160, 'greeting stays short');
    const who = await ask('tum kaun ho');
    assert.match(who, /Air_you/, 'full identity answer WHEN ASKED');

    // powers list
    const pw = await ask('tumhari kya powers hain?');
    assert.match(pw, /THINK/); assert.match(pw, /IMAGINE/); assert.match(pw, /SELF-GENERATE/);
    assert.match(await ask('what can you do'), /Air_you ki powers/);

    // think mode: structured reasoning
    const th = await ask('think how to learn fast typing');
    assert.match(th, /THINK mode/); assert.match(th, /READ:/); assert.match(th, /PLAN:/); assert.match(th, /ANSWER:/);

    // imagine: deterministic per prompt, varied across prompts, real scene
    const im1 = await ask('imagine a rainy night city by the sea');
    const im2 = await ask('imagine a rainy night city by the sea');
    const im3 = await ask('imagine mountains in daylight');
    assert.equal(im1, im2, 'same words -> same imagined scene');
    assert.notEqual(im1, im3, 'different words -> different scene');
    assert.match(im1, /ASCII canvas/);
    assert.ok(/[*~^|OY]/.test(im1), 'scene contains drawn glyphs');

    // read: real file summary from the workspace, honest miss otherwise
    const files = { 'notes.txt': 'hello line1\nfunction alpha() {}\nconst beta = () => 2;\nline4\n' };
    builtin.setWorkspace({
      read: (rel) => { if (files[rel]) return files[rel]; throw new Error('missing'); },
      write: (rel, c) => { files[rel] = c; return rel; },
      listFlat: () => Object.keys(files)
    });
    try {
      const rd = await ask('read notes.txt');
      assert.match(rd, /padh li/); assert.match(rd, /alpha/); assert.match(rd, /4 lines/);
      assert.match(await ask('read ghost.txt'), /nahi mila/);
      // self-generate: writes its own knowledge entry and RECALLS it later
      const sg = await ask('khud ka naya knowledge generate karo: solar system planets');
      assert.match(sg, /Self-generate ho gaya/);
      assert.ok(files['.dev-studio/selfgen.json'], 'selfgen memory persisted to disk');
      const rc = await ask('solar system planets ke baare mein kya yaad hai?');
      assert.match(rc, /khud-generate ki hui yaad/);
      assert.match(rc, /solar/i);
    } finally { builtin.setWorkspace(null); }

    // the game engine is fed INTO Air_you and answerable from its own KB
    const gk = await ask('Air_you ke andar kaunsa game knowledge feed hai?');
    assert.match(gk, /game engine — sab kuch MERI apni feed/);
    assert.match(gk, /GameKit3D/); assert.match(gk, /FX Forge/); assert.match(gk, /One-way rule/i);
  });

  await test('v1.19 API-key system: paste-proof normalize + provider auto-detect', () => {
    // paste junk — quotes, newlines, spaces — auto-clean ho jata hai
    assert.strictEqual(providers.normalizeKey('  "sk-ant-api03-x\ny"  '), 'sk-ant-api03-xy');
    assert.strictEqual(providers.normalizeKey("'gsk_abc 123'"), 'gsk_abc123');
    assert.strictEqual(providers.normalizeKey(null), '');
    // official prefixes → sahi connector; kabhi galat guess nahi
    assert.strictEqual(providers.detectProvider('sk-ant-api03-abcDEF123'), 'anthropic');
    assert.strictEqual(providers.detectProvider('\n"gsk_aBcDeF123456"\n'), 'groq');
    assert.strictEqual(providers.detectProvider('pplx-aBcDeF123'), 'perplexity');
    assert.strictEqual(providers.detectProvider('AIzaSyD-1234567890abcdefghij'), 'gemini');
    assert.strictEqual(providers.detectProvider('sk-proj-aBcDeF1234567890'), 'openai');
    assert.strictEqual(providers.detectProvider('hf_whatever'), null);
    // setKey normalized value store karta hai (getKey se wapas parho)
    providers.setKey('TEST_V119_ENV', ' "gsk_paste\nmess" ');
    assert.strictEqual(providers.getKey('TEST_V119_ENV'), 'gsk_pastemess');
    providers.setKey('TEST_V119_ENV', '');
    assert.strictEqual(providers.getKey('TEST_V119_ENV'), null);
  });

  await test('v1.19 vision: attachImages converts per-provider wire formats', async () => {
    const img = 'data:image/png;base64,iVBORw0KGgo=';
    const msgs = [{ role: 'user', content: 'ye dekho' }];
    // OpenAI-compatible: content array with text + image_url
    const oa = providers.attachImages('openai', msgs, [img]);
    assert.ok(Array.isArray(oa[0].content));
    assert.deepStrictEqual(oa[0].content[0], { type: 'text', text: 'ye dekho' });
    assert.strictEqual(oa[0].content[1].type, 'image_url');
    assert.strictEqual(oa[0].content[1].image_url.url, img);
    assert.strictEqual(typeof msgs[0].content, 'string'); // caller ki history kabhi mutate nahi hoti
    // Anthropic: base64 source blocks, image pehle text baad
    const an = providers.attachImages('anthropic', msgs, [img]);
    assert.strictEqual(an[0].content[0].type, 'image');
    assert.deepStrictEqual(an[0].content[0].source, { type: 'base64', media_type: 'image/png', data: 'iVBORw0KGgo=' });
    assert.strictEqual(an[0].content[1].type, 'text');
    // Gemini: inline_data parts
    const gp = providers.geminiParts(oa[0].content);
    assert.strictEqual(gp[0].text, 'ye dekho');
    assert.deepStrictEqual(gp[1], { inline_data: { mime_type: 'image/png', data: 'iVBORw0KGgo=' } });
    // caps + junk filter
    assert.strictEqual(providers.attachImages('openai', msgs, [img, img, img, img, img])[0].content.length, 5);
    assert.strictEqual(providers.attachImages('openai', msgs, ['junk'])[0].content, 'ye dekho');
    assert.strictEqual(providers.attachImages('openai', msgs, [])[0].content, 'ye dekho');
    // builtin Air_you: honest — metadata note milta hai, dekhne ka natak nahi
    const bi = providers.attachImages('builtin', msgs, [img]);
    assert.match(bi[0].content, /\[User ne image attach ki — image 1: image\/png/);
    const reply = await providers.chat('builtin', null, bi);
    assert.match(reply, /DEKH nahi sakta/);
    assert.match(reply, /ChatGPT, Claude, Gemini, Groq/);
    // SEARCH power ab powers list mein hai
    assert.match(await providers.chat('builtin', null, [{ role: 'user', content: 'tumhari kya powers hain?' }]), /SEARCH/);
  });

  await test('v1.20 situation engine: OBSERVE→TASKS→RISKS→PLAN→REFINE, honest', async () => {
    const situation = require('../shared/situation.cjs');
    const a = situation.assess('apni dukaan ke liye store website banao billing ke saath', { files: ['store/items.json', 'README.md'], lessons: [] });
    assert.equal(a.intent, 'store');
    assert.ok(a.tasks.length >= 4);
    assert.match(a.observe, /store\/items\.json/, 'observe lists REAL matching files only');
    assert.ok(a.risks.length >= 1);
    assert.equal(a.plan, 'OBSERVE → TASKS → ACT → VERIFY → REFINE');
    const r = situation.assess('latest gta 6 news research karo');
    assert.equal(r.intent, 'research');
    assert.equal(r.needsWeb, true);
    // past lessons fold in when they match the goal (learning gets faster)
    const l = situation.assess('store billing fix karo', { lessons: ['store billing: decimal rounding bug — tests add kiye', 'game fps drop'] });
    assert.ok(l.lessons.some((x) => /decimal rounding/.test(x)), 'matching past lesson injected');
    // builtin command end-to-end
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'situation: mera game project crash ho raha hai fix karo' }]);
    assert.match(reply, /SITUATION HANDLING \(Air_you 3\.0\)/);
    assert.match(reply, /intent: FIX/);
    assert.match(reply, /OBSERVE/); assert.match(reply, /TASKS:/); assert.match(reply, /RISKS:/); assert.match(reply, /REFINE/);
    const reply2 = await providers.chat('builtin', null, [{ role: 'user', content: 'halat: store mein time to time changes karne hain' }]);
    assert.match(reply2, /intent: STORE/);
    assert.match(reply2, /SNAPSHOT/i);
    // powers list ab SITUATION + STORE DESK + KNOWLEDGE BANK advertise karti hai
    const pw = await providers.chat('builtin', null, [{ role: 'user', content: 'tumhari kya powers hain?' }]);
    assert.match(pw, /SITUATION \(3\.0\)/); assert.match(pw, /STORE DESK/); assert.match(pw, /KNOWLEDGE BANK/);
  });

  await test('v1.20 STORE DESK 💎: snapshot → history → rollback, journal ke saath', async () => {
    const builtin = require('../shared/builtin.cjs');
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const files = { 'store-items.json': '[{"id":1,"name":"chai","price":120}]', 'index.html': '<h1>Meri Store</h1>', 'notes.md': 'todo: billing' };
    builtin.setWorkspace({
      read: (rel) => { if (files[rel]) return files[rel]; throw new Error('missing'); },
      write: (rel, c) => { files[rel] = c; return rel; },
      listFlat: () => Object.keys(files)
    });
    try {
      const s1 = await ask('store ka snapshot lo');
      assert.match(s1, /STORE SNAPSHOT v1 — 3 files/);
      assert.ok(files['.dev-studio/store/snap-1.json'], 'snapshot disk par persist hua');
      // real edit jaisa change
      files['store-items.json'] = '[{"id":1,"name":"chai","price":999}]';
      const h = await ask('store history dikhao');
      assert.match(h, /snapshot v1 — 3 files/);
      const s2 = await ask('store ka snapshot lo');
      assert.match(s2, /STORE SNAPSHOT v2/);
      // rollback v1 → original price wapas
      const rb = await ask('rollback v1');
      assert.match(rb, /STORE ROLLBACK v1 — 3 files/);
      assert.match(files['store-items.json'], /"price":120/);
      // jo version maujood nahi — honest
      assert.match(await ask('rollback v9'), /nahi mila/);
      // journal ne rollback darj kiya
      assert.match(files['.dev-studio/store/journal.json'], /rollback → snapshot v1/);
    } finally { builtin.setWorkspace(null); }
    // workspace ke bina honest desktop-only jawab
    assert.match(await ask('store ka snapshot lo'), /workspace chahiye/);
  });

  await test('v1.20 KNOWLEDGE BANK: data collection + fast honest reuse', () => {
    const kb = require('../shared/kbank.cjs');
    assert.ok(kb.similarity('gta 6 water physics', 'gta 6 water physics details') > 0.6);
    assert.ok(kb.similarity('gta 6 water', 'react hooks tutorial') < 0.3);
    let bank = '[]';
    bank = kb.record(bank, 'GTA 6 water physics!', [
      { title: 'Waves redo', url: 'https://a/1', snippet: 'water interacts' },
      { title: 'B', url: 'https://a/2', snippet: 's2' }
    ], { summary: 'water redone', source: 'duckduckgo' });
    const hit = kb.find(bank, 'gta 6 water physics');
    assert.ok(hit && hit.sim >= 62, 'similar query hits the bank');
    assert.equal(hit.entry.results[0].title, 'Waves redo');
    assert.match(hit.entry.summary, /water redone/);
    assert.equal(hit.ageH, 0);
    assert.equal(kb.find(bank, 'how to bake cake'), null, 'unrelated query misses');
    // cap 60, newest first
    for (let i = 0; i < 70; i += 1) bank = kb.record(bank, `query number ${i} about topic ${i}`, [{ title: 't' + i, url: 'u', snippet: 's' }]);
    const st = kb.stats(bank);
    assert.equal(st.entries, 60);
    assert.equal(st.queries[0], 'query number 69 about topic 69');
    // 3 din se purana entry hit NAHI hota — fresh search honi chahiye
    const old = JSON.stringify([{ query: 'gta 6 water physics', when: Date.now() - 4 * 864e5, results: [] }]);
    assert.equal(kb.find(old, 'gta 6 water physics'), null);
  });

  await test('v1.20 UPDATER 💎: semver + honest feed handling (kabhi jhooth nahi)', async () => {
    const up = require('../shared/updater.cjs');
    assert.equal(up.semverCmp('1.20.0', '1.19.0'), 1);
    assert.equal(up.semverCmp('1.19.0', '1.20.0'), -1);
    assert.equal(up.semverCmp('1.20.0', '1.20.0'), 0);
    assert.equal(up.semverCmp('2.0.10', '2.0.9'), 1);
    assert.equal(up.semverCmp('junk', '1.0.0'), 0);
    up.setFetch(async () => ({ ok: true, json: async () => ({ tag_name: 'v1.21.0', html_url: 'https://rel', body: 'naya release', assets: [{ name: 'Air-Developing.zip', browser_download_url: 'https://dl/zip' }] }) }));
    const r1 = await up.checkForUpdate('1.20.0');
    assert.equal(r1.ok, true); assert.equal(r1.latest, '1.21.0'); assert.equal(r1.updateAvailable, true);
    assert.equal(r1.url, 'https://dl/zip', 'zip asset preferred');
    up.setFetch(async () => ({ ok: true, json: async () => ({ tag_name: 'v1.20.0' }) }));
    const r2 = await up.checkForUpdate('1.20.0');
    assert.equal(r2.updateAvailable, false); assert.equal(r2.url, up.DEFAULT_FEED);
    up.setFetch(async () => ({ ok: false, status: 503 }));
    const r3 = await up.checkForUpdate('1.20.0');
    assert.equal(r3.ok, false); assert.match(r3.error, /HTTP 503/, 'feed down = honest error, fake "up to date" nahi');
    up.setFetch(async () => { throw new Error('socket hang up'); });
    const r4 = await up.checkForUpdate('1.20.0');
    assert.equal(r4.ok, false); assert.match(r4.error, /socket hang up/);
    up.setFetch(async () => ({ ok: true, json: async () => ({ tag_name: 'nightly' }) }));
    const r5 = await up.checkForUpdate('1.20.0');
    assert.equal(r5.ok, false); assert.match(r5.error, /version tag nahi mila/);
    assert.ok(up.planUpdate('C:\\Dev-Studio').join(' ').includes('khud ko safely replace NAHI'), 'plan honest about running-exe truth');
    up.setFetch(typeof fetch === 'function' ? fetch : null);
  });

  await test('Detail Pack 2: car anatomy, REAL fridge, traffic, airport, heli, gym, beach', () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d, describeSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const mk = (req, frames = 5) => {
      const spec = parseSpec3d(req);
      const sb = runGame({ engineSrc: engine, gameSrc: `const GAME_SPEC3D = ${JSON.stringify(spec)};\n` + c3d, frames, extraSrcs: [engine3d] });
      return sb.__composed3d;
    };
    const G = mk('swat fps mission in the city');
    G.state = 'play';

    // car anatomy: 7 khulne wale parts, hinge-speed animation, mirror follows door
    assert.equal(Object.keys(G.car.parts).length, 7, '4 doors + trunk + hood + fuel cap');
    assert.ok(G.car.mirrors && G.car.engine && G.car.fuel === 62);
    G.scene.togglePart(G, 'hood');
    assert.equal(G.car.parts.hood.target, 1);
    for (let i = 0; i < 40; i += 1) G.scene.update(G, 1 / 60);
    assert.ok(G.car.parts.hood.open > 0.9, 'hood ANIMATED khula (teleport nahi)');
    G.scene.togglePart(G, 'doorLF');
    for (let i = 0; i < 40; i += 1) G.scene.update(G, 1 / 60);
    assert.ok(G.car.mirrors.L.fold > 0.4, 'side mirror front door ke saath fold hua');

    // fridge: items ANDAR pehle se (spawn nahi) → open → take → haath + slosh → drop = gravity → wapas uthao → drink
    const fr = G.props[0];
    assert.equal(fr.kind, 'fridge');
    assert.equal(fr.open, 0);
    assert.deepEqual(fr.items.map((i) => i.kind), ['bottle', 'cup', 'veg']);
    assert.ok(fr.items.every((i) => !i.taken), 'items ALREADY inside before any open');
    fr.x = 1250; fr.z = 660; // khula river-bank strip (buildings se door)
    G.P3.x = fr.x + 6; G.P3.z = fr.z; G.P3.y = 17; G.input.keys.clear();
    assert.equal(G.scene.interact(G), 'fridge');
    assert.equal(G.scene.takeItem(G), null, 'band fridge se item nahi nikalta — honest');
    for (let i = 0; i < 40; i += 1) { G.P3.x = fr.x + 6; G.P3.z = fr.z; G.scene.update(G, 1 / 60); }
    assert.ok(fr.open > 0.9, 'fridge door swing hui');
    assert.equal(G.scene.takeItem(G), 'bottle');
    assert.equal(G.P3.held.kind, 'bottle');
    assert.equal(fr.items[0].taken, true, 'jo nikla wo fridge se GAYA (dobara wahin nahi)');
    assert.ok(G.P3.bottle, 'bottle asli slosh system se judi');
    for (let i = 0; i < 12; i += 1) { G.P3.yaw += 0.06; G.scene.update(G, 1 / 60); }
    assert.ok(Math.abs(G.P3.bottle.x) > 1e-4 || G.P3.bottle.v !== 0, 'haath ki bottle ka paani slosh hua');
    const fill0 = G.P3.held.fill;
    assert.ok(G.scene.drinkHeld(G) && G.P3.held.fill < fill0, 'piya → level gira');
    assert.ok(G.scene.dropHeld(G));
    const d0 = G.dropped[0];
    for (let i = 0; i < 30; i += 1) G.scene.update(G, 1 / 60);
    assert.ok(d0.rest && d0.y === 3, 'gira item GRAVITY se zameen par tika');
    G.P3.x = d0.x + 2; G.P3.z = d0.z;
    assert.equal(G.scene.interact(G), 'pickup', 'wahi gira hua item wapas utha — naya spawn nahi hua');

    // traffic chalti hai; plane parked → takeoff → airborne (engine/prop/pilot); heli rotors
    assert.equal(G.traffic.length, 6);
    const tp0 = G.traffic[0].pos;
    for (let i = 0; i < 30; i += 1) G.scene.update(G, 1 / 60);
    assert.notEqual(G.traffic[0].pos, tp0, 'traffic chalti hai');
    assert.equal(G.planes[0].pilot, true);
    const pl = G.planes[0];
    for (let i = 0; i < 900; i += 1) G.scene.update(G, 1 / 60);
    assert.notEqual(pl.state, 'parked');
    assert.ok(pl.y > 40 && pl.prop > 10, 'plane ASLI takeoff: airborne + prop spun');
    assert.ok(G.helis[0].rotor > 100 && G.helis[0].y > 90, 'heli rotors spin while hovering');

    // gym: andar aaya ped workout karta hai, bahar = walk
    const ped = G.peds[0];
    ped.x = G.gym.x0 + 20; ped.z = G.gym.z0 + 20; ped.state = 'walk'; ped.fleeT = 0;
    if (ped.machine) { ped.machine.busy = null; ped.machine = null; }
    for (let i = 0; i < 5; i += 1) { G.state = 'play'; G.P3.hp = 100; G.scene.update(G, 1 / 60); }
    assert.equal(ped.state, 'workout');
    assert.ok(ped.machine && ped.machine.busy === ped, 'ped ne machine CLAIM ki (organized gym)');
    ped.x = 300; ped.z = 300;
    for (let i = 0; i < 5; i += 1) { G.state = 'play'; G.P3.hp = 100; G.scene.update(G, 1 / 60); }
    assert.equal(ped.state, 'walk');

    // beach: umbrellas + lete hue sunbathers + ball
    assert.equal(G.beach.umbrellas.length, 3);
    assert.equal(G.beach.sunbathers.length, 2);
    assert.ok(G.beach.ball.y >= 0);

    // drive world: chalti gaari honest refuse; refuel sirf cap khula + ruki
    const D = mk('gta 5 open world crime driving game');
    D.state = 'play';
    D.P3.speed = 120;
    assert.equal(D.scene.togglePart(D, 'doorLF'), false, 'chalti gaari ka darwaza honest refuse');
    D.P3.speed = 0;
    assert.equal(D.car.engine.on, true, 'drive world engine ON se start');
    D.scene.togglePart(D, 'fuelCap');
    for (let i = 0; i < 600; i += 1) D.scene.update(D, 1 / 60);
    assert.ok(D.car.fuel > 62, 'cap khula + gaari ruki = petrol bhara');
    const D2 = mk('gta 5 open world crime driving game');
    D2.state = 'play'; D2.P3.speed = 0;
    const fuel0 = D2.car.fuel;
    for (let i = 0; i < 120; i += 1) D2.scene.update(D2, 1 / 60);
    assert.equal(D2.car.fuel, fuel0, 'cap band = honest no-refuel');

    // spec descriptions nayi reality advertise karte hain
    assert.match(describeSpec3d(parseSpec3d('gta 5 game')), /traffic|fridge|takes off/i);
    assert.match(describeSpec3d(parseSpec3d('gta 5 open world crime driving game')), /car anatomy/i);
  });

  await test('Detail Codex: 100k details ka scalable ghar + Air_you KB se jawab', async () => {
    const codex = require('../shared/gamekit/detailcodex.cjs');
    const c = codex.count();
    assert.ok(c.categories >= 7, `codex grew to ${c.categories} categories (7 shipped + v1.23 body/citylife)`);
    assert.ok(c.total >= 35 && c.done >= 25, `entries ${c.total}, done ${c.done}`);
    assert.ok(codex.search('fridge').length >= 1);
    assert.ok(codex.search('hood').length >= 1);
    assert.ok(codex.search('pilot').length >= 2);
    assert.ok(codex.category('car').length >= 7);
    // Air_you codex se jawab deta hai — honest counts ke saath
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const r1 = await ask('car ki kya kya details hain?');
    assert.match(r1, /DETAIL PACK 2 \+ DETAIL CODEX/);
    assert.match(r1, /PETROL CAP/); assert.match(r1, /SIDE MIRRORS/); assert.match(r1, /FRIDGE/i);
    const r2 = await ask('fridge wali GTA detail kaise kaam karti hai?');
    assert.match(r2, /PEHLE SE hote hain/);
    assert.match(r2, /GRAVITY/);
    const r3 = await ask('detail codex mein kitni details hain?');
    assert.match(r3, /categories/);
    assert.ok(r3.includes(String(c.total)), 'honest live count from codex');
    // game-feed KB topic ab Detail Pack 2 bhi pin karta hai
    assert.match(await ask('Air_you ke andar kaunsa game knowledge feed hai?'), /DETAIL PACK 2/);
  });

  /* ============ v1.22.0 — POWER TO EXISTING: AIR LOOP + CODEX 2.0 + deep powers ============ */

  await test('AIR LOOP: agent module OBSERVE→READ→PLAN→WRITE→VERIFY→REFINE (mock ws)', () => {
    const { runAirLoop } = require('../shared/airloop.cjs');
    const files = {
      'store.js': 'function snap() {}\nfunction rollback() {}\nconst store = 1;\n',
      'notes.txt': 'random notes line\nnothing relevant here\n'
    };
    const mockWs = {
      read: (rel) => { if (rel in files) return files[rel]; throw new Error('missing'); },
      write: (rel, c) => { files[rel] = c; return rel; },
      listFlat: () => Object.keys(files)
    };
    const r = runAirLoop({ goal: 'store ko behtar karo', ws: mockWs });
    assert.strictEqual(r.ok, true, 'loop must succeed on mock ws');
    assert.ok(r.steps.length >= 5, 'multi-step loop, not a one-liner');
    assert.ok(r.steps.some((s) => /OBSERVE|list_files/.test(s.tool)), 'OBSERVE step real');
    assert.ok(r.artifact && r.artifact.startsWith('.dev-studio/air/'), 'artifact under .dev-studio/air/');
    assert.strictEqual(r.verified, true, 'VERIFY = read-back exact match');
    assert.ok(files[r.artifact], 'artifact really written to mock disk');
    const journal = JSON.parse(files['.dev-studio/air/journal.json']);
    assert.ok(Array.isArray(journal) && journal[0].lesson, 'REFINE lesson journaled (newest first)');
    // honest failure without workspace — no fake agent theatre
    const r2 = runAirLoop({ goal: 'anything', ws: null });
    assert.strictEqual(r2.ok, false);
    assert.ok(r2.honest && /workspace/i.test(r2.honest), 'honest reason when ws missing');
    const r3 = runAirLoop({ goal: '', ws: mockWs });
    assert.strictEqual(r3.ok, false);
  });

  await test('builtin: airloop command, grep command, THINK real observation, best-scored recall', async () => {
    const builtin = require('../shared/builtin.cjs');
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const files = {
      'store.js': 'function snap() { return 1; }\nfunction rollback(v) { return v; }\nconst HANDLE = "store-handle";\n',
      'app.js': 'console.log("hello");\n'
    };
    builtin.setWorkspace({
      read: (rel) => { if (rel in files) return files[rel]; throw new Error('missing'); },
      write: (rel, c) => { files[rel] = c; return rel; },
      listFlat: () => Object.keys(files)
    });
    try {
      // airloop via chat — full agent report
      const al = await ask('airloop store ko behtar karo');
      assert.match(al, /AIR LOOP/);
      assert.match(al, /OBSERVE|list_files/);
      assert.match(al, /VERIFY/);
      assert.match(al, /koi connected AI is mein shamil nahi/);
      // grep — found / not-found / missing-file, all honest
      const g1 = await ask('grep store.js HANDLE');
      assert.match(g1, /3\b/, 'line number shown');
      assert.match(g1, /store-handle/);
      const g2 = await ask('grep store.js zzzznotthere');
      assert.match(g2, /NAHI mila/);
      const g3 = await ask('grep ghost.js anything');
      assert.match(g3, /nahi mila/);
      // THINK now observes the REAL workspace (file matched by keyword appears)
      const th = await ask('think store ko kaise behtar karun');
      assert.match(th, /THINK mode/); assert.match(th, /READ:/); assert.match(th, /PLAN:/); assert.match(th, /ANSWER:/);
      assert.match(th, /workspace mein MILTI files: store\.js \(\d+ lines\)/);
      // recall = BEST-scored entry wins, not just the newest
      files['.dev-studio/selfgen.json'] = JSON.stringify([
        { topic: 'solar deep entry', at: '2026-01-01', keywords: ['solar', 'system', 'planets', 'orbits'], lines: ['purani magar SABSE behtar yaad'] },
        { topic: 'solar shallow entry', at: '2026-06-01', keywords: ['solar', 'planets'], lines: ['nayi magar kamzor yaad'] }
      ], null, 1);
      const rc = await ask('solar system planets orbits kaise kaam karte hain?');
      assert.match(rc, /khud-generate ki hui yaad/);
      assert.match(rc, /solar deep entry/, 'higher-overlap older entry beats shallow newer one');
    } finally { builtin.setWorkspace(null); }
  });

  await test('CODEX 2.0: user entries + ranked search + live audit + KB live counts', async () => {
    const codex = require('../shared/gamekit/detailcodex.cjs');
    // guessCategory
    assert.strictEqual(codex.guessCategory('car ke wiper baarish mein asli speed'), 'car');
    assert.strictEqual(codex.guessCategory('fridge ki light khulne par jalti hai'), 'home');
    assert.strictEqual(codex.guessCategory('traffic signal yellow hone par cars slow hoti hain'), 'traffic');
    assert.strictEqual(codex.guessCategory('plane runway par roll karta hai'), 'airport');
    assert.strictEqual(codex.guessCategory('kuch bhi ajeeb detail'), 'user');
    // addUserEntry: prepend + cap 200
    let raw = '[]';
    raw = codex.addUserEntry(raw, 'car ke wiper baarish ki speed se chalte hain');
    const parsed = JSON.parse(raw);
    assert.strictEqual(parsed.length, 1);
    assert.strictEqual(parsed[0].impl, 'user-added');
    let big = JSON.stringify(Array.from({ length: 250 }, (_, i) => ({ cat: 'user', detail: `d${i}`, when: '2026-01-01', impl: 'user-added' })));
    big = codex.addUserEntry(big, 'fresh entry');
    assert.strictEqual(JSON.parse(big).length, 200, 'cap 200 enforced');
    // countWithUser merges user entries into the honest total
    const base = codex.count();
    const cw = codex.countWithUser(raw);
    assert.strictEqual(cw.user, 1);
    assert.strictEqual(cw.total, base.total + 1);
    // rankSearch: best score first, user entries included
    const hits = codex.rankSearch('wiper', raw);
    assert.ok(hits.length >= 1 && hits.some((h) => h.impl === 'user-added'));
    assert.ok(hits.every((h, i) => i === 0 || hits[i - 1].score >= h.score), 'sorted desc by score');
    // audit: live game object passes, empty object fails honestly
    const fakeG = {
      car: { parts: { hood: 1, trunk: 1, doorFL: 1, doorFR: 1, doorRL: 1, doorRR: 1, fuelCap: 1 }, engine: { on: false }, mirrors: { fold: 0 } },
      props: [{ kind: 'fridge', items: [1, 2, 3] }], traffic: [1, 2, 3, 4], planes: [{ pilot: true }],
      helis: [{ pilot: true, rotor: 0 }], gym: { x0: 460 }, beach: { umbrellas: [1, 2, 3] },
      weather: { intensity: 0.3 }, peds: [1, 2, 3]
    };
    const a = codex.audit(fakeG);
    assert.strictEqual(a.allLive, true);
    assert.strictEqual(a.passed, a.total);
    const bad = codex.audit({});
    assert.strictEqual(bad.allLive, false);
    assert.strictEqual(bad.passed, 0);
    // builtin: codex mein likho → persists + KB count now includes user entries
    const builtin = require('../shared/builtin.cjs');
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const files = {};
    builtin.setWorkspace({
      read: (rel) => { if (rel in files) return files[rel]; throw new Error('missing'); },
      write: (rel, c) => { files[rel] = c; return rel; },
      listFlat: () => Object.keys(files)
    });
    try {
      const w = await ask('codex mein likho: car ke wiper baarish ki asli speed se chalte hain');
      assert.match(w, /DETAIL CODEX mein likh diya/);
      assert.match(w, /car/, 'category guessed car');
      assert.ok(files['.dev-studio/detailcodex-user.json'], 'user codex persisted');
      const cnt = await ask('detail codex mein kitni details hain?');
      assert.ok(cnt.includes(String(codex.count().total + 1)), 'KB total includes the user entry');
      assert.match(cnt, /AAPKI likhi hui entries/);
      // bank stats: empty honest, then with data
      const b0 = await ask('bank dikhao');
      assert.match(b0, /khaali/);
      files['.dev-studio/kbank.json'] = JSON.stringify([{ query: 'node latest version', when: new Date().toISOString(), hits: 3 }], null, 1);
      const b1 = await ask('bank dikhao');
      assert.match(b1, /KNOWLEDGE BANK/);
      assert.match(b1, /node latest version/);
      // store diff: changed/added/removed all reported honestly
      files['.dev-studio/store/snap-1.json'] = JSON.stringify({ when: '2026-01-01', files: [{ f: 'a.js', c: 'hash1' }, { f: 'b.js', c: 'hash2' }] });
      files['.dev-studio/store/snap-2.json'] = JSON.stringify({ when: '2026-02-01', files: [{ f: 'a.js', c: 'hash9' }, { f: 'c.js', c: 'hash3' }] });
      const d = await ask('store diff v1 v2');
      assert.match(d, /STORE DIFF v1 ↔ v2/);
      assert.match(d, /CHANGE hui \(1\): a\.js/);
      assert.match(d, /ADD hui \(1\): c\.js/);
      assert.match(d, /REMOVE hui \(1\): b\.js/);
      const dMiss = await ask('store diff v1 v9');
      assert.match(dMiss, /nahi mila/);
    } finally { builtin.setWorkspace(null); }
  });

  /* ============ v1.23.0 — BODY & CITY LIFE PACK ============ */

  await test('Body pack (ORGANIZED GYM): machine-specific exercise, real stretch/relax, honest failure, strength ista ista next level', () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d, describeSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const mk = (req, frames = 5) => {
      const spec = parseSpec3d(req);
      const sb = runGame({ engineSrc: engine, gameSrc: `const GAME_SPEC3D = ${JSON.stringify(spec)};\n` + c3d, frames, extraSrcs: [engine3d] });
      return sb.__composed3d;
    };
    const G = mk('swat fps mission in the city');
    G.state = 'play';
    const step = (k) => { for (let i = 0; i < k; i += 1) { G.state = 'play'; G.foes.length = 0; G.P3.hp = 100; G.scene.update(G, 1 / 60); } };
    const realHit = G.input.hit.bind(G.input);
    let pressX = false;
    G.input.hit = (...codes) => (codes.includes('KeyX') && pressX) || realHit(...codes);
    const tapX = () => { pressX = true; step(1); pressX = false; };

    // describe carries the pack
    assert.match(describeSpec3d(parseSpec3d('swat fps mission in the city')), /BODY & CITY LIFE PACK/);

    // 11-muscle anatomy
    assert.equal(Object.keys(G.body.muscles).length, 13);
    assert.equal(G.body.strength, 10);
    assert.equal(G.body.level, 1);

    // ORGANIZED GYM: 6 named machines, sab gym ke andar
    assert.equal(G.machines.length, 26);
    assert.equal(new Set(G.machines.map((m) => m.name)).size, 26);
    for (const m of G.machines) {
      assert.ok(m.x > G.gym.x0 && m.x < G.gym.x0 + G.gym.w && m.z > G.gym.z0 && m.z < G.gym.z0 + G.gym.d, `${m.name} gym ke andar`);
    }
    // boot frames mein peds ne claim kiya ho to reset
    for (const m of G.machines) { if (m.busy && m.busy !== 'player') { const pd = m.busy; pd.machine = null; if (pd.state === 'workout') pd.state = 'walk'; } m.busy = null; m.phase = 0; }
    if (G.body.machine) G.body.machine = null;
    G.body.active = false;

    // exercise door se = honest refuse — kahin bhi pushups NAHI
    G.P3.x = 800; G.P3.z = 800;
    tapX();
    assert.equal(G.body.active, false);
    assert.match(G.P3.msg, /MACHINE ke paas jao/);

    // bench press par G = claim + PUSH-UPS (chest/triceps/delts)
    const bench = G.machines.find((m) => m.id === 'bench');
    G.P3.x = bench.x; G.P3.z = bench.z + 6;
    assert.equal(G.scene.interact(G), 'machine:bench');
    assert.equal(G.body.active, true);
    assert.equal(G.body.exercise, 0);
    assert.equal(bench.busy, 'player');
    step(240);
    assert.ok(G.body.reps >= 2, 'reps counted');
    assert.ok(bench.phase > 1, 'barbell cycle animates');
    assert.ok(G.body.muscles.chest.f > 0.05, 'chest fatigue rises');
    assert.ok(G.body.muscles.quads.f < 0.02, 'quads NOT a bench prime mover — honest anatomy');
    const chestS = G.body.muscles.chest.s;

    // set band (X) → machine free + RELAX: stretch decays
    tapX();
    assert.equal(G.body.active, false);
    assert.equal(bench.busy, null, 'stop = machine free');
    step(120);
    assert.ok(G.body.muscles.chest.s <= chestS + 0.01, 'stretch relaxes after the set');

    // occupied machine → honest wait
    const rack = G.machines.find((m) => m.id === 'rack');
    rack.busy = { ped: true };
    G.P3.x = rack.x; G.P3.z = rack.z + 6;
    tapX();
    assert.equal(G.body.active, false);
    assert.match(G.P3.msg, /OCCUPIED/);
    rack.busy = null;

    // treadmill = cardio (7th exercise)
    const tread = G.machines.find((m) => m.id === 'tread');
    G.P3.x = tread.x; G.P3.z = tread.z;
    tapX();
    assert.equal(G.body.exercise, 10, 'TREADMILL RUN cardio');
    step(120);
    assert.ok(G.body.muscles.calves.f > 0.03, 'cardio calves par');
    // machine chhod kar gaya = honest adhoora set
    G.P3.x = tread.x + 60; G.P3.z = tread.z + 60;
    step(2);
    assert.equal(G.body.active, false);
    assert.equal(tread.busy, null);
    assert.match(G.P3.msg, /MACHINE CHHOD DI/);

    // progressive strength: XP → level 2 → strength gently up (bench par)
    G.P3.x = bench.x; G.P3.z = bench.z + 6;
    G.body.xp = 79;
    tapX();
    step(120);
    assert.ok(G.body.level >= 2);
    assert.ok(G.body.strength > 10 && G.body.strength < 13, `strength grew gently: ${G.body.strength}`);

    // muscle failure = honest auto-stop + soreness + machine release
    assert.equal(G.body.active, true);
    for (const m of ['chest', 'triceps', 'delts']) G.body.muscles[m].f = 0.99;
    step(240);
    assert.equal(G.body.active, false, 'failure stops the exercise');
    assert.equal(bench.busy, null, 'failure = machine released');
    assert.ok(G.body.soreness > 0);
    assert.match(G.P3.msg, /MUSCLE FAILURE/);

    // ambient body: carrying loads forearms — "koi bi kam karta waqat" (bina machine ke bhi)
    for (const m of Object.keys(G.body.muscles)) { G.body.muscles[m].f = 0; G.body.muscles[m].s = 0; }
    G.P3.held = { kind: 'veg' };
    step(60);
    assert.equal(G.body.ambient, 'carry');
    assert.ok(G.body.muscles.forearms.s > 0.05, 'carry stretch on forearms');
    G.P3.held = null;

    // peds machines claim karte hain; flee par release
    let worker = null;
    for (let i = 0; i < 60 * 40; i += 1) {
      G.state = 'play'; G.foes.length = 0; G.P3.hp = 100;
      G.scene.update(G, 1 / 60);
      worker = G.peds.find((p) => p.state === 'workout' && p.machine);
      if (worker) break;
    }
    assert.ok(worker, 'ped claimed a machine');
    assert.equal(worker.machine.busy, worker);
    const mBefore = worker.machine;
    G.shotT = 0.3; G.P3.x = worker.x + 4; G.P3.z = worker.z + 4;
    step(2);
    assert.equal(worker.state, 'flee');
    assert.equal(mBefore.busy, null, 'flee = machine free');
  });

  await test('City life pack: named shops + cash, buses FSM, ships, shipyard, mine, NPC AI, landmarks', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const mk = (req, frames = 5) => {
      const spec = parseSpec3d(req);
      const sb = runGame({ engineSrc: engine, gameSrc: `const GAME_SPEC3D = ${JSON.stringify(spec)};\n` + c3d, frames, extraSrcs: [engine3d] });
      return sb.__composed3d;
    };
    const G = mk('swat fps mission in the city');
    G.state = 'play';
    const step = (k) => { for (let i = 0; i < k; i += 1) { G.state = 'play'; G.foes.length = 0; G.P3.hp = 100; G.scene.update(G, 1 / 60); } };

    // 6 shops, unique NAAM, 2 gun shops
    assert.equal(G.shops.length, 19);
    assert.equal(new Set(G.shops.map((s) => s.name)).size, 19);
    assert.equal(G.shops.filter((s) => s.kind === 'guns').length, 2);
    assert.ok(G.shops.every((s) => s.name.length > 4));

    // gun shop: buy ammo with cash (score) — broke = honest, full mag = no charge
    G.score = 100; G.P3.ammo = 3;
    G.P3.x = G.shops[0].dx; G.P3.z = G.shops[0].dz;
    assert.equal(G.scene.interact(G), 'shop:guns');
    assert.equal(G.P3.ammo, 12);
    assert.equal(G.score, 60);
    G.score = 5; G.P3.ammo = 2;
    assert.equal(G.scene.interact(G), 'shop-broke');
    assert.equal(G.P3.ammo, 2, 'no free ammo — honest refuse');
    G.score = 100; G.P3.ammo = 12;
    assert.equal(G.scene.interact(G), 'shop-honest');
    assert.equal(G.score, 100, 'full mag par paisa nahi katta');

    // mart: bottle with the REAL slosh spring; mechanic: refuel
    const mart = G.shops.find((s) => s.kind === 'mart');
    G.score = 50; G.P3.held = null; G.P3.bottle = null;
    G.P3.x = mart.dx; G.P3.z = mart.dz;
    assert.equal(G.scene.interact(G), 'shop:mart');
    assert.equal(G.P3.held.kind, 'bottle');
    assert.equal(G.P3.bottle.k, 42);
    const mech = G.shops.find((s) => s.kind === 'mechanic');
    G.car.fuel = 30; G.score = 50; G.P3.held = null;
    G.P3.x = mech.dx; G.P3.z = mech.dz;
    assert.equal(G.scene.interact(G), 'shop:mechanic');
    assert.equal(G.car.fuel, 100);
    assert.equal(G.score, 20);

    // buses: halt FSM at motorway stops, doors open then close
    assert.equal(G.buses.length, 2);
    let sawHalt = false; let sawDoors = false;
    for (let i = 0; i < 60 * 25; i += 1) { G.state = 'play'; G.foes.length = 0; G.P3.hp = 100; G.scene.update(G, 1 / 60); if (G.buses[0].state === 'halt') sawHalt = true; if (G.buses[0].state === 'doors') sawDoors = true; }
    assert.ok(sawHalt && sawDoors, 'bus halt + doors cycle live');
    assert.ok(G.motorway.stops.length === 3);

    // ships move; barge hull slams a swimmer for real
    const barge = G.ships[0];
    const bx0 = barge.x;
    step(60);
    assert.notEqual(barge.x, bx0, 'barge moving');
    G.P3.inWater = true; G.P3.hitT = 0; G.P3.hp = 100;
    G.P3.x = barge.x; G.P3.z = barge.z;
    G.state = 'play'; G.foes.length = 0;
    G.scene.update(G, 1 / 60);
    assert.ok(G.P3.hp < 100, 'hull collision = real damage');
    G.P3.inWater = false;
    assert.ok(G.ships.some((s) => s.kind === 'ocean' && s.x > G.ws), 'ocean ship beyond the wall');

    // shipyard hulls build up in real time; crane swings
    const h0 = G.shipyard.hulls[0].stage;
    step(600);
    assert.ok(G.shipyard.hulls[0].stage > h0, 'hull stage grows');
    assert.ok(G.shipyard.crane.ang > 0.4);

    // mine carts run the rail loop
    const c0 = G.mine.carts[0].t;
    step(60);
    assert.notEqual(G.mine.carts[0].t, c0);
    assert.ok(Number.isFinite(G.mine.carts[0].x));

    // NPC AI: destinations + queue/chat/sit states; flee intact (v1.17 pin)
    step(600);
    assert.ok(G.peds.every((p) => p.state !== 'walk' || p.dest), 'walking peds carry destinations');
    let sawRich = false;
    for (let i = 0; i < 60 * 60; i += 1) {
      G.state = 'play'; G.foes.length = 0; G.P3.hp = 100;
      G.scene.update(G, 1 / 60);
      if (G.peds.some((p) => p.state === 'queue' || p.state === 'chat' || p.state === 'sit')) { sawRich = true; break; }
    }
    assert.ok(sawRich, 'queue/chat/sit emerge from the AI');
    const ped = G.peds.find((p) => p.state !== 'flee');
    G.shotT = 0.3; G.P3.x = ped.x + 5; G.P3.z = ped.z + 5;
    step(2);
    assert.equal(ped.state, 'flee');

    // landmarks named
    assert.ok(G.solids.filter((b) => b.name).length >= 3);

    // non-city world: body zinda, city pack gated
    const G2 = mk('zombie survival in the mansion');
    G2.state = 'play';
    assert.ok(G2.body && Object.keys(G2.body.muscles).length === 13);
    assert.deepEqual(G2.shops, []);
    assert.equal(G2.mine, null);

    // Air_you KB answers about the pack
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const kb = await ask('body pack mein kya hai?');
    assert.match(kb, /BODY & CITY LIFE PACK/);
    assert.match(kb, /MUSCLE FAILURE/);
    assert.match(kb, /GUN SHOPS/i);
    assert.match(kb, /IRONKEEL SHIPYARD/);
    const codex = require('../shared/gamekit/detailcodex.cjs');
    assert.equal(codex.category('body').length, 10);
    assert.equal(codex.category('citylife').length, 10);
    assert.ok(codex.count().done >= 52);
  });

  /* ============ v1.25.0 — WORLD ORGANIZE PACK: 26 exercise stations, hospital, 19 shops ============ */

  await test('World organize: 26 stations + honest muscles per machine, hospital staff/stretchers/pharmacy, books XP, gas pump', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d, describeSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const mk = (req, frames = 5) => {
      const spec = parseSpec3d(req);
      const sb = runGame({ engineSrc: engine, gameSrc: `const GAME_SPEC3D = ${JSON.stringify(spec)};\n` + c3d, frames, extraSrcs: [engine3d] });
      return sb.__composed3d;
    };
    const G = mk('swat fps mission in the city');
    G.state = 'play';
    const step = (k) => { for (let i = 0; i < k; i += 1) { G.state = 'play'; G.foes.length = 0; G.P3.hp = Math.min(100, G.P3.hp); G.scene.update(G, 1 / 60); } };
    const realHit = G.input.hit.bind(G.input);
    let pressX = false;
    G.input.hit = (...codes) => (codes.includes('KeyX') && pressX) || realHit(...codes);
    const tapX = () => { pressX = true; step(1); pressX = false; };

    assert.match(describeSpec3d(parseSpec3d('gta 5 game')), /ORGANIZED GYM|HOSPITAL/);

    // 26 stations: unique names, gym zone ke andar, valid exercise mapping
    assert.equal(G.machines.length, 26);
    assert.equal(new Set(G.machines.map((m) => m.name)).size, 26);
    assert.equal(new Set(G.machines.map((m) => m.ex)).size, 26, 'har station ka apna exercise');
    for (const m of G.machines) {
      assert.ok(m.x > G.gym.x0 && m.x < G.gym.x0 + G.gym.w && m.z > G.gym.z0 && m.z < G.gym.z0 + G.gym.d, `${m.name} zone mein`);
      assert.ok(m.ex >= 0 && m.ex < 26);
    }
    // boot frames se claims reset
    for (const m of G.machines) { if (m.busy && m.busy !== 'player') { const pd = m.busy; pd.machine = null; if (pd.state === 'workout') pd.state = 'walk'; } m.busy = null; m.phase = 0; }

    const zeroF = () => { for (const mn of Object.keys(G.body.muscles)) G.body.muscles[mn].f = 0; };
    // LEG PRESS: quads prime — chest honest idle
    const lp = G.machines.find((m) => m.id === 'legpress');
    G.P3.x = lp.x; G.P3.z = lp.z + 6;
    assert.equal(G.scene.interact(G), 'machine:legpress');
    zeroF();
    step(240);
    assert.ok(G.body.muscles.quads.f > 0.03, `leg press quads par (${G.body.muscles.quads.f.toFixed(3)})`);
    assert.ok(G.body.muscles.chest.f < 0.01, 'chest idle — honest per-machine anatomy');
    assert.ok(lp.phase > 1, 'sled slide animation');
    tapX(); // stop

    // LAT PULLDOWN: lats prime (quads is machine par bilkul idle)
    const lat = G.machines.find((m) => m.id === 'lat');
    G.P3.x = lat.x; G.P3.z = lat.z + 6;
    assert.equal(G.scene.interact(G), 'machine:lat');
    zeroF();
    step(300);
    assert.ok(G.body.muscles.lats.f > 0.015, `lat pulldown lats par (${G.body.muscles.lats.f.toFixed(3)})`);
    assert.ok(G.body.muscles.quads.f < 0.01, 'quads idle on lat machine');
    tapX();

    // KETTLEBELL (turf): glutes prime
    const kb = G.machines.find((m) => m.id === 'kbell');
    G.P3.x = kb.x; G.P3.z = kb.z;
    assert.equal(G.scene.interact(G), 'machine:kbell');
    zeroF();
    step(240);
    assert.ok(G.body.muscles.glutes.f > 0.04, `kettlebell swings glutes par (${G.body.muscles.glutes.f.toFixed(3)})`);
    tapX();

    // HOSPITAL: building + beds + shelf + counter + stretchers
    const H = G.hospital;
    assert.ok(H && H.beds.length === 3 && H.shelf && H.counter);
    assert.ok(H.beds.filter((b) => b.pat).length >= 1, 'patients in beds');
    assert.equal(G.stretchers.length, 2);
    // stretcher roll FSM: z badalta hai, wait ↔ roll cycle
    const st = G.stretchers[0];
    let sawRoll = false; let sawWait = false; let zMin = st.z; let zMax = st.z;
    for (let i = 0; i < 60 * 14; i += 1) { G.state = 'play'; G.foes.length = 0; G.scene.update(G, 1 / 60); if (st.state === 'roll') sawRoll = true; if (st.state === 'wait') sawWait = true; zMin = Math.min(zMin, st.z); zMax = Math.max(zMax, st.z); }
    assert.ok(sawRoll && sawWait, 'stretcher roll+wait FSM live');
    assert.ok(zMax - zMin > 20, `stretcher corridor mein chala (${(zMax - zMin).toFixed(0)}u, teleport nahi)`);

    // STAFF: doctor + 2 nurses, AI states
    const staff = G.peds.filter((p) => p.role);
    assert.equal(staff.length, 3);
    assert.equal(staff.filter((p) => p.role === 'doctor').length, 1);
    assert.equal(staff.filter((p) => p.role === 'nurse').length, 2);
    assert.ok(staff.every((p) => ['attend', 'walk', 'chat', 'flee', 'queue'].includes(p.state)), 'staff AI states sane');

    // PHARMACY: dawa $25 = heal 40; full hp honest; broke honest
    const pharm = G.shops.find((s) => s.kind === 'pharmacy');
    assert.ok(pharm && /HOSPITAL/.test(pharm.name));
    G.P3.hp = 50; G.score = 100; G.P3.x = pharm.dx; G.P3.z = pharm.dz;
    assert.equal(G.scene.interact(G), 'shop:pharmacy');
    assert.equal(G.P3.hp, 90);
    assert.equal(G.score, 75);
    G.P3.hp = 100;
    assert.equal(G.scene.interact(G), 'shop-honest');
    assert.equal(G.score, 75, 'full hp = paisa nahi kata');
    G.P3.hp = 40; G.score = 3;
    assert.equal(G.scene.interact(G), 'shop-broke');
    assert.equal(G.P3.hp, 40, 'broke = no medicine');

    // BOOKS: training manual = +25 XP; level-up REST mein bhi check hota hai
    const books = G.shops.find((s) => s.kind === 'books');
    G.score = 100; G.body.xp = 70; G.body.level = 1; G.body.active = false;
    G.P3.x = books.dx; G.P3.z = books.dz;
    assert.equal(G.scene.interact(G), 'shop:books');
    assert.equal(G.score, 80);
    step(2);
    assert.equal(G.body.level, 2, 'book XP ne level diya — bina exercise ke bhi ista ista strength');
    assert.ok(G.body.strength > 10);

    // GAS PUMP: refuel $25
    const gas = G.shops.find((s) => s.kind === 'gas');
    G.car.fuel = 40; G.score = 60; G.P3.x = gas.dx; G.P3.z = gas.dz;
    assert.equal(G.scene.interact(G), 'shop:gas');
    assert.equal(G.car.fuel, 100);
    assert.equal(G.score, 35);

    // COSMETIC shops: barber = naya look
    const barber = G.shops.find((s) => s.kind === 'barber');
    G.score = 60; const o0 = G.P3.outfit || 0;
    G.P3.x = barber.dx; G.P3.z = barber.dz;
    assert.equal(G.scene.interact(G), 'shop:barber');
    assert.equal(G.P3.outfit, o0 + 1);
    assert.equal(G.score, 45);

    // 19 shops sab named + kinds sane
    assert.equal(G.shops.length, 19);
    assert.equal(new Set(G.shops.map((s) => s.name)).size, 19);
    assert.ok(G.shops.every((s) => s.stock && s.stock.length > 4), 'har shop ka apna stock board');

    // CODEX feed: exercises 26, hospital 8, counts grow, guessing sahi
    const codex = require('../shared/gamekit/detailcodex.cjs');
    assert.equal(codex.category('exercises').length, 26);
    assert.equal(codex.category('hospital').length, 8);
    assert.ok(codex.count().total >= 98 && codex.count().done >= 85 && codex.count().categories >= 11);
    assert.equal(codex.guessCategory('hospital ki dawa asli shelf se milti hai'), 'hospital');
    assert.equal(codex.guessCategory('squat rack par bar depth tak utarta hai'), 'exercises');
    assert.equal(codex.guessCategory('stretcher ward tak roll karta hai'), 'hospital');
    assert.ok(codex.rankSearch('lat pulldown', '[]').some((h) => h.id === 'ex.lat'));

    // Air_you KB: hospital + exercise catalog jawab
    const ask = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const kbh = await ask('hospital mein kya hai?');
    assert.match(kbh, /VICE GENERAL|HOSPITAL/i);
    assert.match(kbh, /STRETCHERS?/i);
    assert.match(kbh, /dawa \$25|heal 40/);
    const kbe = await ask('kitni exercises hain?');
    assert.match(kbe, /26 STATIONS/);
    assert.match(kbe, /FUNCTIONAL TURF/);
    assert.match(kbe, /ORGANIZED GYM/);
  });

  await test('AIR BRAIN module (Ask 41): 7 regions, live graph, Hebbian learning, honest pipeline', async () => {
    const brain = require('../shared/brain.cjs');
    const codex = require('../shared/gamekit/detailcodex.cjs');
    // 7 regions — mera kaam karne ka tareeqa, design ki shakal mein
    assert.deepStrictEqual(brain.REGIONS.map((r) => r.id), ['perceive', 'recall', 'plan', 'reason', 'act', 'verify', 'learn']);
    // graph seed: codex + KB = brain ki tarteeb (dead feed nahi)
    const b = brain.create({});
    const st = b.seed({ kbTitles: ['ORGANIZED GYM + HOSPITAL'] });
    assert.ok(st.nodes > 300 && st.edges > 300, `codex se graph seed hua: ${st.nodes} nodes / ${st.edges} edges`);
    // PERCEIVE — tokens + intent, stopwords filter
    const p = b.perceive('hospital ki dawa ka rate kya hai?');
    assert.ok(p.tokens.includes('hospital') && p.tokens.includes('dawa'));
    assert.ok(!p.tokens.includes('ki') && !p.tokens.includes('kya'), 'stopwords filter hue');
    // RECALL — spreading activation asli concepts dhundti hai
    const r = b.recall('hospital stretcher medicine', 5);
    assert.ok(r.some((x) => x.id === 'cat:hospital'), 'cat:hospital recall hua');
    assert.ok(r.some((x) => x.id.startsWith('hp.')), 'hospital entries recall huin');
    // HEBBIAN — fire together, wire together (weights barhte hain)
    b.learn('hospital medicine', 'question');
    const w1 = b.edgeWeight('w:hospital', 'intent:question');
    b.learn('hospital medicine', 'question');
    const w2 = b.edgeWeight('w:hospital', 'intent:question');
    assert.ok(w2 > w1, `Hebbian growth ${w1} -> ${w2}`);
    // PLAN — har step ki done-definition
    const pl = b.plan('ek website banao');
    assert.ok(pl.steps.length >= 3 && pl.steps.every((s) => /done/.test(s.done)), 'per-step done-definition');
    // COGNIZE offline — poori 7-region trace, honest ACT
    const c = b.cognize('gym ka system samjhao');
    assert.deepStrictEqual(c.trace.map((t) => t.region), ['perceive', 'recall', 'plan', 'reason', 'act', 'verify', 'learn']);
    assert.ok(/offline trace-only/.test(c.trace[4].obs), 'bina ws ke ACT honest offline');
    assert.ok(c.confidence > 0 && c.confidence <= 1);
    // unknown goal = weak recall = LOW confidence (jhootha bharosa nahi)
    const c2 = b.cognize('zzz qqq flurb nonsense xyz');
    assert.ok(c2.confidence < 0.5, `weak recall par honest low confidence: ${c2.confidence}`);
    // PERSIST — one-way, sirf .dev-studio/air/
    const files = {};
    const ws = { read: (f) => (files[f] !== undefined ? files[f] : null), write: (f, ct) => { files[f] = ct; return true; }, listFlat: () => Object.keys(files) };
    assert.ok(brain.GRAPH_REL.startsWith('.dev-studio/air/'), 'one-way: graph sirf Air_you ke area mein');
    const b2 = brain.create({ ws }); b2.seed({}); b2.learn('gym treadmill', 'game');
    assert.ok(b2.save() && files[brain.GRAPH_REL], 'graph disk par save hua');
    const b3 = brain.create({ ws });
    assert.ok(b3.load(), 'graph load hua');
    assert.ok(b3.edgeWeight('w:treadmill', 'intent:game') > 0, 'learned edge reload ke baad zinda');
    // DECAY — honest forgetting
    const eb = b3.stats().edges; b3.prune(0.3);
    assert.ok(b3.stats().edges <= eb, 'prune kamzor edges cut karta hai');
    // ACT with ws = AIR LOOP motor cortex
    const c3 = b2.cognize('hospital notes banao', { ws });
    assert.ok(c3.act && c3.act.artifact && c3.trace[4].obs.includes('AIR LOOP'), 'ws ke saath ACT = AIR LOOP');
    // chat routes
    const shown = await providers.chat('builtin', null, [{ role: 'user', content: 'brain dikhao' }]);
    assert.match(shown, /AIR BRAIN MODULE/);
    assert.match(shown, /PERCEIVE/);
    assert.match(shown, /Hebbian/i);
    assert.match(shown, /neural net nahi/, 'honest framing: neural net nahi');
    const thought = await providers.chat('builtin', null, [{ role: 'user', content: 'brain socho: hospital ka system plan karo' }]);
    assert.match(thought, /BRAIN TRACE/);
    assert.match(thought, /RECALL/);
    assert.match(thought, /Confidence/);
    // powers list mein BRAIN MODULE
    assert.match(await providers.chat('builtin', null, [{ role: 'user', content: 'tumhari kya powers hain?' }]), /BRAIN MODULE/);
    // codex feed: brain category (8 entries, all done)
    assert.strictEqual(codex.category('brain').length, 8);
    assert.ok(codex.category('brain').every((e) => e.impl === 'done'));
    const cc = codex.count();
    assert.ok(cc.total >= 106 && cc.done >= 96 && cc.categories >= 12, `codex ${cc.total}/${cc.done}/${cc.categories}`);
    assert.strictEqual(codex.guessCategory('AI ka brain module kaise kaam karta hai'), 'brain');
    assert.strictEqual(codex.guessCategory('hospital ki dawa'), 'hospital');
    assert.ok((codex.rankSearch('brain graph hebbian')[0] || {}).id === 'br.graph', 'rankSearch brain');
  });

  await test('AIR BRAIN same-to-same agent (Ask 44): tool registry, asli tool calls, permission gate, session memory', async () => {
    const tools = require('../shared/tools.cjs');
    const brain = require('../shared/brain.cjs');
    // --- TOOL REGISTRY: bare agent jaise haath ---
    const files = { 'app.js': 'const x = 1;\nconsole.log(x\n', 'package.json': '{"name":"t"}', 'README.md': '# t\n- TODO: kam' };
    const ws = { read: (f) => (files[f] !== undefined ? files[f] : null), write: (f, c) => { files[f] = c; return true; }, listFlat: () => Object.keys(files) };
    const T0 = tools.createTools({ ws, permission: false });
    for (const n of ['list_files', 'read_file', 'write_file', 'edit_file', 'grep', 'node_check', 'run_tests', 'codex_search', 'kb_recall', 'web_search']) assert.ok(T0.tools[n], `tool ${n} registry mein`);
    assert.strictEqual(T0.names().length, 10, '10 tools');
    assert.ok(!T0.call('no_such_tool', {}).ok, 'unknown tool honest error');
    // read free, write gated
    assert.ok(T0.call('read_file', { path: 'package.json' }).ok, 'read free hai');
    const blocked = T0.call('write_file', { path: 'user.js', content: 'x' });
    assert.ok(!blocked.ok && blocked.blocked === 'permission', 'user file write = PERMISSION gate');
    assert.ok(!files['user.js'], 'gate ke baad file nahi likhi gayi');
    // own journal area permission-free (airloop contract jaisa)
    const own = T0.call('write_file', { path: '.dev-studio/air/draft.js', content: 'module.exports = 1;\n' });
    assert.ok(own.ok && own.verified, 'own area write + read-back verify');
    // permission on -> user write chalta hai
    const T1 = tools.createTools({ ws, permission: true });
    assert.ok(T1.call('write_file', { path: 'user.js', content: 'module.exports = 2;\n' }).ok, 'ijazat ke saath write');
    // node_check asli verify: bad src fail, good src pass
    assert.ok(!T0.call('node_check', { path: 'app.js' }).ok, 'broken syntax honest fail');
    assert.ok(T0.call('node_check', { content: 'const a = 1;\n' }).ok, 'good syntax pass');
    // edit_file honest: na mile to kuch nahi badla
    assert.ok(!T0.call('edit_file', { path: 'README.md', old: 'NOPE', new: 'x' }).ok, 'edit old na mile to honest fail');
    // grep line numbers
    const g = T0.call('grep', { path: 'README.md', keyword: 'TODO' });
    assert.ok(g.ok && g.hits === 1 && /2:/.test(g.out), 'grep line-numbered');
    // run_tests bina root = honest
    assert.ok(!T0.call('run_tests', {}).ok, 'run_tests bina root honest');
    // web_search offline = honest needsOnline
    assert.ok(T0.call('web_search', {}).needsOnline, 'web_search offline honest');
    // --- BRAIN TURN: asli loop ---
    const b = brain.create({ ws });
    b.seed({ kbTitles: ['ORGANIZED GYM + HOSPITAL'] });
    const t1 = b.turn('kaam karo: app.js fix karo');
    assert.strictEqual(t1.intent, 'agent');
    const nc = t1.steps.find((s) => s.tool === 'node_check');
    assert.ok(nc && !nc.ok && /SYNTAX ERROR/.test(nc.out), 'turn ne asli syntax error pakda');
    assert.match(t1.answer, /BRAIN TURN/);
    assert.match(t1.answer, /Diagnosis \(honest\)/, 'agent intent mein diagnosis');
    // build turn: artifact + verify
    const t2 = b.turn('ek chota timer banao');
    const wf = t2.steps.find((s) => s.tool === 'write_file');
    assert.ok(wf && wf.ok && t2.verified, 'build artifact likha + node_check verified');
    assert.ok(files['.dev-studio/air/build-ek-chota-timer-banao.js'], 'artifact disk par');
    // question turn: recall + confidence
    const t3 = b.turn('hospital mein kya hai?');
    assert.match(t3.answer, /Confidence/);
    assert.match(t3.answer, /cat:hospital/, 'graph recall jawab mein');
    // session memory persist + reload
    assert.ok(files[brain.create({ ws }).SESSION_REL] || files['.dev-studio/air/session.json'], 'session.json likha gaya');
    const b2 = brain.create({ ws });
    assert.ok(b2.session().length >= 3, 'session turns reload hue');
    // permission flow: ijazat ke bagair user-file edit block, turn honest batata hai
    const t4 = b.turn('kaam karo: user.js edit karo');
    assert.ok(t4.steps.every((s) => !(s.tool === 'edit_file' && s.ok)), 'bina ijazat edit nahi hua');
    // --- chat routes ---
    const r1 = await providers.chat('builtin', null, [{ role: 'user', content: 'kaam karo: app.js fix karo' }]);
    assert.match(r1, /BRAIN TURN/);
    assert.match(r1, /Steps \(asli tool calls\)/);
    const r2 = await providers.chat('builtin', null, [{ role: 'user', content: 'brain yaad dikhao' }]);
    assert.match(r2, /BRAIN KI YAAD/);
    assert.match(r2, /session turns save/);
    const r3 = await providers.chat('builtin', null, [{ role: 'user', content: 'tumhari kya powers hain?' }]);
    assert.match(r3, /same-to-same agent/);
    assert.match(r3, /TOOL REGISTRY/);
  });

  await test('MISSION ENGINE + VIRSA (Ask 45): multi-turn planning, honest pause/retry, heritage lessons', async () => {
    const brain = require('../shared/brain.cjs');
    const files = { 'app.js': 'const x = 1;\nconsole.log(x\n', 'README.md': '# t' };
    const ws = { read: (f) => (files[f] !== undefined ? files[f] : null), write: (f, c) => { files[f] = c; return true; }, listFlat: () => Object.keys(files) };
    const b = brain.create({ ws });
    b.seed({ kbTitles: ['ORGANIZED GYM'] });
    // mission.json own area mein banta hai
    assert.ok(brain.create({ ws }).GOAL_REL.startsWith('.dev-studio/air/'), 'mission own area mein');
    // start: plan + pehla step turant chalta hai
    const S = b.missionStart('app.js fix karo', {});
    const m0 = b.missionStatus();
    assert.ok(m0.steps.length >= 3, 'plan toda gaya (multi-step)');
    assert.strictEqual(m0.current, 1, 'pehla step turn mein hi chala');
    assert.ok(m0.steps[0].status === 'done');
    // step 2 (read) ok, step 3 (node_check) FAIL -> honest PAUSE
    b.missionNext({});
    const r1 = b.missionNext({});
    assert.ok(!r1.result.ok && r1.mission.paused, 'fail step par honest pause');
    const r2 = b.missionNext({});
    assert.ok(r2.mission.paused, 'toote hue par retry bhi fail = paused (jhootha pass nahi)');
    // user fix kare -> retry aage barhta hai
    files['app.js'] = 'const x = 1;\nconsole.log(x);\n';
    const r3 = b.missionNext({});
    assert.ok(r3.result.ok && !r3.mission.paused, 'fix ke baad retry pass');
    let rr = r3;
    for (let i = 0; i < 4 && !rr.complete; i += 1) rr = b.missionNext({});
    assert.ok(rr.complete || b.missionStatus().status === 'complete', 'mission COMPLETE sab steps verify ke baad');
    // VIRSA: purani failed session se lesson
    const V = b.virsaa('app.js fix karo dobara');
    assert.ok(V.rel.length >= 1, 'virsaa ne purani mission turns pakdin');
    assert.ok(V.lessons.some((l) => /fail|node_check|phele/.test(l)), `lesson mila: ${V.lessons[0] || ''}`);
    // naya mission virsa lesson ko plan mein lagata hai
    const S2 = b.missionStart('app.js syntax dekho', {});
    assert.ok(S2.plan.virsaa.lessons.length >= 1, 'naye mission ko virsa lessons mile');
    b.missionEnd();
    assert.strictEqual(b.missionStatus(), null, 'mission khatam = clear');
    // chat routes
    const a1 = await providers.chat('builtin', null, [{ role: 'user', content: 'mission: README.md analyze karo' }]);
    assert.match(a1, /MISSION/);
    assert.match(a1, /Progress:/);
    const a2 = await providers.chat('builtin', null, [{ role: 'user', content: 'mission status' }]);
    assert.match(a2, /MISSION/);
    const a3 = await providers.chat('builtin', null, [{ role: 'user', content: 'virsaa: README analyze' }]);
    assert.match(a3, /VIRSA/);
    const a4 = await providers.chat('builtin', null, [{ role: 'user', content: 'mission khatam' }]);
    assert.match(a4, /Mission band|tha hi nahi/);
    const pw = await providers.chat('builtin', null, [{ role: 'user', content: 'tumhari kya powers hain?' }]);
    assert.match(pw, /MISSION ENGINE/);
  });

  await test('GB-class AI download question hits the Local AI KB topic', async () => {
    const reply = await providers.chat('builtin', null, [{ role: 'user', content: 'GB ka AI kaise download hoga?' }]);
    assert.match(reply, /GB-class AI on your PC/);
    assert.match(reply, /Ollama/);
    assert.match(reply, /100 ?MB/, 'honest GitHub limit is explained');
    // the platform matrix must still own platform questions (no topic hijack)
    const plat = await providers.chat('builtin', null, [{ role: 'user', content: 'kis platform par game chalega?' }]);
    assert.match(plat, /WEB = universal|honest matrix/i);
  });

  await test('city3d runs headlessly; packages pay and traffic hurts', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const city = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'city3d.js'), 'utf8');
    for (const seed of [0, 5]) {
      const sb = runGame({ engineSrc: engine, gameSrc: city, frames: 600, extraSrcs: [engine3d], fuzz: seed || null });
      const G = sb.__city3d;
      assert.ok(G, 'test hook exposed');
      assert.equal(G.buildings3.length, 25);
      assert.equal(G.cars3.length, 10);
      assert.equal(G.collect3.length, 12);
      // package pickup pays — isolate the target package so a second nearby
      // pickup can't make the +1 assert flake
      G.state = 'play';
      const cp = G.collect3[0];
      G.collect3.length = 0; G.collect3.push(cp);
      G.P3.x = cp.x + 5; G.P3.z = cp.z; G.P3.hp = 100; G.P3.hitT = 9;
      const n0 = G.collected; const s0 = G.score;
      G.scene.update(G, 1 / 60);
      assert.equal(G.collected, n0 + 1, 'package collected');
      assert.equal(G.score, s0 + 50, 'cash rewarded');
      // traffic hits hurt
      G.P3.hitT = 0;
      G.collect3.length = 0; // no package may steal the HIT BY TRAFFIC message
      const car = G.cars3[0];
      car.speed = 0; // freeze the car: no drive-off and no wrap-boundary teleport flake
      car.along = 800; // mid-map, far from the wrap edges
      const cx = car.axis === 'x' ? car.along : car.lane;
      const cz = car.axis === 'x' ? car.lane : car.along;
      G.P3.x = cx; G.P3.z = cz;
      const hp0 = G.P3.hp;
      G.scene.update(G, 1 / 60);
      assert.ok(G.P3.hp < hp0, 'traffic damage applied');
      assert.match(G.P3.msg, /HIT BY TRAFFIC/);
    }
  });

  await test('every shipped game survives a fuzzed chaos-input storm', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const { parseSpec } = require('../shared/gamekit/spec.cjs');
    const composed = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed.js'), 'utf8');
    for (const t of ['arena', 'platformer', 'shmup', 'runner', 'city', 'city3d']) {
      const game = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', `${t}.js`), 'utf8');
      for (const seed of [1, 7, 42]) {
        runGame({ engineSrc: engine, gameSrc: game, frames: 250, extraSrcs: t === 'city3d' ? [engine3d] : [], fuzz: seed });
      }
    }
    const src = `const GAME_SPEC = ${JSON.stringify(parseSpec('zombie survival with dash'))};\n` + composed;
    runGame({ engineSrc: engine, gameSrc: src, frames: 250, fuzz: 9 });
  });

  console.log('\nComposed3D — franchise DNA games');

  await test('spec3d parses franchises into five distinct 3D DNAs', async () => {
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const re = parseSpec3d('make a resident evil style survival horror game');
    assert.deepEqual([re.control, re.enemy, re.goal, re.world], ['fps', 'zombie', 'escape', 'mansion']);
    assert.ok(re.atmosphere.ambient < 0.25, 'horror is dark');
    const sp = parseSpec3d('spider-man swinging through the city collecting tokens');
    assert.equal(sp.control, 'swing');
    assert.equal(sp.world, 'city');
    const ch = parseSpec3d('choo-choo charles style train horror');
    assert.deepEqual([ch.control, ch.world], ['train', 'rails']);
    assert.ok(ch.atmosphere.rain, 'the hunter rides in the rain');
    const gta = parseSpec3d('gta 5 open world crime driving game');
    assert.deepEqual([gta.control, gta.enemy, gta.goal], ['drive', 'police', 'deliver']);
    const cod = parseSpec3d('call of duty fps with enemy waves');
    assert.deepEqual([cod.control, cod.enemy, cod.goal, cod.world], ['fps', 'soldier', 'waves', 'arena']);
    const dnas = new Set([re, sp, ch, gta, cod].map((x) => [x.control, x.enemy, x.goal, x.world].join('|')));
    assert.equal(dnas.size, 5, 'five franchises must produce five different games');
  });

  await test('composed3d runs every franchise headlessly and survives fuzz', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const requests = [
      'make a resident evil style survival horror game',
      'spider-man swinging through the city collecting tokens',
      'choo-choo charles style train horror game',
      'gta 5 open world crime driving game',
      'call of duty fps with enemy waves'
    ];
    for (const r of requests) {
      const src = `const GAME_SPEC3D = ${JSON.stringify(parseSpec3d(r))};\n` + c3d;
      const sb = runGame({ engineSrc: engine, gameSrc: src, frames: 400, extraSrcs: [engine3d] });
      assert.ok(sb.__composed3d, `hook exposed for: ${r}`);
      runGame({ engineSrc: engine, gameSrc: src, frames: 250, extraSrcs: [engine3d], fuzz: 3 });
    }
  });

  await test('composed3d mechanics: hitscan kills, pickups pay, the hunter closes in', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const run = (req) => {
      const src = `const GAME_SPEC3D = ${JSON.stringify(parseSpec3d(req))};\n` + c3d;
      return runGame({ engineSrc: engine, gameSrc: src, frames: 200, extraSrcs: [engine3d] }).__composed3d;
    };

    // COD: waves spawn soldiers; two hitscan shots kill one
    const cod = run('call of duty fps with enemy waves');
    cod.state = 'play'; cod.P3.hp = 100;
    while (cod.foes.length < 5) cod.scene.spawnFoe(cod); // harness frames may have thinned the wave
    const P = cod.P3;
    P.yaw = 0; P.pitch = 0; P.ammo = 12; P.fireT = 0; P.reload = 0;
    const f = cod.foes[0]; f.x = P.x; f.z = P.z - 100; f.hp = 2;
    const kills0 = cod.goal.kills; const score0 = cod.score;
    cod.scene.shoot(cod); P.fireT = 0; cod.scene.shoot(cod);
    assert.equal(cod.goal.kills, kills0 + 1, 'soldier down');
    assert.ok(cod.score > score0, 'kill paid score');
    assert.equal(P.ammo, 10, 'ammo consumed');

    // Spider: packages pay on pickup
    const sp = run('spider-man swinging through the city collecting tokens');
    sp.state = 'play'; sp.P3.hp = 100;
    if (!sp.items.length) sp.items.push(sp.scene.spawnPoint(sp, true));
    const it = sp.items[0];
    sp.P3.x = it.x + 4; sp.P3.z = it.z;
    const n0 = sp.goal.collected; const s0 = sp.score;
    sp.scene.update(sp, 1 / 60);
    assert.equal(sp.goal.collected, n0 + 1, 'token grabbed');
    assert.equal(sp.score, s0 + 50, 'tokens pay $50');

    // Charles: the hunter closes in; shooting pushes it back
    const ch = run('choo-choo charles style train horror game');
    ch.state = 'play'; ch.P3.hp = 100;
    if (!ch.hunter) ch.hunter = { gap: 420, hp: 8, weave: 0 }; // harness frames may have slain it
    ch.hunter.gap = 400; ch.hunter.hp = 8; // deterministic starting distance
    const gap0 = ch.hunter.gap;
    for (let i = 0; i < 60; i += 1) ch.scene.update(ch, 1 / 60);
    assert.ok(ch.hunter.gap < gap0, 'hunter gains on the train');
    const gap1 = ch.hunter.gap;
    ch.P3.yaw = 0; ch.P3.pitch = 0; ch.P3.ammo = 12; ch.P3.fireT = 0;
    const hp0 = ch.hunter.hp;
    ch.scene.shoot(ch);
    assert.equal(ch.hunter.hp, hp0 - 1, 'hunter takes damage');
    assert.ok(ch.hunter.gap > gap1, 'a hit pushes the hunter back');
  });

  await test('platform targets: every platform gets its own system, honestly', async () => {
    const mk = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const gn = (t) => agent.parseActions(t).find((a) => a.type === 'game_new');
    const and = await mk('make a spider-man swinging game for android');
    assert.equal(gn(and).platform, 'android');
    assert.equal(gn(and).spec3d.control, 'swing');
    assert.match(and, /Capacitor|APK/);
    assert.equal(gn(await mk('arena game banao windows ke liye')).platform, 'windows');
    const iosReply = await mk('make a racing game for ios');
    assert.equal(gn(iosReply).platform, 'ios');
    assert.match(iosReply, /Mac \+ Xcode|Mac par/, 'the Apple rule is stated honestly');
    // a plain platform question hits the honest KB matrix
    const kb = await mk('kya tumhare game android par chalte hain?');
    assert.match(kb, /Capacitor|Android Studio/i);
    assert.match(kb, /Xcode|Apple/);
    assert.ok(!agent.parseActions(kb).some((a) => a.type === 'game_new'), 'a question must not scaffold');
  });

  await test('horror detail pack: crests unseal the gate, supplies are scarce, the Tyrant wakes', async () => {
    const { runGame } = require('./harness/headless.cjs');
    const { parseSpec3d } = require('../shared/gamekit/spec3d.cjs');
    const engine = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine.js'), 'utf8');
    const engine3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'engine3d.js'), 'utf8');
    const c3d = fs.readFileSync(path.join(__dirname, '..', 'shared', 'gamekit', 'templates', 'composed3d.js'), 'utf8');
    const src = `const GAME_SPEC3D = ${JSON.stringify(parseSpec3d('resident evil style survival horror'))};\n` + c3d;
    const G = runGame({ engineSrc: engine, gameSrc: src, frames: 120, extraSrcs: [engine3d] }).__composed3d;
    G.scene.init(G); // fresh mansion: harness walking may already have consumed a crest or herb
    G.state = 'play'; G.P3.hp = 100; G.P3.hitT = 9; G.P3.msgT = 0;
    assert.equal(G.crests.length, 3, 'three crests are hidden');
    assert.equal(G.pickups.filter((p) => p.kind === 'herb').length, 5, 'five herbs');
    assert.equal(G.pickups.filter((p) => p.kind === 'ammo').length, 4, 'four ammo boxes');
    // the gate is sealed: standing on the exit with no crests must NOT win.
    // clear the area first — a nearby pickup could steal the SEALED message.
    G.crests.length = 0; G.pickups.length = 0;
    G.P3.x = G.marker.x + 5; G.P3.z = G.marker.z;
    G.scene.update(G, 1 / 60);
    assert.equal(G.state, 'play', 'sealed gate blocks the escape');
    assert.match(G.P3.msg, /SEALED/);
    // herbs heal, ammo boxes refill and cancel the reload
    G.scene.init(G); G.state = 'play'; G.P3.hitT = 9;
    G.P3.hp = 40;
    const herb = G.pickups.find((p) => p.kind === 'herb');
    G.P3.x = herb.x + 3; G.P3.z = herb.z;
    G.scene.update(G, 1 / 60);
    assert.equal(G.P3.hp, 70, 'herb heals +30');
    G.P3.hitT = 9; G.P3.ammo = 2; G.P3.reload = 0.5;
    const ammo = G.pickups.find((p) => p.kind === 'ammo');
    G.P3.x = ammo.x + 3; G.P3.z = ammo.z;
    G.scene.update(G, 1 / 60);
    assert.equal(G.P3.ammo, 12, 'ammo box refills the magazine');
    assert.equal(G.P3.reload, 0, 'reload cancelled');
    // zombie dogs mix into the horde
    for (let i = 0; i < 40; i += 1) G.scene.spawnFoe(G);
    assert.ok(G.foes.some((f) => f.kind === 'dog'), 'zombie dogs spawn');
    // three crests wake the Tyrant and unseal the gate
    for (const cr of G.crests.slice()) {
      G.P3.hitT = 9; G.P3.hp = 100;
      G.P3.x = cr.x + 3; G.P3.z = cr.z;
      G.scene.update(G, 1 / 60);
    }
    assert.equal(G.goal.crests, 3, 'all crests found');
    assert.ok(G.boss && G.foes.includes(G.boss), 'the Tyrant is awake and hunting');
    assert.equal(G.boss.hp, 10);
    // the gate is open now: reaching it wins
    G.state = 'play'; G.P3.hitT = 9; G.P3.hp = 100; G.foes.length = 0;
    G.P3.x = G.marker.x + 5; G.P3.z = G.marker.z;
    G.scene.update(G, 1 / 60);
    assert.equal(G.state, 'over', 'escaped the dark');
    assert.match(G._overReason, /ESCAPED/);
  });

  await test('builtin routes franchise asks to composed 3D games', async () => {
    const mk = (t) => providers.chat('builtin', null, [{ role: 'user', content: t }]);
    const gn = (t) => agent.parseActions(t).find((a) => a.type === 'game_new');
    const re = await mk('make me a resident evil style game');
    assert.equal(gn(re).spec3d.enemy, 'zombie');
    assert.match(re, /RESIDENT EVIL/);
    assert.ok(gn(re) && agent.parseActions(re).some((a) => a.type === 'game_check'), 'verified after scaffold');
    assert.equal(gn(await mk('make a spider-man swinging game')).spec3d.control, 'swing');
    assert.equal(gn(await mk('choo choo charles style game banao')).spec3d.control, 'train');
    assert.equal(gn(await mk('make a gta 5 style game')).spec3d.control, 'drive');
    assert.equal(gn(await mk('call of duty style shooter')).spec3d.enemy, 'soldier');
    // plain "gta" (no 5/6) still routes to the 2D mini-GTA — no accidental upgrade
    const plain = await mk('make a game like gta');
    assert.equal(gn(plain).genre, 'city');
  });

  console.log('\nApp lock & audit');
  const { LockManager } = require('../shared/lock.cjs');

  await test('PIN set / verify / change / clear (scrypt, no plaintext)', () => {
    const lm = new LockManager(path.join(tmp, 'lock.json'));
    assert.strictEqual(lm.isSet(), false);
    assert.throws(() => lm.setPin('12'), /at least 4/);
    lm.setPin('1234');
    assert.strictEqual(lm.isSet(), true);
    assert.strictEqual(lm.verify('1234'), true);
    assert.strictEqual(lm.verify('0000'), false);
    assert.throws(() => lm.changePin('9999', '5678'), /incorrect/);
    lm.changePin('1234', '5678');
    assert.strictEqual(lm.verify('5678'), true);
    const raw = fs.readFileSync(path.join(tmp, 'lock.json'), 'utf8');
    // quoted so random hex/digits can never collide, plus a real scrypt-hash shape check
    assert.ok(!raw.includes('"5678"'), 'PIN must never be stored in plaintext');
    const stored = JSON.parse(raw);
    assert.ok(/^[0-9a-f]{64,}$/.test(stored.hash), 'a real scrypt hash is stored, not the PIN');
    assert.ok(stored.salt !== '5678' && stored.hash !== '5678');
    lm.clearPin();
    assert.strictEqual(lm.isSet(), false);
  });

  await test('audit log records, reads newest-first, and clears', () => {
    const lm = new LockManager(path.join(tmp, 'lock2.json'));
    lm.audit('test.event', { a: 1 });
    lm.audit('test.two');
    const e = lm.readAudit();
    assert.strictEqual(e.length, 2);
    assert.strictEqual(e[0].event, 'test.two');
    lm.clearAudit();
    assert.strictEqual(lm.readAudit().length, 0);
  });

  await test('auto-lock minutes persist across instances', () => {
    const f = path.join(tmp, 'lock3.json');
    const lm = new LockManager(f);
    lm.setAutoLock(10);
    const lm2 = new LockManager(f);
    assert.strictEqual(lm2.getAutoLock(), 10);
  });

  await test('user plugins default OFF, official default ON', () => {
    const { PluginManager: PM } = require('../shared/plugins.cjs');
    const offDir = path.join(tmp, 'offdir');
    fs.mkdirSync(path.join(offDir, 'userplug'), { recursive: true });
    fs.writeFileSync(path.join(offDir, 'userplug', 'plugin.json'), JSON.stringify({ id: 'userplug', name: 'U', version: '1', entry: 'index.cjs' }));
    fs.writeFileSync(path.join(offDir, 'userplug', 'index.cjs'), 'module.exports={};');
    const pm = new PM({ dirs: [path.join(__dirname, '..', 'plugins'), offDir], persistFile: path.join(tmp, 'p2.json') });
    const list = pm.scan();
    assert.strictEqual(list.find((p) => p.id === 'userplug').enabled, false, 'user plugin must default off');
    assert.strictEqual(list.find((p) => p.id === 'ollama').enabled, true, 'official plugin defaults on');
  });

  console.log('\nLoopback bridge (Chrome <-> desktop app)');
  const http = require('node:http');
  const { startBridge } = require('../electron/bridge.cjs');

  await test('bridge serves the build, gates RPC by token, loopback only', async () => {
    const distDir = path.join(tmp, 'dist');
    fs.mkdirSync(distDir, { recursive: true });
    fs.writeFileSync(path.join(distDir, 'index.html'), '<html><body>bridge-ok</body></html>');

    const impl = {
      files: async () => ({ ok: true, tree: [{ name: 'a.txt', path: 'a.txt', type: 'file' }] }),
      echo: async (x) => ({ ok: true, x })
    };
    const b = await startBridge({ distDir, impl });

    try {
      assert.strictEqual(b.host, '127.0.0.1', 'bridge must bind loopback only');
      assert.ok(b.port > 0);
      assert.ok(b.url.includes(b.token), 'URL carries the token');
      assert.strictEqual(b.token.length, 64, '256-bit hex token');

      // page + assets are served from disk
      const page = await fetch(b.url);
      assert.strictEqual(page.status, 200);
      assert.match(await page.text(), /bridge-ok/);

      // correct token -> RPC reaches the same impl the desktop uses
      const good = await fetch(`http://127.0.0.1:${b.port}/api/rpc`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-ds-token': b.token },
        body: JSON.stringify({ method: 'echo', args: ['hi'] })
      });
      assert.strictEqual(good.status, 200);
      assert.deepStrictEqual(await good.json(), { ok: true, x: 'hi' });

      // wrong / missing token -> 401
      const bad = await fetch(`http://127.0.0.1:${b.port}/api/rpc`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-ds-token': 'nope' },
        body: JSON.stringify({ method: 'echo', args: ['hi'] })
      });
      assert.strictEqual(bad.status, 401);
      const anon = await fetch(`http://127.0.0.1:${b.port}/api/rpc`, { method: 'POST', body: '{}' });
      assert.strictEqual(anon.status, 401);

      // unknown method -> 404 (whitelist)
      const unknown = await fetch(`http://127.0.0.1:${b.port}/api/rpc`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-ds-token': b.token },
        body: JSON.stringify({ method: 'constructor', args: [] })
      });
      assert.strictEqual(unknown.status, 404);

      // path traversal is neutralized: the URL parser collapses '..' before the
      // filesystem is touched, so a file outside dist/ can never be read.
      const secret = fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8');
      const trav = await new Promise((resolve, reject) => {
        const rq = http.request(
          { host: '127.0.0.1', port: b.port, path: `/../package.json?ds_token=${b.token}`, method: 'GET' },
          (rs) => {
            const chunks = [];
            rs.on('data', (c) => chunks.push(c));
            rs.on('end', () => resolve({ status: rs.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
          }
        );
        rq.on('error', reject);
        rq.end();
      });
      assert.ok(!trav.body.includes('"electron-builder"'), 'traversal must not leak files outside dist/');
      assert.ok(trav.status === 403 || trav.status === 404 || trav.status === 200, `unexpected status ${trav.status}`);
      assert.ok(secret.includes('"electron-builder"'), 'sanity: the target file really is sensitive');
    } finally {
      await b.stop();
    }
  });

  await test('PIN brute force is throttled after 5 wrong attempts', () => {
    const lm = new LockManager(path.join(tmp, 'lock4.json'));
    lm.setPin('4321');
    assert.strictEqual(lm.attemptsLeft(), 5);
    for (let i = 0; i < 4; i += 1) assert.strictEqual(lm.verify('0000'), false);
    assert.strictEqual(lm.attemptsLeft(), 1);
    assert.strictEqual(lm.lockoutMs(), 0, 'no cooldown before the 5th failure');
    assert.strictEqual(lm.verify('0000'), false); // 5th wrong attempt
    assert.strictEqual(lm.attemptsLeft(), 0);
    const left = lm.lockoutMs();
    assert.ok(left > 0 && left <= 30_000, `cooldown should be running, got ${left}`);
    assert.strictEqual(lm.verify('4321'), false, 'even the correct PIN is refused during cooldown');
    // simulate the cooldown expiring
    lm.data.lockedUntil = Date.now() - 1;
    lm._save();
    assert.strictEqual(lm.lockoutMs(), 0);
    assert.strictEqual(lm.verify('4321'), true);
    assert.strictEqual(lm.attemptsLeft(), 5, 'counter resets after a success');
    assert.ok(lm.readAudit(50).some((e) => e.event === 'pin.lockout'), 'lockout must be audited');
  });

  await test('read-only bridge refuses mutating methods but still serves reads', async () => {
    const distDir = path.join(tmp, 'dist2');
    fs.mkdirSync(distDir, { recursive: true });
    fs.writeFileSync(path.join(distDir, 'index.html'), '<html>ro</html>');

    let mode = 'full';
    const impl = {
      files: async () => ({ ok: true, tree: [] }),
      readFile: async (p) => ({ ok: true, content: `content of ${p}` }),
      writeFile: async () => ({ ok: true, wrote: true })
    };
    const b = await startBridge({
      distDir,
      impl,
      mutating: ['writeFile'],
      isReadOnly: () => mode === 'readonly'
    });
    const call = (method, args = []) => fetch(`http://127.0.0.1:${b.port}/api/rpc`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-ds-token': b.token },
      body: JSON.stringify({ method, args })
    });

    try {
      const full = await call('writeFile', ['a.txt', 'hi']);
      assert.strictEqual(full.status, 200);
      assert.deepStrictEqual(await full.json(), { ok: true, wrote: true });

      mode = 'readonly';
      const blocked = await call('writeFile', ['a.txt', 'hi']);
      assert.strictEqual(blocked.status, 403);
      const bj = await blocked.json();
      assert.strictEqual(bj.ok, false);
      assert.strictEqual(bj.readOnly, true);
      assert.match(bj.error, /read-only/i);

      // reads keep working in read-only mode
      const read = await call('readFile', ['a.txt']);
      assert.strictEqual(read.status, 200);
      assert.strictEqual((await read.json()).content, 'content of a.txt');
      const list = await call('files');
      assert.strictEqual(list.status, 200);
    } finally {
      await b.stop();
    }
  });

  console.log('\nWorkspace memory');
  const { MemoryStore } = require('../shared/memory.cjs');

  await test('memory persists project, notes and tasks across reloads', () => {
    const f = path.join(tmp, 'ws', '.dev-studio', 'memory.json');
    const m = new MemoryStore(f);
    assert.strictEqual(m.contextBlock(), '', 'empty memory injects nothing into the prompt');

    m.setProject({ name: 'Shop', summary: 'E-commerce back office', stack: 'React, Node 20', conventions: ['2-space indent', 'no secrets in repo'] });
    const n = m.addNote({ title: 'Auth uses JWT', body: '15 min refresh tokens', tags: ['auth'] });
    const t = m.addTask({ title: 'Add rate limiting to /api/login' });

    const reloaded = new MemoryStore(f);
    assert.strictEqual(reloaded.get().project.name, 'Shop');
    assert.deepStrictEqual(reloaded.get().project.stack, ['React', 'Node 20']);
    assert.strictEqual(reloaded.get().notes[0].id, n.id);

    const ctx = reloaded.contextBlock();
    assert.match(ctx, /Project memory/);
    assert.match(ctx, /Auth uses JWT/);
    assert.match(ctx, /Add rate limiting/);
    assert.match(ctx, /no secrets in repo/);

    reloaded.setTaskStatus(t.id, 'done');
    assert.strictEqual(new MemoryStore(f).stats().done, 1);
    assert.ok(!new MemoryStore(f).contextBlock().includes('[done]'), 'finished tasks leave the prompt');
  });

  await test('memory caps run history and clears by kind', () => {
    const m = new MemoryStore(path.join(tmp, 'ws2', '.dev-studio', 'memory.json'));
    for (let i = 0; i < 60; i += 1) m.recordRun({ prompt: `p${i}`, provider: 'builtin', actions: 0, chars: 10 });
    assert.strictEqual(m.get().runs.length, 40, 'run history is capped');
    m.addTask({ title: 'x' });
    m.clear('tasks');
    assert.strictEqual(m.get().tasks.length, 0);
    m.addNote({ title: 'keep' });
    m.clear('all');
    assert.strictEqual(m.get().notes.length, 0);
    assert.throws(() => m.addNote({}), /title/i);
    assert.throws(() => m.addTask({}), /title/i);
  });

  await test('systemPrompt injects memory alongside plugin tools', () => {
    const base = agent.systemPrompt();
    const withMem = agent.systemPrompt('## Project memory\nStack: React, Electron');
    assert.ok(!base.includes('Project memory'));
    assert.match(withMem, /## Project memory/);
    assert.ok(withMem.startsWith(base), 'memory is appended after the standard prompt');
  });

  await test('guest tokens: read-only by default, expiring, revocable', async () => {
    const distDir = path.join(tmp, 'dist3');
    fs.mkdirSync(distDir, { recursive: true });
    fs.writeFileSync(path.join(distDir, 'index.html'), '<html>guest</html>');

    const guests = [];
    let lastUsed = null;
    const impl = {
      files: async () => ({ ok: true, tree: [] }),
      writeFile: async () => ({ ok: true })
    };
    const b = await startBridge({
      distDir,
      impl,
      mutating: ['writeFile'],
      guests: () => guests,
      onGuestUse: (id) => { lastUsed = id; }
    });
    const call = (tok, method, args = []) => fetch(`http://127.0.0.1:${b.port}/api/rpc`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-ds-token': tok },
      body: JSON.stringify({ method, args })
    });

    try {
      // no token at all
      assert.strictEqual((await call('', 'files')).status, 401);

      // read-only guest: reads fine, writes refused
      const g1 = { id: 'g1', label: 'reviewer', token: 'guest-token-one', readOnly: true, expiresAt: Date.now() + 60_000 };
      guests.push(g1);
      assert.strictEqual((await call(g1.token, 'files')).status, 200);
      const blocked = await call(g1.token, 'writeFile', ['a.txt', 'x']);
      assert.strictEqual(blocked.status, 403);
      assert.strictEqual((await blocked.json()).guest, true);
      assert.strictEqual(lastUsed, 'g1', 'guest use is tracked');

      // explicitly full-access guest may write
      const g2 = { id: 'g2', label: 'pair', token: 'guest-token-two', readOnly: false, expiresAt: Date.now() + 60_000 };
      guests.push(g2);
      assert.strictEqual((await call(g2.token, 'writeFile', ['a.txt', 'x'])).status, 200);

      // expired guest is rejected outright
      g1.expiresAt = Date.now() - 1000;
      assert.strictEqual((await call(g1.token, 'files')).status, 401);

      // revoked guest is rejected outright
      guests.length = 0;
      assert.strictEqual((await call(g2.token, 'files')).status, 401);

      // the owner token keeps working regardless
      assert.strictEqual((await call(b.token, 'files')).status, 200);
      assert.strictEqual((await call(b.token, 'writeFile', ['a.txt', 'x'])).status, 200);
    } finally {
      await b.stop();
    }
  });

  fs.rmSync(tmp, { recursive: true, force: true });

  console.log(`\n${pass} passed, ${fail} failed\n`);
  process.exit(fail === 0 ? 0 : 1);
})();
