/**
 * VICE VISTA — the overlook (v1.38.0). Third-person 3D scene-game inspired by
 * a GTA-VI-style vista composition: character (backpack ke saath, peeche se)
 * ek observation deck par, saamne bay + islands + downtown skyline, upar
 * clouds aur suraj. Original art, original code — kisi render ki copy nahi.
 *
 * Gameplay: deck par chalo (railing safe rakhti hai), 6 vista-shards collect
 * karo (har ek $100), sab mile to VISTA COMPLETE. N = day/night, P pause.
 *
 * Controls: WASD walk · Shift sprint · ←/→ or Q/E turn · P pause · N night
 */
const g = new GameKit({
  title: 'VICE VISTA', width: 960, height: 540, accent: '#7fd4e8',
  titleCard: {
    tagline: 'the overlook — bay, islands, skyline; collect the vista shards',
    controls: [
      'WASD — walk the deck · Shift — sprint',
      '←/→ or Q/E — turn · camera follows behind',
      '6 vista shards = $100 each · N = day/night · P = pause'
    ]
  }
});

const DECK_Y = 120;
const DECK_HX = 45;          // deck half x
const DECK_HZ = 30;          // deck half z
const PASTEL = [[0.96, 0.9, 0.8], [0.96, 0.62, 0.55], [0.42, 0.8, 0.74], [0.98, 0.74, 0.8], [0.62, 0.85, 0.9], [0.92, 0.8, 0.45]];
const GLASS = [[0.36, 0.55, 0.8], [0.5, 0.7, 0.85], [0.3, 0.45, 0.7], [0.55, 0.4, 0.75]];

g.start({
  init(g) {
    g.state = 'play';
    g.night = false;
    g.time = 0;
    // ---- downtown skyline across the bay (deterministic layout) ----
    g.towers = [];
    for (let i = 0; i < 42; i += 1) {
      const x = g.rand(-750, 750);
      const z = g.rand(560, 1250);
      const w = g.rand(34, 78);
      g.towers.push({ x, z, w, d: w * g.rand(0.8, 1.2), h: g.rand(120, 330), col: (i % 3 === 0 ? GLASS : PASTEL)[i % 6] });
    }
    // ---- islands in the bay ----
    g.islands = [
      { x: -520, z: 480, s: 300 }, { x: 260, z: 560, s: 240 }, { x: -80, z: 700, s: 180 }
    ];
    // ---- clouds ----
    g.clouds = [];
    for (let i = 0; i < 9; i += 1) {
      g.clouds.push({ x: g.rand(-900, 900), z: g.rand(300, 1600), y: g.rand(210, 280), w: g.rand(90, 200), v: g.rand(3, 9) });
    }
    // ---- vista shards on the deck ----
    g.shards = [
      { x: -38, z: -24 }, { x: 38, z: -24 }, { x: -38, z: 24 }, { x: 38, z: 24 }, { x: 0, z: -26 }, { x: 0, z: 26 }
    ].map((p, i) => ({ ...p, i, got: false }));
    g.collected = 0; g.score = 0; g.msg = ''; g.msgT = 0;
    // ---- player (third person, deck centre, skyline ki taraf) ----
    g.P3 = { x: 0, z: 8, yaw: Math.PI, pitch: 0, walk: 0, moving: 0 };
  },

  update(g, dt) {
    if (g.input.hit('KeyP', 'Escape')) g.togglePause();
    if (g.input.hit('KeyN')) g.night = !g.night;
    if (g.state === 'pause') return;
    g.time += dt;
    const P = g.P3;
    if (g.input.down('ArrowLeft') || g.input.down('KeyQ')) P.yaw -= 2.0 * dt;
    if (g.input.down('ArrowRight') || g.input.down('KeyE')) P.yaw += 2.0 * dt;
    const ax = g.input.axis();
    const spd = g.input.down('ShiftLeft', 'ShiftRight') ? 46 : 26;
    const fx = Math.sin(P.yaw); const fz = -Math.cos(P.yaw);
    const rx = Math.cos(P.yaw); const rz = Math.sin(P.yaw);
    let mvx = fx * -ax.y + rx * ax.x;
    let mvz = fz * -ax.y + rz * ax.x;
    const ml = Math.hypot(mvx, mvz);
    P.moving = ml > 0.01 ? 1 : 0;
    if (ml > 0.01) {
      mvx /= ml; mvz /= ml;
      P.x += mvx * spd * dt; P.z += mvz * spd * dt;
      P.walk += dt * (spd / 4);
    }
    // railing boundary: deck se neeche koi nahi girta
    P.x = g.clamp(P.x, -DECK_HX + 3, DECK_HX - 3);
    P.z = g.clamp(P.z, -DECK_HZ + 3, DECK_HZ - 3);
    // shards
    for (const s of g.shards) {
      if (!s.got && Math.hypot(P.x - s.x, P.z - s.z) < 4) {
        s.got = true; g.collected += 1; g.score += 100;
        g.msg = g.collected >= g.shards.length ? 'VISTA COMPLETE — poora sheher tumhara' : `vista shard ${g.collected}/${g.shards.length} (+$100)`;
        g.msgT = 4;
      }
    }
    if (g.msgT > 0) g.msgT -= dt;
    for (const c of g.clouds) { c.x += c.v * dt; if (c.x > 1100) c.x = -1100; }
  },

  draw(g) {
    const K3 = globalThis.GameKit3D || (typeof window !== 'undefined' ? window.GameKit3D : null);
    if (!K3) { g.text('engine3d.js missing', g.width / 2, g.height / 2, 18, '#fff', 'center'); return; }
    const ctx = g.ctx; const W = g.width; const H = g.height;
    const night = g.night;
    // sky bands
    ctx.fillStyle = night ? '#150a2e' : '#2f7fb8'; ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = night ? '#2a1245' : '#7fd4e8'; ctx.fillRect(0, H * 0.36, W, H * 0.26);
    ctx.fillStyle = night ? '#ff2d78' : '#ffe9c0'; ctx.fillRect(0, H * 0.58, W, H * 0.07);
    // sun / moon
    ctx.fillStyle = night ? '#e8e6f2' : '#ffe9b0';
    ctx.beginPath();
    for (let i = 0; i < 12; i += 1) {
      const a = (i / 12) * Math.PI * 2;
      const px = W * 0.76 + Math.cos(a) * 24; const py = H * 0.13 + Math.sin(a) * 24;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath(); ctx.fill();

    const P = g.P3;
    const fx = Math.sin(P.yaw); const fz = -Math.cos(P.yaw);
    const camera = {
      pos: [P.x - fx * 16, DECK_Y + 7.5, P.z - fz * 16],
      yaw: P.yaw, pitch: -0.22,
      fov: 70, aspect: W / H, near: 0.5, far: 5000, width: W, height: H
    };
    const faces = [];
    // clouds (neeche se dikhte hain: winding neeche-normal deti hai)
    for (const c of g.clouds) {
      const hw = c.w / 2; const hh = c.w / 5;
      const cc = night ? [0.25, 0.2, 0.4] : [0.97, 0.97, 0.99];
      // billboard quads (camera ki taraf -z normal): 2 puff layers
      faces.push({ verts: [[c.x - hw, c.y + hh, c.z], [c.x + hw, c.y + hh, c.z], [c.x + hw, c.y - hh, c.z], [c.x - hw, c.y - hh, c.z]], color: cc });
      faces.push({ verts: [[c.x - hw * 0.6, c.y + hh * 1.9, c.z - 2], [c.x + hw * 0.7, c.y + hh * 1.9, c.z - 2], [c.x + hw * 0.7, c.y + hh * 0.4, c.z - 2], [c.x - hw * 0.6, c.y + hh * 0.4, c.z - 2]], color: cc });
    }
    // bay water
    faces.push(...K3.waterMesh(-1400, 240, 2800, 2600, 14, g.time, { base: night ? [0.02, 0.12, 0.2] : [0.04, 0.45, 0.52], amp: night ? 0.35 : 0.9, wire: 0 }));
    // islands + their low blocks
    for (const isl of g.islands) {
      const y = 2.2;
      faces.push({ verts: [[isl.x, y, isl.z + isl.s], [isl.x + isl.s, y, isl.z + isl.s], [isl.x + isl.s, y, isl.z], [isl.x, y, isl.z]], color: night ? [0.1, 0.12, 0.1] : [0.35, 0.5, 0.3] });
      for (let b = 0; b < 5; b += 1) {
        const bx = isl.x + 20 + b * (isl.s / 5);
        const bh = 14 + ((b * 37 + isl.x) % 30);
        faces.push(...K3.boxFaces(bx, y, isl.z + isl.s * 0.35, isl.s / 7, bh, isl.s / 6, night ? [0.2, 0.2, 0.3] : [0.85, 0.82, 0.72]));
      }
    }
    // skyline towers (+ night neon)
    for (const t of g.towers) {
      faces.push(...K3.boxFaces(t.x, 0, t.z, t.w, t.h, t.d, night ? t.col.map((c) => c * 0.35) : t.col));
      if (night && t.h > 150) {
        const neon = [[1, 0.15, 0.5], [0.2, 0.9, 1], [0.65, 1, 0.3], [1, 0.75, 0.15]][Math.floor(t.x + t.z) & 3];
        faces.push(...K3.boxFaces(t.x + 2, t.h * 0.62, t.z - 0.8, t.w - 4, 5, 1, neon));
        faces.push(...K3.boxFaces(t.x + 2, t.h * 0.3, t.z - 0.8, t.w - 4, 3.5, 1, neon));
        faces.push(...K3.boxFaces(t.x + t.w * 0.4, t.h, t.z + t.d * 0.4, 2.5, 8, 2.5, [1, 0.2, 0.2])); // rooftop beacon
      }
    }
    // observation deck + railing + beacon
    faces.push(...K3.boxFaces(-DECK_HX, DECK_Y - 8, -DECK_HZ, DECK_HX * 2, 8, DECK_HZ * 2, [0.22, 0.22, 0.26]));
    for (let px = -DECK_HX; px <= DECK_HX; px += 10) {
      faces.push(...K3.boxFaces(px - 0.3, DECK_Y, -DECK_HZ - 0.3, 0.6, 3.2, 0.6, [0.3, 0.3, 0.35]));
      faces.push(...K3.boxFaces(px - 0.3, DECK_Y, DECK_HZ - 0.3, 0.6, 3.2, 0.6, [0.3, 0.3, 0.35]));
    }
    for (let pz = -DECK_HZ; pz <= DECK_HZ; pz += 10) {
      faces.push(...K3.boxFaces(-DECK_HX - 0.3, DECK_Y, pz - 0.3, 0.6, 3.2, 0.6, [0.3, 0.3, 0.35]));
      faces.push(...K3.boxFaces(DECK_HX - 0.3, DECK_Y, pz - 0.3, 0.6, 3.2, 0.6, [0.3, 0.3, 0.35]));
    }
    faces.push(...K3.boxFaces(-DECK_HX, DECK_Y + 3, -DECK_HZ - 0.4, DECK_HX * 2, 0.5, 0.8, [0.4, 0.4, 0.46]));
    faces.push(...K3.boxFaces(-DECK_HX, DECK_Y + 3, DECK_HZ - 0.4, DECK_HX * 2, 0.5, 0.8, [0.4, 0.4, 0.46]));
    const blink = (g.time % 1) < 0.5;
    faces.push(...K3.boxFaces(-0.4, DECK_Y, -DECK_HZ + 2, 0.8, 4, 0.8, [0.3, 0.3, 0.34]));
    faces.push(...K3.boxFaces(-0.7, DECK_Y + 4, -DECK_HZ + 1.7, 1.4, 1.4, 1.4, blink ? [1, 0.12, 0.12] : [0.35, 0.05, 0.05]));
    // vista shards (spinning cyan cubes)
    for (const s of g.shards) {
      if (s.got) continue;
      const bob = DECK_Y + 2 + Math.sin(g.time * 2 + s.i) * 0.5;
      const cube = K3.boxFaces(s.x - 0.8, bob, s.z - 0.8, 1.6, 1.6, 1.6, [0.2, 0.9, 1]);
      for (const f of cube) faces.push(K3.rotateFaceY(f, s.x, s.z, g.time * 2));
    }
    // ---- character (third person, backpack, walk-cycle limbs) ----
    const ang = P.yaw + Math.PI;
    const sw = Math.sin(P.walk) * (P.moving ? 2.2 : 0);
    const body = [
      // legs (swing), torso, head, backpack, arms
      ...K3.boxFaces(-0.55, DECK_Y, -0.3 + sw * 0.4, 0.5, 2.2, 0.6, [0.35, 0.45, 0.65]),
      ...K3.boxFaces(0.05, DECK_Y, -0.3 - sw * 0.4, 0.5, 2.2, 0.6, [0.35, 0.45, 0.65]),
      ...K3.boxFaces(-0.7, DECK_Y + 2.2, -0.45, 1.4, 2.0, 0.9, [0.95, 0.95, 0.95]),
      ...K3.boxFaces(-0.45, DECK_Y + 4.2, -0.4, 0.9, 0.9, 0.9, [0.8, 0.6, 0.5]),
      ...K3.boxFaces(-0.6, DECK_Y + 2.4, 0.5, 1.2, 1.7, 0.7, [0.9, 0.45, 0.1]),
      ...K3.boxFaces(-0.95, DECK_Y + 2.3, -0.25 - sw * 0.3, 0.35, 1.7, 0.5, [0.8, 0.6, 0.5]),
      ...K3.boxFaces(0.6, DECK_Y + 2.3, -0.25 + sw * 0.3, 0.35, 1.7, 0.5, [0.8, 0.6, 0.5])
    ];
    // pehle character ko P par translate karo, phir yaw ke gird ghumao
    for (const f of body) {
      const shifted = { color: f.color, verts: f.verts.map((v) => [v[0] + P.x, v[1], v[2] + P.z]) };
      faces.push(K3.rotateFaceY(shifted, P.x, P.z, ang));
    }

    const res = K3.renderScene(ctx, {
      camera, faces,
      light: [-0.45, 0.82, -0.38],
      ambient: night ? 0.22 : 0.5, diffuse: 0.72,
      fogNear: 700, fogFar: 3200,
      fogColor: night ? [30, 14, 52] : [205, 232, 240]
    });
    // HUD
    ctx.fillStyle = '#0b0b10'; ctx.fillRect(0, 0, W, 40);
    g.text(`VICE VISTA  ${night ? 'NIGHT' : 'DAY'}  shards:${g.collected}/${g.shards.length}  cash:$${g.score}  faces:${res.drawn}`, 10, 54, 12, '#9ff3ff');
    g.text('WASD walk · Shift sprint · Q/E turn · N night · P pause', 10, 70, 10, '#ff9ecb');
    if (g.msgT > 0) g.text(g.msg, W / 2, 100, 16, '#ffe08a', 'center');
  }
});

if (typeof window !== 'undefined') window.__vicevista = g; // test hook
