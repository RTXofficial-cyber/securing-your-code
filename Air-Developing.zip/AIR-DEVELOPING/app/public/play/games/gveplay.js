"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };

  // shared/gve/engine.cjs
  var require_engine = __commonJS({
    "shared/gve/engine.cjs"(exports, module) {
      "use strict";
      var FIXED_DT = 1 / 60;
      var MAX_FRAME = 0.25;
      var STATES = ["BOOT", "MENU", "PLAY", "PAUSE", "OVER"];
      var Pool = class {
        constructor(factory, reset, initial = 32) {
          this.factory = factory;
          this.reset = reset;
          this.free = [];
          this.live = 0;
          this.created = 0;
          this.reused = 0;
          for (let i = 0; i < initial; i += 1) this.free.push(factory());
          this.created = initial;
        }
        acquire() {
          const o = this.free.length ? (this.reused += 1, this.free.pop()) : (this.created += 1, this.factory());
          this.reset(o);
          this.live += 1;
          return o;
        }
        release(o) {
          if (this.live > 0) this.live -= 1;
          this.free.push(o);
        }
        stats() {
          return { free: this.free.length, live: this.live, created: this.created, reused: this.reused };
        }
      };
      var Engine = class {
        constructor(opts = {}) {
          this.state = "BOOT";
          this.time = 0;
          this.frame = 0;
          this.accumulator = 0;
          this.fixedDt = FIXED_DT;
          this.fixedSteps = 0;
          this.renderCalls = 0;
          this.modules = [];
          this.pools = {};
          this.disposed = 0;
          this.raf = opts.raf || null;
          this.listeners = { state: [] };
        }
        setState(s) {
          if (!STATES.includes(s) || s === this.state) return false;
          const prev = this.state;
          this.state = s;
          this.listeners.state.forEach((f) => f(prev, s));
          return true;
        }
        onState(f) {
          this.listeners.state.push(f);
        }
        register(mod) {
          if (!mod || !mod.id) throw new Error("module needs id");
          this.modules.push(mod);
          this.modules.sort((a, b) => (a.order || 50) - (b.order || 50));
          return mod;
        }
        pool(name, factory, reset, initial) {
          if (!this.pools[name]) this.pools[name] = new Pool(factory, reset, initial);
          return this.pools[name];
        }
        /** one rendered frame: dt clamp + fixed-step physics updates + module tick */
        tick(rawDt, ctx) {
          const dt = Math.min(Math.max(rawDt || 0, 0), MAX_FRAME);
          this.renderCalls += 1;
          if (this.state === "PAUSE") return { steps: 0, dt };
          this.accumulator += dt;
          let steps = 0;
          while (this.accumulator >= this.fixedDt && steps < 8) {
            this.time += this.fixedDt;
            this.fixedSteps += 1;
            steps += 1;
            for (const m of this.modules) if (m.fixed) m.fixed(ctx, this.fixedDt);
            this.accumulator -= this.fixedDt;
          }
          this.frame += 1;
          for (const m of this.modules) if (m.update) m.update(ctx, dt);
          return { steps, dt };
        }
        /** run N seconds of simulated time (headless harness helper) */
        run(seconds, ctx, frameDt = 1 / 60) {
          const n = Math.round(seconds / frameDt);
          let total = 0;
          for (let i = 0; i < n; i += 1) total += this.tick(frameDt, ctx).steps;
          return total;
        }
        poolStats() {
          const out = {};
          for (const k of Object.keys(this.pools)) out[k] = this.pools[k].stats();
          return out;
        }
        dispose() {
          this.modules = [];
          this.pools = {};
          this.disposed += 1;
        }
      };
      module.exports = { Engine, Pool, FIXED_DT, STATES };
    }
  });

  // shared/gve/render.cjs
  var require_render = __commonJS({
    "shared/gve/render.cjs"(exports, module) {
      "use strict";
      var Color = class {
        constructor(r = 0, g = 0, b = 0) {
          this.r = r;
          this.g = g;
          this.b = b;
        }
      };
      function lutTealMagenta(c, amount = 0.5) {
        const luma = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
        const shadow = Math.max(0, 1 - luma * 2);
        const high = Math.max(0, luma * 2 - 1);
        return new Color(
          Math.min(1, c.r + amount * (high * 0.35 - shadow * 0.1)),
          Math.min(1, c.g + amount * (shadow * 0.22)),
          Math.min(1, c.b + amount * (shadow * 0.35 + high * 0.18))
        );
      }
      var RenderPipeline = class {
        constructor(opts = {}) {
          this.gl = opts.gl || null;
          this.width = opts.width || 1280;
          this.height = opts.height || 720;
          this.passes = [
            { id: "scene", on: true },
            { id: "bloom", on: true, threshold: 0.72, softKnee: 0.25, intensity: 0.9 },
            { id: "ssao", on: true, radius: 0.35, kernel: 12, bias: 0.025 },
            { id: "grading", on: true, lut: lutTealMagenta, amount: 0.55 },
            { id: "grain", on: true, intensity: 0.045, seed: 1337 },
            { id: "present", on: true }
          ];
          this.gpu = /* @__PURE__ */ new Map();
          this.disposedCount = 0;
          this.frameBudgetMs = opts.frameBudgetMs || 16.6;
          this.stats = { frames: 0, draws: 0, disposed: 0, passRuns: {} };
        }
        resize(w, h) {
          if (w <= 0 || h <= 0) return false;
          this.width = w;
          this.height = h;
          this.aspect = w / h;
          if (this.gl && this.gl.viewport) this.gl.viewport(0, 0, w, h);
          return true;
        }
        track(id, bytes) {
          this.gpu.set(id, { bytes, lastSeen: this.stats.frames });
        }
        /** GPU memory cleanup: meshes not seen for N frames get disposed */
        collectGarbage(unseenFrames = 120) {
          let freed = 0;
          for (const [id, g] of this.gpu) {
            if (this.stats.frames - g.lastSeen > unseenFrames) {
              this.gpu.delete(id);
              this.disposedCount += 1;
              freed += g.bytes;
            }
          }
          this.stats.disposed = this.disposedCount;
          return freed;
        }
        bloomExtract(luma) {
          const p = this.passes[1];
          const knee = p.threshold * p.softKnee;
          const soft = Math.max(0, luma - p.threshold + knee);
          return soft * soft / (4 * knee + 1e-5) * p.intensity;
        }
        ssaoOcclude(sampleDepths, viewDepth) {
          const p = this.passes[2];
          let occ = 0;
          for (const d of sampleDepths.slice(0, p.kernel)) {
            const diff = viewDepth - d;
            if (diff > p.bias && diff < p.radius) occ += 1;
          }
          return 1 - occ / Math.max(1, Math.min(p.kernel, sampleDepths.length));
        }
        grain(u, v) {
          const p = this.passes[4];
          const n = Math.sin(u * 12.9898 + v * 78.233 + this.stats.frames * 0.01 + p.seed) * 43758.5453;
          return (n - Math.floor(n) - 0.5) * p.intensity;
        }
        /** full pipeline for one pixel-color sample (math adapter path) */
        shade(color, ctx = {}) {
          let c = color;
          for (const p of this.passes) {
            if (!p.on) continue;
            this.stats.passRuns[p.id] = (this.stats.passRuns[p.id] || 0) + 1;
            if (p.id === "bloom") {
              const l = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
              const add = this.bloomExtract(l) * (ctx.neon ? 1.6 : 1);
              c = new Color(Math.min(1, c.r + add), Math.min(1, c.g + add), Math.min(1, c.b + add));
            } else if (p.id === "ssao") {
              const ao = ctx.depths ? this.ssaoOcclude(ctx.depths, ctx.viewDepth || 1) : 1;
              c = new Color(c.r * ao, c.g * ao, c.b * ao);
            } else if (p.id === "grading") c = p.lut(c, p.amount);
            else if (p.id === "grain") {
              const g = this.grain(ctx.u || 0.5, ctx.v || 0.5);
              c = new Color(Math.max(0, Math.min(1, c.r + g)), Math.max(0, Math.min(1, c.g + g)), Math.max(0, Math.min(1, c.b + g)));
            }
          }
          return c;
        }
        present(draws = 1) {
          this.stats.frames += 1;
          this.stats.draws += draws;
        }
      };
      module.exports = { RenderPipeline, Color, lutTealMagenta };
    }
  });

  // shared/gve/physics.cjs
  var require_physics = __commonJS({
    "shared/gve/physics.cjs"(exports, module) {
      "use strict";
      var LAYERS = ["world", "player", "vehicle", "ped", "bullet", "pickup"];
      var MATRIX = {
        // can-collide matrix (symmetric)
        world: ["player", "vehicle", "ped", "bullet", "pickup"],
        player: ["world", "vehicle", "ped", "pickup"],
        vehicle: ["world", "player", "vehicle", "ped", "pickup"],
        ped: ["world", "player", "vehicle", "ped"],
        bullet: ["world", "player", "vehicle", "ped"],
        pickup: ["world", "player"]
      };
      var V = {
        add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }),
        sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }),
        scale: (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s }),
        dot: (a, b) => a.x * b.x + a.y * b.y + a.z * b.z,
        len: (a) => Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z),
        norm: (a) => {
          const l = V.len(a) || 1;
          return { x: a.x / l, y: a.y / l, z: a.z / l };
        },
        cross: (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x })
      };
      var Body = class {
        constructor(o = {}) {
          this.id = o.id || `b${Math.random().toString(36).slice(2, 8)}`;
          this.pos = o.pos || { x: 0, y: 0, z: 0 };
          this.vel = o.vel || { x: 0, y: 0, z: 0 };
          this.radius = o.radius != null ? o.radius : 0.5;
          this.half = o.half || null;
          this.capsule = o.capsule || null;
          this.mass = o.mass || 1;
          this.layer = o.layer || "world";
          this.static = !!o.static;
          this.restitution = o.restitution != null ? o.restitution : 0.2;
          this.friction = o.friction != null ? o.friction : 0.6;
          this.grounded = false;
          this.contacts = 0;
        }
        get invMass() {
          return this.static ? 0 : 1 / this.mass;
        }
      };
      var PhysicsSystem = class {
        constructor(opts = {}) {
          this.gravity = opts.gravity != null ? opts.gravity : -9.81;
          this.floorY = opts.floorY != null ? opts.floorY : 0;
          this.bodies = [];
          this.cell = opts.cell || 8;
          this.hash = /* @__PURE__ */ new Map();
          this.stats = { steps: 0, pairs: 0, contacts: 0, impulses: 0 };
        }
        add(b) {
          this.bodies.push(b);
          return b;
        }
        remove(b) {
          const i = this.bodies.indexOf(b);
          if (i >= 0) this.bodies.splice(i, 1);
        }
        canCollide(a, b) {
          return (MATRIX[a.layer] || []).includes(b.layer);
        }
        buildHash() {
          this.hash.clear();
          for (const b of this.bodies) {
            const k = `${Math.floor(b.pos.x / this.cell)},${Math.floor(b.pos.z / this.cell)}`;
            if (!this.hash.has(k)) this.hash.set(k, []);
            this.hash.get(k).push(b);
          }
        }
        neighbors(b) {
          const cx = Math.floor(b.pos.x / this.cell);
          const cz = Math.floor(b.pos.z / this.cell);
          const out = [];
          for (let dx = -1; dx <= 1; dx += 1) for (let dz = -1; dz <= 1; dz += 1) {
            const arr = this.hash.get(`${cx + dx},${cz + dz}`);
            if (arr) {
              for (const o of arr) if (o !== b) out.push(o);
            }
          }
          return out;
        }
        /** sphere vs sphere (capsule approximated as sphere at center height) */
        narrow(a, b) {
          const d = V.sub(b.pos, a.pos);
          const dist = V.len(d);
          const r = a.radius + b.radius;
          if (dist >= r || dist === 0) return null;
          return { normal: V.scale(d, 1 / dist), depth: r - dist };
        }
        resolve(a, b, hit) {
          const n = hit.normal;
          const totalInv = a.invMass + b.invMass;
          if (totalInv === 0) return;
          const corr = V.scale(n, hit.depth / totalInv * 0.8);
          a.pos = V.sub(a.pos, V.scale(corr, a.invMass));
          b.pos = V.add(b.pos, V.scale(corr, b.invMass));
          const rv = V.sub(b.vel, a.vel);
          const velN = V.dot(rv, n);
          if (velN > 0) return;
          const e = Math.min(a.restitution, b.restitution);
          const j = -(1 + e) * velN / totalInv;
          const imp = V.scale(n, j);
          a.vel = V.sub(a.vel, V.scale(imp, a.invMass));
          b.vel = V.add(b.vel, V.scale(imp, b.invMass));
          const t = V.norm(V.sub(rv, V.scale(n, velN)));
          const mu = Math.min(a.friction, b.friction);
          const jtRaw = -V.dot(rv, t) / totalInv;
          const jt = Math.max(-j * mu, Math.min(j * mu, jtRaw));
          const fimp = V.scale(t, jt);
          a.vel = V.sub(a.vel, V.scale(fimp, a.invMass));
          b.vel = V.add(b.vel, V.scale(fimp, b.invMass));
          this.stats.impulses += 1;
          if (n.y > 0.5) {
            b.grounded = true;
          }
          if (n.y < -0.5) {
            a.grounded = true;
          }
          a.contacts += 1;
          b.contacts += 1;
          this.stats.contacts += 1;
        }
        /** one fixed step: integrate + broadphase + narrowphase + resolve */
        fixed(ctx, dt) {
          this.stats.steps += 1;
          for (const b of this.bodies) {
            if (b.static) continue;
            b.vel.y += this.gravity * dt;
            b.grounded = false;
            b.contacts = 0;
            b.pos = V.add(b.pos, V.scale(b.vel, dt));
            if (b.pos.y < b.radius + this.floorY) {
              b.pos.y = b.radius + this.floorY;
              if (b.vel.y < 0) b.vel.y = 0;
              b.grounded = true;
            }
          }
          this.buildHash();
          const seen = /* @__PURE__ */ new Set();
          for (const a of this.bodies) {
            for (const b of this.neighbors(a)) {
              const key = a.id < b.id ? a.id + b.id : b.id + a.id;
              if (seen.has(key)) continue;
              seen.add(key);
              this.stats.pairs += 1;
              if (!this.canCollide(a, b)) continue;
              const hit = this.narrow(a, b);
              if (hit) this.resolve(a, b, hit);
            }
          }
        }
        raycast(origin, dir, maxDist = 200, filter = () => true) {
          const d = V.norm(dir);
          let best = null;
          for (const b of this.bodies) {
            if (!filter(b)) continue;
            const to = V.sub(b.pos, origin);
            const t = V.dot(to, d);
            if (t < 0 || t > maxDist) continue;
            const closest = V.add(origin, V.scale(d, t));
            const dist = V.len(V.sub(closest, b.pos));
            if (dist <= b.radius && (!best || t < best.t)) best = { body: b, t, point: closest };
          }
          return best;
        }
      };
      module.exports = { PhysicsSystem, Body, V, LAYERS, MATRIX };
    }
  });

  // shared/gve/streamer.cjs
  var require_streamer = __commonJS({
    "shared/gve/streamer.cjs"(exports, module) {
      "use strict";
      var WorldStreamer = class {
        constructor(opts = {}) {
          this.chunkSize = opts.chunkSize || 256;
          this.radius = opts.radius || 2;
          this.loadBudget = opts.loadBudget || 4;
          this.unloadBudget = opts.unloadBudget || 2;
          this.lod = opts.lod || [128, 384, 768];
          this.chunks = /* @__PURE__ */ new Map();
          this.assets = /* @__PURE__ */ new Map();
          this.generator = opts.generator || null;
          this.stats = { loaded: 0, unloaded: 0, lod: [0, 0, 0], poolReuse: 0 };
          this.propPool = { free: [], live: 0 };
        }
        key(cx, cz) {
          return `${cx},${cz}`;
        }
        chunkOf(x, z) {
          return [Math.floor(x / this.chunkSize), Math.floor(z / this.chunkSize)];
        }
        acquireProp() {
          if (this.propPool.free.length) {
            this.stats.poolReuse += 1;
            return this.propPool.free.pop();
          }
          return { id: null, x: 0, z: 0, lod: 0 };
        }
        releaseProp(p) {
          this.propPool.live -= 1;
          this.propPool.free.push(p);
        }
        refAsset(id, bytes = 1024) {
          const a = this.assets.get(id) || { refs: 0, bytes };
          a.refs += 1;
          this.assets.set(id, a);
          return a;
        }
        unrefAsset(id) {
          const a = this.assets.get(id);
          if (!a) return false;
          a.refs -= 1;
          if (a.refs <= 0) this.assets.delete(id);
          return true;
        }
        lodTier(dist) {
          return dist <= this.lod[0] ? 0 : dist <= this.lod[1] ? 1 : dist <= this.lod[2] ? 2 : -1;
        }
        /** call every engine update with player position */
        update(ctx, dt, player) {
          const px = player ? player.x : 0;
          const pz = player ? player.z : 0;
          const [ccx, ccz] = this.chunkOf(px, pz);
          const wanted = [];
          for (let dz = -this.radius; dz <= this.radius; dz += 1) for (let dx = -this.radius; dx <= this.radius; dx += 1) {
            const k = this.key(ccx + dx, ccz + dz);
            if (!this.chunks.has(k)) wanted.push({ k, cx: ccx + dx, cz: ccz + dz, d: dx * dx + dz * dz });
          }
          wanted.sort((a, b) => a.d - b.d);
          let loaded = 0;
          for (const w of wanted) {
            if (loaded >= this.loadBudget) break;
            const ents = this.generator ? this.generator(w.cx, w.cz) : [];
            const props = ents.map((e) => {
              const p = this.acquireProp();
              p.id = e.id;
              p.x = e.x;
              p.z = e.z;
              p.asset = e.asset || null;
              this.propPool.live += 1;
              return p;
            });
            this.chunks.set(w.k, { cx: w.cx, cz: w.cz, props, assets: ents.map((e) => e.asset).filter(Boolean) });
            for (const a of this.chunks.get(w.k).assets) this.refAsset(a);
            this.stats.loaded += 1;
            loaded += 1;
          }
          let unloaded = 0;
          for (const [k, c] of this.chunks) {
            if (unloaded >= this.unloadBudget) break;
            const dx = c.cx - ccx;
            const dz = c.cz - ccz;
            if (Math.max(Math.abs(dx), Math.abs(dz)) > this.radius + 1) {
              for (const p of c.props) this.releaseProp(p);
              for (const a of c.assets) this.unrefAsset(a);
              this.chunks.delete(k);
              this.stats.unloaded += 1;
              unloaded += 1;
            }
          }
          this.stats.lod = [0, 0, 0];
          for (const [, c] of this.chunks) {
            const wx = (c.cx + 0.5) * this.chunkSize;
            const wz = (c.cz + 0.5) * this.chunkSize;
            const t = this.lodTier(Math.hypot(wx - px, wz - pz));
            for (const p of c.props) p.lod = t < 0 ? 2 : t;
            if (t >= 0) this.stats.lod[t] += c.props.length;
          }
          return { chunks: this.chunks.size };
        }
      };
      module.exports = { WorldStreamer };
    }
  });

  // shared/gve/player.cjs
  var require_player = __commonJS({
    "shared/gve/player.cjs"(exports, module) {
      "use strict";
      var { V } = require_physics();
      var PSTATES = ["IDLE", "WALK", "SPRINT", "JUMP", "FALL", "CROUCH"];
      function quatFromYawPitch(yaw, pitch) {
        const cy = Math.cos(yaw * 0.5);
        const sy = Math.sin(yaw * 0.5);
        const cp = Math.cos(pitch * 0.5);
        const sp = Math.sin(pitch * 0.5);
        return { w: cy * cp, x: sy * sp, y: sy * cp, z: -cy * sp };
      }
      function quatMul(a, b) {
        return {
          w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
          x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
          y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
          z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w
        };
      }
      function quatSlerp(a, b, t) {
        let dot = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;
        let bb = b;
        if (dot < 0) {
          dot = -dot;
          bb = { w: -b.w, x: -b.x, y: -b.y, z: -b.z };
        }
        if (dot > 0.9995) {
          const r = { w: a.w + (bb.w - a.w) * t, x: a.x + (bb.x - a.x) * t, y: a.y + (bb.y - a.y) * t, z: a.z + (bb.z - a.z) * t };
          const l = Math.hypot(r.w, r.x, r.y, r.z) || 1;
          return { w: r.w / l, x: r.x / l, y: r.y / l, z: r.z / l };
        }
        const th = Math.acos(Math.max(-1, Math.min(1, dot)));
        const s = Math.sin(th);
        const wa = Math.sin((1 - t) * th) / s;
        const wb = Math.sin(t * th) / s;
        return { w: a.w * wa + bb.w * wb, x: a.x * wa + bb.x * wb, y: a.y * wa + bb.y * wb, z: a.z * wa + bb.z * wb };
      }
      var PlayerController = class {
        constructor(physics, opts = {}) {
          this.phy = physics;
          this.walk = opts.walk || 2.2;
          this.sprint = opts.sprint || 5.2;
          this.crouch = opts.crouch || 1.1;
          this.jumpVel = opts.jumpVel || 4.6;
          this.accel = opts.accel || 24;
          this.state = "IDLE";
          this.stateTime = 0;
          this.yaw = 0;
          this.pitch = -0.25;
          this.camQuat = quatFromYawPitch(this.yaw, this.pitch);
          this.camDist = opts.camDist || 3.4;
          this.camHeight = opts.camHeight || 1.5;
          this.camSmooth = opts.camSmooth || 12;
          this.input = { f: 0, r: 0, jump: false, sprint: false, crouch: false };
          this.body = physics.add(new (require_physics()).Body({ layer: "player", radius: 0.45, capsule: { height: 1.8 }, mass: 78, friction: 0.05, pos: { x: 0, y: 1, z: 0 } }));
          this.history = [];
        }
        setInput(i) {
          Object.assign(this.input, i);
        }
        mouseLook(dyaw, dpitch) {
          this.yaw += dyaw;
          this.pitch = Math.max(-1.2, Math.min(0.9, this.pitch + dpitch));
        }
        next() {
          const b = this.body;
          const moving = Math.abs(this.input.f) + Math.abs(this.input.r) > 0.1;
          if (!b.grounded && b.vel.y < -1) return "FALL";
          if (!b.grounded && b.vel.y >= -1) return this.state === "FALL" ? "FALL" : "JUMP";
          if (this.input.crouch) return "CROUCH";
          if (this.input.jump && b.grounded) return "JUMP";
          if (!moving) return "IDLE";
          return this.input.sprint ? "SPRINT" : "WALK";
        }
        fixed(ctx, dt) {
          const b = this.body;
          const want = this.next();
          if (want !== this.state) {
            this.state = want;
            this.stateTime = 0;
            this.history.push(want);
            if (this.history.length > 60) this.history.shift();
          }
          this.stateTime += dt;
          const speed = this.state === "SPRINT" ? this.sprint : this.state === "CROUCH" ? this.crouch : this.walk;
          const sy = Math.sin(this.yaw);
          const cy = Math.cos(this.yaw);
          const wish = V.norm({ x: sy * this.input.f + cy * this.input.r, y: 0, z: cy * this.input.f - sy * this.input.r });
          const target = V.scale(wish, speed);
          const k = Math.min(1, this.accel * dt);
          b.vel.x += (target.x - b.vel.x) * k;
          b.vel.z += (target.z - b.vel.z) * k;
          if (this.input.jump && b.grounded) {
            b.vel.y = this.jumpVel;
            b.grounded = false;
          }
          this.input.jump = false;
        }
        update(ctx, dt) {
          const target = quatFromYawPitch(this.yaw, this.pitch);
          this.camQuat = quatSlerp(this.camQuat, target, Math.min(1, this.camSmooth * dt));
          const f = this.forward();
          this.camPos = {
            x: this.body.pos.x - f.x * this.camDist,
            y: this.body.pos.y + this.camHeight - f.y * this.camDist * -1,
            z: this.body.pos.z - f.z * this.camDist
          };
        }
        forward() {
          const q = this.camQuat;
          return V.norm({
            x: 2 * (q.x * q.z + q.w * q.y) * -1,
            y: 2 * (q.y * q.z - q.w * q.x),
            z: 1 - 2 * (q.x * q.x + q.y * q.y)
          });
        }
      };
      module.exports = { PlayerController, quatFromYawPitch, quatMul, quatSlerp, PSTATES };
    }
  });

  // shared/gve/vehicle.cjs
  var require_vehicle = __commonJS({
    "shared/gve/vehicle.cjs"(exports, module) {
      "use strict";
      var { V, Body } = require_physics();
      function tractionCurve(slip) {
        const s = Math.abs(slip);
        if (s < 0.18) return s / 0.18;
        return Math.max(0.35, 1 - (s - 0.18) * 1.6);
      }
      var Wheel = class {
        constructor(off) {
          this.offset = off;
          this.suspLen = 0.35;
          this.maxTravel = 0.28;
          this.stiffness = 32e3;
          this.damping = 4200;
          this.compression = 0;
          this.load = 0;
          this.spin = 0;
          this.grounded = false;
          this.slip = 0;
        }
      };
      var VehiclePhysics = class {
        constructor(physics, opts = {}) {
          this.phy = physics;
          this.mass = opts.mass || 1350;
          this.chassis = physics.add(new Body({ layer: "vehicle", radius: 1.1, mass: this.mass, friction: 0.05, pos: { x: 8, y: 0.7, z: 8 } }));
          this.wheels = [new Wheel({ x: -0.85, z: 1.5 }), new Wheel({ x: 0.85, z: 1.5 }), new Wheel({ x: -0.85, z: -1.5 }), new Wheel({ x: 0.85, z: -1.5 })];
          this.heading = opts.heading || 0;
          this.rpm = 800;
          this.gear = 1;
          this.input = { throttle: 0, brake: 0, steer: 0, handbrake: false };
          this.enterState = "out";
          this.enterT = 0;
          this.drift = 0;
          this.groundY = opts.groundY != null ? opts.groundY : 0;
        }
        setInput(i) {
          Object.assign(this.input, i);
        }
        /** player<->door interaction: distance vector check + F press */
        tryEnter(playerPos, fPressed) {
          const d = V.len(V.sub(this.chassis.pos, playerPos));
          if (this.enterState === "out" && fPressed && d < 2.6) {
            this.enterState = "lerping";
            this.enterT = 0;
            return true;
          }
          return false;
        }
        exit() {
          if (this.enterState === "in") {
            this.enterState = "out";
            return true;
          }
          return false;
        }
        fixed(ctx, dt) {
          const c = this.chassis;
          if (this.enterState === "lerping") {
            this.enterT += dt;
            if (this.enterT > 0.6) this.enterState = "in";
            return;
          }
          for (const w of this.wheels) {
            const wx = c.pos.x + w.offset.x * Math.cos(this.heading) + w.offset.z * Math.sin(this.heading);
            const wz = c.pos.z - w.offset.x * Math.sin(this.heading) + w.offset.z * Math.cos(this.heading);
            const ground = this.groundY;
            const rest = c.pos.y - ground;
            w.compression = Math.max(0, Math.min(w.maxTravel, w.suspLen + 0.4 - rest + 0.77));
            w.grounded = w.compression > 0.01;
            const springF = w.stiffness * w.compression;
            const dampF = w.damping * Math.max(-1, Math.min(1, c.vel.y));
            w.load = Math.max(0, springF + dampF) / 4;
          }
          const grounded = this.wheels.some((w) => w.grounded);
          const drive = this.input.throttle - this.input.brake * 0.9;
          const engineF = drive * 9e3 * tractionCurve(drive > 0 ? Math.min(1, Math.abs(this.rpm - 3e3) / 3e3) : 0.2);
          const fx = Math.sin(this.heading);
          const fz = Math.cos(this.heading);
          if (grounded && this.enterState === "in") {
            c.vel.x += fx * (engineF / this.mass) * dt;
            c.vel.z += fz * (engineF / this.mass) * dt;
          }
          const speed = Math.hypot(c.vel.x, c.vel.z);
          const steerEff = this.input.steer * Math.min(1, speed / 6) * (this.input.handbrake ? 1.6 : 1);
          this.heading += steerEff * 1.9 * dt * (this.gear >= 0 ? 1 : -1);
          const lat = { x: Math.cos(this.heading), z: -Math.sin(this.heading) };
          const vLat = c.vel.x * lat.x + c.vel.z * lat.z;
          const grip = this.input.handbrake ? 0.25 : 0.92;
          const slip = speed > 0.5 ? vLat / speed : 0;
          this.drift = Math.abs(slip);
          const latF = -vLat * grip * tractionCurve(slip) * 8;
          c.vel.x += lat.x * latF * dt;
          c.vel.z += lat.z * latF * dt;
          c.vel.x *= 1 - 0.6 * dt;
          c.vel.z *= 1 - 0.6 * dt;
          if (grounded) {
            const rest = c.pos.y - this.groundY - 0.7;
            c.vel.y += (-rest * 60 - c.vel.y * 8) * dt;
          }
          this.rpm = 800 + speed * 260 + this.input.throttle * 900;
          this.gear = speed > 28 ? 3 : speed > 14 ? 2 : 1;
        }
        update(ctx, dt) {
          for (const w of this.wheels) w.spin += Math.hypot(this.chassis.vel.x, this.chassis.vel.z) * dt / 0.32;
        }
        speed() {
          return Math.hypot(this.chassis.vel.x, this.chassis.vel.z);
        }
      };
      module.exports = { VehiclePhysics, Wheel, tractionCurve };
    }
  });

  // shared/gve/combat.cjs
  var require_combat = __commonJS({
    "shared/gve/combat.cjs"(exports, module) {
      "use strict";
      var { V } = require_physics();
      var WEAPONS = [
        { id: "fist", name: "FISTS", dmg: 8, rpm: 120, spread: 0, range: 2, pellets: 1, impulse: 4 },
        { id: "pistol", name: "PISTOL", dmg: 26, rpm: 300, spread: 8e-3, range: 90, pellets: 1, impulse: 30 },
        { id: "smg", name: "SMG", dmg: 17, rpm: 800, spread: 0.02, range: 70, pellets: 1, impulse: 18 },
        { id: "rifle", name: "ASSAULT RIFLE", dmg: 30, rpm: 620, spread: 0.014, range: 120, pellets: 1, impulse: 34 }
      ];
      var CombatSystem = class {
        constructor(physics, engine, opts = {}) {
          this.phy = physics;
          this.engine = engine;
          this.slot = 1;
          this.ammo = { pistol: 60, smg: 120, rifle: 90 };
          this.cooldown = 0;
          this.recoil = 0;
          this.hits = 0;
          this.shots = 0;
          this.impacts = engine.pool("impacts", () => ({ x: 0, y: 0, z: 0, life: 0, nx: 0, ny: 1, nz: 0 }), (o) => {
            o.life = 0;
          });
          this.tracers = engine.pool("tracers", () => ({ x1: 0, y1: 0, z1: 0, x2: 0, y2: 0, z2: 0, life: 0 }), (o) => {
            o.life = 0;
          });
          this.log = [];
        }
        wheel(dir) {
          this.slot = (this.slot + (dir || 1) + WEAPONS.length) % WEAPONS.length;
          return WEAPONS[this.slot];
        }
        weapon() {
          return WEAPONS[this.slot];
        }
        fire(origin, dirVec, dt, targetFilter) {
          const w = this.weapon();
          if (this.cooldown > 0) return null;
          if (w.id !== "fist" && (this.ammo[w.id] || 0) <= 0) return { dry: true };
          this.cooldown = 60 / w.rpm;
          if (w.id !== "fist") this.ammo[w.id] -= 1;
          this.shots += 1;
          const d = V.norm(dirVec);
          const s = w.spread;
          d.x += (Math.random() - 0.5) * s;
          d.y += (Math.random() - 0.5) * s;
          d.z += (Math.random() - 0.5) * s;
          const dn = V.norm(d);
          const hit = this.phy.raycast(origin, dn, w.range, targetFilter || ((b) => b.layer !== "bullet" && b.layer !== "player"));
          const end = hit ? hit.point : V.add(origin, V.scale(dn, w.range));
          const tr = this.tracers.acquire();
          tr.x1 = origin.x;
          tr.y1 = origin.y;
          tr.z1 = origin.z;
          tr.x2 = end.x;
          tr.y2 = end.y;
          tr.z2 = end.z;
          tr.life = 0.09;
          this.recoil = Math.min(0.35, this.recoil + 0.06 + w.impulse * 1e-3);
          if (hit) {
            this.hits += 1;
            if (!hit.body.static) hit.body.vel = V.add(hit.body.vel, V.scale(dn, w.impulse / hit.body.mass));
            const im = this.impacts.acquire();
            im.x = end.x;
            im.y = end.y;
            im.z = end.z;
            im.life = 0.5;
            im.nx = -dn.x;
            im.ny = -dn.y;
            im.nz = -dn.z;
            this.log.push({ t: "hit", layer: hit.body.layer, dmg: w.dmg });
            if (this.log.length > 40) this.log.shift();
            return { hit: hit.body, dmg: w.dmg, point: end };
          }
          return { hit: null };
        }
        update(ctx, dt) {
          this.cooldown = Math.max(0, this.cooldown - dt);
          this.recoil = Math.max(0, this.recoil - dt * 1.4);
          for (const p of this.impacts.free.concat([])) {
          }
          const age = (pool) => {
            for (let i = pool.free.length - 1; i >= 0; i -= 1) {
              const o = pool.free[i];
              if (o.life > 0) {
                o.life -= dt;
              }
            }
          };
          age(this.impacts);
          age(this.tracers);
        }
      };
      module.exports = { CombatSystem, WEAPONS };
    }
  });

  // shared/gve/traffic.cjs
  var require_traffic = __commonJS({
    "shared/gve/traffic.cjs"(exports, module) {
      "use strict";
      var { V } = require_physics();
      var TrafficAI = class {
        constructor(physics, opts = {}) {
          this.phy = physics;
          this.nodes = [];
          this.cars = [];
          this.cruise = opts.cruise || 7;
          this.stopDist = opts.stopDist || 6;
          this.avoidDist = opts.avoidDist || 9;
          this.stats = { stops: 0, avoids: 0, panics: 0 };
        }
        addNode(x, z, links = [], light = null) {
          this.nodes.push({ x, z, links, light });
          return this.nodes.length - 1;
        }
        spawnCar(nodeIdx, layer = "vehicle") {
          const { Body } = require_physics();
          const n = this.nodes[nodeIdx];
          const body = this.phy.add(new Body({ layer, radius: 1, mass: 1200, friction: 0.05, pos: { x: n.x, y: 0.6, z: n.z } }));
          const car = { body, node: nodeIdx, next: this.nodes[nodeIdx].links[0] != null ? this.nodes[nodeIdx].links[0] : nodeIdx, speed: this.cruise, panic: 0, stopT: 0 };
          this.cars.push(car);
          return car;
        }
        gunshot(x, z, radius = 40) {
          for (const c of this.cars) {
            if (Math.hypot(c.body.pos.x - x, c.body.pos.z - z) < radius) {
              c.panic = 6;
              this.stats.panics += 1;
            }
          }
        }
        update(ctx, dt) {
          for (const c of this.cars) {
            const target = this.nodes[c.next];
            if (!target) continue;
            const to = { x: target.x - c.body.pos.x, y: 0, z: target.z - c.body.pos.z };
            const dist = Math.hypot(to.x, to.z);
            if (dist < 2.2) {
              c.node = c.next;
              const links = this.nodes[c.node].links;
              c.next = links.length ? links[Math.floor(Math.random() * links.length)] : c.node;
            }
            const dir = dist > 0 ? { x: to.x / dist, z: to.z / dist } : { x: 0, z: 0 };
            let want = c.panic > 0 ? this.cruise * 1.9 : this.cruise;
            if (target.light === "red" && dist < this.stopDist) {
              want = 0;
              c.stopT += dt;
              if (c.stopT > dt) this.stats.stops += 0;
            }
            for (const o of this.cars) {
              if (o === c) continue;
              const d = Math.hypot(o.body.pos.x - c.body.pos.x, o.body.pos.z - c.body.pos.z);
              if (d < this.avoidDist && d > 0.1) {
                const ox = (o.body.pos.x - c.body.pos.x) / d;
                const oz = (o.body.pos.z - c.body.pos.z) / d;
                const align = ox * dir.x + oz * dir.z;
                if (align > 0.8) {
                  want = Math.min(want, Math.max(0, (d - 3) / this.avoidDist) * this.cruise);
                  this.stats.avoids += dt > 0 ? 0 : 0;
                  if (d < 4.5) want = 0;
                }
              }
            }
            if (c.panic > 0) c.panic -= dt;
            c.speed += (want - c.speed) * Math.min(1, 3 * dt);
            c.body.vel.x += (dir.x * c.speed - c.body.vel.x) * Math.min(1, 4 * dt);
            c.body.vel.z += (dir.z * c.speed - c.body.vel.z) * Math.min(1, 4 * dt);
            if (want === 0) this.stats.stops += dt;
          }
        }
      };
      module.exports = { TrafficAI };
    }
  });

  // shared/gve/wanted.cjs
  var require_wanted = __commonJS({
    "shared/gve/wanted.cjs"(exports, module) {
      "use strict";
      var { V, Body } = require_physics();
      var WantedSystem = class {
        constructor(physics, traffic, opts = {}) {
          this.phy = physics;
          this.traffic = traffic;
          this.stars = 0;
          this.heat = 0;
          this.maxHeat = [0, 20, 45, 80, 120, 170];
          this.units = [];
          this.roadblocks = [];
          this.spawnCooldown = 0;
          this.stats = { spawns: 0, pits: 0, blocks: 0, escalations: 0 };
          this.crime = { copHit: 12, shot: 6, ram: 20 };
        }
        addHeat(h) {
          this.heat += h;
          let s = 0;
          for (let i = 1; i <= 5; i += 1) if (this.heat >= this.maxHeat[i] * 0.4) s = i;
          if (s > this.stars) {
            this.stars = s;
            this.stats.escalations += 1;
          }
        }
        decay(dt, hidden) {
          if (hidden) this.heat = Math.max(0, this.heat - dt * 3);
          const s = this.stars;
          if (s > 0 && this.heat < this.maxHeat[s] * 0.2) this.stars = s - 1;
        }
        spawnUnit(mode, x, z) {
          const body = this.phy.add(new Body({ layer: "vehicle", radius: 1.05, mass: 1500, friction: 0.05, pos: { x, y: 0.6, z } }));
          const u = { body, mode, cool: 0 };
          this.units.push(u);
          this.stats.spawns += 1;
          return u;
        }
        /** roadblock ahead: project player velocity onto road vector array */
        placeRoadblock(player, roadNodes) {
          const v = V.norm({ x: player.vel.x, y: 0, z: player.vel.z });
          let best = null;
          let bestT = -1;
          for (const n of roadNodes) {
            const to = { x: n.x - player.pos.x, z: n.z - player.pos.z };
            const d = Math.hypot(to.x, to.z);
            if (d < 12 || d > 300) continue;
            const t = (to.x * v.x + to.z * v.z) / (d || 1);
            if (t > bestT) {
              bestT = t;
              best = n;
            }
          }
          if (!best) return null;
          const block = { x: best.x, z: best.z, cars: 3 };
          this.roadblocks.push(block);
          for (let i = -1; i <= 1; i += 1) this.spawnUnit("block", best.x + i * 2.4, best.z + 2);
          this.stats.blocks += 1;
          return block;
        }
        update(ctx, dt, player, roadNodes) {
          this.spawnCooldown -= dt;
          const wantUnits = this.stars >= 5 ? 6 : this.stars >= 3 ? 4 : this.stars >= 1 ? 2 : 0;
          if (this.stars > 0 && this.units.length < wantUnits && this.spawnCooldown <= 0) {
            const a = Math.random() * Math.PI * 2;
            this.spawnUnit(this.stars >= 3 ? "pit" : "patrol", player.pos.x + Math.cos(a) * 45, player.pos.z + Math.sin(a) * 45);
            this.spawnCooldown = 2.5;
          }
          if (this.stars >= 5 && this.roadblocks.length < 2 && roadNodes && roadNodes.length) this.placeRoadblock(player, roadNodes);
          for (const u of this.units) {
            const to = V.sub(player.pos, u.body.pos);
            const d = V.len(to) || 1;
            const dir = V.scale(to, 1 / d);
            let speed = u.mode === "pit" ? 16 : 10;
            if (u.mode === "block") {
              speed = 0;
            }
            let aim = dir;
            if (u.mode === "pit" && d > 4) {
              const lead = V.add(player.pos, V.scale(player.vel, 0.5));
              aim = V.norm(V.sub(lead, u.body.pos));
              if (d < 6) {
                this.stats.pits += dt;
                speed = 18;
              }
            }
            u.body.vel.x += (aim.x * speed - u.body.vel.x) * Math.min(1, 3 * dt);
            u.body.vel.z += (aim.z * speed - u.body.vel.z) * Math.min(1, 3 * dt);
          }
        }
      };
      module.exports = { WantedSystem };
    }
  });

  // shared/gve/atmosphere.cjs
  var require_atmosphere = __commonJS({
    "shared/gve/atmosphere.cjs"(exports, module) {
      "use strict";
      var AtmosphereSystem = class {
        constructor(opts = {}) {
          this.dayLength = opts.dayLength || 480;
          this.t = opts.start != null ? opts.start : 0.3;
          this.weather = "clear";
          this.weatherT = 0;
          this.next = "clear";
          this.blend = 1;
          this.chain = ["clear", "overcast", "rain", "storm", "fog"];
          this.params = { cloud: 0, rain: 0, fog: 0, wind: 2, lightning: 0 };
          this.stats = { cycles: 0, switches: 0, strikes: 0 };
        }
        sunAngle() {
          return this.t * Math.PI * 2 - Math.PI / 2;
        }
        sunElevation() {
          return Math.sin(this.sunAngle());
        }
        sunDir() {
          const a = this.sunAngle();
          return { x: Math.cos(a) * 0.6, y: Math.sin(a), z: Math.cos(a) * 0.4 };
        }
        isNight() {
          return this.sunElevation() < -0.08;
        }
        skyColors() {
          const e = this.sunElevation();
          const day = Math.max(0, Math.min(1, (e + 0.1) * 2));
          const dusk = Math.max(0, 1 - Math.abs(e) * 5) * (e > -0.25 ? 1 : 0);
          return {
            top: { r: 0.05 + day * 0.2 + dusk * 0.25, g: 0.07 + day * 0.42 + dusk * 0.12, b: 0.12 + day * 0.75 },
            horizon: { r: 0.1 + day * 0.55 + dusk * 0.65, g: 0.1 + day * 0.62 + dusk * 0.28, b: 0.14 + day * 0.72 + dusk * 0.1 },
            sun: { r: 1, g: 0.85 - dusk * 0.35, b: 0.6 - dusk * 0.3 }
          };
        }
        setWeather(w) {
          if (w !== this.weather && this.chain.includes(w)) {
            this.next = w;
            this.blend = 0;
            this.stats.switches += 1;
          }
        }
        update(ctx, dt) {
          const prev = this.t;
          this.t = (this.t + dt / this.dayLength) % 1;
          if (this.t < prev) this.stats.cycles += 1;
          if (this.blend < 1) {
            this.blend = Math.min(1, this.blend + dt / 6);
            if (this.blend >= 1) this.weather = this.next;
          }
          const target = {
            clear: { cloud: 0.1, rain: 0, fog: 0.02, wind: 2, lightning: 0 },
            overcast: { cloud: 0.7, rain: 0, fog: 0.1, wind: 4, lightning: 0 },
            rain: { cloud: 0.9, rain: 0.8, fog: 0.2, wind: 6, lightning: 0 },
            storm: { cloud: 1, rain: 1, fog: 0.3, wind: 11, lightning: 1 },
            fog: { cloud: 0.5, rain: 0, fog: 0.85, wind: 1, lightning: 0 }
          }[this.next];
          for (const k of Object.keys(target)) this.params[k] += (target[k] - this.params[k]) * Math.min(1, dt * 0.8);
          if (this.params.lightning > 0.5 && Math.random() < dt * 0.15) this.stats.strikes += 1;
        }
        /** post-process hook: night neon bloom boost */
        bloomBoost() {
          return this.isNight() ? 1.5 : 1;
        }
      };
      module.exports = { AtmosphereSystem };
    }
  });

  // shared/gve/audio.cjs
  var require_audio = __commonJS({
    "shared/gve/audio.cjs"(exports, module) {
      "use strict";
      var { V } = require_physics();
      var STATIONS = [
        { id: "vice-fm", name: "VICE FM", genre: "synthwave", tracks: ["Neon Tide", "Chrome Hearts", "Midnight Interchange"] },
        { id: "iron-soul", name: "IRON SOUL", genre: "funk", tracks: ["Bassline Boulevard", "Velvet Gear"] },
        { id: "reef-radio", name: "REEF RADIO", genre: "pop", tracks: ["Salt & Sun", "Boardwalk Dreams", "Marina Lights"] }
      ];
      var AudioEngine = class {
        constructor(opts = {}) {
          this.listener = { pos: { x: 0, y: 1.6, z: 0 }, quat: { w: 1, x: 0, y: 0, z: 0 }, vel: { x: 0, y: 0, z: 0 } };
          this.sources = [];
          this.maxDist = opts.maxDist || 60;
          this.station = 0;
          this.track = 0;
          this.trackT = 0;
          this.stream = "PLAYING";
          this.online = !!opts.online;
          this.stats = { mixes: 0, switches: 0 };
        }
        addSource(s) {
          const src = { vel: { x: 0, y: 0, z: 0 }, volume: 1, radius: 2, loop: true, ...s };
          this.sources.push(src);
          return src;
        }
        attenuation(dist, radius) {
          if (dist <= radius) return 1;
          return Math.max(0, 1 - (dist - radius) / (this.maxDist - radius)) ** 1.6;
        }
        pan(srcPos) {
          const q = this.listener.quat;
          const right = { x: 1 - 2 * (q.y * q.y + q.z * q.z), y: 2 * (q.x * q.y + q.w * q.z), z: 2 * (q.x * q.z - q.w * q.y) };
          const d = V.norm(V.sub(srcPos, this.listener.pos));
          return Math.max(-1, Math.min(1, V.dot(d, { x: right.x, y: 0, z: right.z })));
        }
        doppler(src) {
          const d = V.norm(V.sub(src.pos, this.listener.pos));
          const rel = V.sub(src.vel, this.listener.vel);
          const radial = V.dot(rel, d);
          return 1 + radial * 0.012;
        }
        mix() {
          this.stats.mixes += 1;
          return this.sources.map((s) => {
            const dist = V.len(V.sub(s.pos, this.listener.pos));
            return { id: s.id, gain: this.attenuation(dist, s.radius) * s.volume, pan: this.pan(s.pos), pitch: this.doppler(s) };
          }).filter((c) => c.gain > 1e-3);
        }
        enginePitch(rpm) {
          return 0.6 + Math.min(1.6, rpm / 6e3);
        }
        radio(dt) {
          if (!this.online && this.stream === "BUFFERING") this.stream = "STALLED";
          this.trackT += dt;
          if (this.trackT > 30) {
            this.trackT = 0;
            this.track = (this.track + 1) % STATIONS[this.station].tracks.length;
          }
          return { station: STATIONS[this.station], track: STATIONS[this.station].tracks[this.track], stream: this.stream };
        }
        nextStation() {
          this.station = (this.station + 1) % STATIONS.length;
          this.track = 0;
          this.stats.switches += 1;
          if (!this.online) this.stream = "STALLED";
          return STATIONS[this.station];
        }
        update(ctx, dt) {
          this.radio(dt);
        }
      };
      module.exports = { AudioEngine, STATIONS };
    }
  });

  // shared/gve/ui.cjs
  var require_ui = __commonJS({
    "shared/gve/ui.cjs"(exports, module) {
      "use strict";
      var UISystem = class {
        constructor(opts = {}) {
          this.w = opts.w || 1280;
          this.h = opts.h || 720;
          this.safe = opts.safe || 0.035;
          this.health = 100;
          this.armour = 0;
          this.stars = 0;
          this.wheel = { slots: ["FISTS", "PISTOL", "SMG", "ASSAULT RIFLE"], active: 1, open: false };
          this.messages = [];
          this.blips = [];
          this.map = { zoom: 1, radius: 90, cx: 0.12, cy: 0.86 };
          this.stats = { frames: 0 };
        }
        resize(w, h) {
          this.w = w;
          this.h = h;
        }
        safeRect() {
          const mx = this.w * this.safe;
          const my = this.h * this.safe;
          return { x: mx, y: my, w: this.w - mx * 2, h: this.h - my * 2 };
        }
        say(text, kind = "info", ttl = 4) {
          this.messages.push({ text, kind, ttl });
          if (this.messages.length > 6) this.messages.shift();
        }
        addBlip(b) {
          this.blips.push(b);
          return b;
        }
        /** world (x,z) -> minimap pixel, rotated by camera yaw, clamped to circle */
        worldToMap(x, z, player, yaw) {
          const dx = x - player.x;
          const dz = z - player.z;
          const c = Math.cos(-yaw);
          const s = Math.sin(-yaw);
          let mx = dx * c - dz * s;
          let mz = dx * s + dz * c;
          const dist = Math.hypot(mx, mz);
          const scale = this.map.radius * this.map.zoom / this.map.radius;
          mx *= scale;
          mz *= scale;
          if (dist > this.map.radius) {
            const k = this.map.radius / dist;
            mx *= k;
            mz *= k;
          }
          return { x: this.w * this.map.cx + mx, y: this.h * this.map.cy + mz, edge: dist > this.map.radius };
        }
        update(ctx, dt) {
          this.stats.frames += 1;
          for (let i = this.messages.length - 1; i >= 0; i -= 1) {
            this.messages[i].ttl -= dt;
            if (this.messages[i].ttl <= 0) this.messages.splice(i, 1);
          }
        }
        hud() {
          return {
            health: this.health,
            armour: this.armour,
            stars: this.stars,
            weapon: this.wheel.slots[this.wheel.active],
            messages: this.messages.map((m) => m.text),
            safe: this.safeRect()
          };
        }
      };
      module.exports = { UISystem };
    }
  });

  // shared/gve/vicecity.cjs
  var require_vicecity = __commonJS({
    "shared/gve/vicecity.cjs"(exports, module) {
      "use strict";
      var WORLD = 1560;
      var ROAD_EVERY = 260;
      var ROAD_OFF = 120;
      var ZONES = [
        { id: "gym", name: "IRON BODY GYM", x: 420, z: 632, w: 440, h: 64, asset: "gym" },
        { id: "hospital", name: "VICE GENERAL HOSPITAL", x: 180, z: 916, w: 200, h: 80, asset: "hospital" },
        { id: "beach", name: "VICE BEACH", x: 880, z: 0, w: 680, h: 1560, asset: "palm" },
        { id: "shops", name: "BOARDWALK SHOPS", x: 820, z: 300, w: 60, h: 900, asset: "shop" },
        { id: "downtown", name: "DOWNTOWN", x: 120, z: 120, w: 600, h: 400, asset: "tower" }
      ];
      function hash2(a, b, i) {
        let h = a * 374761393 + b * 668265263 + i * 1274126177 | 0;
        h = (h ^ h >> 13) * 1103515245 | 0;
        h = (h ^ h >> 16) >>> 0;
        return h / 4294967295;
      }
      function roadNodes() {
        const nodes = [];
        const n = Math.floor((WORLD - ROAD_OFF) / ROAD_EVERY);
        for (let iz = 0; iz <= n; iz += 1) for (let ix = 0; ix <= n; ix += 1) {
          nodes.push({ x: ROAD_OFF + ix * ROAD_EVERY, z: ROAD_OFF + iz * ROAD_EVERY, ix, iz });
        }
        return nodes;
      }
      function roadLinks(nodes, n) {
        return nodes.map((nd) => {
          const links = [];
          const r = nodes.find((o) => o.ix === nd.ix + 1 && o.iz === nd.iz);
          const d = nodes.find((o) => o.ix === nd.ix && o.iz === nd.iz + 1);
          if (r) links.push(nodes.indexOf(r));
          if (d) links.push(nodes.indexOf(d));
          return links;
        });
      }
      function buildRoadGraph() {
        const n = Math.floor((WORLD - ROAD_OFF) / ROAD_EVERY);
        const nodes = roadNodes();
        const links = roadLinks(nodes, n);
        for (let i = 0; i < nodes.length; i += 1) for (const j of links[i]) if (!links[j].includes(i)) links[j].push(i);
        return nodes.map((nd, i) => ({ x: nd.x, z: nd.z, links: links[i], light: (nd.ix + nd.iz) % 4 === 0 ? "red" : null }));
      }
      function zoneAt(x, z) {
        return ZONES.find((zn) => x >= zn.x && x <= zn.x + zn.w && z >= zn.z && z <= zn.z + zn.h) || null;
      }
      function onRoad(x, z, half = 26) {
        const mx = ((x - ROAD_OFF) % ROAD_EVERY + ROAD_EVERY) % ROAD_EVERY;
        const mz = ((z - ROAD_OFF) % ROAD_EVERY + ROAD_EVERY) % ROAD_EVERY;
        return mx < half || mx > ROAD_EVERY - half || mz < half || mz > ROAD_EVERY - half;
      }
      function chunkGen(cx, cz) {
        const props = [];
        const x0 = cx * 256;
        const z0 = cz * 256;
        const off = (x, z, dists) => {
          if (!onRoad(x, z)) return [x, z];
          for (const d of dists) {
            for (const s of [1, -1]) {
              if (!onRoad(x + d * s, z)) return [x + d * s, z];
              if (!onRoad(x, z + d * s)) return [x, z + d * s];
            }
          }
          return null;
        };
        for (const zn of ZONES) {
          if (zn.x < x0 + 256 && zn.x + zn.w > x0 && zn.z < z0 + 256 && zn.z + zn.h > z0) {
            const ax = Math.min(Math.max(zn.x + zn.w / 2, x0 + 12), x0 + 244);
            const az = Math.min(Math.max(zn.z + zn.h / 2, z0 + 12), z0 + 244);
            const oa = off(ax, az, [30, 60, 90, 120]);
            if (oa) props.push({ id: `${zn.id}-${cx}-${cz}`, x: oa[0], z: oa[1], asset: zn.asset });
          }
        }
        for (let i = 0; i < 6; i += 1) {
          const x = x0 + hash2(cx, cz, i) * 236 + 10;
          const z = z0 + hash2(cz, cx, i + 40) * 236 + 10;
          const zn = zoneAt(x, z);
          if (zn) {
            const oz = off(x, z, [26, 44, 64, 90]);
            if (oz) props.push({ id: `${zn.id}-${cx}-${cz}-${i}`, x: oz[0], z: oz[1], asset: zn.asset });
            continue;
          }
          if (onRoad(x, z)) {
            const ol = off(x, z, [12, 18, 26]);
            if (ol) props.push({ id: `light-${cx}-${cz}-${i}`, x: ol[0], z: ol[1], asset: "streetlight" });
            continue;
          }
          props.push({ id: `bld-${cx}-${cz}-${i}`, x, z, asset: hash2(cx, cz, i + 9) > 0.7 ? "tower" : "building" });
        }
        return props;
      }
      function attachVice(g, opts = {}) {
        g.vice = { WORLD, ZONES, nodes: buildRoadGraph() };
        g.streamer.generator = chunkGen;
        for (const n of g.vice.nodes) g.traffic.addNode(n.x, n.z, n.links.slice(), n.light);
        const cars = opts.cars != null ? opts.cars : 8;
        for (let i = 0; i < cars; i += 1) {
          const ni = Math.floor(hash2(i, 7, 1) * g.vice.nodes.length);
          const c = g.traffic.spawnCar(ni);
          c.body.pos.x = g.vice.nodes[ni].x;
          c.body.pos.z = g.vice.nodes[ni].z;
        }
        g.player.body.pos = { x: 250, y: 1, z: 250 };
        g.vehicle.chassis.pos = { x: 251.6, y: 0.7, z: 251.6 };
        return g.vice;
      }
      module.exports = { WORLD, ZONES, roadNodes, buildRoadGraph, chunkGen, zoneAt, onRoad, attachVice, hash2 };
    }
  });

  // shared/gve/index.cjs
  var require_gve = __commonJS({
    "shared/gve/index.cjs"(exports, module) {
      "use strict";
      var { Engine } = require_engine();
      var { RenderPipeline } = require_render();
      var { PhysicsSystem, Body, V } = require_physics();
      var { WorldStreamer } = require_streamer();
      var { PlayerController } = require_player();
      var { VehiclePhysics } = require_vehicle();
      var { CombatSystem, WEAPONS } = require_combat();
      var { TrafficAI } = require_traffic();
      var { WantedSystem } = require_wanted();
      var { AtmosphereSystem } = require_atmosphere();
      var { AudioEngine } = require_audio();
      var { UISystem } = require_ui();
      function createGVE(opts = {}) {
        const engine = new Engine(opts);
        const render = new RenderPipeline(opts);
        const physics = new PhysicsSystem(opts);
        const streamer = new WorldStreamer({ generator: opts.generator || ((cx, cz) => [{ id: `prop-${cx}-${cz}`, x: cx * 256 + 40, z: cz * 256 + 60, asset: "propset" }]) });
        const player = new PlayerController(physics, opts);
        const vehicle = new VehiclePhysics(physics, opts);
        const combat = new CombatSystem(physics, engine, opts);
        const traffic = new TrafficAI(physics, opts);
        const wanted = new WantedSystem(physics, traffic, opts);
        const atmo = new AtmosphereSystem(opts);
        const audio = new AudioEngine(opts);
        const ui = new UISystem(opts);
        engine.register({ id: "physics", order: 10, fixed: (ctx, dt) => physics.fixed(ctx, dt) });
        engine.register({ id: "player", order: 20, fixed: (ctx, dt) => player.fixed(ctx, dt), update: (ctx, dt) => player.update(ctx, dt) });
        engine.register({ id: "vehicle", order: 30, fixed: (ctx, dt) => vehicle.fixed(ctx, dt), update: (ctx, dt) => vehicle.update(ctx, dt) });
        engine.register({ id: "streamer", order: 40, update: (ctx, dt) => streamer.update(ctx, dt, player.body.pos) });
        engine.register({ id: "combat", order: 50, update: (ctx, dt) => combat.update(ctx, dt) });
        engine.register({ id: "traffic", order: 60, update: (ctx, dt) => traffic.update(ctx, dt) });
        engine.register({ id: "wanted", order: 70, update: (ctx, dt) => wanted.update(ctx, dt, player.body, traffic.nodes) });
        engine.register({ id: "atmosphere", order: 80, update: (ctx, dt) => atmo.update(ctx, dt) });
        engine.register({ id: "audio", order: 90, update: (ctx, dt) => {
          audio.listener.pos = player.camPos || player.body.pos;
          audio.update(ctx, dt);
        } });
        engine.register({ id: "ui", order: 100, update: (ctx, dt) => {
          ui.stars = wanted.stars;
          ui.update(ctx, dt);
        } });
        engine.register({ id: "render", order: 110, update: () => render.present(1 + traffic.cars.length) });
        engine.setState("PLAY");
        return { engine, render, physics, streamer, player, vehicle, combat, traffic, wanted, atmo, audio, ui, V, WEAPONS };
      }
      function createViceGVE(opts = {}) {
        const g = createGVE(opts);
        require_vicecity().attachVice(g, opts);
        return g;
      }
      module.exports = { createGVE, createViceGVE, Engine, RenderPipeline, PhysicsSystem, Body, WorldStreamer, PlayerController, VehiclePhysics, CombatSystem, TrafficAI, WantedSystem, AtmosphereSystem, AudioEngine, UISystem, WEAPONS, V };
    }
  });

  // shared/gamekit/engine3d.js
  var require_engine3d = __commonJS({
    "shared/gamekit/engine3d.js"() {
      "use strict";
      (function(global) {
        "use strict";
        const ident = () => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
        function mul(a, b) {
          const o = new Array(16);
          for (let r = 0; r < 4; r += 1) {
            for (let c = 0; c < 4; c += 1) {
              o[r * 4 + c] = a[r * 4] * b[c] + a[r * 4 + 1] * b[4 + c] + a[r * 4 + 2] * b[8 + c] + a[r * 4 + 3] * b[12 + c];
            }
          }
          return o;
        }
        function translation(x, y, z) {
          const m = ident();
          m[3] = x;
          m[7] = y;
          m[11] = z;
          return m;
        }
        function rotX(a) {
          const c = Math.cos(a);
          const s = Math.sin(a);
          const m = ident();
          m[5] = c;
          m[6] = -s;
          m[9] = s;
          m[10] = c;
          return m;
        }
        function rotY(a) {
          const c = Math.cos(a);
          const s = Math.sin(a);
          const m = ident();
          m[0] = c;
          m[2] = s;
          m[8] = -s;
          m[10] = c;
          return m;
        }
        function rotZ(a) {
          const c = Math.cos(a);
          const s = Math.sin(a);
          const m = ident();
          m[0] = c;
          m[1] = -s;
          m[4] = s;
          m[5] = c;
          return m;
        }
        function perspective(fovDeg, aspect, near, far) {
          const f = 1 / Math.tan(fovDeg * Math.PI / 180 / 2);
          const m = new Array(16).fill(0);
          m[0] = f / aspect;
          m[5] = f;
          m[10] = (far + near) / (near - far);
          m[11] = 2 * far * near / (near - far);
          m[14] = -1;
          return m;
        }
        function transformPoint(m, v) {
          return [
            m[0] * v[0] + m[1] * v[1] + m[2] * v[2] + m[3],
            m[4] * v[0] + m[5] * v[1] + m[6] * v[2] + m[7],
            m[8] * v[0] + m[9] * v[1] + m[10] * v[2] + m[11],
            m[12] * v[0] + m[13] * v[1] + m[14] * v[2] + m[15]
          ];
        }
        const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
        const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
        const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
        function norm(a) {
          const l = Math.hypot(a[0], a[1], a[2]) || 1;
          return [a[0] / l, a[1] / l, a[2] / l];
        }
        function viewMatrix(camera) {
          return mul(
            mul(rotX(camera.pitch || 0), rotY(camera.yaw || 0)),
            translation(-camera.pos[0], -camera.pos[1], -camera.pos[2])
          );
        }
        function projectPoint(camera, p) {
          const v = transformPoint(viewMatrix(camera), p);
          if (v[2] > -camera.near) return null;
          const f = 1 / Math.tan(camera.fov * Math.PI / 180 / 2);
          const depth = -v[2];
          const sx = f / camera.aspect * (v[0] / depth);
          const sy = f * (v[1] / depth);
          if (sx < -1.6 || sx > 1.6 || sy < -1.6 || sy > 1.6) return null;
          return { x: (sx * 0.5 + 0.5) * camera.width, y: (0.5 - sy * 0.5) * camera.height, depth };
        }
        function boxFaces(x0, y0, z0, w, h, d, base) {
          const x1 = x0 + w;
          const y1 = y0 + h;
          const z1 = z0 + d;
          return [
            { verts: [[x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0]], color: Math.min(1, base * 1.14) },
            // top (+y)
            { verts: [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]], color: base },
            // front (+z)
            { verts: [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]], color: base * 0.82 },
            // back (-z)
            { verts: [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]], color: base * 0.9 },
            // right (+x)
            { verts: [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]], color: base * 0.74 }
            // left (-x)
          ];
        }
        function groundFace(x0, z0, s, color) {
          return { verts: [[x0, 0, z0 + s], [x0 + s, 0, z0 + s], [x0 + s, 0, z0], [x0, 0, z0]], color };
        }
        function rotateFaceY(face, cx, cz, ang) {
          const c = Math.cos(ang);
          const s = Math.sin(ang);
          return {
            color: face.color,
            verts: face.verts.map((v) => {
              const dx = v[0] - cx;
              const dz = v[2] - cz;
              return [cx + dx * c - dz * s, v[1], cz + dx * s + dz * c];
            })
          };
        }
        function renderScene(ctx, opts) {
          const camera = opts.camera;
          const faces = opts.faces || [];
          const light = norm(opts.light || [-0.45, 0.82, -0.38]);
          const ambient = opts.ambient === void 0 ? 0.34 : opts.ambient;
          const diffuse = opts.diffuse === void 0 ? 0.82 : opts.diffuse;
          const fogNear = opts.fogNear === void 0 ? 220 : opts.fogNear;
          const fogFar = opts.fogFar === void 0 ? 950 : opts.fogFar;
          const fogColor = opts.fogColor || [11, 11, 11];
          const view = viewMatrix(camera);
          const f = 1 / Math.tan(camera.fov * Math.PI / 180 / 2);
          const drawList = [];
          let culled = 0;
          for (const face of faces) {
            const vs = face.verts;
            const n = norm(cross(sub(vs[1], vs[0]), sub(vs[2], vs[0])));
            const center = [
              vs.reduce((a, v) => a + v[0], 0) / vs.length,
              vs.reduce((a, v) => a + v[1], 0) / vs.length,
              vs.reduce((a, v) => a + v[2], 0) / vs.length
            ];
            const toCam = sub(camera.pos, center);
            if (dot(n, toCam) <= 0) {
              culled += 1;
              continue;
            }
            const dist = Math.hypot(toCam[0], toCam[1], toCam[2]);
            if (dist > fogFar * 1.25) {
              culled += 1;
              continue;
            }
            const pts = [];
            let depthSum = 0;
            let bad = false;
            for (const v of vs) {
              const t = transformPoint(view, v);
              if (t[2] > -camera.near) {
                bad = true;
                break;
              }
              const depth = -t[2];
              depthSum += depth;
              const sx = f / camera.aspect * (t[0] / depth);
              const sy = f * (t[1] / depth);
              pts.push([(sx * 0.5 + 0.5) * camera.width, (0.5 - sy * 0.5) * camera.height]);
            }
            if (bad) {
              culled += 1;
              continue;
            }
            const lam = Math.max(0, dot(n, light));
            let shade = (face.color === void 0 ? 0.6 : face.color) * (ambient + diffuse * lam);
            const fogT = Math.min(1, Math.max(0, (dist - fogNear) / Math.max(1, fogFar - fogNear)));
            const r = Math.round(Math.min(1, shade) * 255 * (1 - fogT) + fogColor[0] * fogT);
            const gg = Math.round(Math.min(1, shade) * 255 * (1 - fogT) + fogColor[1] * fogT);
            const b = Math.round(Math.min(1, shade) * 255 * (1 - fogT) + fogColor[2] * fogT);
            const wire = face.wire !== void 0 ? face.wire : opts.wire || 0;
            drawList.push({ pts, depth: depthSum / pts.length, fill: `rgb(${r},${gg},${b})`, wire });
          }
          drawList.sort((a, b) => b.depth - a.depth);
          for (const d of drawList) {
            ctx.beginPath();
            ctx.moveTo(d.pts[0][0], d.pts[0][1]);
            for (let i = 1; i < d.pts.length; i += 1) ctx.lineTo(d.pts[i][0], d.pts[i][1]);
            ctx.closePath();
            ctx.fillStyle = d.fill;
            ctx.fill();
            ctx.strokeStyle = d.fill;
            ctx.lineWidth = 1;
            ctx.stroke();
            if (d.wire) {
              ctx.strokeStyle = `rgba(245,244,240,${d.wire})`;
              ctx.stroke();
            }
          }
          return { drawn: drawList.length, culled };
        }
        function waveY(x, z, time) {
          return Math.sin(x * 0.045 + time * 1.7) * 0.62 + Math.sin(z * 0.06 - time * 1.3) * 0.44 + Math.sin((x + z) * 0.025 + time * 2.3) * 0.34;
        }
        function waterMesh(x0, z0, w, d, segs, time, base, wire) {
          const faces = [];
          const sw = w / segs;
          const sd = d / segs;
          const o = base && typeof base === "object" ? base : { base, wire };
          const b = o.base === void 0 ? 0.26 : o.base;
          const amp = o.amp === void 0 ? 1 : o.amp;
          const wireA = o.wire === void 0 ? 0.12 : o.wire;
          for (let i = 0; i < segs; i += 1) {
            for (let j = 0; j < segs; j += 1) {
              const x = x0 + i * sw;
              const z = z0 + j * sd;
              const y00 = waveY(x, z, time) * amp;
              const y10 = waveY(x + sw, z, time) * amp;
              const y11 = waveY(x + sw, z + sd, time) * amp;
              const y01 = waveY(x, z + sd, time) * amp;
              const tilt = (y00 + y01) / 2 - (y10 + y11) / 2;
              const spec = Math.max(0, tilt) * 0.55;
              faces.push({
                verts: [[x, y00, z + sd], [x + sw, y10, z + sd], [x + sw, y11, z], [x, y01, z]],
                color: Math.min(1, b + spec * amp),
                wire: wireA
              });
            }
          }
          return faces;
        }
        function postFX(ctx, W, H, o) {
          o = o || {};
          const frame = o.frame || 0;
          if (o.vignette) {
            const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.38, W / 2, H / 2, Math.max(W, H) * 0.72);
            g.addColorStop(0, "rgba(0,0,0,0)");
            g.addColorStop(1, `rgba(0,0,0,${o.vignette})`);
            ctx.fillStyle = g;
            ctx.fillRect(0, 0, W, H);
          }
          if (o.tint) {
            ctx.fillStyle = o.tint;
            ctx.fillRect(0, 0, W, H);
          }
          if (o.scanlines) {
            ctx.fillStyle = `rgba(0,0,0,${o.scanlines})`;
            for (let y = 0; y < H; y += 3) ctx.fillRect(0, y, W, 1);
          }
          if (o.grain) {
            ctx.fillStyle = "rgba(245,244,240,.05)";
            for (let i = 0; i < o.grain; i += 1) {
              ctx.fillRect((i * 7919 + frame * 613) % W, (i * 104729 + frame * 1571) % H, 1, 1);
            }
          }
        }
        function newSlosh(k, c) {
          return { x: 0, v: 0, k: k === void 0 ? 42 : k, c: c === void 0 ? 4.5 : c };
        }
        function stepSlosh(sl, accel, dt) {
          sl.v += (-sl.k * sl.x - sl.c * sl.v + accel) * dt;
          sl.x += sl.v * dt;
          if (sl.x > 1.2) {
            sl.x = 1.2;
            sl.v *= -0.35;
          }
          if (sl.x < -1.2) {
            sl.x = -1.2;
            sl.v *= -0.35;
          }
          return sl;
        }
        function spawnRipple(list, x, z, strength) {
          if (!list) return;
          if (list.length > 44) list.shift();
          list.push({ x, z, r: 4, vr: 34 + (strength || 0.5) * 60, a: 0.34 + (strength || 0.5) * 0.4 });
        }
        function stepRipples(list, dt) {
          for (let i = list.length - 1; i >= 0; i -= 1) {
            const r = list[i];
            r.r += r.vr * dt;
            r.a -= 0.5 * dt;
            if (r.a <= 0) list.splice(i, 1);
          }
          return list;
        }
        global.GameKit3D = {
          M4: { ident, mul, translation, rotX, rotY, rotZ, perspective, transformPoint },
          vec: { sub, cross, dot, norm },
          viewMatrix,
          projectPoint,
          renderScene,
          boxFaces,
          groundFace,
          rotateFaceY,
          waveY,
          waterMesh,
          postFX,
          newSlosh,
          stepSlosh,
          spawnRipple,
          stepRipples
        };
      })(typeof window !== "undefined" ? window : globalThis);
    }
  });

  // shared/gve/render3d.cjs
  var require_render3d = __commonJS({
    "shared/gve/render3d.cjs"(exports, module) {
      "use strict";
      var vice = require_vicecity();
      function loadGK() {
        if (globalThis.GameKit3D) return globalThis.GameKit3D;
        require_engine3d();
        return globalThis.GameKit3D || null;
      }
      function idHash(s) {
        let h = 2166136261;
        for (let i = 0; i < s.length; i += 1) {
          h ^= s.charCodeAt(i);
          h = Math.imul(h, 16777619);
        }
        return (h >>> 0) % 1e3 / 1e3;
      }
      var ASSET_SIZE = {
        tower: { w: [26, 44], h: [70, 140] },
        building: { w: [16, 30], h: [22, 55] },
        gym: { w: [30, 40], h: [14, 18] },
        hospital: { w: [28, 36], h: [24, 30] },
        shop: { w: [12, 18], h: [8, 14] },
        palm: { w: [1.2, 1.6], h: [10, 14] },
        streetlight: { w: [0.5, 0.7], h: [8, 9.5] }
      };
      function chaseUpdate(cam, tgt, fwd, dt, opts = {}) {
        const dist = opts.dist === void 0 ? 12 : opts.dist;
        const height = opts.height === void 0 ? 5 : opts.height;
        const pitch = opts.pitch === void 0 ? -0.22 : opts.pitch;
        const turn = opts.turn === void 0 ? 5 : opts.turn;
        const wantYaw = Math.atan2(-(fwd.x || 0), -(fwd.z || 0));
        let d = wantYaw - cam.yaw;
        while (d > Math.PI) d -= Math.PI * 2;
        while (d < -Math.PI) d += Math.PI * 2;
        const k = Math.min(1, turn * (dt || 0.016));
        cam.yaw += d * k;
        cam.pitch += (pitch - cam.pitch) * k;
        const fx = -Math.sin(cam.yaw);
        const fz = -Math.cos(cam.yaw);
        cam.pos[0] = tgt.x - fx * dist;
        cam.pos[1] = (tgt.y || 0) + height;
        cam.pos[2] = tgt.z - fz * dist;
        cam.fov = opts.fov === void 0 ? 68 : opts.fov;
        return cam;
      }
      function buildFaces(g, camPos, K3) {
        const faces = [];
        const inRange = (x, z, r) => Math.hypot(x - camPos[0], z - camPos[2]) < r;
        const night = g.atmo.isNight();
        for (let gx = -1; gx <= 3; gx += 1) {
          for (let gz = -1; gz <= 3; gz += 1) {
            const x0 = gx * 520;
            const z0 = gz * 520;
            if (!inRange(x0 + 260, z0 + 260, 1600)) continue;
            faces.push(K3.groundFace(x0, z0, 520, night ? 0.1 : 0.16));
          }
        }
        const ZC = { gym: 0.3, hospital: 0.34, beach: 0.4, shops: 0.3, downtown: 0.26 };
        for (const zn of vice.ZONES) {
          if (!inRange(zn.x + zn.w / 2, zn.z + zn.h / 2, 1400)) continue;
          const y = 0.12;
          const x1 = zn.x + zn.w;
          const z1 = zn.z + zn.h;
          faces.push({ verts: [[zn.x, y, z1], [x1, y, z1], [x1, y, zn.z], [zn.x, y, zn.z]], color: ZC[zn.id] || 0.3 });
        }
        const nodes = g.vice.nodes;
        for (let i = 0; i < nodes.length; i += 1) {
          const n = nodes[i];
          if (inRange(n.x, n.z, 900)) faces.push(...K3.boxFaces(n.x - 9, 0.05, n.z - 9, 18, 0.3, 18, night ? 0.14 : 0.2));
          for (const j of n.links) {
            if (j <= i) continue;
            const o = nodes[j];
            const mx = (n.x + o.x) / 2;
            const mz = (n.z + o.z) / 2;
            if (!inRange(mx, mz, 900)) continue;
            const dx = Math.abs(o.x - n.x);
            const dz = Math.abs(o.z - n.z);
            if (dx >= dz) faces.push(...K3.boxFaces(Math.min(n.x, o.x) - 8, 0.05, n.z - 8, dx + 16, 0.3, 16, night ? 0.13 : 0.19));
            else faces.push(...K3.boxFaces(n.x - 8, 0.05, Math.min(n.z, o.z) - 8, 16, 0.3, dz + 16, night ? 0.13 : 0.19));
          }
          if (n.light) {
            if (inRange(n.x, n.z, 700)) faces.push(...K3.boxFaces(n.x + 7, 0.3, n.z + 7, 0.7, 7, 0.7, 0.55));
          }
        }
        for (const ch of g.streamer.chunks.values()) {
          for (const p of ch.props) {
            if (!inRange(p.x, p.z, 800)) continue;
            const a = ASSET_SIZE[p.asset] || ASSET_SIZE.building;
            const t = idHash(p.id || `${p.x}:${p.z}`);
            const w = a.w[0] + (a.w[1] - a.w[0]) * t;
            const h = a.h[0] + (a.h[1] - a.h[0]) * idHash(`${p.id}h`);
            faces.push(...K3.boxFaces(p.x - w / 2, 0.2, p.z - w / 2, w, h, w, 0.42 + t * 0.4));
          }
        }
        const carBox = (x, y, z, ang, base) => {
          if (!inRange(x, z, 700)) return;
          for (const f of K3.boxFaces(x - 2.3, y, z - 1.1, 4.6, 1.4, 2.2, base)) faces.push(K3.rotateFaceY(f, x, z, ang));
        };
        for (const c of g.traffic.cars) {
          const p = c.body.pos;
          const nx = nodes[c.next] || nodes[c.node] || p;
          const ang = Math.atan2(nx.z - p.z, nx.x - p.x);
          carBox(p.x, p.y + 0.2, p.z, ang, c.panic > 0 ? 0.95 : 0.72);
        }
        for (const u of g.wanted.units) {
          const p = u.body.pos;
          const v = u.body.vel || { x: 0, z: 1 };
          carBox(p.x, p.y + 0.2, p.z, Math.atan2(v.z, v.x), g.wanted.stars >= 3 ? 0.98 : 0.6);
        }
        if (g.vehicle.enterState !== "out") {
          const p = g.vehicle.chassis.pos;
          carBox(p.x, p.y, p.z, Math.atan2(Math.cos(g.vehicle.heading), Math.sin(g.vehicle.heading)), 0.92);
        }
        if (g.vehicle.enterState !== "in") {
          const p = g.player.body.pos;
          faces.push(...K3.boxFaces(p.x - 0.45, p.y, p.z - 0.45, 0.9, 1.8, 0.9, 0.95));
        }
        return faces;
      }
      function createDraw3D(opts = {}) {
        const cam = { pos: [0, 5, 0], yaw: 0, pitch: -0.22, fov: 68 };
        let seeded = false;
        return function draw3d(play, g, canvas, ctx) {
          const K3 = loadGK();
          const W = canvas.width;
          const H = canvas.height;
          if (!K3) {
            ctx.fillStyle = "#fff";
            ctx.fillText("engine3d.js missing", W / 2, H / 2);
            return { drawn: 0, faces: 0 };
          }
          const inVeh = g.vehicle.enterState === "in";
          const tgt = inVeh ? g.vehicle.chassis.pos : g.player.body.pos;
          const fwd = inVeh ? { x: Math.sin(g.vehicle.heading), z: Math.cos(g.vehicle.heading) } : g.player.forward();
          if (!seeded) {
            cam.yaw = Math.atan2(-fwd.x, -fwd.z);
            seeded = true;
          }
          chaseUpdate(cam, tgt, fwd, play.lastDt === void 0 ? 0.016 : play.lastDt, {
            dist: inVeh ? 13 : 9,
            height: inVeh ? 5.4 : 4.2,
            pitch: inVeh ? -0.2 : -0.26
          });
          const night = g.atmo.isNight();
          ctx.fillStyle = night ? "#07070c" : "#101418";
          ctx.fillRect(0, 0, W, H);
          const camera = {
            pos: cam.pos,
            yaw: cam.yaw,
            pitch: cam.pitch,
            fov: cam.fov,
            aspect: W / H,
            near: 0.4,
            far: 2400,
            width: W,
            height: H
          };
          const faces = buildFaces(g, cam.pos, K3);
          const res = K3.renderScene(ctx, {
            camera,
            faces,
            light: [-0.45, 0.82, -0.38],
            ambient: night ? 0.16 : 0.34,
            fogNear: 200,
            fogFar: 950,
            fogColor: night ? [7, 7, 12] : [16, 20, 24]
          });
          if (g.atmo.params.rain > 0.3) {
            ctx.strokeStyle = "rgba(160,190,255,0.35)";
            for (let i = 0; i < 50; i += 1) {
              const rx = (i * 97 + play.draws * 13) % W;
              const ry = (i * 57 + play.draws * 29) % H;
              ctx.beginPath();
              ctx.moveTo(rx, ry);
              ctx.lineTo(rx - 3, ry + 9);
              ctx.stroke();
            }
          }
          const spd = inVeh ? g.vehicle.speed() : Math.hypot(g.player.body.vel.x, g.player.body.vel.z);
          ctx.fillStyle = "#f4f3ef";
          ctx.font = "12px monospace";
          ctx.fillText(`GVE VICE CITY 3D  ${night ? "NIGHT" : "DAY"} ${g.atmo.weather.toUpperCase()}  stars:${"*".repeat(g.wanted.stars)}  speed:${spd.toFixed(1)}  chunks:${g.streamer.chunks.size}  faces:${res.drawn}/${faces.length}  ${inVeh ? "DRIVING (F=exit)" : "ON FOOT (F=enter car, SPACE=shoot)"}${play.paused ? "  PAUSED" : ""}`, 10, 18);
          return { drawn: res.drawn, culled: res.culled, faces: faces.length, cam: { pos: cam.pos.slice(), yaw: cam.yaw, pitch: cam.pitch } };
        };
      }
      module.exports = { loadGK, idHash, chaseUpdate, buildFaces, createDraw3D };
    }
  });

  // shared/gve/browser.cjs
  var require_browser = __commonJS({
    "shared/gve/browser.cjs"(exports, module) {
      var { createGVE } = require_gve();
      var vice = require_vicecity();
      var render3d = require_render3d();
      function createPlay(deps = {}) {
        const canvas = deps.canvas || null;
        const ctx = canvas && canvas.getContext ? canvas.getContext("2d") : null;
        const g = createGVE({});
        vice.attachVice(g, { cars: 8 });
        const keys = deps.keys || /* @__PURE__ */ new Set();
        const mode3d = deps.mode === "3d" || !!deps.mode3d;
        const api = {
          g,
          keys,
          draws: 0,
          paused: false,
          time: 0,
          lastDt: 0.016,
          mode: mode3d ? "3d" : "2d",
          draw3d: mode3d ? render3d.createDraw3D() : null,
          frame3d: null,
          step(dt) {
            if (keys.has("p")) {
              this.paused = !this.paused;
              keys.delete("p");
            }
            if (!this.paused) {
              const inVehicle = g.vehicle.enterState === "in";
              if (inVehicle) {
                g.vehicle.setInput({
                  throttle: keys.has("w") || keys.has("arrowup") ? 1 : 0,
                  brake: keys.has("s") || keys.has("arrowdown") ? 1 : 0,
                  steer: (keys.has("d") || keys.has("arrowright") ? 1 : 0) - (keys.has("a") || keys.has("arrowleft") ? 1 : 0),
                  handbrake: keys.has("shift")
                });
                if (keys.has("f")) {
                  g.vehicle.exit();
                  keys.delete("f");
                }
                if (keys.has(" ")) {
                  const fx = Math.sin(g.vehicle.heading);
                  const fz = Math.cos(g.vehicle.heading);
                  const o = { x: g.vehicle.chassis.pos.x, y: 1, z: g.vehicle.chassis.pos.z };
                  g.combat.fire(o, { x: fx, y: 0, z: fz }, dt);
                  g.wanted.addHeat(0.8);
                  g.traffic.gunshot(o.x, o.z, 40);
                }
              } else {
                g.player.setInput({
                  f: (keys.has("w") || keys.has("arrowup") ? 1 : 0) - (keys.has("s") || keys.has("arrowdown") ? 1 : 0),
                  r: (keys.has("d") || keys.has("arrowright") ? 1 : 0) - (keys.has("a") || keys.has("arrowleft") ? 1 : 0),
                  sprint: keys.has("shift")
                });
                if (keys.has("f") && g.vehicle.tryEnter(g.player.body.pos, true)) keys.delete("f");
                if (keys.has(" ")) {
                  const f = g.player.forward();
                  const o = { x: g.player.body.pos.x, y: 1.2, z: g.player.body.pos.z };
                  g.combat.fire(o, { x: f.x, y: 0, z: f.z }, dt);
                  g.wanted.addHeat(0.8);
                  g.traffic.gunshot(o.x, o.z, 40);
                }
              }
              g.engine.tick(dt, {});
              this.time += dt;
              this.lastDt = dt;
            }
            this.draw();
            return this;
          },
          draw() {
            this.draws += 1;
            if (!ctx || !canvas) return;
            if (this.draw3d) {
              this.frame3d = this.draw3d(this, g, canvas, ctx);
              return;
            }
            const W = canvas.width;
            const H = canvas.height;
            const night = g.atmo.isNight();
            ctx.fillStyle = night ? "#07070c" : "#101418";
            ctx.fillRect(0, 0, W, H);
            const cam = g.vehicle.enterState === "in" ? g.vehicle.chassis.pos : g.player.body.pos;
            const scale = 0.42;
            const px = (x) => W / 2 + (x - cam.x) * scale;
            const pz = (z) => H / 2 + (z - cam.z) * scale;
            ctx.strokeStyle = night ? "#1c2030" : "#2a2f36";
            ctx.lineWidth = 10;
            for (const n of g.vice.nodes) {
              for (const li of n.links) {
                const o = g.vice.nodes[li];
                ctx.beginPath();
                ctx.moveTo(px(n.x), pz(n.z));
                ctx.lineTo(px(o.x), pz(o.z));
                ctx.stroke();
              }
            }
            for (const zn of vice.ZONES) {
              ctx.fillStyle = zn.id === "beach" ? "rgba(220,190,120,0.10)" : zn.id === "hospital" ? "rgba(255,80,80,0.12)" : "rgba(120,200,255,0.07)";
              ctx.fillRect(px(zn.x), pz(zn.z), zn.w * scale, zn.h * scale);
            }
            const dot = (x, z, r, col) => {
              ctx.fillStyle = col;
              ctx.beginPath();
              ctx.arc(px(x), pz(z), r, 0, 7);
              ctx.fill();
            };
            for (const c of g.traffic.cars) dot(c.body.pos.x, c.body.pos.z, 4, "#7f8ea3");
            for (const u of g.wanted.units) dot(u.body.pos.x, u.body.pos.z, 5, g.wanted.stars >= 3 ? "#ff5050" : "#5f7fff");
            if (g.vehicle.enterState !== "out") dot(g.vehicle.chassis.pos.x, g.vehicle.chassis.pos.z, 7, "#f4f3ef");
            dot(g.player.body.pos.x, g.player.body.pos.z, 5, "#ffe08a");
            if (g.atmo.params.rain > 0.3) {
              ctx.strokeStyle = "rgba(160,190,255,0.35)";
              for (let i = 0; i < 40; i += 1) {
                const rx = (i * 97 + this.draws * 13) % W;
                const ry = (i * 57 + this.draws * 29) % H;
                ctx.beginPath();
                ctx.moveTo(rx, ry);
                ctx.lineTo(rx - 3, ry + 9);
                ctx.stroke();
              }
            }
            ctx.fillStyle = "#f4f3ef";
            ctx.font = "12px monospace";
            const spd = g.vehicle.enterState === "in" ? g.vehicle.speed() : Math.hypot(g.player.body.vel.x, g.player.body.vel.z);
            ctx.fillText(`GVE VICE CITY  ${night ? "NIGHT" : "DAY"} ${g.atmo.weather.toUpperCase()}  stars:${"\u2605".repeat(g.wanted.stars)}  speed:${spd.toFixed(1)}  chunks:${g.streamer.chunks.size}  ${g.vehicle.enterState === "in" ? "DRIVING (F=exit)" : "ON FOOT (F=enter car, SPACE=shoot)"}${this.paused ? "  PAUSED" : ""}`, 10, 18);
          },
          state() {
            return {
              time: this.time,
              paused: this.paused,
              draws: this.draws,
              player: { ...g.player.body.pos },
              state: g.player.state,
              vehicle: g.vehicle.enterState,
              speed: g.vehicle.speed(),
              stars: g.wanted.stars,
              weather: g.atmo.weather,
              chunks: g.streamer.chunks.size,
              traffic: g.traffic.cars.length,
              police: g.wanted.units.length
            };
          }
        };
        return api;
      }
      if (typeof window !== "undefined" && typeof document !== "undefined") {
        const canvas = document.getElementById("game");
        const q = typeof window.URLSearchParams === "function" ? new window.URLSearchParams(window.location.search).get("g") : null;
        if (canvas && q !== "gve3d") {
          const play = createPlay({ canvas });
          const keys = play.keys;
          window.addEventListener("keydown", (e) => keys.add(e.key.toLowerCase()));
          window.addEventListener("keyup", (e) => keys.delete(e.key.toLowerCase()));
          let last = 0;
          const loop = (t) => {
            const dt = Math.min(0.05, (t - last) / 1e3 || 0.016);
            last = t;
            play.step(dt);
            window.requestAnimationFrame(loop);
          };
          window.requestAnimationFrame(loop);
          window.GVE_PLAY = play;
        }
      }
      module.exports = { createPlay };
    }
  });
  require_browser();
})();
