/* ============================================================================
 * GameKitGL — asli WebGL2 + GLSL shader renderer (v1.39.0)
 * ----------------------------------------------------------------------------
 * Software rasterizer (engine3d.js) flat-color polygons deta tha. Ye module
 * GPU par asli per-pixel shading karta hai:
 *   - MESH program:   Blinn-Phong specular + lambert + emissive neon + distance fog
 *   - WATER program:  vertex shader mein Gerstner-style waves (analytic normals),
 *                     fragment mein Fresnel + tight sun-specular + glitter
 *   - SKY program:    fullscreen procedural sky — gradient, sun/moon disc + glow,
 *                     4-octave FBM value-noise clouds, night stars
 *   - BLOOM post:     bright-pass -> separable gaussian blur -> additive composite
 * Real z-buffer (depth test), is liye painter-sort ki zaroorat nahi.
 * WebGL2 na mile (purana browser/headless) to create() null deta hai aur game
 * software renderer par gir jata hai — koi crash nahi.
 * ========================================================================== */
(function (global) {
  'use strict';

  /* ---------------- mat4 (column-major, WebGL layout) ---------------- */
  function perspective(fovDeg, aspect, near, far) {
    const f = 1 / Math.tan((fovDeg * Math.PI) / 360);
    const nf = 1 / (near - far);
    return [
      f / aspect, 0, 0, 0,
      0, f, 0, 0,
      0, 0, (far + near) * nf, -1,
      0, 0, 2 * far * near * nf, 0
    ];
  }
  function lookAt(pos, fwd, up) {
    const z = norm3(neg3(fwd));                 // camera -z = view dir
    const x = norm3(cross3(up, z));
    const y = cross3(z, x);
    return [
      x[0], y[0], z[0], 0,
      x[1], y[1], z[1], 0,
      x[2], y[2], z[2], 0,
      -dot3(x, pos), -dot3(y, pos), -dot3(z, pos), 1
    ];
  }
  function mul4(a, b) {
    const o = new Array(16);
    for (let c = 0; c < 4; c += 1) {
      for (let r = 0; r < 4; r += 1) {
        o[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1] + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
      }
    }
    return o;
  }
  const cross3 = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  const dot3 = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  const neg3 = (a) => [-a[0], -a[1], -a[2]];
  const norm3 = (a) => { const l = Math.hypot(a[0], a[1], a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };

  /* ------------------------------- GLSL ------------------------------- */
  const MESH_VS = `#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNorm;
layout(location=2) in vec3 aCol;
layout(location=3) in float aEm;
uniform mat4 uVP;
out vec3 vN; out vec3 vC; out vec3 vW; out float vE;
void main() {
  vW = aPos; vN = aNorm; vC = aCol; vE = aEm;
  gl_Position = uVP * vec4(aPos, 1.0);
}`;
  const MESH_FS = `#version 300 es
precision highp float;
in vec3 vN; in vec3 vC; in vec3 vW; in float vE;
uniform vec3 uCam; uniform vec3 uLight; uniform vec3 uFogCol; uniform vec2 uFog;
uniform float uAmb; uniform float uNight;
out vec4 frag;
void main() {
  vec3 N = normalize(vN);
  vec3 L = normalize(uLight);
  vec3 V = normalize(uCam - vW);
  vec3 H = normalize(L + V);
  float lam = max(dot(N, L), 0.0);
  float spec = pow(max(dot(N, H), 0.0), 48.0) * 0.40 * (1.0 - uNight * 0.7);
  vec3 col = vC * (uAmb + 0.90 * lam) + vec3(spec);
  col += vC * vE * 1.8;                       // emissive: neon strips, beacon
  float d = length(uCam - vW);
  float f = clamp((d - uFog.x) / max(1.0, uFog.y - uFog.x), 0.0, 1.0);
  frag = vec4(mix(col, uFogCol, f), 1.0);
}`;
  const WATER_VS = `#version 300 es
layout(location=0) in vec2 aXZ;
uniform mat4 uVP; uniform float uTime; uniform float uAmp;
out vec3 vW; out vec3 vN;
float w(vec2 p) {
  return sin(p.x * 0.021 + uTime * 1.1) * 0.5
       + sin(p.y * 0.017 - uTime * 0.9) * 0.4
       + sin((p.x + p.y) * 0.008 + uTime * 0.6) * 0.6;
}
void main() {
  float e = 1.5;
  vec2 p = aXZ;
  float h  = w(p) * uAmp;
  float hx = w(p + vec2(e, 0.0)) * uAmp;
  float hz = w(p + vec2(0.0, e)) * uAmp;
  vec3 N = normalize(vec3(-(hx - h) / e, 1.0, -(hz - h) / e));
  vN = N;
  vW = vec3(p.x, h, p.y);
  gl_Position = uVP * vec4(vW, 1.0);
}`;
  const WATER_FS = `#version 300 es
precision highp float;
in vec3 vW; in vec3 vN;
uniform vec3 uCam; uniform vec3 uLight; uniform vec3 uDeep; uniform vec3 uShal;
uniform vec3 uFogCol; uniform vec2 uFog; uniform float uTime;
out vec4 frag;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
void main() {
  vec3 N = normalize(vN);
  vec3 V = normalize(uCam - vW);
  vec3 L = normalize(uLight);
  vec3 H = normalize(L + V);
  float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
  float spec = pow(max(dot(N, H), 0.0), 180.0) * 1.6;
  float glit = step(0.985, hash(floor(vW.xz * 0.7) + floor(uTime * 8.0))) * 0.5;
  vec3 col = mix(uDeep, uShal, 0.35 + 0.30 * sin(vW.x * 0.01 + uTime * 0.4));
  col = mix(col, uFogCol * 0.9 + 0.1, fres * 0.6);
  col += vec3(spec + glit);
  float d = length(uCam - vW);
  float f = clamp((d - uFog.x) / max(1.0, uFog.y - uFog.x), 0.0, 1.0);
  frag = vec4(mix(col, uFogCol, f), 1.0);
}`;
  const SKY_VS = `#version 300 es
uniform vec3 uFwd; uniform vec3 uRight; uniform vec3 uUp;
uniform float uTanH; uniform float uAspect;
out vec3 vDir;
void main() {
  vec2 ndc = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vDir = uFwd + uRight * (ndc.x * 2.0 - 1.0) * uAspect * uTanH
              + uUp    * (ndc.y * 2.0 - 1.0) * uTanH;
  gl_Position = vec4(ndc * 2.0 - 1.0, 1.0, 1.0);
}`;
  const SKY_FS = `#version 300 es
precision highp float;
in vec3 vDir;
uniform float uTime; uniform float uNight; uniform vec3 uSunDir;
uniform vec3 uZen; uniform vec3 uHor; uniform vec3 uFogCol;
out vec4 frag;
float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float a = 0.5, s = 0.0;
  for (int i = 0; i < 4; i += 1) { s += a * noise(p); p *= 2.03; a *= 0.5; }
  return s;
}
void main() {
  vec3 d = normalize(vDir);
  float t = clamp(d.y * 1.6 + 0.25, 0.0, 1.0);
  vec3 col = mix(uHor, uZen, t);
  vec3 sdv = normalize(uSunDir);
  float sd = max(dot(d, sdv), 0.0);
  col += (1.0 - uNight) * vec3(1.0, 0.85, 0.55) * pow(sd, 6.0) * 0.35;
  float disc = smoothstep(0.9985, 0.9995, sd);
  col += disc * mix(vec3(1.0, 0.95, 0.80), vec3(0.90, 0.92, 1.0), uNight) * 1.4;
  if (d.y > 0.015) {
    vec2 cuv = d.xz / (d.y + 0.12) * 1.4 + vec2(uTime * 0.008, 0.0);
    float cl = fbm(cuv);
    float m = smoothstep(0.48, 0.75, cl) * smoothstep(0.015, 0.08, d.y);
    vec3 cc = mix(vec3(0.98), vec3(0.32, 0.26, 0.45), uNight);
    col = mix(col, cc, m * 0.85);
  }
  float stars = step(0.9975, hash(floor(d.xz * 300.0 + d.y * 170.0))) * uNight * step(0.1, d.y);
  col += vec3(stars);
  col = mix(col, uFogCol, 1.0 - smoothstep(-0.05, 0.06, d.y));
  frag = vec4(col, 1.0);
}`;
  const QUAD_VS = `#version 300 es
out vec2 vUv;
void main() {
  vec2 uv = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vUv = uv;
  gl_Position = vec4(uv * 2.0 - 1.0, 0.0, 1.0);
}`;
  const BRIGHT_FS = `#version 300 es
precision highp float;
in vec2 vUv; uniform sampler2D uTex;
out vec4 frag;
void main() {
  vec3 c = texture(uTex, vUv).rgb;
  float l = dot(c, vec3(0.299, 0.587, 0.114));
  frag = vec4(c * smoothstep(0.72, 1.05, l), 1.0);
}`;
  const BLUR_FS = `#version 300 es
precision highp float;
in vec2 vUv; uniform sampler2D uTex; uniform vec2 uDir;
out vec4 frag;
void main() {
  vec3 s = texture(uTex, vUv).rgb * 0.227027;
  s += (texture(uTex, vUv + uDir * 1.3846).rgb + texture(uTex, vUv - uDir * 1.3846).rgb) * 0.3162162;
  s += (texture(uTex, vUv + uDir * 3.2308).rgb + texture(uTex, vUv - uDir * 3.2308).rgb) * 0.0702702;
  frag = vec4(s, 1.0);
}`;
  const COMP_FS = `#version 300 es
precision highp float;
in vec2 vUv; uniform sampler2D uScene; uniform sampler2D uBloom;
out vec4 frag;
void main() {
  vec3 c = texture(uScene, vUv).rgb + texture(uBloom, vUv).rgb * 0.85;
  c = c / (c + vec3(0.55)) * 1.6;              // soft filmic toe — highlight roll-off
  frag = vec4(c, 1.0);
}`;

  /* --------------------------- helper: program --------------------------- */
  function compile(gl, type, src) {
    const sh = gl.createShader(type);
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (gl.getShaderParameter(sh, gl.COMPILE_STATUS) === false) {
      const log = gl.getShaderInfoLog ? gl.getShaderInfoLog(sh) : '';
      gl.deleteShader(sh);
      throw new Error('shader compile failed: ' + log);
    }
    return sh;
  }
  function program(gl, vs, fs) {
    const p = gl.createProgram();
    gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs));
    gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (gl.getProgramParameter(p, gl.LINK_STATUS) === false) {
      throw new Error('program link failed: ' + (gl.getProgramInfoLog ? gl.getProgramInfoLog(p) : ''));
    }
    const u = {};
    const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS) || 0;
    for (let i = 0; i < n; i += 1) {
      const info = gl.getActiveUniform(p, i);
      if (info) u[info.name] = gl.getUniformLocation(p, info.name);
    }
    return { p, u };
  }
  function tex2d(gl, w, h) {
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }

  /* ------------------------------- create ------------------------------- */
  function create(engineCanvas, W, H) {
    // Engine ka canvas pehle se 2D context hold karta hai (HUD/text), is liye
    // GL layer apna alag overlay canvas banati hai jo engine canvas ke NEECHE
    // leta hai; engine canvas transparent ho kar HUD upar dikhata hai.
    const doc = (engineCanvas && engineCanvas.ownerDocument) || (typeof document !== 'undefined' ? document : null);
    if (!doc || !doc.createElement) return null;
    const glc = doc.createElement('canvas');
    glc.width = W; glc.height = H;
    if (glc.style) {
      glc.style.cssText = 'position:fixed;z-index:0;pointer-events:none';
    }
    const fit = () => {
      if (!glc.style || !engineCanvas.getBoundingClientRect) return;
      const r = engineCanvas.getBoundingClientRect();
      glc.style.left = (r.left || 0) + 'px';
      glc.style.top = (r.top || 0) + 'px';
      glc.style.width = (r.width || W) + 'px';
      glc.style.height = (r.height || H) + 'px';
    };
    fit();
    if (typeof global.addEventListener === 'function') global.addEventListener('resize', fit);
    const parent = (engineCanvas && engineCanvas.parentNode) || doc.body;
    if (parent) {
      if (engineCanvas && engineCanvas.parentNode && parent.insertBefore) parent.insertBefore(glc, engineCanvas);
      else if (parent.appendChild) parent.appendChild(glc);
    }
    if (engineCanvas && engineCanvas.style) {
      engineCanvas.style.position = 'relative';
      engineCanvas.style.zIndex = '1';
    }
    const gl = glc.getContext('webgl2', { antialias: true, alpha: false });
    if (!gl) return null;

    const mesh = program(gl, MESH_VS, MESH_FS);
    const water = program(gl, WATER_VS, WATER_FS);
    const sky = program(gl, SKY_VS, SKY_FS);
    const bright = program(gl, QUAD_VS, BRIGHT_FS);
    const blur = program(gl, QUAD_VS, BLUR_FS);
    const comp = program(gl, QUAD_VS, COMP_FS);

    // dynamic mesh buffer: pos(3) normal(3) color(3) emissive(1) = 10 floats/vert
    const meshBuf = gl.createBuffer();
    let meshVerts = new Float32Array(64 * 1024);

    // static water grid 48x48 quads over the bay
    const SEG = 48;
    const X0 = -1400, X1 = 1400, Z0 = 240, Z1 = 2840;
    const grid = new Float32Array((SEG + 1) * (SEG + 1) * 2);
    let gi = 0;
    for (let j = 0; j <= SEG; j += 1) {
      for (let i = 0; i <= SEG; i += 1) {
        grid[gi++] = X0 + ((X1 - X0) * i) / SEG;
        grid[gi++] = Z0 + ((Z1 - Z0) * j) / SEG;
      }
    }
    const idx = new Uint16Array(SEG * SEG * 6);
    let ii = 0;
    for (let j = 0; j < SEG; j += 1) {
      for (let i = 0; i < SEG; i += 1) {
        const a = j * (SEG + 1) + i, b = a + 1, c = a + SEG + 1, d = c + 1;
        idx[ii++] = a; idx[ii++] = c; idx[ii++] = b;
        idx[ii++] = b; idx[ii++] = c; idx[ii++] = d;
      }
    }
    const waterBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, waterBuf);
    gl.bufferData(gl.ARRAY_BUFFER, grid, gl.STATIC_DRAW);
    const waterIdx = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, waterIdx);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);

    // FBO chain: scene (full) -> bright (half) -> blur ping-pong (half)
    const sceneTex = tex2d(gl, W, H);
    const depthRb = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, depthRb);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, W, H);
    const sceneFb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, sceneTex, 0);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, depthRb);
    const hw = Math.max(2, W >> 1), hh = Math.max(2, H >> 1);
    const bloomA = tex2d(gl, hw, hh);
    const bloomB = tex2d(gl, hw, hh);
    const fbA = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbA);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, bloomA, 0);
    const fbB = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbB);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, bloomB, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);

    const vao = gl.createVertexArray ? gl.createVertexArray() : null;

    function quad(prog) { gl.useProgram(prog.p); gl.drawArrays(gl.TRIANGLES, 0, 3); }

    /* faces: [{verts:[[x,y,z]x4], color:[r,g,b], e?:number}] */
    function uploadMesh(faces) {
      let need = faces.length * 6 * 10;
      if (meshVerts.length < need) meshVerts = new Float32Array(need);
      let o = 0;
      for (const f of faces) {
        const v = f.verts;
        const ax = v[1][0] - v[0][0], ay = v[1][1] - v[0][1], az = v[1][2] - v[0][2];
        const bx = v[2][0] - v[0][0], by = v[2][1] - v[0][1], bz = v[2][2] - v[0][2];
        let nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        const nl = Math.hypot(nx, ny, nz) || 1;
        nx /= nl; ny /= nl; nz /= nl;
        const col = Array.isArray(f.color) ? f.color : [f.color, f.color, f.color];
        const e = f.e || 0;
        const tri = [0, 1, 2, 0, 2, 3];
        for (let k = 0; k < 6; k += 1) {
          const p = v[tri[k]];
          meshVerts[o++] = p[0]; meshVerts[o++] = p[1]; meshVerts[o++] = p[2];
          meshVerts[o++] = nx; meshVerts[o++] = ny; meshVerts[o++] = nz;
          meshVerts[o++] = col[0]; meshVerts[o++] = col[1]; meshVerts[o++] = col[2];
          meshVerts[o++] = e;
        }
      }
      gl.bindBuffer(gl.ARRAY_BUFFER, meshBuf);
      gl.bufferData(gl.ARRAY_BUFFER, meshVerts.subarray(0, o), gl.DYNAMIC_DRAW);
      return o / 10;
    }

    function render(o) {
      const cam = o.camera;
      const cp = Math.cos(cam.pitch), sp = Math.sin(cam.pitch);
      const fwd = [Math.sin(cam.yaw) * cp, sp, -Math.cos(cam.yaw) * cp];
      const right = norm3(cross3(fwd, [0, 1, 0]));
      const up = cross3(right, fwd);
      const P = perspective(cam.fov, cam.aspect, cam.near, cam.far);
      const V = lookAt(cam.pos, fwd, up);
      const VP = mul4(P, V);
      const night = o.night ? 1 : 0;

      gl.bindFramebuffer(gl.FRAMEBUFFER, sceneFb);
      gl.viewport(0, 0, W, H);
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.clearColor(0, 0, 0, 1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

      // 1) sky (depth write off, depth test off)
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.useProgram(sky.p);
      gl.uniform3fv(sky.u.uFwd, fwd);
      gl.uniform3fv(sky.u.uRight, right);
      gl.uniform3fv(sky.u.uUp, up);
      gl.uniform1f(sky.u.uTanH, Math.tan((cam.fov * Math.PI) / 360));
      gl.uniform1f(sky.u.uAspect, cam.aspect);
      gl.uniform1f(sky.u.uTime, o.time);
      gl.uniform1f(sky.u.uNight, night);
      gl.uniform3fv(sky.u.uSunDir, o.sunDir);
      gl.uniform3fv(sky.u.uZen, o.zenith);
      gl.uniform3fv(sky.u.uHor, o.horizon);
      gl.uniform3fv(sky.u.uFogCol, o.fogColor);
      gl.drawArrays(gl.TRIANGLES, 0, 3);

      // 2) water
      gl.enable(gl.DEPTH_TEST);
      gl.depthMask(true);
      gl.useProgram(water.p);
      gl.uniformMatrix4fv(water.u.uVP, false, VP);
      gl.uniform1f(water.u.uTime, o.time);
      gl.uniform1f(water.u.uAmp, o.night ? 0.5 : 1.0);
      gl.uniform3fv(water.u.uCam, cam.pos);
      gl.uniform3fv(water.u.uLight, o.light);
      gl.uniform3fv(water.u.uDeep, o.night ? [0.01, 0.05, 0.10] : [0.02, 0.28, 0.36]);
      gl.uniform3fv(water.u.uShal, o.night ? [0.05, 0.12, 0.20] : [0.10, 0.62, 0.68]);
      gl.uniform3fv(water.u.uFogCol, o.fogColor);
      gl.uniform2fv(water.u.uFog, o.fog);
      gl.bindBuffer(gl.ARRAY_BUFFER, waterBuf);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, waterIdx);
      gl.drawElements(gl.TRIANGLES, idx.length, gl.UNSIGNED_SHORT, 0);

      // 3) mesh (towers, deck, character, shards, neon)
      const count = uploadMesh(o.faces);
      gl.useProgram(mesh.p);
      gl.uniformMatrix4fv(mesh.u.uVP, false, VP);
      gl.uniform3fv(mesh.u.uCam, cam.pos);
      gl.uniform3fv(mesh.u.uLight, o.light);
      gl.uniform3fv(mesh.u.uFogCol, o.fogColor);
      gl.uniform2fv(mesh.u.uFog, o.fog);
      gl.uniform1f(mesh.u.uAmb, o.night ? 0.24 : 0.52);
      gl.uniform1f(mesh.u.uNight, night);
      gl.bindBuffer(gl.ARRAY_BUFFER, meshBuf);
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 40, 0);
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 40, 12);
      gl.enableVertexAttribArray(2);
      gl.vertexAttribPointer(2, 3, gl.FLOAT, false, 40, 24);
      gl.enableVertexAttribArray(3);
      gl.vertexAttribPointer(3, 1, gl.FLOAT, false, 40, 36);
      gl.drawArrays(gl.TRIANGLES, 0, count);

      // 4) bloom: bright -> blurH -> blurV -> composite
      gl.disable(gl.DEPTH_TEST);
      gl.depthMask(false);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbA);
      gl.viewport(0, 0, hw, hh);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, sceneTex);
      gl.useProgram(bright.p);
      gl.uniform1i(bright.u.uTex, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbB);
      gl.bindTexture(gl.TEXTURE_2D, bloomA);
      gl.useProgram(blur.p);
      gl.uniform1i(blur.u.uTex, 0);
      gl.uniform2f(blur.u.uDir, 1 / hw, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbA);
      gl.bindTexture(gl.TEXTURE_2D, bloomB);
      gl.uniform2f(blur.u.uDir, 0, 1 / hh);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      gl.viewport(0, 0, W, H);
      gl.useProgram(comp.p);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, sceneTex);
      gl.uniform1i(comp.u.uScene, 0);
      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, bloomA);
      gl.uniform1i(comp.u.uBloom, 1);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.activeTexture(gl.TEXTURE0);
      return { drawn: count / 6, gl: true };
    }

    return { render, gl, vao };
  }

  global.GameKitGL = { create, SHADERS: { MESH_VS, MESH_FS, WATER_VS, WATER_FS, SKY_VS, SKY_FS, QUAD_VS, BRIGHT_FS, BLUR_FS, COMP_FS } };
})(typeof window !== 'undefined' ? window : globalThis);
