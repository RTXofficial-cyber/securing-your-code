/**
 * DETAIL CODEX (v1.21.0) — the scalable home for the "100,000 details".
 *
 * The user's point was right: real-game fidelity is a MOUNTAIN of details
 * (car doors that open, fridges whose contents really come out, traffic
 * that yields, pilots in cockpits…). You cannot pour 100k details into a
 * chat — so this codex is the system: every real-world detail gets a
 * catalogued entry with an HONEST impl flag ('done' = actually simulated
 * in the engine right now, 'planned' = catalogued, build pending). Air_you
 * answers from this codex, and every shipping turn flips more entries to
 * 'done'. That is how the mountain gets moved — batch by batch.
 */

const CODEX = {
  car: [
    { id: 'car.doors', name: 'Doors (4) — open/close, hinges, ajar state', real: 'har darwaza hinge par khulta hai, khula darwaza body se bahar swing karta hai', impl: 'done' },
    { id: 'car.trunk', name: 'Trunk (diggi) — open/close, storage', real: 'trunk upar uthta hai, andar space dikhta hai', impl: 'done' },
    { id: 'car.hood', name: 'Hood (bonnet) — open/close, engine bay', real: 'hood khulne par engine block nazar aata hai', impl: 'done' },
    { id: 'car.engine', name: 'Engine — on/off, rpm, temperature', real: 'start par rpm idle ~800, chalne par badhta hai; temp warm-up ke baad ~92°C', impl: 'done' },
    { id: 'car.fuelcap', name: 'Petrol cap — open, refuel, tank level', real: 'cap khole bina petrol nahi bhar sakti; bharte waqt level barhta hai, 100% par auto-stop', impl: 'done' },
    { id: 'car.mirrors', name: 'Side mirrors (2) — mounted on front doors', real: 'mirrors darwazon ke saath move/fold hote hain', impl: 'done' },
    { id: 'car.wheels', name: 'Wheels + tire deformation', real: 'drift/fast par tires compress + skid tracks (GTA-6 detail pack se live)', impl: 'done' },
    { id: 'car.interior', name: 'Interior: seats, dashboard, steering, duct-taped handle', real: 'cabin detail — GTA-6 trailer wala duct-taped door handle tak', impl: 'planned' },
    { id: 'car.lights', name: 'Head/brake lights: filament warm-up vs instant LED', real: 'purane bulbs filament garam hone par fade-in; LED instant; brake par red glow', impl: 'planned' },
    { id: 'car.suspension', name: 'Suspension bounce + chassis lean in corners', real: 'weight shift, cornering lean, bumps par bounce', impl: 'planned' }
  ],
  home: [
    { id: 'home.fridge', name: 'Fridge — open/close, items ALREADY inside', real: 'fridge ke andar bottle/cup/sabzi PEHLE se hoti hain (spawn nahi) — kholo, nikalo, haath mein uthao', impl: 'done' },
    { id: 'home.held', name: 'Held items — haath mein uthao, chale to hilte hain', real: 'bottle ka paani slosh karta hai (spring-damper physics), player ke saath move karta hai', impl: 'done' },
    { id: 'home.drop', name: 'Drop = REAL drop — item girta hai, zameen par tikta hai', real: 'gravity se girta hai, thud sound, wapas uthaya ja sakta hai — gayab nahi hota', impl: 'done' },
    { id: 'home.drink', name: 'Drink from cup/bottle — level girta hai', real: 'ghoont piyo to fill level kam, khaali ho to honest "khaali"', impl: 'done' },
    { id: 'home.kitchen', name: 'Kitchen: stove, sink, utensils, microwave doors', real: 'har appliance ke apne open/close + use states', impl: 'planned' },
    { id: 'home.lights', name: 'Ghar ke lights: switches, warm glow, tube-light flicker', real: 'switch par flicker ke baad start, warm-up', impl: 'planned' }
  ],
  traffic: [
    { id: 'traffic.cars', name: 'Road traffic — lanes, direction, wrapping', real: 'AI cars roads par chalti hain, kinare par wrap, bridge se river cross', impl: 'done' },
    { id: 'traffic.yield', name: 'Cars yield to the player', real: 'player qareeb ho to traffic slow — brake glow ke saath', impl: 'done' },
    { id: 'traffic.brakes', name: 'Brake lights glow when slowing', real: 'slow hote hi peeche red brake faces', impl: 'done' },
    { id: 'traffic.peds', name: 'Crowds cross roads, react to horns/gunfire', real: 'GTA-6 pack: gunfire/speeding car par bhaagte hain (live)', impl: 'done' },
    { id: 'traffic.signals', name: 'Traffic signals + intersection stops', real: 'signals cycle, cars intersection par rukti hain', impl: 'planned' }
  ],
  airport: [
    { id: 'airport.runway', name: 'Runway + centerline markings', real: 'flat strip, dashes, threshold markings', impl: 'done' },
    { id: 'airport.plane', name: 'Plane: parked → takeoff roll → rotate → cruise', real: 'throttle, speed build, rotate speed par lift, phir circling', impl: 'done' },
    { id: 'airport.engine', name: 'Plane engine + spinning propeller', real: 'throttle ke saath prop spin rate; engine ON tab hi takeoff', impl: 'done' },
    { id: 'airport.pilot', name: 'Pilot visible in the cockpit', real: 'cockpit mein pilot ka head+body dikhta hai', impl: 'done' },
    { id: 'airport.heli', name: 'Helicopter: main + tail rotor, hover circle, pilot', real: 'rotor spin, height hold with drift, sheher ke upar circle', impl: 'done' },
    { id: 'airport.landing', name: 'Landing gear + touchdown smoke', real: 'gear retract takeoff ke baad, touchdown par tire smoke', impl: 'planned' }
  ],
  beach: [
    { id: 'beach.umbrellas', name: 'Beach umbrellas + towels', real: 'kinare par umbrellas, towels bichhe', impl: 'done' },
    { id: 'beach.sunbathers', name: 'Sunbathers lying (not standing peds)', real: 'lete hue log — alag pose, bheed se separate', impl: 'done' },
    { id: 'beach.ball', name: 'Beach ball bouncing', real: 'ball hawa mein uchalta, shadow ke saath', impl: 'done' },
    { id: 'beach.sand', name: 'Wet→dry sand gradient + footprints on sand', real: 'GTA-6 pack: paani ke paas geela sand, footprints (live)', impl: 'done' },
    { id: 'beach.waves', name: 'Waves lapping the shoreline foam', real: 'kinare par foam line jo aage-peeche hoti hai', impl: 'planned' }
  ],
  gym: [
    { id: 'gym.zone', name: 'Gym building (open zone) with roof + posts', real: 'alag building jisme log workout karte hain', impl: 'done' },
    { id: 'gym.machines', name: '6 REAL MACHINES: bench, squat rack, pull-up bar, treadmill, deadlift platform, plank mat', real: 'ORGANIZED GYM (v1.24): har machine apni shape + busy animation ke saath; exercise SIRF machine par (G/X) — kahin bhi nahi (live)', impl: 'done' },
    { id: 'gym.claim', name: 'Machines are CLAIMED — busy ped/player, honest "OCCUPIED, wait karo"', real: 'machine ek waqt mein ek user; peds claim karte hain, flee par release (live)', impl: 'done' },
    { id: 'gym.walkoff', name: 'Walking off mid-set = honest ADHOORA set', real: '44 units door = set stop, machine free, reps jitne hue utna XP (live)', impl: 'done' },
    { id: 'gym.treadmill', name: 'Treadmill = TREADMILL RUN cardio (7th exercise)', real: 'belt stripes chalte hain; calves/quads/hamstrings prime (live)', impl: 'done' },
    { id: 'gym.workout', name: 'Peds work out AT machines (bobbing reps, machine animates)', real: 'zone mein aate hi khali machine claim → workout, machine phase chalti', impl: 'done' },
    { id: 'gym.exit', name: 'Workout stops when they leave / panic overrides', real: 'zone se bahar → walk; gunfire → flee (machine instantly free)', impl: 'done' }
  ],
  city: [
    { id: 'city.grid', name: 'City blocks + road corridors', real: 'grid buildings, roads corridors mein (live)', impl: 'done' },
    { id: 'city.river', name: 'River + bridges + bay', real: 'GTA-6 pack: river z 700-900, 2 bridges, bay east (live)', impl: 'done' },
    { id: 'city.weather', name: 'Drifting weather cell: rain, wind, fog, storm HUD', real: 'GTA-6 pack: intensity/wind drift, STORM HUD (live)', impl: 'done' },
    { id: 'city.wildlife', name: 'Alligators, seabirds, dolphins catalogued', real: 'gators + birds live; dolphins bay ke liye planned', impl: 'done' },
    { id: 'city.night', name: 'Night cycle: neon reflections on humid asphalt', real: 'raat ki neon, geeli sadak par reflection', impl: 'planned' }
  ],
  /* BODY & CITY LIFE PACK (v1.23.0) — shipped entries */
  body: [
    { id: 'body.muscles', name: '11-muscle anatomy map (chest…calves)', real: 'har muscle ka apna stretch + fatigue state (live)', impl: 'done' },
    { id: 'body.exercises', name: '7 exercises with real prime movers + stabilizers (machine-bound)', real: 'bench press/squat/pullup/lunge/plank/deadlift/treadmill — har exercise APNI machine par (G/X), kaunsa muscle stretch kaunsa relax (live)', impl: 'done' },
    { id: 'body.eccentric', name: 'Eccentric STRETCH → concentric RELAX cycle', real: 'rep phase ke saath stretch barhti/uttar ti hai — HUD par live bars (live)', impl: 'done' },
    { id: 'body.fatigue', name: 'Fatigue accumulates, slows your reps', real: 'thakan rep speed kam karti hai (1−0.4·avgF) — asli thakan ka asli asar (live)', impl: 'done' },
    { id: 'body.failure', name: 'Muscle failure = honest auto-stop', real: '93% fatigue par exercise RUKTI hai: "MUSCLE FAILURE — REST karo" (live)', impl: 'done' },
    { id: 'body.recovery', name: 'Recovery: rest faster than moving', real: 'fatigue resting 0.075/s, active 0.04/s utarti hai (live)', impl: 'done' },
    { id: 'body.progressive', name: 'Strength ISTA ISTA next level', real: 'XP → level thresholds (level×80), strength +1.5/level — progressive overload, instant nahi (live)', impl: 'done' },
    { id: 'body.ambient', name: 'Ambient load: walk/sprint/swim/carry/shoot/drive', real: 'koi bhi kaam karo — calves/quads/delts/forearms par asli asar (live)', impl: 'done' },
    { id: 'body.hud', name: 'BODY HUD: top-3 muscle stretch/fatigue bars', real: 'LV·STR·XP + ASCII bars har frame (live)', impl: 'done' },
    { id: 'body.soreness', name: 'Soreness after failure', real: 'failure par soreness spike, dheere utarti hai (live)', impl: 'done' }
  ],
  citylife: [
    { id: 'cl.gunshops', name: '2 named GUN SHOPS (ammo $40)', real: 'AMMU-VICE GUNS + BOOMSTICK DEPOT — buy = score se cash katta; broke/full mag = honest (live)', impl: 'done' },
    { id: 'cl.shops', name: '19 NAMED SHOPS — real life ki dukaanein, har ek ka stock + rate + 3D label', real: 'guns, mart, bakery, barber, cafe, pizza, books, mechanic, petrol pump, electronics, jewelry, florist, outfitters, tattoo, laundromat, mobile, hardware, pharmacy (live)', impl: 'done' },
    { id: 'cl.motorway', name: 'VICE MOTORWAY: strip + dashes + 3 bus stops', real: 'wide road, shelters, labels (live)', impl: 'done' },
    { id: 'cl.buses', name: 'Buses with real halt FSM + doors', real: 'run → stop par halt 3.5s (doors khulti) → doors band → run; player ko yield (live)', impl: 'done' },
    { id: 'cl.barges', name: 'River barges with containers + wake', real: 'chalti barges, ripples; tairte player ko hull slam = real damage (live)', impl: 'done' },
    { id: 'cl.oceanship', name: 'Ocean ship past the bay wall (tall mast)', real: 'MV IRONKEEL open-ocean lane par — mast deewar ke upar dikhta (live)', impl: 'done' },
    { id: 'cl.shipyard', name: 'IRONKEEL SHIPYARD: hulls build in real time', real: 'stage 0→100% dheere dheere, ribs dikhti hain, crane ghumta hai (live)', impl: 'done' },
    { id: 'cl.mine', name: 'BLACKVEIN MINE: pit terraces + rail-loop carts', real: 'descending rings, dark entrance, 2 carts loop par chalti (live)', impl: 'done' },
    { id: 'cl.npc-ai', name: 'NPC AI: destinations, queue, chat, sit', real: 'peds shop/gym/beach/wander chunte hain; aapas mein CHAT face-to-face; hospital visitors counter par queue (live)', impl: 'done' },
    { id: 'cl.landmarks', name: '5 named landmark towers', real: 'HARBOR TOWER, MERIDIAN PLAZA, CIVIC CENTER, NORTHGATE TOWER, OLD UNION DEPOT (live)', impl: 'done' }
  ],
  exercises: [
    { id: 'ex.bench', name: 'BENCH PRESS — chest/triceps/delts', real: 'barbell press cycle animation; incline bench alag station (upper chest/delts) (live)', impl: 'done' },
    { id: 'ex.fly', name: 'CHEST FLY MACHINE — arm pads swing', real: 'pads khulte/band hote hain rep ke saath (live)', impl: 'done' },
    { id: 'ex.press', name: 'SHOULDER PRESS RACK — delts/triceps/traps', real: 'dumbbells overhead press animation (live)', impl: 'done' },
    { id: 'ex.curl', name: 'CURL STATION — biceps/forearms', real: 'barbell curl arc (live)', impl: 'done' },
    { id: 'ex.pushdown', name: 'CABLE PUSHDOWN — triceps', real: 'handle cable ke saath neeche, stack visible (live)', impl: 'done' },
    { id: 'ex.pullup', name: 'PULL-UP BAR — lats/biceps/forearms', real: 'ooncha frame + crossbar (live)', impl: 'done' },
    { id: 'ex.lat', name: 'LAT PULLDOWN — lats/biceps', real: 'overhead bar seene tak + weight stack (live)', impl: 'done' },
    { id: 'ex.row', name: 'SEATED CABLE ROW — lats/traps/biceps', real: 'handle peeche kheenchta, cable column (live)', impl: 'done' },
    { id: 'ex.shrug', name: 'BARBELL SHRUGS — traps/forearms', real: 'chhoti tez lift + plates (live)', impl: 'done' },
    { id: 'ex.tread', name: 'TREADMILL RUN — cardio (calves/quads/hamstrings)', real: 'belt stripes chalti hain, console lit (live)', impl: 'done' },
    { id: 'ex.cycle', name: 'STATIONARY CYCLE — quads/calves/glutes', real: 'pedal wheel ghoomta, console (live)', impl: 'done' },
    { id: 'ex.rowerg', name: 'ROWING ERG — full body cardio', real: 'seat rail par slide + handle pull (live)', impl: 'done' },
    { id: 'ex.squat', name: 'SQUATS — quads/glutes/hamstrings', real: 'bar squat DEPTH tak utarta (live)', impl: 'done' },
    { id: 'ex.legpress', name: 'LEG PRESS — inclined sled slide', real: 'sled weight ke saath slide (live)', impl: 'done' },
    { id: 'ex.legext', name: 'LEG EXTENSION — quads isolated', real: 'shin pad swing (live)', impl: 'done' },
    { id: 'ex.legcurl', name: 'LEG CURL — hamstrings/calves', real: 'prone pad swing (live)', impl: 'done' },
    { id: 'ex.calf', name: 'CALF RAISE — calves', real: 'heel platform raise + shoulder pads (live)', impl: 'done' },
    { id: 'ex.deadlift', name: 'DEADLIFTS — hamstrings/glutes/lats', real: 'bar zameen se lockout tak (live)', impl: 'done' },
    { id: 'ex.dips', name: 'DIPS — triceps/chest/delts', real: 'parallel bars + body dip animation (live)', impl: 'done' },
    { id: 'ex.plank', name: 'PLANK (iso) — core/obliques', real: 'mat + hold wobble (live)', impl: 'done' },
    { id: 'ex.crunch', name: 'AB CRUNCHES — core/obliques', real: 'hinge pad uthna (live)', impl: 'done' },
    { id: 'ex.kbell', name: 'KETTLEBELL SWINGS — glutes/hamstrings/core', real: 'rack + ek bell swing arc (live)', impl: 'done' },
    { id: 'ex.lunge', name: 'LUNGES — quads/glutes/calves', real: 'floor markers + stride box (live)', impl: 'done' },
    { id: 'ex.burpee', name: 'BURPEES — full body floor', real: 'floor se jump tak (live)', impl: 'done' },
    { id: 'ex.stretch', name: 'COOLDOWN STRETCH — hamstrings/calves/chest', real: 'stretch corner mat + strap; relax-focused rate (live)', impl: 'done' },
    { id: 'ex.turf', name: 'FUNCTIONAL TURF — open-air floor zone', real: '6 floor stations gym ke east, alag turf floor (live)', impl: 'done' }
  ],
  hospital: [
    { id: 'hp.building', name: 'VICE GENERAL HOSPITAL — named building, bada H-cross', real: 'shell + roof + door ke upar bara cross + 3D label (live)', impl: 'done' },
    { id: 'hp.beds', name: 'Ward beds with patients', real: '3 beds, 2 par lete hue patient shapes, headrest (live)', impl: 'done' },
    { id: 'hp.stretchers', name: 'STRETCHERS with roll FSM', real: 'entrance ↔ ward roll, wait, wapas — wheels + patient; teleport nahi (live)', impl: 'done' },
    { id: 'hp.medicines', name: 'MEDICINE SHELF — dawaiyon ki rows', real: '3 shelves × 4 medicine boxes alag brightness (live)', impl: 'done' },
    { id: 'hp.pharmacy', name: 'PHARMACY COUNTER — dawa $25 = heal 40', real: 'counter + G buy; hp full = honest "paisa nahi kata"; broke = honest (live)', impl: 'done' },
    { id: 'hp.staff', name: 'STAFF: doctor + 2 nurses (AI)', real: 'role wale peds — duty points par attend, hospital mein walk, DOCTOR/NURSE labels, gunfire par sab ki tarah flee (live)', impl: 'done' },
    { id: 'hp.visitors', name: 'Visitors queue at pharmacy counter', real: 'aam peds hospital counter ko destination banate hain (live)', impl: 'done' },
    { id: 'hp.ambulance', name: 'Ambulance siren arrivals', real: 'emergency entrance par ambulance aana — agli manzil', impl: 'planned' }
  ],
  gve: [
    { id: 'gve.engine', name: 'GVE Module 1 — fixed 1/60 timestep loop + pools', real: 'accumulator pattern, PAUSE freeze, Pool reuse counters (live headless)', impl: 'done' },
    { id: 'gve.render', name: 'GVE Module 2 — post pipeline bloom/SSAO/LUT/grain', real: 'teal-magenta cinematic wash, GPU dispose registry, resize math (live)', impl: 'done' },
    { id: 'gve.physics', name: 'GVE Module 3 — 6-layer collision matrix + impulses', real: 'spatial hash broadphase, sphere narrowphase, momentum impulse, raycast (live)', impl: 'done' },
    { id: 'gve.streamer', name: 'GVE Module 4 — chunk streaming + LOD + asset refs', real: 'radius chunks, load/unload budgets, refcount, prop pool (live)', impl: 'done' },
    { id: 'gve.player', name: 'GVE Module 5 — 6-state character FSM + quat cam', real: 'IDLE/WALK/SPRINT/JUMP/FALL/CROUCH, slerp orbital camera (live)', impl: 'done' },
    { id: 'gve.vehicle', name: 'GVE Module 6 — raycast vehicle + drift traction', real: '4-wheel spring/damper, slip-ratio curve, handbrake grip 0.25, enter lerp (live)', impl: 'done' },
    { id: 'gve.combat', name: 'GVE Module 7 — raycast combat + weapon wheel', real: 'screen-center ray, kinetic impulse, impact/tracer pools, 4 weapons (live)', impl: 'done' },
    { id: 'gve.traffic', name: 'GVE Module 8 — lane traffic AI', real: 'waypoint graph, red-light stop, obstacle avoid, gunshot panic (live)', impl: 'done' },
    { id: 'gve.wanted', name: 'GVE Module 9 — 5-star wanted FSM', real: 'patrol → pit/ram → roadblock ahead of trajectory, heat decay (live)', impl: 'done' },
    { id: 'gve.atmosphere', name: 'GVE Module 10 — day/night + weather sim', real: 'sun elevation math, weather blend FSM, night neon bloom boost (live)', impl: 'done' },
    { id: 'gve.audio', name: 'GVE Module 11 — positional audio + radio', real: 'attenuation/pan/doppler math, 3 stations, offline = honest STALLED (live)', impl: 'done' },
    { id: 'gve.ui', name: 'GVE Module 12 — scaleform HUD + minimap', real: 'safe-area, world→minimap rotate/clamp, message TTL, blips (live)', impl: 'done' }
  ],
  brain: [
    { id: 'br.regions', name: '7 REGIONS — PERCEIVE → RECALL → PLAN → REASON → ACT → VERIFY → LEARN', real: 'shared/brain.cjs cognitive pipeline; har region ka apna kaam + honest obs (live)', impl: 'done' },
    { id: 'br.graph', name: 'LIVE KNOWLEDGE GRAPH — nodes + weighted edges', real: 'Detail Codex + KB + user sawaalon se seed/wire; 400+ nodes (live)', impl: 'done' },
    { id: 'br.hebbian', name: 'HEBBIAN LEARNING — fire together, wire together', real: 'har interaction edge weights barhata hai (+0.25/word-fire); brain dikhao mein strongest pathways (live)', impl: 'done' },
    { id: 'br.recall', name: 'SPREADING ACTIVATION — 2-hop recall', real: 'query tokens se activation phailti hai; top-k concepts confidence banate hain (live)', impl: 'done' },
    { id: 'br.plandon', name: 'PLAN — har step ki done-definition', real: 'situation engine tasks + per-step done/risk; jhootha "done" nahi (live)', impl: 'done' },
    { id: 'br.confidence', name: 'HONEST CONFIDENCE — recall strength se', real: 'weak recall = kam confidence, saaf lafzon mein; andaza nahi (live)', impl: 'done' },
    { id: 'br.decay', name: 'DECAY/PRUNE — honest forgetting', real: 'kamzor edges (<0.12) prune hote hain (live)', impl: 'done' },
    { id: 'br.persist', name: 'ONE-WAY PERSIST — .dev-studio/air/brain-graph.json', real: 'graph disk par save/load; connected AIs ko kabhi nahi milta (live)', impl: 'done' }
  ]
};

function categories() { return Object.keys(CODEX); }

function count() {
  let total = 0; let done = 0;
  for (const k of Object.keys(CODEX)) for (const e of CODEX[k]) { total += 1; if (e.impl === 'done') done += 1; }
  return { total, done, planned: total - done, categories: Object.keys(CODEX).length };
}

function category(name) { return CODEX[String(name || '').toLowerCase()] || null; }

/* search across the whole codex — Air_you answers "car ki details" etc. from here */
function search(q) {
  const s = String(q || '').toLowerCase();
  const hits = [];
  for (const k of Object.keys(CODEX)) {
    for (const e of CODEX[k]) {
      if (k.includes(s) || e.name.toLowerCase().includes(s) || e.real.toLowerCase().includes(s) || e.id.includes(s)) hits.push({ cat: k, ...e });
    }
  }
  return hits;
}

/* ============ CODEX 2.0 (v1.22.0) — user entries + ranked search + live audit ============ */

/* User-fed details live at <ws>/.dev-studio/detailcodex-user.json (cap 200).
   The user cannot type 100,000 details in chat — so the codex GROWS from
   whatever batches he feeds, and every count includes them honestly. */
function parseUser(rawUser) {
  try {
    const u = JSON.parse(rawUser);
    return Array.isArray(u) ? u.filter((e) => e && typeof e.detail === 'string') : [];
  } catch { return []; }
}

function guessCategory(detail) {
  const d = String(detail || '').toLowerCase();
  if (/\bgve\b|game engine|virtual engine|wanted level|weapon wheel|raycast vehicle|day.?night cycle/.test(d)) return 'gve';
  // brain pehle: AI-architecture words kisi world category se collide nahi karte
  if (/\bbrain\b|dimagh|dimaagh|dimaag|hebbian|cognize|knowledge graph|brain graph|neural graph/.test(d)) return 'brain';
  // traffic pehle: "cars slow" jaisi lines road-context hain, car-anatomy nahi
  if (/(traffic|signal|road|sadak|bridge|\bpul\b|\blane)/.test(d)) return 'traffic';
  if (/(hospital|aspatal|doctor|nurse|dawa|medicine|dawai|stretcher|pharmacy|ilaaj|ward|\bbed\b)/.test(d)) return 'hospital';
  if (/(bench press|incline|chest fly|shoulder press|curl|pushdown|pull.?up|pulldown|seated row|shrug|treadmill|cycle|rowing|squat|leg press|leg ext|leg curl|calf raise|deadlift|dips|plank|crunch|kettlebell|lunge|burpee|stretch)/.test(d)) return 'exercises';
  if (/(car|gaari|door|darwaz|hood|trunk|engine|mirror|fuel|petrol|wheel|tire|wiper|brake|gear)/.test(d)) return 'car';
  if (/(fridge|kitchen|bottle|cup|veg|sabzi|ghar|home|room|light|fan|stove|microwave)/.test(d)) return 'home';
  if (/(plane|airport|flight|runway|heli|pilot|jet|udna|udaan)/.test(d)) return 'airport';
  if (/(beach|sand|\bret\b|umbrella|sunbathe|samundar ka kinara)/.test(d)) return 'beach';
  if (/(muscle|stretch|relax|fatigue|squat|pushup|pullup|lunge|plank|deadlift|strength|reps|body)/.test(d)) return 'body';
  if (/(shop|dukaan|bus|motorway|ship|barge|shipyard|mine|kan\b|npc|landmark)/.test(d)) return 'citylife';
  if (/(gym|workout|treadmill|weight|exercise|dumbbell)/.test(d)) return 'gym';
  if (/(city|sheher|building|crowd|market| gali)/.test(d)) return 'city';
  return 'user';
}

function addUserEntry(rawUser, detail) {
  const u = parseUser(rawUser);
  const entry = {
    cat: guessCategory(detail),
    detail: String(detail || '').slice(0, 240),
    when: new Date().toISOString().slice(0, 10),
    impl: 'user-added'
  };
  return JSON.stringify([entry, ...u].slice(0, 200), null, 1);
}

function countWithUser(rawUser) {
  const base = count();
  const u = parseUser(rawUser);
  return { ...base, user: u.length, total: base.total + u.length };
}

/* Ranked search across shipped + user entries (token scoring, best first) */
function rankSearch(q, rawUser) {
  const s = String(q || '').toLowerCase();
  const toks = s.split(/[^a-z0-9]+/).filter((w) => w.length > 2);
  const hits = [];
  for (const k of Object.keys(CODEX)) {
    for (const e of CODEX[k]) {
      const hay = `${k} ${e.name} ${e.real} ${e.id}`.toLowerCase();
      let score = 0;
      for (const t of toks) if (hay.includes(t)) score += 1;
      if (s.length > 2 && hay.includes(s)) score += 2;
      if (score > 0) hits.push({ cat: k, score, ...e });
    }
  }
  for (const e of parseUser(rawUser)) {
    const hay = `${e.cat} ${e.detail}`.toLowerCase();
    let score = 0;
    for (const t of toks) if (hay.includes(t)) score += 1;
    if (score > 0) hits.push({ cat: e.cat, score, id: `user.${e.when}`, name: e.detail, real: e.detail, impl: 'user-added' });
  }
  return hits.sort((a, b) => b.score - a.score);
}

/* Live honest audit: hand it a RUNNING composed3d game object and it checks
   which Detail Pack systems are actually alive in it — no paper claims. */
function audit(G) {
  const checks = {
    car_anatomy: Boolean(G && G.car && G.car.parts && Object.keys(G.car.parts).length === 7 && G.car.engine && G.car.mirrors),
    fridge_props: Boolean(G && Array.isArray(G.props) && G.props.some((p) => p.kind === 'fridge' && Array.isArray(p.items) && p.items.length >= 3)),
    traffic: Boolean(G && Array.isArray(G.traffic) && G.traffic.length >= 4),
    plane_pilot: Boolean(G && Array.isArray(G.planes) && G.planes.some((p) => p.pilot === true)),
    heli_rotors: Boolean(G && Array.isArray(G.helis) && G.helis.some((h) => h.pilot === true && h.rotor !== undefined)),
    gym_zone: Boolean(G && G.gym && Number.isFinite(G.gym.x0)),
    beach_props: Boolean(G && G.beach && Array.isArray(G.beach.umbrellas) && G.beach.umbrellas.length >= 1),
    weather_cell: Boolean(G && G.weather && Number.isFinite(G.weather.intensity)),
    crowds: Boolean(G && Array.isArray(G.peds) && G.peds.length > 0)
  };
  const total = Object.keys(checks).length;
  const passed = Object.values(checks).filter(Boolean).length;
  return { checks, passed, total, allLive: passed === total };
}

module.exports = { CODEX, categories, count, category, search, parseUser, guessCategory, addUserEntry, countWithUser, rankSearch, audit };
