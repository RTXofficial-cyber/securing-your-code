/**
 * AIR TOOLS (v1.27.0) — Air_you ke HAATH (tool registry).
 *
 * User ka ask (Ask 44): "jaise AAP ke modules/structure/working hai, same
 * to same AI banao." Bare coding agent ki working ka pehla hissa ye hai ke
 * uske paas TOOLS hote hain (read, write, edit, list, grep, run, search)
 * aur har turn mein wo unhe CHALATA hai — canned jawab nahi deta.
 *
 * Har tool: { name, description, permission, run(args, ctx) -> {ok, out} }
 *  - permission:false = dekhna/parhna (hamesha allowed)
 *  - permission:true  = likhna/chalana (sirf jab user ijazat de)
 * Ye bilkul wahi gate hai jo bare agent mein hota hai: read free, write gated.
 *
 * node_check asli syntax verification hai (vm.Script compile, execute nahi)
 * — jhootha "theek hai" kabhi nahi.
 */
const vm = require('vm');
const { spawnSync } = require('child_process');

function createTools(ctx) {
  const c = ctx || {};
  const ws = c.ws || null;
  const permission = !!c.permission;
  const brain = c.brain || null;
  const tools = {};

  const hasWs = () => !!ws && typeof ws.read === 'function';
  const canWrite = () => hasWs() && typeof ws.write === 'function';

  function def(name, description, needsPermission, run) {
    tools[name] = { name, description, permission: needsPermission, run };
  }

  def('list_files', 'workspace ki saari files (flat list, cap 400)', false, () => {
    if (!hasWs() || typeof ws.listFlat !== 'function') return { ok: false, out: 'workspace nahi mila' };
    const f = (ws.listFlat() || []).slice(0, 400);
    return { ok: true, out: `${f.length} files`, files: f };
  });

  def('read_file', 'file parho (cap 4000 chars)', false, (a) => {
    if (!hasWs()) return { ok: false, out: 'workspace nahi mila' };
    const p = String((a && a.path) || '');
    if (!p) return { ok: false, out: 'path chahiye' };
    const raw = ws.read(p);
    if (raw == null) return { ok: false, out: `file nahi mili: ${p}` };
    const s = String(raw);
    return { ok: true, out: s.slice(0, 4000), lines: s.replace(/\n$/, '').split('\n').length };
  });

  def('write_file', 'file likho (permission-gated)', true, (a) => {
    if (!canWrite()) return { ok: false, out: 'workspace writable nahi hai' };
    const p = String((a && a.path) || '');
    const content = String((a && a.content) || '');
    if (!p) return { ok: false, out: 'path chahiye' };
    ws.write(p, content);
    const back = String(ws.read(p) || '');
    const verified = back.length === content.length;   // read-back verify, jhooth nahi
    return { ok: verified, out: verified ? `likha + read-back verify (${back.length} chars)` : 'write hua lekin read-back MISMATCH', verified };
  });

  def('edit_file', 'file mein old -> new replace (permission-gated)', true, (a) => {
    if (!canWrite()) return { ok: false, out: 'workspace writable nahi hai' };
    const p = String((a && a.path) || '');
    const oldS = String((a && a.old) || '');
    const newS = String((a && a.new) || '');
    const raw = p ? ws.read(p) : null;
    if (raw == null) return { ok: false, out: `file nahi mili: ${p}` };
    if (!oldS || !String(raw).includes(oldS)) return { ok: false, out: 'old text file mein nahi mila (honest: edit nahi hua)' };
    ws.write(p, String(raw).replace(oldS, newS));
    return { ok: true, out: `edit lag gaya: ${p}`, verified: String(ws.read(p)).includes(newS) };
  });

  def('grep', 'file mein keyword dhoondo (line numbers ke saath)', false, (a) => {
    if (!hasWs()) return { ok: false, out: 'workspace nahi mila' };
    const p = String((a && a.path) || '');
    const kw = String((a && a.keyword) || '');
    const raw = p ? ws.read(p) : null;
    if (raw == null) return { ok: false, out: `file nahi mili: ${p}` };
    const hits = [];
    String(raw).split('\n').forEach((ln, i) => { if (kw && ln.toLowerCase().includes(kw.toLowerCase())) hits.push(`${i + 1}: ${ln.slice(0, 120)}`); });
    return { ok: true, out: hits.length ? hits.slice(0, 20).join('\n') : `0 lines milin "${kw}" (honest)`, hits: hits.length };
  });

  def('node_check', 'JS syntax verify (compile-only, execute nahi)', false, (a) => {
    const p = String((a && a.path) || '');
    let src = a && a.content != null ? String(a.content) : null;
    if (src == null) {
      if (!hasWs()) return { ok: false, out: 'workspace nahi mila' };
      const raw = p ? ws.read(p) : null;
      if (raw == null) return { ok: false, out: `file nahi mili: ${p}` };
      src = String(raw);
    }
    try { new vm.Script(src, { filename: p || 'check.js' }); return { ok: true, out: `syntax OK${p ? `: ${p}` : ''}` }; }
    catch (e) { return { ok: false, out: `SYNTAX ERROR: ${String(e.message).slice(0, 200)}` }; }
  });

  def('run_tests', 'poora logic test suite chalao (permission + asli fs root chahiye)', true, () => {
    const root = c.wsRoot;
    if (!root) return { ok: false, out: 'test suite ke liye asli workspace root chahiye (desktop app mein milega)' };
    const r = spawnSync('node', ['test/run.cjs'], { cwd: root, encoding: 'utf8', timeout: 240000 });
    const tail = String(r.stdout || '').split('\n').slice(-3).join(' | ').slice(0, 200);
    return { ok: r.status === 0, out: tail || `exit ${r.status}` };
  });

  def('codex_search', 'Detail Codex mein search (feed nahi, brain ka recall)', false, (a) => {
    try {
      const codex = require('./gamekit/detailcodex.cjs');
      const q = String((a && a.q) || '');
      const seen = {};
      let hits = codex.search(q);
      if (!hits.length) {           // poora sawal literal match na ho to tokens se milao
        for (const w of q.toLowerCase().split(/[^a-z0-9]+/).filter((x) => x.length > 3)) {
          for (const h of codex.search(w)) if (!seen[h.id]) { seen[h.id] = 1; hits.push(h); }
        }
      }
      hits = hits.slice(0, 6);
      return { ok: true, out: hits.length ? hits.map((h) => `${h.cat}/${h.id}: ${h.name}`).join('\n') : '0 hits (honest)', hits: hits.length };
    } catch (e) { return { ok: false, out: e.message }; }
  });

  def('kb_recall', 'Knowledge Bank topics recall', false, (a) => {
    if (!brain) return { ok: false, out: 'brain context nahi mila' };
    const rec = brain.recall(String((a && a.q) || ''), 5);
    return { ok: rec.length > 0, out: rec.length ? rec.map((r) => `${r.id} (${r.act.toFixed(2)})`).join(', ') : 'graph mein koi strong connection nahi (honest)', recall: rec };
  });

  def('web_search', 'live internet search (online mode chahiye)', false, () => ({ ok: false, out: 'OFFLINE mode: web_search sirf online (WiFi + Studio chat) mein chalta hai — honest', needsOnline: true }));

  const isOwn = (p) => /^\.dev-studio\//.test(String(p || ''));   // Air_you ka apna journal area (airloop jaisa) — wahan write free
  function call(name, args) {
    const t = tools[name];
    if (!t) return { ok: false, out: `unknown tool "${name}" (honest: mere paas ye tool nahi)`, tool: name };
    if (t.permission && !permission && !isOwn(args && args.path)) return { ok: false, out: `PERMISSION chahiye: "${name}" user ki file badalta hai — ijazat ke bagair nahi (read free, write gated)`, tool: name, blocked: 'permission' };
    try {
      const r = t.run(args || {}) || { ok: false, out: 'tool ne kuch nahi lautaya' };
      return { ...r, tool: name };
    } catch (e) { return { ok: false, out: `tool error: ${String(e.message).slice(0, 160)}`, tool: name }; }
  }

  return { tools, call, names: () => Object.keys(tools), permission: () => permission };
}

module.exports = { createTools };
