# GTA-VIRTUAL-ENGINE (GVE) — v1.29.0 ARCHITECTURE

12 modular subsystems, vanilla JS, zero runtime deps (Three.js/Cannon.js
style APIs replaced by hand-written vector/quaternion/raycast math so the
engine runs HEADLESS in tests and offline in the zip).

## Inter-dependency tree
```
1 engine.cjs (fixed 1/60 timestep, pools, states)
├── 2 render.cjs (post pipeline: bloom/SSAO/LUT/grain, GPU dispose registry)
│     └── 10 atmosphere.cjs feeds sky params + night bloom boost
├── 3 physics.cjs (layer collision matrix, spatial hash, impulses, raycast)
│     ├── 5 player.cjs (capsule body, 6-state FSM, quaternion orbital cam)
│     ├── 6 vehicle.cjs (4-wheel raycast suspension, slip traction, drift)
│     └── 7 combat.cjs (screen-ray hits, impact/tracer pools, weapon wheel)
├── 4 streamer.cjs (chunk grid, LOD tiers, load/unload budget, asset refs)
│     ├── 8 traffic.cjs (lane waypoint graph, steering, red-light stop, panic)
│     └── 9 wanted.cjs (5-star FSM, patrol/pit/roadblock-ahead-of-trajectory)
├── 11 audio.cjs (positional atten/pan/doppler, radio FSM, offline-honest)
└── 12 ui.cjs (scaleform HUD data, safe-area, world→minimap projection)
```

## Module contracts (all headless-verified in test/run.cjs)
1. Engine: accumulator fixed-step; PAUSE freezes physics; Pool reuse counters.
2. Render: bloomExtract knee math; ssaoOcclude kernel; lutTealMagenta curve;
   collectGarbage frees unseen GPU ids; resize aspect math.
3. Physics: MATRIX gates layers; impulses conserve momentum; raycast t-order.
4. Streamer: radius chunks, budgets per tick, refcount assets, prop pool.
5. Player: IDLE/WALK/SPRINT/JUMP/FALL/CROUCH transitions; slerp cam quat.
6. Vehicle: suspension compression per wheel; tractionCurve slip peak 0.18;
   handbrake grip 0.25 → drift; tryEnter distance gate + lerp state.
7. Combat: rpm cooldown; spread cone; kinetic impulse /mass; wheel slots.
8. Traffic: waypoint advance; stop at red within stopDist; panic on gunshot.
9. Wanted: heat→stars thresholds; pit intercept lead; roadblock projection.
10. Atmosphere: sun elevation cycle; weather blend; bloomBoost night 1.5.
11. Audio: attenuation^1.6 rolloff; pan from listener quat; doppler radial;
    offline stream = STALLED (honest, no fake network).
12. UI: safeRect; worldToMap rotate+clamp edge flag; message TTL queue.
