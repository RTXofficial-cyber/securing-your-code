/**
 * GVE MODULE 4 — OPEN-WORLD STREAMING & ASSET MANAGEMENT.
 * Chunk grid (size S), stream radius R chunks, 3 LOD tiers by distance,
 * per-tick load/unload budget (no frame spikes), refcounted asset registry,
 * entity pools per chunk so GC never sees streamed props.
 */
class WorldStreamer {
  constructor(opts = {}) {
    this.chunkSize = opts.chunkSize || 256;
    this.radius = opts.radius || 2;                 // chunks around player
    this.loadBudget = opts.loadBudget || 4;         // chunks per tick
    this.unloadBudget = opts.unloadBudget || 2;
    this.lod = opts.lod || [128, 384, 768];          // tier distances (units)
    this.chunks = new Map();                        // "cx,cz" -> chunk
    this.assets = new Map();                        // id -> {refs, bytes}
    this.generator = opts.generator || null;        // (cx,cz) -> entities[]
    this.stats = { loaded: 0, unloaded: 0, lod: [0, 0, 0], poolReuse: 0 };
    this.propPool = { free: [], live: 0 };
  }
  key(cx, cz) { return `${cx},${cz}`; }
  chunkOf(x, z) { return [Math.floor(x / this.chunkSize), Math.floor(z / this.chunkSize)]; }
  acquireProp() {
    if (this.propPool.free.length) { this.stats.poolReuse += 1; return this.propPool.free.pop(); }
    return { id: null, x: 0, z: 0, lod: 0 };
  }
  releaseProp(p) { this.propPool.live -= 1; this.propPool.free.push(p); }
  refAsset(id, bytes = 1024) {
    const a = this.assets.get(id) || { refs: 0, bytes };
    a.refs += 1; this.assets.set(id, a); return a;
  }
  unrefAsset(id) {
    const a = this.assets.get(id);
    if (!a) return false;
    a.refs -= 1;
    if (a.refs <= 0) this.assets.delete(id);
    return true;
  }
  lodTier(dist) { return dist <= this.lod[0] ? 0 : dist <= this.lod[1] ? 1 : dist <= this.lod[2] ? 2 : -1; }
  /** call every engine update with player position */
  update(ctx, dt, player) {
    const px = player ? player.x : 0; const pz = player ? player.z : 0;
    const [ccx, ccz] = this.chunkOf(px, pz);
    // queue wanted chunks inside radius, nearest first
    const wanted = [];
    for (let dz = -this.radius; dz <= this.radius; dz += 1) for (let dx = -this.radius; dx <= this.radius; dx += 1) {
      const k = this.key(ccx + dx, ccz + dz);
      if (!this.chunks.has(k)) wanted.push({ k, cx: ccx + dx, cz: ccz + dz, d: dx * dx + dz * dz });
    }
    wanted.sort((a, b) => a.d - b.d);
    let loaded = 0;
    for (const w of wanted) {
      if (loaded >= this.loadBudget) break;
      const ents = this.generator ? this.generator(w.cx, w.cz) : [];
      const props = ents.map((e) => { const p = this.acquireProp(); p.id = e.id; p.x = e.x; p.z = e.z; p.asset = e.asset || null; this.propPool.live += 1; return p; });
      this.chunks.set(w.k, { cx: w.cx, cz: w.cz, props, assets: (ents.map((e) => e.asset).filter(Boolean)) });
      for (const a of this.chunks.get(w.k).assets) this.refAsset(a);
      this.stats.loaded += 1; loaded += 1;
    }
    // unload far chunks (budgeted) + unref assets + pool props back
    let unloaded = 0;
    for (const [k, c] of this.chunks) {
      if (unloaded >= this.unloadBudget) break;
      const dx = c.cx - ccx; const dz = c.cz - ccz;
      if (Math.max(Math.abs(dx), Math.abs(dz)) > this.radius + 1) {
        for (const p of c.props) this.releaseProp(p);
        for (const a of c.assets) this.unrefAsset(a);
        this.chunks.delete(k);
        this.stats.unloaded += 1; unloaded += 1;
      }
    }
    // LOD tiers by distance to player
    this.stats.lod = [0, 0, 0];
    for (const [, c] of this.chunks) {
      const wx = (c.cx + 0.5) * this.chunkSize; const wz = (c.cz + 0.5) * this.chunkSize;
      const t = this.lodTier(Math.hypot(wx - px, wz - pz));
      for (const p of c.props) p.lod = t < 0 ? 2 : t;
      if (t >= 0) this.stats.lod[t] += c.props.length;
    }
    return { chunks: this.chunks.size };
  }
}

module.exports = { WorldStreamer };
