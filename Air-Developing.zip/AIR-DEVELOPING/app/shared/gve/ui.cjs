/**
 * GVE MODULE 12 — SCALEFORM-INSPIRED HUD + MINIMAP ENGINE.
 * Safe-area scaling, health/armour/wanted-stars/weapon-wheel slots,
 * world->minimap projection math (rotation by camera yaw + zoom clamp),
 * message queue with TTL, blip registry. Pure data + math: any renderer
 * (canvas2d/WebGL/DOM) can draw the described scaleforms.
 */
class UISystem {
  constructor(opts = {}) {
    this.w = opts.w || 1280; this.h = opts.h || 720;
    this.safe = opts.safe || 0.035;
    this.health = 100; this.armour = 0;
    this.stars = 0;
    this.wheel = { slots: ['FISTS', 'PISTOL', 'SMG', 'ASSAULT RIFLE'], active: 1, open: false };
    this.messages = [];             // { text, ttl, kind }
    this.blips = [];                // { id, x, z, kind, color }
    this.map = { zoom: 1, radius: 90, cx: 0.12, cy: 0.86 };   // normalized anchor
    this.stats = { frames: 0 };
  }
  resize(w, h) { this.w = w; this.h = h; }
  safeRect() {
    const mx = this.w * this.safe; const my = this.h * this.safe;
    return { x: mx, y: my, w: this.w - mx * 2, h: this.h - my * 2 };
  }
  say(text, kind = 'info', ttl = 4) { this.messages.push({ text, kind, ttl }); if (this.messages.length > 6) this.messages.shift(); }
  addBlip(b) { this.blips.push(b); return b; }
  /** world (x,z) -> minimap pixel, rotated by camera yaw, clamped to circle */
  worldToMap(x, z, player, yaw) {
    const dx = x - player.x; const dz = z - player.z;
    const c = Math.cos(-yaw); const s = Math.sin(-yaw);
    let mx = dx * c - dz * s; let mz = dx * s + dz * c;
    const dist = Math.hypot(mx, mz);
    const scale = (this.map.radius * this.map.zoom) / this.map.radius;
    mx *= scale; mz *= scale;
    if (dist > this.map.radius) { const k = this.map.radius / dist; mx *= k; mz *= k; }
    return { x: this.w * this.map.cx + mx, y: this.h * this.map.cy + mz, edge: dist > this.map.radius };
  }
  update(ctx, dt) {
    this.stats.frames += 1;
    for (let i = this.messages.length - 1; i >= 0; i -= 1) {
      this.messages[i].ttl -= dt;
      if (this.messages[i].ttl <= 0) this.messages.splice(i, 1);
    }
  }
  hud() {
    return {
      health: this.health, armour: this.armour, stars: this.stars,
      weapon: this.wheel.slots[this.wheel.active],
      messages: this.messages.map((m) => m.text),
      safe: this.safeRect()
    };
  }
}

module.exports = { UISystem };
