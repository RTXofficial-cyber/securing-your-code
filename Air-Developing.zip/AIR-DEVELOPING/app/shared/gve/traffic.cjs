/**
 * GVE MODULE 8 — AUTONOMOUS TRAFFIC: node-based lane waypoint graph,
 * steering behaviors (obstacle avoidance, red-light distance stop, panic
 * paths on gunshots), crawl speeds, lane keeping.
 */
const { V } = require('./physics.cjs');

class TrafficAI {
  constructor(physics, opts = {}) {
    this.phy = physics;
    this.nodes = [];                 // { x, z, links: [idx], light: null|'red'|'green' }
    this.cars = [];                  // { body, node, next, speed, panic, stopT }
    this.cruise = opts.cruise || 7;
    this.stopDist = opts.stopDist || 6;
    this.avoidDist = opts.avoidDist || 9;
    this.stats = { stops: 0, avoids: 0, panics: 0 };
  }
  addNode(x, z, links = [], light = null) { this.nodes.push({ x, z, links, light }); return this.nodes.length - 1; }
  spawnCar(nodeIdx, layer = 'vehicle') {
    const { Body } = require('./physics.cjs');
    const n = this.nodes[nodeIdx];
    const body = this.phy.add(new Body({ layer, radius: 1.0, mass: 1200, friction: 0.05, pos: { x: n.x, y: 0.6, z: n.z } }));
    const car = { body, node: nodeIdx, next: this.nodes[nodeIdx].links[0] != null ? this.nodes[nodeIdx].links[0] : nodeIdx, speed: this.cruise, panic: 0, stopT: 0 };
    this.cars.push(car);
    return car;
  }
  gunshot(x, z, radius = 40) {
    for (const c of this.cars) {
      if (Math.hypot(c.body.pos.x - x, c.body.pos.z - z) < radius) { c.panic = 6; this.stats.panics += 1; }
    }
  }
  update(ctx, dt) {
    for (const c of this.cars) {
      const target = this.nodes[c.next];
      if (!target) continue;
      const to = { x: target.x - c.body.pos.x, y: 0, z: target.z - c.body.pos.z };
      const dist = Math.hypot(to.x, to.z);
      // reached waypoint -> advance along links
      if (dist < 2.2) {
        c.node = c.next;
        const links = this.nodes[c.node].links;
        c.next = links.length ? links[Math.floor(Math.random() * links.length)] : c.node;
      }
      const dir = dist > 0 ? { x: to.x / dist, z: to.z / dist } : { x: 0, z: 0 };
      let want = c.panic > 0 ? this.cruise * 1.9 : this.cruise;
      // red light stop: distance check to node with light
      if (target.light === 'red' && dist < this.stopDist) { want = 0; c.stopT += dt; if (c.stopT > dt) this.stats.stops += 0; }
      // obstacle avoidance: car ahead in same direction
      for (const o of this.cars) {
        if (o === c) continue;
        const d = Math.hypot(o.body.pos.x - c.body.pos.x, o.body.pos.z - c.body.pos.z);
        if (d < this.avoidDist && d > 0.1) {
          const ox = (o.body.pos.x - c.body.pos.x) / d; const oz = (o.body.pos.z - c.body.pos.z) / d;
          const align = ox * dir.x + oz * dir.z;
          if (align > 0.8) { want = Math.min(want, Math.max(0, (d - 3) / this.avoidDist) * this.cruise); this.stats.avoids += dt > 0 ? 0 : 0; if (d < 4.5) want = 0; }
        }
      }
      if (c.panic > 0) c.panic -= dt;
      // steer = lerp velocity toward dir*want
      c.speed += (want - c.speed) * Math.min(1, 3 * dt);
      c.body.vel.x += (dir.x * c.speed - c.body.vel.x) * Math.min(1, 4 * dt);
      c.body.vel.z += (dir.z * c.speed - c.body.vel.z) * Math.min(1, 4 * dt);
      if (want === 0) this.stats.stops += dt;   // accumulated stop time
    }
  }
}

module.exports = { TrafficAI };
