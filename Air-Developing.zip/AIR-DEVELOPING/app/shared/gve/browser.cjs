/**
 * GVE PLAY — playable browser slice of the 12-module engine (v1.31.0).
 * Top-down canvas view of Vice City: drive/walk, enter vehicles (F),
 * shoot (Space) -> wanted heat, traffic cruises lanes, police chase by
 * stars, day/night + weather tint the frame. createPlay(deps) is DOM-free
 * (headless-testable); the bundled iife self-boots on #game canvas.
 */
const { createGVE } = require('./index.cjs');
const vice = require('./vicecity.cjs');

function createPlay(deps = {}) {
  const canvas = deps.canvas || null;
  const ctx = canvas && canvas.getContext ? canvas.getContext('2d') : null;
  const g = createGVE({});
  vice.attachVice(g, { cars: 8 });
  const keys = deps.keys || new Set();
  const api = {
    g, keys, draws: 0, paused: false, time: 0,
    step(dt) {
      if (keys.has('p')) { this.paused = !this.paused; keys.delete('p'); }
      if (!this.paused) {
        const inVehicle = g.vehicle.enterState === 'in';
        if (inVehicle) {
          g.vehicle.setInput({
            throttle: keys.has('w') || keys.has('arrowup') ? 1 : 0,
            brake: keys.has('s') || keys.has('arrowdown') ? 1 : 0,
            steer: (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0),
            handbrake: keys.has('shift')
          });
          if (keys.has('f')) { g.vehicle.exit(); keys.delete('f'); }
          if (keys.has(' ')) {                       // drive-by: heading mein fire
            const fx = Math.sin(g.vehicle.heading); const fz = Math.cos(g.vehicle.heading);
            const o = { x: g.vehicle.chassis.pos.x, y: 1, z: g.vehicle.chassis.pos.z };
            g.combat.fire(o, { x: fx, y: 0, z: fz }, dt);
            g.wanted.addHeat(0.8);
            g.traffic.gunshot(o.x, o.z, 40);
          }
        } else {
          g.player.setInput({
            f: (keys.has('w') || keys.has('arrowup') ? 1 : 0) - (keys.has('s') || keys.has('arrowdown') ? 1 : 0),
            r: (keys.has('d') || keys.has('arrowright') ? 1 : 0) - (keys.has('a') || keys.has('arrowleft') ? 1 : 0),
            sprint: keys.has('shift')
          });
          if (keys.has('f') && g.vehicle.tryEnter(g.player.body.pos, true)) keys.delete('f');
          if (keys.has(' ')) {
            const f = g.player.forward();
            const o = { x: g.player.body.pos.x, y: 1.2, z: g.player.body.pos.z };
            g.combat.fire(o, { x: f.x, y: 0, z: f.z }, dt);
            g.wanted.addHeat(0.8);
            g.traffic.gunshot(o.x, o.z, 40);
          }
        }
        g.engine.tick(dt, {});
        this.time += dt;
      }
      this.draw();
      return this;
    },
    draw() {
      this.draws += 1;                 // headless mein bhi frame gira
      if (!ctx || !canvas) return;
      const W = canvas.width; const H = canvas.height;
      const night = g.atmo.isNight();
      ctx.fillStyle = night ? '#07070c' : '#101418';
      ctx.fillRect(0, 0, W, H);
      const cam = g.vehicle.enterState === 'in' ? g.vehicle.chassis.pos : g.player.body.pos;
      const scale = 0.42;
      const px = (x) => W / 2 + (x - cam.x) * scale;
      const pz = (z) => H / 2 + (z - cam.z) * scale;
      // roads
      ctx.strokeStyle = night ? '#1c2030' : '#2a2f36';
      ctx.lineWidth = 10;
      for (const n of g.vice.nodes) {
        for (const li of n.links) {
          const o = g.vice.nodes[li];
          ctx.beginPath(); ctx.moveTo(px(n.x), pz(n.z)); ctx.lineTo(px(o.x), pz(o.z)); ctx.stroke();
        }
      }
      // zones
      for (const zn of vice.ZONES) {
        ctx.fillStyle = zn.id === 'beach' ? 'rgba(220,190,120,0.10)' : zn.id === 'hospital' ? 'rgba(255,80,80,0.12)' : 'rgba(120,200,255,0.07)';
        ctx.fillRect(px(zn.x), pz(zn.z), zn.w * scale, zn.h * scale);
      }
      // traffic + police + vehicle + player
      const dot = (x, z, r, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(px(x), pz(z), r, 0, 7); ctx.fill(); };
      for (const c of g.traffic.cars) dot(c.body.pos.x, c.body.pos.z, 4, '#7f8ea3');
      for (const u of g.wanted.units) dot(u.body.pos.x, u.body.pos.z, 5, g.wanted.stars >= 3 ? '#ff5050' : '#5f7fff');
      if (g.vehicle.enterState !== 'out') dot(g.vehicle.chassis.pos.x, g.vehicle.chassis.pos.z, 7, '#f4f3ef');
      dot(g.player.body.pos.x, g.player.body.pos.z, 5, '#ffe08a');
      // rain
      if (g.atmo.params.rain > 0.3) {
        ctx.strokeStyle = 'rgba(160,190,255,0.35)';
        for (let i = 0; i < 40; i += 1) { const rx = (i * 97 + this.draws * 13) % W; const ry = (i * 57 + this.draws * 29) % H; ctx.beginPath(); ctx.moveTo(rx, ry); ctx.lineTo(rx - 3, ry + 9); ctx.stroke(); }
      }
      // HUD
      ctx.fillStyle = '#f4f3ef';
      ctx.font = '12px monospace';
      const spd = g.vehicle.enterState === 'in' ? g.vehicle.speed() : Math.hypot(g.player.body.vel.x, g.player.body.vel.z);
      ctx.fillText(`GVE VICE CITY  ${night ? 'NIGHT' : 'DAY'} ${g.atmo.weather.toUpperCase()}  stars:${'★'.repeat(g.wanted.stars)}  speed:${spd.toFixed(1)}  chunks:${g.streamer.chunks.size}  ${g.vehicle.enterState === 'in' ? 'DRIVING (F=exit)' : 'ON FOOT (F=enter car, SPACE=shoot)'}${this.paused ? '  PAUSED' : ''}`, 10, 18);
    },
    state() {
      return {
        time: this.time, paused: this.paused, draws: this.draws,
        player: { ...g.player.body.pos }, state: g.player.state,
        vehicle: g.vehicle.enterState, speed: g.vehicle.speed(),
        stars: g.wanted.stars, weather: g.atmo.weather, chunks: g.streamer.chunks.size,
        traffic: g.traffic.cars.length, police: g.wanted.units.length
      };
    }
  };
  return api;
}

/* DOM bootstrap (only in a browser) */
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  const canvas = document.getElementById('game');
  if (canvas) {
    const play = createPlay({ canvas });
    const keys = play.keys;
    window.addEventListener('keydown', (e) => keys.add(e.key.toLowerCase()));
    window.addEventListener('keyup', (e) => keys.delete(e.key.toLowerCase()));
    let last = 0;
    const loop = (t) => {
      const dt = Math.min(0.05, (t - last) / 1000 || 0.016);
      last = t;
      play.step(dt);
      window.requestAnimationFrame(loop);
    };
    window.requestAnimationFrame(loop);
    window.GVE_PLAY = play;
  }
}

module.exports = { createPlay };
