/**
 * GVE MODULE 11 — POSITIONAL AUDIO + RADIO STREAM ENGINE (offline-safe).
 * Distance attenuation (inverse + rolloff), stereo pan from listener
 * quaternion, Doppler from radial velocity, engine pitch from rpm,
 * radio station FSM with procedural (offline) track schedule + stream
 * states BUFFERING/PLAYING/STALLED — honest: no network in offline mode.
 */
const { V } = require('./physics.cjs');

const STATIONS = [
  { id: 'vice-fm', name: 'VICE FM', genre: 'synthwave', tracks: ['Neon Tide', 'Chrome Hearts', 'Midnight Interchange'] },
  { id: 'iron-soul', name: 'IRON SOUL', genre: 'funk', tracks: ['Bassline Boulevard', 'Velvet Gear'] },
  { id: 'reef-radio', name: 'REEF RADIO', genre: 'pop', tracks: ['Salt & Sun', 'Boardwalk Dreams', 'Marina Lights'] }
];

class AudioEngine {
  constructor(opts = {}) {
    this.listener = { pos: { x: 0, y: 1.6, z: 0 }, quat: { w: 1, x: 0, y: 0, z: 0 }, vel: { x: 0, y: 0, z: 0 } };
    this.sources = [];              // { id, pos, vel, volume, radius, loop }
    this.maxDist = opts.maxDist || 60;
    this.station = 0; this.track = 0; this.trackT = 0;
    this.stream = 'PLAYING';        // PLAYING | BUFFERING | STALLED
    this.online = !!opts.online;
    this.stats = { mixes: 0, switches: 0 };
  }
  addSource(s) { const src = { vel: { x: 0, y: 0, z: 0 }, volume: 1, radius: 2, loop: true, ...s }; this.sources.push(src); return src; }
  attenuation(dist, radius) {
    if (dist <= radius) return 1;
    return Math.max(0, 1 - (dist - radius) / (this.maxDist - radius)) ** 1.6;   // inverse-ish rolloff
  }
  pan(srcPos) {
    // right vector from listener quat (manual)
    const q = this.listener.quat;
    const right = { x: 1 - 2 * (q.y * q.y + q.z * q.z), y: 2 * (q.x * q.y + q.w * q.z), z: 2 * (q.x * q.z - q.w * q.y) };
    const d = V.norm(V.sub(srcPos, this.listener.pos));
    return Math.max(-1, Math.min(1, V.dot(d, { x: right.x, y: 0, z: right.z })));
  }
  doppler(src) {
    const d = V.norm(V.sub(src.pos, this.listener.pos));
    const rel = V.sub(src.vel, this.listener.vel);
    const radial = V.dot(rel, d);
    return 1 + radial * 0.012;      // ~speed-of-sound scaled for gameplay
  }
  mix() {
    this.stats.mixes += 1;
    return this.sources.map((s) => {
      const dist = V.len(V.sub(s.pos, this.listener.pos));
      return { id: s.id, gain: this.attenuation(dist, s.radius) * s.volume, pan: this.pan(s.pos), pitch: this.doppler(s) };
    }).filter((c) => c.gain > 0.001);
  }
  enginePitch(rpm) { return 0.6 + Math.min(1.6, rpm / 6000); }
  radio(dt) {
    if (!this.online && this.stream === 'BUFFERING') this.stream = 'STALLED';   // honest offline
    this.trackT += dt;
    if (this.trackT > 30) { this.trackT = 0; this.track = (this.track + 1) % STATIONS[this.station].tracks.length; }
    return { station: STATIONS[this.station], track: STATIONS[this.station].tracks[this.track], stream: this.stream };
  }
  nextStation() { this.station = (this.station + 1) % STATIONS.length; this.track = 0; this.stats.switches += 1; if (!this.online) this.stream = 'STALLED'; return STATIONS[this.station]; }
  update(ctx, dt) { this.radio(dt); }
}

module.exports = { AudioEngine, STATIONS };
