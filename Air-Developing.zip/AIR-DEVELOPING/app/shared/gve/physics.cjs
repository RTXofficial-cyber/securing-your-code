/**
 * GVE MODULE 3 — CUSTOM PHYSICS & COLLISION MATRIX (hand-written vectors).
 * Layers: world | player | vehicle | ped | bullet | pickup. Broadphase via
 * uniform spatial hash; narrowphase sphere/AABB/capsule; impulse response
 * with restitution + friction; fixed-step integration happens in Engine.
 */
const LAYERS = ['world', 'player', 'vehicle', 'ped', 'bullet', 'pickup'];
const MATRIX = {                       // can-collide matrix (symmetric)
  world: ['player', 'vehicle', 'ped', 'bullet', 'pickup'],
  player: ['world', 'vehicle', 'ped', 'pickup'],
  vehicle: ['world', 'player', 'vehicle', 'ped', 'pickup'],
  ped: ['world', 'player', 'vehicle', 'ped'],
  bullet: ['world', 'player', 'vehicle', 'ped'],
  pickup: ['world', 'player']
};
const V = {
  add: (a, b) => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z }),
  sub: (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }),
  scale: (a, s) => ({ x: a.x * s, y: a.y * s, z: a.z * s }),
  dot: (a, b) => a.x * b.x + a.y * b.y + a.z * b.z,
  len: (a) => Math.sqrt(a.x * a.x + a.y * a.y + a.z * a.z),
  norm: (a) => { const l = V.len(a) || 1; return { x: a.x / l, y: a.y / l, z: a.z / l }; },
  cross: (a, b) => ({ x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x })
};

class Body {
  constructor(o = {}) {
    this.id = o.id || `b${Math.random().toString(36).slice(2, 8)}`;
    this.pos = o.pos || { x: 0, y: 0, z: 0 };
    this.vel = o.vel || { x: 0, y: 0, z: 0 };
    this.radius = o.radius != null ? o.radius : 0.5;
    this.half = o.half || null;              // AABB half-extents (optional)
    this.capsule = o.capsule || null;        // { height } vertical capsule
    this.mass = o.mass || 1;
    this.layer = o.layer || 'world';
    this.static = !!o.static;
    this.restitution = o.restitution != null ? o.restitution : 0.2;
    this.friction = o.friction != null ? o.friction : 0.6;
    this.grounded = false;
    this.contacts = 0;
  }
  get invMass() { return this.static ? 0 : 1 / this.mass; }
}

class PhysicsSystem {
  constructor(opts = {}) {
    this.gravity = opts.gravity != null ? opts.gravity : -9.81;
    this.floorY = opts.floorY != null ? opts.floorY : 0;   // flat city floor (sphere ground city-scale par curve karta tha)
    this.bodies = [];
    this.cell = opts.cell || 8;
    this.hash = new Map();
    this.stats = { steps: 0, pairs: 0, contacts: 0, impulses: 0 };
  }
  add(b) { this.bodies.push(b); return b; }
  remove(b) { const i = this.bodies.indexOf(b); if (i >= 0) this.bodies.splice(i, 1); }
  canCollide(a, b) { return (MATRIX[a.layer] || []).includes(b.layer); }
  buildHash() {
    this.hash.clear();
    for (const b of this.bodies) {
      const k = `${Math.floor(b.pos.x / this.cell)},${Math.floor(b.pos.z / this.cell)}`;
      if (!this.hash.has(k)) this.hash.set(k, []);
      this.hash.get(k).push(b);
    }
  }
  neighbors(b) {
    const cx = Math.floor(b.pos.x / this.cell); const cz = Math.floor(b.pos.z / this.cell);
    const out = [];
    for (let dx = -1; dx <= 1; dx += 1) for (let dz = -1; dz <= 1; dz += 1) {
      const arr = this.hash.get(`${cx + dx},${cz + dz}`);
      if (arr) for (const o of arr) if (o !== b) out.push(o);
    }
    return out;
  }
  /** sphere vs sphere (capsule approximated as sphere at center height) */
  narrow(a, b) {
    const d = V.sub(b.pos, a.pos);
    const dist = V.len(d);
    const r = a.radius + b.radius;
    if (dist >= r || dist === 0) return null;
    return { normal: V.scale(d, 1 / dist), depth: r - dist };
  }
  resolve(a, b, hit) {
    const n = hit.normal;
    // positional correction (split by invMass)
    const totalInv = a.invMass + b.invMass;
    if (totalInv === 0) return;
    const corr = V.scale(n, hit.depth / totalInv * 0.8);
    a.pos = V.sub(a.pos, V.scale(corr, a.invMass));
    b.pos = V.add(b.pos, V.scale(corr, b.invMass));
    // impulse
    const rv = V.sub(b.vel, a.vel);
    const velN = V.dot(rv, n);
    if (velN > 0) return;
    const e = Math.min(a.restitution, b.restitution);
    const j = -(1 + e) * velN / totalInv;
    const imp = V.scale(n, j);
    a.vel = V.sub(a.vel, V.scale(imp, a.invMass));
    b.vel = V.add(b.vel, V.scale(imp, b.invMass));
    // tangent friction — Coulomb clamp: |jt| <= mu * j (asli physics)
    const t = V.norm(V.sub(rv, V.scale(n, velN)));
    const mu = Math.min(a.friction, b.friction);
    const jtRaw = -V.dot(rv, t) / totalInv;
    const jt = Math.max(-j * mu, Math.min(j * mu, jtRaw));
    const fimp = V.scale(t, jt);
    a.vel = V.sub(a.vel, V.scale(fimp, a.invMass));
    b.vel = V.add(b.vel, V.scale(fimp, b.invMass));
    this.stats.impulses += 1;
    if (n.y > 0.5) { b.grounded = true; } if (n.y < -0.5) { a.grounded = true; }   // normal a→b: upar wala grounded
    a.contacts += 1; b.contacts += 1;
    this.stats.contacts += 1;
  }
  /** one fixed step: integrate + broadphase + narrowphase + resolve */
  fixed(ctx, dt) {
    this.stats.steps += 1;
    for (const b of this.bodies) {
      if (b.static) continue;
      b.vel.y += this.gravity * dt;
      b.grounded = false; b.contacts = 0;
      b.pos = V.add(b.pos, V.scale(b.vel, dt));
      if (b.pos.y < b.radius + this.floorY) {           // flat floor clamp
        b.pos.y = b.radius + this.floorY;
        if (b.vel.y < 0) b.vel.y = 0;
        b.grounded = true;
      }
    }
    this.buildHash();
    const seen = new Set();
    for (const a of this.bodies) {
      for (const b of this.neighbors(a)) {
        const key = a.id < b.id ? a.id + b.id : b.id + a.id;
        if (seen.has(key)) continue;
        seen.add(key);
        this.stats.pairs += 1;
        if (!this.canCollide(a, b)) continue;
        const hit = this.narrow(a, b);
        if (hit) this.resolve(a, b, hit);
      }
    }
  }
  raycast(origin, dir, maxDist = 200, filter = () => true) {
    const d = V.norm(dir);
    let best = null;
    for (const b of this.bodies) {
      if (!filter(b)) continue;
      const to = V.sub(b.pos, origin);
      const t = V.dot(to, d);
      if (t < 0 || t > maxDist) continue;
      const closest = V.add(origin, V.scale(d, t));
      const dist = V.len(V.sub(closest, b.pos));
      if (dist <= b.radius && (!best || t < best.t)) best = { body: b, t, point: closest };
    }
    return best;
  }
}

module.exports = { PhysicsSystem, Body, V, LAYERS, MATRIX };
