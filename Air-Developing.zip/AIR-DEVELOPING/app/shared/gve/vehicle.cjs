/**
 * GVE MODULE 6 — VEHICLE DYNAMICS: raycast-car model, 4 independent wheels
 * (spring stiffness + damping + anti-roll), slip-ratio traction curve for
 * handbrake drifts, enter/exit lerp + input-map swap + camera attach.
 */
const { V, Body } = require('./physics.cjs');

function tractionCurve(slip) {
  // Pacejka-ish: rises to peak at ~0.18 slip, falls off (drift window)
  const s = Math.abs(slip);
  if (s < 0.18) return s / 0.18;
  return Math.max(0.35, 1 - (s - 0.18) * 1.6);
}

class Wheel {
  constructor(off) {
    this.offset = off;              // {x,z} chassis-relative
    this.suspLen = 0.35; this.maxTravel = 0.28;
    this.stiffness = 32000; this.damping = 4200;
    this.compression = 0; this.load = 0; this.spin = 0;
    this.grounded = false; this.slip = 0;
  }
}

class VehiclePhysics {
  constructor(physics, opts = {}) {
    this.phy = physics;
    this.mass = opts.mass || 1350;
    this.chassis = physics.add(new Body({ layer: 'vehicle', radius: 1.1, mass: this.mass, friction: 0.05, pos: { x: 8, y: 0.7, z: 8 } }));   // grip traction-curve se model hoti hai, ground friction se nahi
    this.wheels = [new Wheel({ x: -0.85, z: 1.5 }), new Wheel({ x: 0.85, z: 1.5 }), new Wheel({ x: -0.85, z: -1.5 }), new Wheel({ x: 0.85, z: -1.5 })];
    this.heading = opts.heading || 0;
    this.rpm = 800; this.gear = 1;
    this.input = { throttle: 0, brake: 0, steer: 0, handbrake: false };
    this.enterState = 'out';        // out | lerping | in
    this.enterT = 0;
    this.drift = 0;
    this.groundY = opts.groundY != null ? opts.groundY : 0;
  }
  setInput(i) { Object.assign(this.input, i); }
  /** player<->door interaction: distance vector check + F press */
  tryEnter(playerPos, fPressed) {
    const d = V.len(V.sub(this.chassis.pos, playerPos));
    if (this.enterState === 'out' && fPressed && d < 2.6) { this.enterState = 'lerping'; this.enterT = 0; return true; }
    return false;
  }
  exit() { if (this.enterState === 'in') { this.enterState = 'out'; return true; } return false; }
  fixed(ctx, dt) {
    const c = this.chassis;
    if (this.enterState === 'lerping') {
      this.enterT += dt;
      if (this.enterT > 0.6) this.enterState = 'in';
      return;
    }
    // suspension raycasts (vertical) -> compression + spring/damper load
    for (const w of this.wheels) {
      const wx = c.pos.x + w.offset.x * Math.cos(this.heading) + w.offset.z * Math.sin(this.heading);
      const wz = c.pos.z - w.offset.x * Math.sin(this.heading) + w.offset.z * Math.cos(this.heading);
      const ground = this.groundY;
      const rest = c.pos.y - ground;
      w.compression = Math.max(0, Math.min(w.maxTravel, w.suspLen + 0.4 - rest + 0.35));
      w.grounded = w.compression > 0.01;
      const springF = w.stiffness * w.compression;
      const dampF = w.damping * Math.max(-1, Math.min(1, c.vel.y));
      w.load = Math.max(0, springF + dampF) / 4;
    }
    const grounded = this.wheels.some((w) => w.grounded);
    // longitudinal: engine force via traction
    const drive = this.input.throttle - this.input.brake * 0.9;
    const engineF = drive * 9000 * tractionCurve(drive > 0 ? Math.min(1, Math.abs(this.rpm - 3000) / 3000) : 0.2);
    const fx = Math.sin(this.heading); const fz = Math.cos(this.heading);
    if (grounded && this.enterState === 'in') {
      c.vel.x += fx * (engineF / this.mass) * dt;
      c.vel.z += fz * (engineF / this.mass) * dt;
    }
    // steering: yaw rate from speed + steer (arcade-refined)
    const speed = Math.hypot(c.vel.x, c.vel.z);
    const steerEff = this.input.steer * Math.min(1, speed / 6) * (this.input.handbrake ? 1.6 : 1);
    this.heading += steerEff * 1.9 * dt * (this.gear >= 0 ? 1 : -1);
    // lateral grip: slip ratio -> traction curve; handbrake cuts grip = drift
    const lat = { x: Math.cos(this.heading), z: -Math.sin(this.heading) };
    const vLat = c.vel.x * lat.x + c.vel.z * lat.z;
    const grip = this.input.handbrake ? 0.25 : 0.92;
    const slip = speed > 0.5 ? vLat / speed : 0;
    this.drift = Math.abs(slip);
    const latF = -vLat * grip * tractionCurve(slip) * 8;
    c.vel.x += lat.x * latF * dt;
    c.vel.z += lat.z * latF * dt;
    // drag + rolling resistance + vertical settle
    c.vel.x *= (1 - 0.6 * dt); c.vel.z *= (1 - 0.6 * dt);
    if (grounded) {
      const rest = c.pos.y - this.groundY - 0.7;
      c.vel.y += (-rest * 60 - c.vel.y * 8) * dt;
    }
    // rpm/gears from speed
    this.rpm = 800 + speed * 260 + this.input.throttle * 900;
    this.gear = speed > 28 ? 3 : speed > 14 ? 2 : 1;
  }
  update(ctx, dt) {
    for (const w of this.wheels) w.spin += Math.hypot(this.chassis.vel.x, this.chassis.vel.z) * dt / 0.32;
  }
  speed() { return Math.hypot(this.chassis.vel.x, this.chassis.vel.z); }
}

module.exports = { VehiclePhysics, Wheel, tractionCurve };
