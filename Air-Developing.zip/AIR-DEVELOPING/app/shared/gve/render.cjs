/**
 * GVE MODULE 2 — RENDERER & POST-PROCESSING PIPELINE (adapter-based).
 * WebGL2 adapter when a real GL context exists; headless/math adapter
 * otherwise so the whole pipeline (bloom threshold, SSAO kernel, grain,
 * teal-magenta LUT, resize math, GPU disposal registry) runs in tests.
 * All color math manual — no shader-source placeholders.
 */
class Color { constructor(r = 0, g = 0, b = 0) { this.r = r; this.g = g; this.b = b; } }

function lutTealMagenta(c, amount = 0.5) {
  // cinematic wash: shadows -> teal, highlights -> magenta (manual curve)
  const luma = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
  const shadow = Math.max(0, 1 - luma * 2);
  const high = Math.max(0, luma * 2 - 1);
  return new Color(
    Math.min(1, c.r + amount * (high * 0.35 - shadow * 0.10)),
    Math.min(1, c.g + amount * (shadow * 0.22)),
    Math.min(1, c.b + amount * (shadow * 0.35 + high * 0.18))
  );
}

class RenderPipeline {
  constructor(opts = {}) {
    this.gl = opts.gl || null;                 // null = headless math adapter
    this.width = opts.width || 1280; this.height = opts.height || 720;
    this.passes = [
      { id: 'scene', on: true },
      { id: 'bloom', on: true, threshold: 0.72, softKnee: 0.25, intensity: 0.9 },
      { id: 'ssao', on: true, radius: 0.35, kernel: 12, bias: 0.025 },
      { id: 'grading', on: true, lut: lutTealMagenta, amount: 0.55 },
      { id: 'grain', on: true, intensity: 0.045, seed: 1337 },
      { id: 'present', on: true }
    ];
    this.gpu = new Map();                      // id -> {bytes, lastSeen}
    this.disposedCount = 0;
    this.frameBudgetMs = opts.frameBudgetMs || 16.6;
    this.stats = { frames: 0, draws: 0, disposed: 0, passRuns: {} };
  }
  resize(w, h) {
    if (w <= 0 || h <= 0) return false;
    this.width = w; this.height = h;
    this.aspect = w / h;
    if (this.gl && this.gl.viewport) this.gl.viewport(0, 0, w, h);
    return true;
  }
  track(id, bytes) { this.gpu.set(id, { bytes, lastSeen: this.stats.frames }); }
  /** GPU memory cleanup: meshes not seen for N frames get disposed */
  collectGarbage(unseenFrames = 120) {
    let freed = 0;
    for (const [id, g] of this.gpu) {
      if (this.stats.frames - g.lastSeen > unseenFrames) { this.gpu.delete(id); this.disposedCount += 1; freed += g.bytes; }
    }
    this.stats.disposed = this.disposedCount;
    return freed;
  }
  bloomExtract(luma) {
    const p = this.passes[1];
    const knee = p.threshold * p.softKnee;
    const soft = Math.max(0, luma - p.threshold + knee);
    return (soft * soft) / (4 * knee + 1e-5) * p.intensity;
  }
  ssaoOcclude(sampleDepths, viewDepth) {
    const p = this.passes[2];
    let occ = 0;
    for (const d of sampleDepths.slice(0, p.kernel)) {
      const diff = viewDepth - d;
      if (diff > p.bias && diff < p.radius) occ += 1;
    }
    return 1 - occ / Math.max(1, Math.min(p.kernel, sampleDepths.length));
  }
  grain(u, v) {
    const p = this.passes[4];
    const n = Math.sin((u * 12.9898 + v * 78.233 + this.stats.frames * 0.01 + p.seed)) * 43758.5453;
    return (n - Math.floor(n) - 0.5) * p.intensity;
  }
  /** full pipeline for one pixel-color sample (math adapter path) */
  shade(color, ctx = {}) {
    let c = color;
    for (const p of this.passes) {
      if (!p.on) continue;
      this.stats.passRuns[p.id] = (this.stats.passRuns[p.id] || 0) + 1;
      if (p.id === 'bloom') {
        const l = 0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b;
        const add = this.bloomExtract(l) * (ctx.neon ? 1.6 : 1);
        c = new Color(Math.min(1, c.r + add), Math.min(1, c.g + add), Math.min(1, c.b + add));
      } else if (p.id === 'ssao') {
        const ao = ctx.depths ? this.ssaoOcclude(ctx.depths, ctx.viewDepth || 1) : 1;
        c = new Color(c.r * ao, c.g * ao, c.b * ao);
      } else if (p.id === 'grading') c = p.lut(c, p.amount);
      else if (p.id === 'grain') { const g = this.grain(ctx.u || 0.5, ctx.v || 0.5); c = new Color(Math.max(0, Math.min(1, c.r + g)), Math.max(0, Math.min(1, c.g + g)), Math.max(0, Math.min(1, c.b + g))); }
    }
    return c;
  }
  present(draws = 1) { this.stats.frames += 1; this.stats.draws += draws; }
}

module.exports = { RenderPipeline, Color, lutTealMagenta };
