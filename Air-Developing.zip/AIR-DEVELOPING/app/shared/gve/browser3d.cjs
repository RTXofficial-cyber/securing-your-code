/**
 * GVE VICE CITY 3D — bundle entry for the chase-camera render (v1.32.0).
 * Same createPlay() simulation as the top-down slice (WASD/F/SPACE/P — the
 * full 12-module GVE loop), but the frame is drawn by render3d.cjs on top
 * of GameKit3D's software perspective renderer. play.html?g=gve3d loads
 * engine3d.js first, so window.GameKit3D is already live; render3d falls
 * back to requiring it directly (headless/tests).
 */
const { createPlay } = require('./browser.cjs');

/* DOM bootstrap (only in a browser, only for ?g=gve3d) */
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
  const q = typeof window.URLSearchParams === 'function'
    ? new window.URLSearchParams(window.location.search).get('g') : null;
  const canvas = document.getElementById('game');
  if (canvas && q === 'gve3d') {
    const play = createPlay({ canvas, mode: '3d' });
    const keys = play.keys;
    window.addEventListener('keydown', (e) => keys.add(e.key.toLowerCase()));
    window.addEventListener('keyup', (e) => keys.delete(e.key.toLowerCase()));
    let last = 0;
    const loop = (t) => {
      const dt = Math.min(0.05, (t - last) / 1000 || 0.016);
      last = t;
      play.step(dt);
      window.requestAnimationFrame(loop);
    };
    window.requestAnimationFrame(loop);
    window.GVE_PLAY3D = play;
  }
}

module.exports = { createPlay };
