/**
 * GVE MODULE 10 — DYNAMIC SKY / DAY-NIGHT / WEATHER SIMULATOR.
 * Sun angle from time-of-day (manual spherical math), sky gradient colors
 * from elevation, weather FSM (clear/overcast/rain/storm/fog) with smooth
 * transitions, night neon-bloom boost fed to RenderPipeline.
 */
class AtmosphereSystem {
  constructor(opts = {}) {
    this.dayLength = opts.dayLength || 480;      // seconds per full cycle
    this.t = opts.start != null ? opts.start : 0.3;   // 0..1 (0=midnight)
    this.weather = 'clear';
    this.weatherT = 0;
    this.next = 'clear';
    this.blend = 1;
    this.chain = ['clear', 'overcast', 'rain', 'storm', 'fog'];
    this.params = { cloud: 0, rain: 0, fog: 0, wind: 2, lightning: 0 };
    this.stats = { cycles: 0, switches: 0, strikes: 0 };
  }
  sunAngle() { return this.t * Math.PI * 2 - Math.PI / 2; }
  sunElevation() { return Math.sin(this.sunAngle()); }
  sunDir() {
    const a = this.sunAngle();
    return { x: Math.cos(a) * 0.6, y: Math.sin(a), z: Math.cos(a) * 0.4 };
  }
  isNight() { return this.sunElevation() < -0.08; }
  skyColors() {
    const e = this.sunElevation();
    const day = Math.max(0, Math.min(1, (e + 0.1) * 2));
    const dusk = Math.max(0, 1 - Math.abs(e) * 5) * (e > -0.25 ? 1 : 0);
    return {
      top: { r: 0.05 + day * 0.20 + dusk * 0.25, g: 0.07 + day * 0.42 + dusk * 0.12, b: 0.12 + day * 0.75 },
      horizon: { r: 0.10 + day * 0.55 + dusk * 0.65, g: 0.10 + day * 0.62 + dusk * 0.28, b: 0.14 + day * 0.72 + dusk * 0.10 },
      sun: { r: 1, g: 0.85 - dusk * 0.35, b: 0.6 - dusk * 0.3 }
    };
  }
  setWeather(w) { if (w !== this.weather && this.chain.includes(w)) { this.next = w; this.blend = 0; this.stats.switches += 1; } }
  update(ctx, dt) {
    const prev = this.t;
    this.t = (this.t + dt / this.dayLength) % 1;
    if (this.t < prev) this.stats.cycles += 1;
    // weather transition blend
    if (this.blend < 1) {
      this.blend = Math.min(1, this.blend + dt / 6);
      if (this.blend >= 1) this.weather = this.next;
    }
    const target = {
      clear: { cloud: 0.1, rain: 0, fog: 0.02, wind: 2, lightning: 0 },
      overcast: { cloud: 0.7, rain: 0, fog: 0.1, wind: 4, lightning: 0 },
      rain: { cloud: 0.9, rain: 0.8, fog: 0.2, wind: 6, lightning: 0 },
      storm: { cloud: 1, rain: 1, fog: 0.3, wind: 11, lightning: 1 },
      fog: { cloud: 0.5, rain: 0, fog: 0.85, wind: 1, lightning: 0 }
    }[this.next];
    for (const k of Object.keys(target)) this.params[k] += (target[k] - this.params[k]) * Math.min(1, dt * 0.8);
    if (this.params.lightning > 0.5 && Math.random() < dt * 0.15) this.stats.strikes += 1;
  }
  /** post-process hook: night neon bloom boost */
  bloomBoost() { return this.isNight() ? 1.5 : 1.0; }
}

module.exports = { AtmosphereSystem };
