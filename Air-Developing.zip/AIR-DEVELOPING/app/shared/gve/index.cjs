/**
 * GVE — GTA-VIRTUAL-ENGINE aggregator (v1.29.0). Wires all 12 modules in
 * dependency order onto one Engine loop. createGVE() returns a runnable,
 * headless-testable world; browsers can attach a GL adapter later.
 */
const { Engine } = require('./engine.cjs');
const { RenderPipeline } = require('./render.cjs');
const { PhysicsSystem, Body, V } = require('./physics.cjs');
const { WorldStreamer } = require('./streamer.cjs');
const { PlayerController } = require('./player.cjs');
const { VehiclePhysics } = require('./vehicle.cjs');
const { CombatSystem, WEAPONS } = require('./combat.cjs');
const { TrafficAI } = require('./traffic.cjs');
const { WantedSystem } = require('./wanted.cjs');
const { AtmosphereSystem } = require('./atmosphere.cjs');
const { AudioEngine } = require('./audio.cjs');
const { UISystem } = require('./ui.cjs');
const { PedSystem } = require('./peds.cjs');
const { MissionSystem } = require('./missions.cjs');

function createGVE(opts = {}) {
  const engine = new Engine(opts);
  const render = new RenderPipeline(opts);
  const physics = new PhysicsSystem(opts);
  const streamer = new WorldStreamer({ generator: opts.generator || ((cx, cz) => [{ id: `prop-${cx}-${cz}`, x: cx * 256 + 40, z: cz * 256 + 60, asset: 'propset' }]) });
  const player = new PlayerController(physics, opts);
  const vehicle = new VehiclePhysics(physics, opts);
  const combat = new CombatSystem(physics, engine, opts);
  const traffic = new TrafficAI(physics, opts);
  const wanted = new WantedSystem(physics, traffic, opts);
  const atmo = new AtmosphereSystem(opts);
  const audio = new AudioEngine(opts);
  const ui = new UISystem(opts);
  const g = { engine, render, physics, streamer, player, vehicle, combat, traffic, wanted, atmo, audio, ui, V, WEAPONS };
  const peds = new PedSystem(g, opts.peds || {});
  const missions = new MissionSystem(g);
  g.peds = peds; g.missions = missions;

  engine.register({ id: 'physics', order: 10, fixed: (ctx, dt) => physics.fixed(ctx, dt) });
  engine.register({ id: 'player', order: 20, fixed: (ctx, dt) => player.fixed(ctx, dt), update: (ctx, dt) => player.update(ctx, dt) });
  engine.register({ id: 'vehicle', order: 30, fixed: (ctx, dt) => vehicle.fixed(ctx, dt), update: (ctx, dt) => vehicle.update(ctx, dt) });
  engine.register({ id: 'streamer', order: 40, update: (ctx, dt) => streamer.update(ctx, dt, player.body.pos) });
  engine.register({ id: 'combat', order: 50, update: (ctx, dt) => combat.update(ctx, dt) });
  engine.register({ id: 'traffic', order: 60, update: (ctx, dt) => traffic.update(ctx, dt) });
  engine.register({ id: 'peds', order: 65, update: (ctx, dt) => peds.update(ctx, dt) });
  engine.register({ id: 'missions', order: 75, update: (ctx, dt) => missions.update(ctx, dt) });
  engine.register({ id: 'wanted', order: 70, update: (ctx, dt) => wanted.update(ctx, dt, player.body, traffic.nodes) });
  engine.register({ id: 'atmosphere', order: 80, update: (ctx, dt) => atmo.update(ctx, dt) });
  engine.register({ id: 'audio', order: 90, update: (ctx, dt) => { audio.listener.pos = player.camPos || player.body.pos; audio.update(ctx, dt); } });
  engine.register({ id: 'ui', order: 100, update: (ctx, dt) => { ui.stars = wanted.stars; ui.update(ctx, dt); } });
  engine.register({ id: 'render', order: 110, update: () => render.present(1 + traffic.cars.length) });

  engine.setState('PLAY');
  return g;
}

/** GVE wired to Vice City (streamer gen + traffic graph + city spawns) */
function createViceGVE(opts = {}) {
  const g = createGVE(opts);
  require('./vicecity.cjs').attachVice(g, opts);
  return g;
}

module.exports = { createGVE, createViceGVE, Engine, RenderPipeline, PhysicsSystem, Body, WorldStreamer, PlayerController, VehiclePhysics, CombatSystem, TrafficAI, WantedSystem, AtmosphereSystem, AudioEngine, UISystem, WEAPONS, V };
