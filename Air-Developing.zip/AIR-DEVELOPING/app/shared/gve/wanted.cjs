/**
 * GVE MODULE 9 — MULTI-TIER POLICE AGGRO + TACTICAL SPAWNS (5-star FSM).
 * 1-2: localized patrol cars pathfind to player vector.
 * 3-4: pit maneuvers / aggressive ramming (intercept steering).
 * 5:   tactical roadblocks placed AHEAD of player's travel trajectory
 *      (road vector array projection). Heat decays when hidden.
 */
const { V, Body } = require('./physics.cjs');

class WantedSystem {
  constructor(physics, traffic, opts = {}) {
    this.phy = physics; this.traffic = traffic;
    this.stars = 0; this.heat = 0;
    this.maxHeat = [0, 20, 45, 80, 120, 170];
    this.units = [];                 // { body, mode: 'patrol'|'pit'|'block', target }
    this.roadblocks = [];
    this.spawnCooldown = 0;
    this.stats = { spawns: 0, pits: 0, blocks: 0, escalations: 0 };
    this.crime = { copHit: 12, shot: 6, ram: 20 };
  }
  addHeat(h) {
    this.heat += h;
    let s = 0;
    for (let i = 1; i <= 5; i += 1) if (this.heat >= this.maxHeat[i] * 0.4) s = i;
    if (s > this.stars) { this.stars = s; this.stats.escalations += 1; }
  }
  decay(dt, hidden) {
    if (hidden) this.heat = Math.max(0, this.heat - dt * 3);
    const s = this.stars;
    if (s > 0 && this.heat < this.maxHeat[s] * 0.2) this.stars = s - 1;
  }
  spawnUnit(mode, x, z) {
    const body = this.phy.add(new Body({ layer: 'vehicle', radius: 1.05, mass: 1500, friction: 0.05, pos: { x, y: 0.6, z } }));
    const u = { body, mode, cool: 0 };
    this.units.push(u);
    this.stats.spawns += 1;
    return u;
  }
  /** roadblock ahead: project player velocity onto road vector array */
  placeRoadblock(player, roadNodes) {
    const v = V.norm({ x: player.vel.x, y: 0, z: player.vel.z });
    let best = null; let bestT = -1;
    for (const n of roadNodes) {
      const to = { x: n.x - player.pos.x, z: n.z - player.pos.z };
      const d = Math.hypot(to.x, to.z);
      if (d < 12 || d > 90) continue;
      const t = (to.x * v.x + to.z * v.z) / (d || 1);
      if (t > bestT) { bestT = t; best = n; }
    }
    if (!best) return null;
    const block = { x: best.x, z: best.z, cars: 3 };
    this.roadblocks.push(block);
    for (let i = -1; i <= 1; i += 1) this.spawnUnit('block', best.x + i * 2.4, best.z + 2);
    this.stats.blocks += 1;
    return block;
  }
  update(ctx, dt, player, roadNodes) {
    this.spawnCooldown -= dt;
    const wantUnits = this.stars >= 5 ? 6 : this.stars >= 3 ? 4 : this.stars >= 1 ? 2 : 0;
    if (this.stars > 0 && this.units.length < wantUnits && this.spawnCooldown <= 0) {
      const a = Math.random() * Math.PI * 2;
      this.spawnUnit(this.stars >= 3 ? 'pit' : 'patrol', player.pos.x + Math.cos(a) * 45, player.pos.z + Math.sin(a) * 45);
      this.spawnCooldown = 2.5;
    }
    if (this.stars >= 5 && this.roadblocks.length < 2 && roadNodes && roadNodes.length) this.placeRoadblock(player, roadNodes);
    for (const u of this.units) {
      const to = V.sub(player.pos, u.body.pos);
      const d = V.len(to) || 1;
      const dir = V.scale(to, 1 / d);
      let speed = u.mode === 'pit' ? 16 : 10;
      if (u.mode === 'block') { speed = 0; }
      // pit: intercept point ahead of player velocity
      let aim = dir;
      if (u.mode === 'pit' && d > 4) {
        const lead = V.add(player.pos, V.scale(player.vel, 0.5));
        aim = V.norm(V.sub(lead, u.body.pos));
        if (d < 6) { this.stats.pits += dt; speed = 18; }   // ram window
      }
      u.body.vel.x += (aim.x * speed - u.body.vel.x) * Math.min(1, 3 * dt);
      u.body.vel.z += (aim.z * speed - u.body.vel.z) * Math.min(1, 3 * dt);
    }
  }
}

module.exports = { WantedSystem };
