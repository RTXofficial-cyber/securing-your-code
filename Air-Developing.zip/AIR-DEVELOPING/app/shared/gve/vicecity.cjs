/**
 * GVE ⇄ VICE CITY BRIDGE (v1.31.0).
 * City layout mirror of composed3d's Vice City (same zone rects/road feel)
 * as DATA, so GVE's streamer/traffic/wanted systems run on the real city:
 * road grid graph, zone rects (gym/hospital/beach/shops/landmarks),
 * deterministic chunk generator (buildings/props per chunk, seeded hash).
 */
const WORLD = 1560;
const ROAD_EVERY = 260;
const ROAD_OFF = 120;

const ZONES = [
  { id: 'gym', name: 'IRON BODY GYM', x: 420, z: 632, w: 440, h: 64, asset: 'gym' },
  { id: 'hospital', name: 'VICE GENERAL HOSPITAL', x: 180, z: 916, w: 200, h: 80, asset: 'hospital' },
  { id: 'beach', name: 'VICE BEACH', x: 880, z: 0, w: 680, h: 1560, asset: 'palm' },
  { id: 'shops', name: 'BOARDWALK SHOPS', x: 820, z: 300, w: 60, h: 900, asset: 'shop' },
  { id: 'downtown', name: 'DOWNTOWN', x: 120, z: 120, w: 600, h: 400, asset: 'tower' }
];

function hash2(a, b, i) {
  let h = (a * 374761393 + b * 668265263 + i * 1274126177) | 0;
  h = (h ^ (h >> 13)) * 1103515245 | 0;
  h = (h ^ (h >> 16)) >>> 0;
  return h / 4294967295;
}

function roadNodes() {
  const nodes = [];
  const n = Math.floor((WORLD - ROAD_OFF) / ROAD_EVERY);
  for (let iz = 0; iz <= n; iz += 1) for (let ix = 0; ix <= n; ix += 1) {
    nodes.push({ x: ROAD_OFF + ix * ROAD_EVERY, z: ROAD_OFF + iz * ROAD_EVERY, ix, iz });
  }
  return nodes;
}
function roadLinks(nodes, n) {
  // grid links: right + down neighbours
  return nodes.map((nd) => {
    const links = [];
    const r = nodes.find((o) => o.ix === nd.ix + 1 && o.iz === nd.iz);
    const d = nodes.find((o) => o.ix === nd.ix && o.iz === nd.iz + 1);
    if (r) links.push(nodes.indexOf(r));
    if (d) links.push(nodes.indexOf(d));
    return links;
  });
}
/** bidirectional link arrays for TrafficAI */
function buildRoadGraph() {
  const n = Math.floor((WORLD - ROAD_OFF) / ROAD_EVERY);
  const nodes = roadNodes();
  const links = roadLinks(nodes, n);
  // make symmetric
  for (let i = 0; i < nodes.length; i += 1) for (const j of links[i]) if (!links[j].includes(i)) links[j].push(i);
  return nodes.map((nd, i) => ({ x: nd.x, z: nd.z, links: links[i], light: (nd.ix + nd.iz) % 4 === 0 ? 'red' : null }));
}

function zoneAt(x, z) { return ZONES.find((zn) => x >= zn.x && x <= zn.x + zn.w && z >= zn.z && z <= zn.z + zn.h) || null; }
function onRoad(x, z, half = 26) {
  const mx = ((x - ROAD_OFF) % ROAD_EVERY + ROAD_EVERY) % ROAD_EVERY;
  const mz = ((z - ROAD_OFF) % ROAD_EVERY + ROAD_EVERY) % ROAD_EVERY;
  return mx < half || mx > ROAD_EVERY - half || mz < half || mz > ROAD_EVERY - half;
}

/** deterministic chunk props for WorldStreamer.generator */
function chunkGen(cx, cz) {
  const props = [];
  const x0 = cx * 256; const z0 = cz * 256;
  // road-safe placement: koi building/prop asphalt ke beech na ug jaye
  const off = (x, z, dists) => {
    if (!onRoad(x, z)) return [x, z];
    for (const d of dists) {
      for (const s of [1, -1]) {
        if (!onRoad(x + d * s, z)) return [x + d * s, z];
        if (!onRoad(x, z + d * s)) return [x, z + d * s];
      }
    }
    return null;
  };
  // guaranteed zone anchors: har zone jo chunk ko touch karta hai, uska ek
  // prop zaroor (streamed city mein gym/hospital kabhi miss na ho)
  for (const zn of ZONES) {
    if (zn.x < x0 + 256 && zn.x + zn.w > x0 && zn.z < z0 + 256 && zn.z + zn.h > z0) {
      const ax = Math.min(Math.max(zn.x + zn.w / 2, x0 + 12), x0 + 244);
      const az = Math.min(Math.max(zn.z + zn.h / 2, z0 + 12), z0 + 244);
      const oa = off(ax, az, [30, 60, 90, 120]);
      if (oa) props.push({ id: `${zn.id}-${cx}-${cz}`, x: oa[0], z: oa[1], asset: zn.asset });
    }
  }
  for (let i = 0; i < 6; i += 1) {
    const x = x0 + hash2(cx, cz, i) * 236 + 10;
    const z = z0 + hash2(cz, cx, i + 40) * 236 + 10;
    const zn = zoneAt(x, z);
    if (zn) {
      const oz = off(x, z, [26, 44, 64, 90]);
      if (oz) props.push({ id: `${zn.id}-${cx}-${cz}-${i}`, x: oz[0], z: oz[1], asset: zn.asset });
      continue;
    }
    if (onRoad(x, z)) {
      const ol = off(x, z, [12, 18, 26]);     // streetlight footpath par, asphalt par nahi
      if (ol) props.push({ id: `light-${cx}-${cz}-${i}`, x: ol[0], z: ol[1], asset: 'streetlight' });
      continue;
    }
    props.push({ id: `bld-${cx}-${cz}-${i}`, x, z, asset: hash2(cx, cz, i + 9) > 0.7 ? 'tower' : 'building' });
  }
  return props;
}

/** wire a GVE instance to Vice City: streamer gen + traffic + wanted roads */
function attachVice(g, opts = {}) {
  g.vice = { WORLD, ZONES, nodes: buildRoadGraph() };
  g.streamer.generator = chunkGen;
  // road graph -> TrafficAI waypoint network (same indices)
  for (const n of g.vice.nodes) g.traffic.addNode(n.x, n.z, n.links.slice(), n.light);
  const cars = opts.cars != null ? opts.cars : 8;
  for (let i = 0; i < cars; i += 1) {
    const ni = Math.floor(hash2(i, 7, 1) * g.vice.nodes.length);
    const c = g.traffic.spawnCar(ni);
    c.body.pos.x = g.vice.nodes[ni].x; c.body.pos.z = g.vice.nodes[ni].z;
  }
  // player + vehicle start downtown
  g.player.body.pos = { x: 250, y: 1, z: 250 };
  g.vehicle.chassis.pos = { x: 251.6, y: 0.7, z: 251.6 };   // player spawn ke bagal: F turant kaam kare
  if (g.peds && g.peds.list.length === 0) g.peds.populate(g.vice.nodes);   // bheed footpaths par
  return g.vice;
}

module.exports = { WORLD, ZONES, roadNodes, buildRoadGraph, chunkGen, zoneAt, onRoad, attachVice, hash2 };
