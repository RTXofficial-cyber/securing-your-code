/**
 * GVE RENDER3D — chase-camera 3D render of the 12-module slice (v1.32.0).
 * Reuses GameKit3D (shared/gamekit/engine3d.js — the SAME software renderer
 * the arcade 3D titles run on): perspective camera, backface culling,
 * lambert + ambient shading, distance fog, painter's-algorithm depth sort.
 * The city geometry comes from the live sim: streamed chunk props become
 * boxes, road-graph links become asphalt, traffic/police/player become
 * oriented boxes. DOM-free by design — createDraw3D() returns a function
 * (play, g, canvas, ctx) => frameInfo, so tests drive it headlessly with a
 * recording ctx and can assert on real draw calls.
 */
const vice = require('./vicecity.cjs');

function loadGK() {
  if (globalThis.GameKit3D) return globalThis.GameKit3D;
  require('../gamekit/engine3d.js');            // side effect: sets globalThis.GameKit3D
  return globalThis.GameKit3D || null;
}

/** deterministic 0..1 from a string id (stable building heights per prop) */
function idHash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i += 1) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return ((h >>> 0) % 1000) / 1000;
}

const ASSET_SIZE = {
  tower:       { w: [26, 44], h: [70, 140] },
  building:    { w: [16, 30], h: [22, 55] },
  gym:         { w: [30, 40], h: [14, 18] },
  hospital:    { w: [28, 36], h: [24, 30] },
  shop:        { w: [12, 18], h: [8, 14] },
  palm:        { w: [1.2, 1.6], h: [10, 14] },
  streetlight: { w: [0.5, 0.7], h: [8, 9.5] }
};

/**
 * Smooth chase camera. GameKit3D convention: camera looks down local -z, so
 * world forward for a yaw is (-sin yaw, -cos yaw). We want that forward to
 * match the entity's travel direction, hence wantYaw = atan2(-fx, -fz).
 * Yaw/pitch are angle-lerped so hard steering doesn't snap the view.
 */
function chaseUpdate(cam, tgt, fwd, dt, opts = {}) {
  const dist = opts.dist === undefined ? 12 : opts.dist;
  const height = opts.height === undefined ? 5 : opts.height;
  const pitch = opts.pitch === undefined ? -0.22 : opts.pitch;
  const turn = opts.turn === undefined ? 5 : opts.turn;
  const wantYaw = Math.atan2(-(fwd.x || 0), -(fwd.z || 0));
  let d = wantYaw - cam.yaw;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  const k = Math.min(1, turn * (dt || 0.016));
  cam.yaw += d * k;
  cam.pitch += (pitch - cam.pitch) * k;
  const fx = -Math.sin(cam.yaw); const fz = -Math.cos(cam.yaw);   // smoothed forward
  cam.pos[0] = tgt.x - fx * dist;
  cam.pos[1] = (tgt.y || 0) + height;
  cam.pos[2] = tgt.z - fz * dist;
  cam.fov = opts.fov === undefined ? 68 : opts.fov;
  return cam;
}

/** all visible world faces around a camera position (distance-culled) */
function buildFaces(g, camPos, K3) {
  const faces = [];
  const inRange = (x, z, r) => Math.hypot(x - camPos[0], z - camPos[2]) < r;
  const night = g.atmo.isNight();

  // ground: 520-unit tiles across the 1560 city + margin
  for (let gx = -1; gx <= 3; gx += 1) {
    for (let gz = -1; gz <= 3; gz += 1) {
      const x0 = gx * 520; const z0 = gz * 520;
      if (!inRange(x0 + 260, z0 + 260, 1600)) continue;
      faces.push(K3.groundFace(x0, z0, 520, night ? 0.1 : 0.16));
    }
  }

  // zones: tinted pads slightly above ground
  const ZC = { gym: 0.3, hospital: 0.34, beach: 0.4, shops: 0.3, downtown: 0.26 };
  for (const zn of vice.ZONES) {
    if (!inRange(zn.x + zn.w / 2, zn.z + zn.h / 2, 1400)) continue;
    const y = 0.12; const x1 = zn.x + zn.w; const z1 = zn.z + zn.h;
    faces.push({ verts: [[zn.x, y, z1], [x1, y, z1], [x1, y, zn.z], [zn.x, y, zn.z]], color: ZC[zn.id] || 0.3 });
  }

  // roads: asphalt boxes between linked nodes + intersection pads
  const nodes = g.vice.nodes;
  for (let i = 0; i < nodes.length; i += 1) {
    const n = nodes[i];
    if (inRange(n.x, n.z, 900)) faces.push(...K3.boxFaces(n.x - 9, 0.05, n.z - 9, 18, 0.3, 18, night ? 0.14 : 0.2));
    for (const j of n.links) {
      if (j <= i) continue;                    // each link once
      const o = nodes[j];
      const mx = (n.x + o.x) / 2; const mz = (n.z + o.z) / 2;
      if (!inRange(mx, mz, 900)) continue;
      const dx = Math.abs(o.x - n.x); const dz = Math.abs(o.z - n.z);
      if (dx >= dz) faces.push(...K3.boxFaces(Math.min(n.x, o.x) - 8, 0.05, n.z - 8, dx + 16, 0.3, 16, night ? 0.13 : 0.19));
      else faces.push(...K3.boxFaces(n.x - 8, 0.05, Math.min(n.z, o.z) - 8, 16, 0.3, dz + 16, night ? 0.13 : 0.19));
    }
    if (n.light) {                             // signal pole at lit intersections
      if (inRange(n.x, n.z, 700)) faces.push(...K3.boxFaces(n.x + 7, 0.3, n.z + 7, 0.7, 7, 0.7, 0.55));
    }
  }

  // streamed buildings/props — live chunks only, exactly what the streamer loaded
  for (const ch of g.streamer.chunks.values()) {
    for (const p of ch.props) {
      if (!inRange(p.x, p.z, 800)) continue;
      const a = ASSET_SIZE[p.asset] || ASSET_SIZE.building;
      const t = idHash(p.id || `${p.x}:${p.z}`);
      const w = a.w[0] + (a.w[1] - a.w[0]) * t;
      const h = a.h[0] + (a.h[1] - a.h[0]) * idHash(`${p.id}h`);
      faces.push(...K3.boxFaces(p.x - w / 2, 0.2, p.z - w / 2, w, h, w, 0.42 + t * 0.4));
    }
  }

  // oriented box helper (car length along local +x, rotated to heading)
  const carBox = (x, y, z, ang, base) => {
    if (!inRange(x, z, 700)) return;
    for (const f of K3.boxFaces(x - 2.3, y, z - 1.1, 4.6, 1.4, 2.2, base)) faces.push(K3.rotateFaceY(f, x, z, ang));
  };

  // traffic: face toward the car's next graph node
  for (const c of g.traffic.cars) {
    const p = c.body.pos; const nx = nodes[c.next] || nodes[c.node] || p;
    const ang = Math.atan2(nx.z - p.z, nx.x - p.x);
    carBox(p.x, p.y + 0.2, p.z, ang, c.panic > 0 ? 0.95 : 0.72);
  }
  // police units (wanted module)
  for (const u of g.wanted.units) {
    const p = u.body.pos; const v = u.body.vel || { x: 0, z: 1 };
    carBox(p.x, p.y + 0.2, p.z, Math.atan2(v.z, v.x), g.wanted.stars >= 3 ? 0.98 : 0.6);
  }
  // player vehicle + on-foot player
  if (g.vehicle.enterState !== 'out') {
    const p = g.vehicle.chassis.pos;
    carBox(p.x, p.y, p.z, Math.atan2(Math.cos(g.vehicle.heading), Math.sin(g.vehicle.heading)), 0.92);
  }
  if (g.vehicle.enterState !== 'in') {
    const p = g.player.body.pos;
    faces.push(...K3.boxFaces(p.x - 0.45, p.y, p.z - 0.45, 0.9, 1.8, 0.9, 0.95));
  }
  return faces;
}

/** renderer factory: one persistent chase cam; call the returned fn per frame */
function createDraw3D(opts = {}) {
  const cam = { pos: [0, 5, 0], yaw: 0, pitch: -0.22, fov: 68 };
  let seeded = false;
  return function draw3d(play, g, canvas, ctx) {
    const K3 = loadGK();
    const W = canvas.width; const H = canvas.height;
    if (!K3) { ctx.fillStyle = '#fff'; ctx.fillText('engine3d.js missing', W / 2, H / 2); return { drawn: 0, faces: 0 }; }
    const inVeh = g.vehicle.enterState === 'in';
    const tgt = inVeh ? g.vehicle.chassis.pos : g.player.body.pos;
    const fwd = inVeh
      ? { x: Math.sin(g.vehicle.heading), z: Math.cos(g.vehicle.heading) }
      : g.player.forward();
    if (!seeded) { cam.yaw = Math.atan2(-fwd.x, -fwd.z); seeded = true; }   // no first-frame swing
    chaseUpdate(cam, tgt, fwd, play.lastDt === undefined ? 0.016 : play.lastDt, {
      dist: inVeh ? 13 : 9, height: inVeh ? 5.4 : 4.2, pitch: inVeh ? -0.2 : -0.26
    });
    const night = g.atmo.isNight();
    ctx.fillStyle = night ? '#07070c' : '#101418';
    ctx.fillRect(0, 0, W, H);
    const camera = {
      pos: cam.pos, yaw: cam.yaw, pitch: cam.pitch,
      fov: cam.fov, aspect: W / H, near: 0.4, far: 2400, width: W, height: H
    };
    const faces = buildFaces(g, cam.pos, K3);
    const res = K3.renderScene(ctx, {
      camera, faces,
      light: [-0.45, 0.82, -0.38],
      ambient: night ? 0.16 : 0.34,
      fogNear: 200, fogFar: 950,
      fogColor: night ? [7, 7, 12] : [16, 20, 24]
    });
    // rain overlay (screen space streaks)
    if (g.atmo.params.rain > 0.3) {
      ctx.strokeStyle = 'rgba(160,190,255,0.35)';
      for (let i = 0; i < 50; i += 1) {
        const rx = (i * 97 + play.draws * 13) % W; const ry = (i * 57 + play.draws * 29) % H;
        ctx.beginPath(); ctx.moveTo(rx, ry); ctx.lineTo(rx - 3, ry + 9); ctx.stroke();
      }
    }
    // HUD
    const spd = inVeh ? g.vehicle.speed() : Math.hypot(g.player.body.vel.x, g.player.body.vel.z);
    ctx.fillStyle = '#f4f3ef';
    ctx.font = '12px monospace';
    ctx.fillText(`GVE VICE CITY 3D  ${night ? 'NIGHT' : 'DAY'} ${g.atmo.weather.toUpperCase()}  stars:${'*'.repeat(g.wanted.stars)}  speed:${spd.toFixed(1)}  chunks:${g.streamer.chunks.size}  faces:${res.drawn}/${faces.length}  ${inVeh ? 'DRIVING (F=exit)' : 'ON FOOT (F=enter car, SPACE=shoot)'}${play.paused ? '  PAUSED' : ''}`, 10, 18);
    return { drawn: res.drawn, culled: res.culled, faces: faces.length, cam: { pos: cam.pos.slice(), yaw: cam.yaw, pitch: cam.pitch } };
  };
}

module.exports = { loadGK, idHash, chaseUpdate, buildFaces, createDraw3D };
