/**
 * GVE MODULE 1 — CORE ENGINE LOOP & STATE MANAGER (vanilla JS, no deps).
 * Fixed physics timestep (1/60) + variable render dt, accumulator pattern
 * (clipping-safe), module registry in dependency order, object pooling,
 * memory budget tracking. Headless-testable: rAF injectable.
 */
const FIXED_DT = 1 / 60;
const MAX_FRAME = 0.25;           // spiral-of-death guard
const STATES = ['BOOT', 'MENU', 'PLAY', 'PAUSE', 'OVER'];

class Pool {
  constructor(factory, reset, initial = 32) {
    this.factory = factory; this.reset = reset;
    this.free = []; this.live = 0; this.created = 0; this.reused = 0;
    for (let i = 0; i < initial; i += 1) this.free.push(factory());
    this.created = initial;
  }
  acquire() {
    const o = this.free.length ? (this.reused += 1, this.free.pop()) : (this.created += 1, this.factory());
    this.reset(o); this.live += 1; return o;
  }
  release(o) { if (this.live > 0) this.live -= 1; this.free.push(o); }
  stats() { return { free: this.free.length, live: this.live, created: this.created, reused: this.reused }; }
}

class Engine {
  constructor(opts = {}) {
    this.state = 'BOOT';
    this.time = 0; this.frame = 0; this.accumulator = 0;
    this.fixedDt = FIXED_DT;
    this.fixedSteps = 0; this.renderCalls = 0;
    this.modules = [];            // { id, update(g, dt), order }
    this.pools = {};
    this.disposed = 0;
    this.raf = opts.raf || null;  // injectable for headless/tests
    this.listeners = { state: [] };
  }
  setState(s) {
    if (!STATES.includes(s) || s === this.state) return false;
    const prev = this.state; this.state = s;
    this.listeners.state.forEach((f) => f(prev, s));
    return true;
  }
  onState(f) { this.listeners.state.push(f); }
  register(mod) {
    if (!mod || !mod.id) throw new Error('module needs id');
    this.modules.push(mod);
    this.modules.sort((a, b) => (a.order || 50) - (b.order || 50));
    return mod;
  }
  pool(name, factory, reset, initial) {
    if (!this.pools[name]) this.pools[name] = new Pool(factory, reset, initial);
    return this.pools[name];
  }
  /** one rendered frame: dt clamp + fixed-step physics updates + module tick */
  tick(rawDt, ctx) {
    const dt = Math.min(Math.max(rawDt || 0, 0), MAX_FRAME);
    this.renderCalls += 1;
    if (this.state === 'PAUSE') return { steps: 0, dt };
    this.accumulator += dt;
    let steps = 0;
    while (this.accumulator >= this.fixedDt && steps < 8) {
      this.time += this.fixedDt; this.fixedSteps += 1; steps += 1;
      for (const m of this.modules) if (m.fixed) m.fixed(ctx, this.fixedDt);
      this.accumulator -= this.fixedDt;
    }
    this.frame += 1;
    for (const m of this.modules) if (m.update) m.update(ctx, dt);
    return { steps, dt };
  }
  /** run N seconds of simulated time (headless harness helper) */
  run(seconds, ctx, frameDt = 1 / 60) {
    const n = Math.round(seconds / frameDt);
    let total = 0;
    for (let i = 0; i < n; i += 1) total += this.tick(frameDt, ctx).steps;
    return total;
  }
  poolStats() {
    const out = {};
    for (const k of Object.keys(this.pools)) out[k] = this.pools[k].stats();
    return out;
  }
  dispose() { this.modules = []; this.pools = {}; this.disposed += 1; }
}

module.exports = { Engine, Pool, FIXED_DT, STATES };
