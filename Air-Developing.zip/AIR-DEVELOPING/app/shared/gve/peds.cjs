/**
 * GVE Peds — Vice City ki bheed (v1.33.0). GTA-style pedestrian system:
 * sidewalk waypoints par chalne wale NPCs, gunfire/tez gaadi se panic ho kar
 * bhaagte hain, goli lagne par girte hain. Physics layer 'ped' (matrix mein
 * pehle se wired) — cars inse takrate hain, player inhe dhakka deta hai.
 * Combat integration: fire() wrapper hit.body.layer==='ped' par hp kaatta
 * hai, isliye koi bhi weapon (on-foot ya drive-by) inhe lagta hai.
 */
const { Body } = require('./physics.cjs');

const WALK = 1.4;
const FLEE = 3.4;

function hashN(seed, i) {
  let h = (seed * 374761393 + i * 668265263) | 0;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) % 1000 / 1000;
}

class PedSystem {
  constructor(g, opts = {}) {
    this.g = g;
    this.count = opts.count || 96;
    this.list = [];
    this.stats = { fled: 0, downed: 0, spawns: 0 };
    this.seed = opts.seed || 7;
    // combat wrapper: ped bodies ko damage mile (fire() ka return hit.body)
    const combat = g.combat;
    const orig = combat.fire.bind(combat);
    combat.fire = (o, d, dt, tf) => {
      const r = orig(o, d, dt, tf);
      if (r && r.hit && r.hit.layer === 'ped' && r.hit.ped) {
        r.hit.ped.hp -= r.dmg || 10;
        if (r.hit.ped.hp <= 0 && r.hit.ped.state !== 'down') this.down(r.hit.ped);
      }
      if (combat.weapon().id !== 'fist') this.panicAt(o.x, o.z, 45);
      return r;
    };
  }

  /** sidewalk spawn: road node ke kinare, asphalt se off */
  spawnAt(x, z, i) {
    const body = this.g.physics.add(new Body({
      layer: 'ped', radius: 0.5, mass: 70, friction: 0.4,
      pos: { x, y: 0.45, z }
    }));
    const ped = {
      body, hp: 100, state: 'walk', t: 0, i: i || 0,
      tx: x, tz: z, panic: 0, shade: 0.4 + hashN(this.seed, i || 0) * 0.5
    };
    body.ped = ped;
    this.pickTarget(ped);
    this.list.push(ped);
    this.stats.spawns += 1;
    return ped;
  }

  populate(nodes) {
    const OFF = [[12, 0], [-12, 0], [0, 12], [0, -12]];   // char footpath corners
    for (let i = 0; i < this.count; i += 1) {
      const n = nodes[i % nodes.length];
      const o = OFF[Math.floor(i / nodes.length) % OFF.length];
      this.spawnAt(n.x + o[0], n.z + o[1], i);
    }
  }

  pickTarget(ped) {
    if (!this.g.vice || !this.g.vice.nodes || !this.g.vice.nodes.length) return;
    const n = this.g.vice.nodes[Math.floor(hashN(this.seed + ped.i, Math.floor(ped.t * 3 + ped.i * 7)) * this.g.vice.nodes.length)];
    const side = (hashN(ped.i, 9) > 0.5 ? 1 : -1) * 12;
    ped.tx = n.x + (hashN(ped.i, 3) > 0.5 ? side : 0);
    ped.tz = n.z + (hashN(ped.i, 3) > 0.5 ? 0 : side);
  }

  down(ped) {
    ped.state = 'down';
    ped.t = 0;
    this.stats.downed += 1;
    this.g.wanted.addHeat(30);                          // witness-free nahi: heat
  }

  /** gunfire/panic source se bheed bhaago */
  panicAt(x, z, radius = 45) {
    for (const ped of this.list) {
      if (ped.state === 'down') continue;
      const d = Math.hypot(ped.body.pos.x - x, ped.body.pos.z - z);
      if (d < radius) {
        ped.state = 'flee'; ped.panic = 6;
        ped.fx = (ped.body.pos.x - x) / (d || 1);
        ped.fz = (ped.body.pos.z - z) / (d || 1);
        this.stats.fled += 1;
      }
    }
  }

  update(ctx, dt) {
    const g = this.g;
    const vp = g.vehicle.enterState === 'in' ? g.vehicle.chassis.pos : null;
    const vspeed = vp ? g.vehicle.speed() : 0;
    for (const ped of this.list) {
      ped.t += dt;
      if (ped.state === 'down') {
        ped.body.vel.x *= 0.8; ped.body.vel.z *= 0.8;
        if (ped.t > 25) {                               // ambulance le gayi: respawn
          const n = g.vice.nodes[ped.i % g.vice.nodes.length];
          ped.body.pos = { x: n.x + 12, y: 0.45, z: n.z + 12 };
          ped.hp = 100; ped.state = 'walk'; ped.t = 0;
          this.pickTarget(ped);
        }
        continue;
      }
      // tez gaadi paas se guzre to panic
      if (vp && vspeed > 6 && ped.state !== 'flee') {
        const d = Math.hypot(ped.body.pos.x - vp.x, ped.body.pos.z - vp.z);
        if (d < 7) { ped.state = 'flee'; ped.panic = 4; ped.fx = (ped.body.pos.x - vp.x) / (d || 1); ped.fz = (ped.body.pos.z - vp.z) / (d || 1); this.stats.fled += 1; }
      }
      if (ped.state === 'flee') {
        ped.panic -= dt;
        if (ped.panic <= 0) { ped.state = 'walk'; this.pickTarget(ped); }
        ped.body.vel.x = ped.fx * FLEE; ped.body.vel.z = ped.fz * FLEE;
      } else {
        const dx = ped.tx - ped.body.pos.x; const dz = ped.tz - ped.body.pos.z;
        const d = Math.hypot(dx, dz);
        if (d < 2) this.pickTarget(ped);
        else { ped.body.vel.x = (dx / d) * WALK; ped.body.vel.z = (dz / d) * WALK; }
      }
    }
  }
}

module.exports = { PedSystem, WALK, FLEE };
