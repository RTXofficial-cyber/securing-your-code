/**
 * GVE MODULE 5 — THIRD-PERSON CHARACTER CONTROLLER + ANIM STATE MACHINE.
 * Capsule body on PhysicsSystem; input map WASD/Space/Shift/Ctrl; states
 * IDLE/WALK/SPRINT/JUMP/FALL/CROUCH with entry/exit rules; orbital
 * over-the-shoulder camera via manual quaternion math (yaw*pitch, slerp).
 */
const { V } = require('./physics.cjs');
const PSTATES = ['IDLE', 'WALK', 'SPRINT', 'JUMP', 'FALL', 'CROUCH'];

function quatFromYawPitch(yaw, pitch) {
  const cy = Math.cos(yaw * 0.5); const sy = Math.sin(yaw * 0.5);
  const cp = Math.cos(pitch * 0.5); const sp = Math.sin(pitch * 0.5);
  return { w: cy * cp, x: sy * sp, y: sy * cp, z: -cy * sp };   // Y-up yaw * X pitch
}
function quatMul(a, b) {
  return {
    w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
    x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
    y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
    z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w
  };
}
function quatSlerp(a, b, t) {
  let dot = a.w * b.w + a.x * b.x + a.y * b.y + a.z * b.z;
  let bb = b;
  if (dot < 0) { dot = -dot; bb = { w: -b.w, x: -b.x, y: -b.y, z: -b.z }; }
  if (dot > 0.9995) {
    const r = { w: a.w + (bb.w - a.w) * t, x: a.x + (bb.x - a.x) * t, y: a.y + (bb.y - a.y) * t, z: a.z + (bb.z - a.z) * t };
    const l = Math.hypot(r.w, r.x, r.y, r.z) || 1;
    return { w: r.w / l, x: r.x / l, y: r.y / l, z: r.z / l };
  }
  const th = Math.acos(Math.max(-1, Math.min(1, dot)));
  const s = Math.sin(th);
  const wa = Math.sin((1 - t) * th) / s; const wb = Math.sin(t * th) / s;
  return { w: a.w * wa + bb.w * wb, x: a.x * wa + bb.x * wb, y: a.y * wa + bb.y * wb, z: a.z * wa + bb.z * wb };
}

class PlayerController {
  constructor(physics, opts = {}) {
    this.phy = physics;
    this.walk = opts.walk || 2.2; this.sprint = opts.sprint || 5.2; this.crouch = opts.crouch || 1.1;
    this.jumpVel = opts.jumpVel || 4.6;
    this.accel = opts.accel || 24;
    this.state = 'IDLE';
    this.stateTime = 0;
    this.yaw = 0; this.pitch = -0.25;
    this.camQuat = quatFromYawPitch(this.yaw, this.pitch);
    this.camDist = opts.camDist || 3.4; this.camHeight = opts.camHeight || 1.5;
    this.camSmooth = opts.camSmooth || 12;
    this.input = { f: 0, r: 0, jump: false, sprint: false, crouch: false };
    this.body = physics.add(new (require('./physics.cjs').Body)({ layer: 'player', radius: 0.45, capsule: { height: 1.8 }, mass: 78, friction: 0.05, pos: { x: 0, y: 1, z: 0 } }));
    this.history = [];
  }
  setInput(i) { Object.assign(this.input, i); }
  mouseLook(dyaw, dpitch) {
    this.yaw += dyaw;
    this.pitch = Math.max(-1.2, Math.min(0.9, this.pitch + dpitch));
  }
  next() {
    const b = this.body;
    const moving = Math.abs(this.input.f) + Math.abs(this.input.r) > 0.1;
    if (!b.grounded && b.vel.y < -1) return 'FALL';
    if (!b.grounded && b.vel.y >= -1) return this.state === 'FALL' ? 'FALL' : 'JUMP';
    if (this.input.crouch) return 'CROUCH';
    if (this.input.jump && b.grounded) return 'JUMP';
    if (!moving) return 'IDLE';
    return this.input.sprint ? 'SPRINT' : 'WALK';
  }
  fixed(ctx, dt) {
    const b = this.body;
    const want = this.next();
    if (want !== this.state) { this.state = want; this.stateTime = 0; this.history.push(want); if (this.history.length > 60) this.history.shift(); }
    this.stateTime += dt;
    const speed = this.state === 'SPRINT' ? this.sprint : this.state === 'CROUCH' ? this.crouch : this.walk;
    // wish dir from camera yaw
    const sy = Math.sin(this.yaw); const cy = Math.cos(this.yaw);
    const wish = V.norm({ x: (sy * this.input.f) + (cy * this.input.r), y: 0, z: (cy * this.input.f) - (sy * this.input.r) });
    const target = V.scale(wish, speed);
    const k = Math.min(1, this.accel * dt);
    b.vel.x += (target.x - b.vel.x) * k;
    b.vel.z += (target.z - b.vel.z) * k;
    if (this.input.jump && b.grounded) { b.vel.y = this.jumpVel; b.grounded = false; }
    this.input.jump = false;
  }
  update(ctx, dt) {
    // orbital over-the-shoulder camera: target quat slerp
    const target = quatFromYawPitch(this.yaw, this.pitch);
    this.camQuat = quatSlerp(this.camQuat, target, Math.min(1, this.camSmooth * dt));
    // camera position behind capsule using quat forward
    const f = this.forward();
    this.camPos = {
      x: this.body.pos.x - f.x * this.camDist,
      y: this.body.pos.y + this.camHeight - f.y * this.camDist * -1,
      z: this.body.pos.z - f.z * this.camDist
    };
  }
  forward() {
    // quat -> forward vector (manual)
    const q = this.camQuat;
    return V.norm({
      x: 2 * (q.x * q.z + q.w * q.y) * -1,
      y: 2 * (q.y * q.z - q.w * q.x),
      z: 1 - 2 * (q.x * q.x + q.y * q.y)
    });
  }
}

module.exports = { PlayerController, quatFromYawPitch, quatMul, quatSlerp, PSTATES };
