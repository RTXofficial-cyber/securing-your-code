/**
 * GVE MODULE 7 — RAYCAST COMBAT + WEAPON WHEEL.
 * Screen-center ray from camera quat; hitbox-layer evaluation via
 * PhysicsSystem.raycast; bullet-impact particle POOL; kinetic force vectors
 * applied to hit bodies; recoil + spread per weapon profile; wheel slots.
 */
const { V } = require('./physics.cjs');

const WEAPONS = [
  { id: 'fist', name: 'FISTS', dmg: 8, rpm: 120, spread: 0, range: 2, pellets: 1, impulse: 4 },
  { id: 'pistol', name: 'PISTOL', dmg: 26, rpm: 300, spread: 0.008, range: 90, pellets: 1, impulse: 30 },
  { id: 'smg', name: 'SMG', dmg: 17, rpm: 800, spread: 0.02, range: 70, pellets: 1, impulse: 18 },
  { id: 'rifle', name: 'ASSAULT RIFLE', dmg: 30, rpm: 620, spread: 0.014, range: 120, pellets: 1, impulse: 34 }
];

class CombatSystem {
  constructor(physics, engine, opts = {}) {
    this.phy = physics; this.engine = engine;
    this.slot = 1;
    this.ammo = { pistol: 60, smg: 120, rifle: 90 };
    this.cooldown = 0;
    this.recoil = 0;
    this.hits = 0; this.shots = 0;
    this.impacts = engine.pool('impacts', () => ({ x: 0, y: 0, z: 0, life: 0, nx: 0, ny: 1, nz: 0 }), (o) => { o.life = 0; });
    this.tracers = engine.pool('tracers', () => ({ x1: 0, y1: 0, z1: 0, x2: 0, y2: 0, z2: 0, life: 0 }), (o) => { o.life = 0; });
    this.log = [];
  }
  wheel(dir) { this.slot = (this.slot + (dir || 1) + WEAPONS.length) % WEAPONS.length; return WEAPONS[this.slot]; }
  weapon() { return WEAPONS[this.slot]; }
  fire(origin, dirVec, dt, targetFilter) {
    const w = this.weapon();
    if (this.cooldown > 0) return null;
    if (w.id !== 'fist' && (this.ammo[w.id] || 0) <= 0) return { dry: true };
    this.cooldown = 60 / w.rpm;
    if (w.id !== 'fist') this.ammo[w.id] -= 1;
    this.shots += 1;
    const d = V.norm(dirVec);
    // spread cone (manual)
    const s = w.spread;
    d.x += (Math.random() - 0.5) * s; d.y += (Math.random() - 0.5) * s; d.z += (Math.random() - 0.5) * s;
    const dn = V.norm(d);
    const hit = this.phy.raycast(origin, dn, w.range, targetFilter || ((b) => b.layer !== 'bullet' && b.layer !== 'player'));
    const end = hit ? hit.point : V.add(origin, V.scale(dn, w.range));
    const tr = this.tracers.acquire();
    tr.x1 = origin.x; tr.y1 = origin.y; tr.z1 = origin.z; tr.x2 = end.x; tr.y2 = end.y; tr.z2 = end.z; tr.life = 0.09;
    this.recoil = Math.min(0.35, this.recoil + 0.06 + w.impulse * 0.001);
    if (hit) {
      this.hits += 1;
      // kinetic force vector onto hit body
      if (!hit.body.static) hit.body.vel = V.add(hit.body.vel, V.scale(dn, w.impulse / hit.body.mass));
      const im = this.impacts.acquire();
      im.x = end.x; im.y = end.y; im.z = end.z; im.life = 0.5;
      im.nx = -dn.x; im.ny = -dn.y; im.nz = -dn.z;
      this.log.push({ t: 'hit', layer: hit.body.layer, dmg: w.dmg });
      if (this.log.length > 40) this.log.shift();
      return { hit: hit.body, dmg: w.dmg, point: end };
    }
    return { hit: null };
  }
  update(ctx, dt) {
    this.cooldown = Math.max(0, this.cooldown - dt);
    this.recoil = Math.max(0, this.recoil - dt * 1.4);
    for (const p of this.impacts.free.concat([])) {} // no-op keep pool shape
    // age live impacts/tracers via pool scan
    const age = (pool) => {
      for (let i = pool.free.length - 1; i >= 0; i -= 1) {
        const o = pool.free[i];
        if (o.life > 0) { o.life -= dt; }
      }
    };
    age(this.impacts); age(this.tracers);
  }
}

module.exports = { CombatSystem, WEAPONS };
