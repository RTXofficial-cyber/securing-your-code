/**
 * GVE MISSIONS — GTA-style mission chain (v1.33.0). Contact-point offers
 * (marker ke upar chalo → mission shuru), phase-based objectives (goto /
 * enter vehicle / kill targets / collect pickups / escape heat), timer
 * fails, cash rewards, pass/fail text. Story original hai (Vice City
 * homage: dual protagonists "J" aur "Lucia-annalog" Marisol) — systems
 * GTA-jaise, content apna.
 */
const { Body } = require('./physics.cjs');

const MISSIONS = [
  {
    title: 'FIRST WORDS', reward: 500, offer: { x: 262, z: 262 },
    brief: 'J: "Sheher naya, kaam purana. Gym mein contact mila hai — phir gaadi nikaalo beach ki taraf."',
    phases: [
      { type: 'goto', pos: { x: 500, z: 660 }, r: 5, label: 'IRON BODY GYM pahuncho (on foot)' },
      { type: 'enter', label: 'kisi gaadi mein betho (F)' },
      { type: 'goto', pos: { x: 1160, z: 780 }, r: 8, label: 'beach parking par pahuncho' }
    ]
  },
  {
    title: 'BOARDWALK BUST', reward: 1200, offer: { x: 1160, z: 780 },
    brief: 'Marisol: "Boardwalk par rival crew mal dhoka de rahi hai. Teen ko giraao, phir niklo."',
    phases: [
      { type: 'kill', count: 3, at: { x: 850, z: 600 }, label: 'rival crew giraao (3)' },
      { type: 'goto', pos: { x: 850, z: 1000 }, r: 6, label: 'boardwalk south marker par pahuncho' }
    ]
  },
  {
    title: 'AMBULANCE RUN', reward: 1500, offer: { x: 850, z: 1000 },
    brief: 'Dispatch: "Zakhami boardwalk se Vice General pahunchna hai — 60 second. Gaadi bhaago!"',
    phases: [
      { type: 'enter', label: 'gaadi mein betho (F)' },
      { type: 'goto', pos: { x: 280, z: 950 }, r: 10, time: 60, label: 'HOSPITAL pahuncho (60s)' }
    ]
  },
  {
    title: 'COURIER NIGHT', reward: 2000, offer: { x: 280, z: 950 },
    brief: 'J: "Teen package, sheher ke teen kone. Chhoona mat, sirf uthana."',
    phases: [
      { type: 'collect', count: 3, at: [{ x: 640, z: 380 }, { x: 380, z: 900 }, { x: 1160, z: 380 }], label: 'packages uthao (3)' }
    ]
  },
  {
    title: 'GYM RAT', reward: 2500, offer: { x: 1160, z: 380 },
    brief: 'Coach: "Speed test. Teen checkpoint, paanv se, 90 second. Saans sambhal."',
    phases: [
      { type: 'goto', pos: { x: 500, z: 660 }, r: 5, time: 90, label: 'checkpoint 1: gym' },
      { type: 'goto', pos: { x: 640, z: 120 }, r: 5, label: 'checkpoint 2: downtown north' },
      { type: 'goto', pos: { x: 420, z: 640 }, r: 5, label: 'checkpoint 3: gym west' }
    ]
  },
  {
    title: 'LAST LIGHT', reward: 5000, offer: { x: 420, z: 640 },
    brief: 'Marisol: "Aakhri kaam. Do guard, phir heat ko chakma — jab tak sitare zero na hon, mat rukna."',
    phases: [
      { type: 'kill', count: 2, at: { x: 640, z: 640 }, label: 'guards giraao (2)' },
      { type: 'escape', label: 'heat se niklo (sitare zero)' },
      { type: 'goto', pos: { x: 250, z: 250 }, r: 6, label: 'safehouse pahuncho' }
    ]
  }
];

class MissionSystem {
  constructor(g) {
    this.g = g;
    this.list = MISSIONS;
    this.offerIdx = 0;
    this.state = 'offer';            // offer | active
    this.idx = -1; this.phase = 0;
    this.cash = 0;
    this.text = ''; this.textT = 0;
    this.timer = 0;
    this.targets = []; this.pickups = [];
    this.stats = { done: 0, failed: 0 };
  }

  current() { return this.idx >= 0 ? MISSIONS[this.idx] : null; }
  objective() {
    const m = this.current();
    if (!m) return `NEXT JOB: ${MISSIONS[this.offerIdx % MISSIONS.length].title} (marker par jao)`;
    const ph = m.phases[this.phase];
    return `${m.title}: ${ph.label}${this.timer > 0 ? ` [${Math.ceil(this.timer)}s]` : ''}`;
  }
  blip() {
    const m = this.current();
    if (this.state === 'offer') return MISSIONS[this.offerIdx % MISSIONS.length].offer;
    const ph = m.phases[this.phase];
    if (ph.type === 'goto') return ph.pos;
    if (ph.type === 'kill' || ph.type === 'collect') return ph.at && ph.at.x !== undefined ? ph.at : (this.targets[0] ? this.targets[0].body.pos : null);
    return null;
  }
  say(t, secs = 6) { this.text = t; this.textT = secs; }

  start(i) {
    this.idx = i; this.phase = 0; this.state = 'active';
    const m = MISSIONS[i];
    this.say(`${m.title} — ${m.brief}`, 8);
    this.beginPhase();
  }

  beginPhase() {
    const m = this.current(); const ph = m.phases[this.phase];
    this.timer = ph.time || 0;
    this.targets = []; this.pickups = [];
    if (ph.type === 'kill' && this.g.peds) {
      for (let k = 0; k < ph.count; k += 1) {
        const p = this.g.peds.spawnAt(ph.at.x + (k - 1) * 4, ph.at.z + (k % 2) * 4, 100 + k);
        p.missionTarget = true; p.state = 'walk';
        this.targets.push(p);
      }
    }
    if (ph.type === 'collect') {
      for (const pos of ph.at) {
        const b = this.g.physics.add(new Body({ layer: 'pickup', radius: 1, mass: 1, static: true, pos: { x: pos.x, y: 1, z: pos.z } }));
        b.pickup = true;
        this.pickups.push(b);
      }
    }
  }

  focus() {
    const g = this.g;
    return g.vehicle.enterState === 'in' ? g.vehicle.chassis.pos : g.player.body.pos;
  }

  completePhase() {
    for (const b of this.pickups) this.g.physics.remove(b);
    this.pickups = [];
    const m = this.current();
    this.phase += 1;
    if (this.phase >= m.phases.length) {
      this.cash += m.reward;
      this.stats.done += 1;
      this.say(`MISSION PASS — ${m.title} (+$${m.reward})`, 7);
      this.state = 'offer';
      this.offerIdx = this.idx + 1;
      this.idx = -1;
      return;
    }
    this.beginPhase();
  }

  fail(reason) {
    this.stats.failed += 1;
    this.say(`MISSION FAIL — ${reason}`, 6);
    for (const b of this.pickups) this.g.physics.remove(b);
    this.pickups = []; this.targets = [];
    this.state = 'offer';
    this.offerIdx = this.idx >= 0 ? this.idx : this.offerIdx;   // wahi mission dobara
    this.idx = -1;
  }

  update(ctx, dt) {
    if (this.textT > 0) this.textT -= dt;
    const f = this.focus();
    if (this.state === 'offer') {
      const o = MISSIONS[this.offerIdx % MISSIONS.length].offer;
      if (Math.hypot(f.x - o.x, f.z - o.z) < 3) this.start(this.offerIdx % MISSIONS.length);
      return;
    }
    const m = this.current(); const ph = m.phases[this.phase];
    if (this.timer > 0) {
      this.timer -= dt;
      if (this.timer <= 0) { this.fail('waqt khatam'); return; }
    }
    switch (ph.type) {
      case 'goto':
        if (Math.hypot(f.x - ph.pos.x, f.z - ph.pos.z) < ph.r) this.completePhase();
        break;
      case 'enter':
        if (this.g.vehicle.enterState === 'in') this.completePhase();
        break;
      case 'kill':
        if (this.targets.filter((t) => t.state === 'down').length >= ph.count) this.completePhase();
        break;
      case 'collect': {
        for (let i = this.pickups.length - 1; i >= 0; i -= 1) {
          const b = this.pickups[i];
          if (Math.hypot(f.x - b.pos.x, f.z - b.pos.z) < 3) { this.g.physics.remove(b); this.pickups.splice(i, 1); }
        }
        if (this.pickups.length === 0) this.completePhase();
        break;
      }
      case 'escape':
        if (this.g.wanted.stars === 0 && this.g.wanted.heat < 5) this.completePhase();
        break;
      default:
        this.completePhase();
    }
  }
}

module.exports = { MissionSystem, MISSIONS };
