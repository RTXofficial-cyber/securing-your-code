/**
 * AIR BRAIN — MULTI-AGENT SUPERVISOR (v1.37.0). Blueprint ka "multi-agent
 * supervisor": ek goal lo, chaar agent phases chalo (research → plan →
 * execute → review), har phase apne mode wala AIEngine use karta hai aur
 * supervisor journal rakhta hai. Execute phase offline engine ke asli
 * action-blocks (action:write_file {...}) ko task-dir mein chalata hai —
 * bahar filesystem ko touch nahi karta (permission boundary). Review phase
 * har likhi hui file ko `node --check` se verify karta hai.
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const { AIEngine } = require('./brain.cjs');

/** action-block parser: string-aware brace matching (code ke braces JSON mein hote hain) */
function parseActions(reply) {
  const out = [];
  const text = String(reply || '');
  const re = /action:(\w+)/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    let i = text.indexOf('{', re.lastIndex);
    if (i < 0) break;
    let depth = 0; let inStr = false; let esc = false; let end = -1;
    for (let j = i; j < text.length; j += 1) {
      const ch = text[j];
      if (inStr) {
        if (esc) esc = false;
        else if (ch === '\\') esc = true;
        else if (ch === '"') inStr = false;
      } else if (ch === '"') inStr = true;
      else if (ch === '{') depth += 1;
      else if (ch === '}') { depth -= 1; if (depth === 0) { end = j; break; } }
    }
    if (end < 0) break;
    try { out.push({ tool: m[1], args: JSON.parse(text.slice(i, end + 1)) }); } catch { /* malformed */ }
    re.lastIndex = end + 1;
  }
  return out;
}

async function runTask(goal, opts = {}) {
  const taskDir = opts.taskDir || path.join('.dev-studio', 'airbrain-tasks');
  fs.mkdirSync(taskDir, { recursive: true });
  const journal = [];
  const artifacts = [];

  // 1) RESEARCH agent: facts + constraints
  const research = await new AIEngine({ mode: 'research' }).chat(`List facts, constraints and pitfalls for this goal (bullets only): ${goal}`);
  journal.push({ agent: 'research', out: String(research.reply).slice(0, 1200) });

  // 2) PLAN agent: step list
  const planReply = await new AIEngine({ mode: 'assistant' }).chat(`Make a short numbered plan (max 4 bullets, "- " prefix) to accomplish: ${goal}. Context: ${journal[0].out.slice(0, 400)}`);
  const steps = String(planReply.reply).split('\n').map((l) => l.replace(/^[\s\d.)-]+/, '').trim()).filter((l) => l.length > 8).slice(0, 4);
  journal.push({ agent: 'plan', steps });

  // 3) CODER agent(s): har step par kaam; action blocks task-dir mein execute
  for (let i = 0; i < steps.length; i += 1) {
    // offline engine intent-based hai: step ko sabse qareeb scaffold intent mein map karo
    const txt = `${steps[i]} ${goal}`.toLowerCase();
    const intent = /api|server|http|endpoint/.test(txt) ? 'create an api'
      : /website|site|page|landing/.test(txt) ? 'build me a website'
        : /game|play/.test(txt) ? 'make a game'
          : /todo|app/.test(txt) ? 'make a todo app'
            : 'write a cli tool';
    const coder = await new AIEngine({ mode: 'coder' }).chat(`${intent} — supervisor step ${i + 1}/${steps.length}: ${steps[i]} (goal: ${goal})`);
    const actions = parseActions(coder.reply);
    journal.push({ agent: 'coder', step: steps[i], actions: actions.map((a) => a.tool) });
    for (const a of actions) {
      if (a.tool !== 'write_file' || !a.args || !a.args.path) continue;
      let safe = path.basename(String(a.args.path));          // task-dir se bahar kuch nahi
      if (artifacts.some((x) => path.basename(x.path) === safe)) {
        const dot = safe.lastIndexOf('.');
        safe = dot > 0 ? `${safe.slice(0, dot)}-${i + 1}${safe.slice(dot)}` : `${safe}-${i + 1}`;
      }
      const fp = path.join(taskDir, safe);
      try {
        fs.writeFileSync(fp, String(a.args.content || ''));
        artifacts.push({ path: fp, bytes: String(a.args.content || '').length, verified: null });
      } catch (e) {
        journal.push({ agent: 'supervisor', error: String(e.message || e) });
      }
    }
  }

  // 4) REVIEW agent: har artifact node --check se verify
  for (const art of artifacts) {
    if (!/\.js$|\.cjs$|\.mjs$/.test(art.path)) { art.verified = 'non-js'; continue; }
    try {
      execFileSync(process.execPath, ['--check', art.path], { stdio: 'pipe' });
      art.verified = true;
    } catch {
      art.verified = false;
    }
  }
  const okCount = artifacts.filter((a) => a.verified === true).length;
  const review = await new AIEngine({ mode: 'support' }).chat(`Review summary: goal="${goal}", artifacts=${artifacts.length}, verified=${okCount}. Give a 2-line verdict (APPROVED/NEEDS WORK + reason).`);
  journal.push({ agent: 'review', verdict: String(review.reply).slice(0, 400) });

  return {
    goal,
    status: artifacts.length && okCount === artifacts.length ? 'APPROVED' : artifacts.length ? 'NEEDS WORK' : 'NO ARTIFACTS',
    artifacts,
    journal,
    report: [
      `**SUPERVISOR REPORT — ${goal}**`,
      `- research: ${journal[0].out.split('\n')[0] || 'ok'}`,
      `- plan: ${steps.length} steps`,
      `- execute: ${artifacts.length} artifacts (${okCount} verified by node --check)`,
      `- review: ${(journal[journal.length - 1].verdict || '').split('\n')[0]}`,
      `- status: **${artifacts.length && okCount === artifacts.length ? 'APPROVED' : 'NEEDS WORK'}**`
    ].join('\n')
  };
}

module.exports = { runTask, parseActions };
