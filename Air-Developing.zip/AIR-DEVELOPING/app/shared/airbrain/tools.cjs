/**
 * AIR BRAIN — TOOL CALLING (v1.35.0). Blueprint ka "optionally call tools":
 * Air_you ke 10 asli tools (shared/tools.cjs) bridge hote hain — intent
 * match ho to brain tool chala kar output context mein lata hai. Permission
 * gate wahi raha: write/run tools ko ctx.permission chahiye.
 */
const { createTools } = require('../tools.cjs');

const INTENTS = [
  { re: /list my files|files listao|workspace dekho/, tool: 'list_files' },
  { re: /environment check|system info/, tool: 'env_check' },
  { re: /find (.+) in my code|code search/, tool: 'search_code' },
  { re: /read (.+)|show (.+)|explain (.+)/, tool: 'read_file' },
  { re: /run it|execute/, tool: 'run_last' }
];

function listTools(ctx) {
  const t = createTools(ctx || {});
  return t.names().map((n) => ({ name: n, description: t.tools[n].description, permission: t.tools[n].permission }));
}

function matchIntent(message) {
  const m = String(message || '').toLowerCase();
  for (const i of INTENTS) if (i.re.test(m)) return i.tool;
  return null;
}

async function callTool(name, args, ctx) {
  const t = createTools(ctx || {});
  if (!t.tools[name]) return { ok: false, error: `unknown tool ${name}` };
  if (t.tools[name].permission && !t.permission()) return { ok: false, error: 'permission required' };
  try {
    const out = await t.call(name, args || {});
    return { ok: true, out };
  } catch (e) {
    return { ok: false, error: String(e.message || e) };
  }
}

module.exports = { listTools, matchIntent, callTool, INTENTS };
