/**
 * AIR BRAIN — AGENT ROUTER (v1.36.0). Blueprint ka route_agent(): message ke
 * keywords se decide karta hai ke kaun sa agent/mode kaam kare (coder, sales,
 * support, research, assistant). Mode explicitly diya ho to router skip.
 */
const RULES = [
  { agent: 'coder', words: ['code', 'python', 'javascript', 'debug', 'api', 'function', 'programming', 'bug', 'refactor', 'compile'] },
  { agent: 'support', words: ['error', 'fix', 'crash', 'not working', 'kaam nahi', 'problem', 'help me'] },
  { agent: 'sales', words: ['business', 'startup', 'plan', 'pricing', 'market', 'product strategy'] },
  { agent: 'research', words: ['research', 'facts', 'compare', 'why does', 'explain how', 'study'] }
];

function routeAgent(message) {
  const m = String(message || '').toLowerCase();
  for (const r of RULES) if (r.words.some((w) => m.includes(w))) return r.agent;
  return 'assistant';
}

module.exports = { routeAgent, RULES };
