/**
 * AIR BRAIN — MEMORY (v1.35.0). Blueprint ka "conversation history + memory
 * store": in-memory history + optional JSON file persistence (sessions
 * survive restarts). build_messages() blueprint contract jaisa: system pehle,
 * phir history, aakhir mein user message.
 */
const fs = require('fs');

class Memory {
  constructor(opts = {}) {
    this.file = opts.file || null;
    this.max = opts.max || 60;
    this.history = [];
    if (this.file) {
      try {
        const raw = fs.readFileSync(this.file, 'utf8');
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) this.history = arr.slice(-this.max);
      } catch { /* nayi memory */ }
    }
  }

  push(role, content) {
    this.history.push({ role, content: String(content).slice(0, 4000) });
    if (this.history.length > this.max) this.history.splice(0, this.history.length - this.max);
    this.save();
    return this;
  }

  save() {
    if (!this.file) return;
    try { fs.writeFileSync(this.file, JSON.stringify(this.history)); } catch { /* read-only fs */ }
  }

  recent(n = 20) { return this.history.slice(-n); }
  clear() { this.history = []; this.save(); return this; }

  buildMessages(system, userMessage, extraHistory) {
    const messages = [{ role: 'system', content: system }];
    for (const item of (extraHistory || this.recent())) {
      if (item && item.role && item.content !== undefined) messages.push({ role: item.role, content: item.content });
    }
    messages.push({ role: 'user', content: userMessage });
    return messages;
  }
}

module.exports = { Memory };
