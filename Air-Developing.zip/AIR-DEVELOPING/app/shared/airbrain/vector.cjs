/**
 * AIR BRAIN — VECTOR SEARCH (v1.37.0). Blueprint ke "vector DB for large
 * docs" ka zero-dependency equivalent: TF-IDF + cosine similarity. Koi
 * external embedding service nahi — vectors local text se bante hain,
 * isliye offline bhi chalta hai aur knowledge base barhne ke saath scale
 * karta hai (keyword overlap se kahin behtar ranking).
 */
function tokenize(text) {
  return String(text).toLowerCase().match(/[a-z0-9]{2,}/g) || [];
}

class VectorIndex {
  constructor() {
    this.docs = [];          // {id, src, text, tf:{}, norm}
    this.df = {};            // term -> kitne docs mein
  }

  add(id, text, src) {
    const toks = tokenize(text);
    const tf = {};
    for (const t of toks) tf[t] = (tf[t] || 0) + 1;
    for (const t of Object.keys(tf)) this.df[t] = (this.df[t] || 0) + 1;
    this.docs.push({ id, src, text, tf, len: toks.length || 1 });
    return this;
  }

  idf(term) {
    const n = this.docs.length || 1;
    const d = this.df[term] || 0;
    return Math.log(1 + n / (1 + d));
  }

  vec(tf) {
    const v = {};
    let norm = 0;
    for (const t of Object.keys(tf)) {
      const w = (tf[t] / 1) * this.idf(t);
      v[t] = w;
      norm += w * w;
    }
    return { v, norm: Math.sqrt(norm) || 1 };
  }

  search(query, k = 3) {
    const qtoks = tokenize(query);
    if (!qtoks.length || !this.docs.length) return [];
    const qtf = {};
    for (const t of qtoks) qtf[t] = (qtf[t] || 0) + 1;
    const q = this.vec(qtf);
    const out = [];
    for (const d of this.docs) {
      const dv = this.vec(d.tf);
      let dot = 0;
      for (const t of Object.keys(q.v)) if (dv.v[t]) dot += q.v[t] * dv.v[t];
      const cos = dot / (q.norm * dv.norm);
      if (cos > 0.01) out.push({ id: d.id, src: d.src, text: d.text, score: cos });
    }
    out.sort((a, b) => b.score - a.score);
    return out.slice(0, k);
  }
}

module.exports = { VectorIndex, tokenize };
