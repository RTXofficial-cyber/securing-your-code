/**
 * AIR BRAIN — SESSION STORE (v1.36.0). Blueprint ka "session_id + database
 * storage": har session ki apni persistent history, ek JSON file mein
 * (SQLite ka zero-dep equivalent). Sessions reboot ke baad bhi zinda.
 */
const fs = require('fs');

class SessionStore {
  constructor(opts = {}) {
    this.file = opts.file || null;
    this.max = opts.max || 60;
    this.data = {};
    if (this.file) {
      try { this.data = JSON.parse(fs.readFileSync(this.file, 'utf8')) || {}; } catch { this.data = {}; }
    }
  }

  save() {
    if (!this.file) return;
    try { fs.writeFileSync(this.file, JSON.stringify(this.data)); } catch { /* ro */ }
  }

  history(sessionId) {
    const id = String(sessionId || 'default');
    if (!this.data[id]) this.data[id] = [];
    return this.data[id];
  }

  push(sessionId, role, content) {
    const h = this.history(sessionId);
    h.push({ role, content: String(content).slice(0, 4000) });
    if (h.length > this.max) h.splice(0, h.length - this.max);
    this.save();
    return this;
  }

  ids() { return Object.keys(this.data); }
  clear(sessionId) { delete this.data[String(sessionId || 'default')]; this.save(); return this; }
}

module.exports = { SessionStore };
