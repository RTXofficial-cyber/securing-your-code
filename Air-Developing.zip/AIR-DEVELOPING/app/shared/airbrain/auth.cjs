/**
 * AIR BRAIN — AUTH (v1.36.0). GitHub blueprint ka JWT user-auth hissa,
 * zero-dependency Node crypto mein: passwords scrypt-hash + salt, tokens
 * HMAC-SHA256 signed (JWT-jaisa payload: user + expiry). Store = JSON file
 * (single-PC app ke liye SQLite ki jagah file hi database hai).
 */
const crypto = require('crypto');
const fs = require('fs');

class UserStore {
  constructor(opts = {}) {
    this.file = opts.file || null;
    this.ttl = opts.ttl || 60 * 60 * 12;          // 12h token
    this.secret = opts.secret || process.env.AIRBRAIN_SECRET || 'airbrain-dev-secret-change-me';
    this.users = {};
    if (this.file) {
      try { this.users = JSON.parse(fs.readFileSync(this.file, 'utf8')) || {}; } catch { this.users = {}; }
    }
  }

  save() {
    if (!this.file) return;
    try { fs.writeFileSync(this.file, JSON.stringify(this.users, null, 2)); } catch { /* ro */ }
  }

  register(username, password) {
    const u = String(username || '').trim().toLowerCase();
    if (!u || String(password || '').length < 6) return { ok: false, error: 'username + password (min 6 chars) chahiye' };
    if (this.users[u]) return { ok: false, error: 'user pehle se maujood' };
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(String(password), salt, 32).toString('hex');
    this.users[u] = { salt, hash, created: Date.now() };
    this.save();
    return { ok: true, user: u };
  }

  login(username, password) {
    const u = String(username || '').trim().toLowerCase();
    const rec = this.users[u];
    if (!rec) return { ok: false, error: 'unknown user' };
    const hash = crypto.scryptSync(String(password), rec.salt, 32).toString('hex');
    if (!crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(rec.hash))) return { ok: false, error: 'ghalat password' };
    return { ok: true, token: this.token(u) };
  }

  token(user) {
    const payload = Buffer.from(JSON.stringify({ u: user, exp: Date.now() + this.ttl * 1000 })).toString('base64url');
    const sig = crypto.createHmac('sha256', this.secret).update(payload).digest('base64url');
    return `${payload}.${sig}`;
  }

  verify(token) {
    try {
      const [payload, sig] = String(token || '').split('.');
      if (!payload || !sig) return null;
      const want = crypto.createHmac('sha256', this.secret).update(payload).digest('base64url');
      if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(want))) return null;
      const data = JSON.parse(Buffer.from(payload, 'base64url').toString());
      if (data.exp < Date.now()) return null;
      return data.u;
    } catch { return null; }
  }

  count() { return Object.keys(this.users).length; }
}

module.exports = { UserStore };
