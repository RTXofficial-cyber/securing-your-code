/** AIR BRAIN MODULE (v1.35.0) — prompts + memory + RAG + tools + engine. */
const prompts = require('./prompts.cjs');
const { Memory } = require('./memory.cjs');
const rag = require('./rag.cjs');
const tools = require('./tools.cjs');
const { AIEngine, provider } = require('./brain.cjs');

const { UserStore } = require('./auth.cjs');
const { SessionStore } = require('./sessions.cjs');
const agents = require('./agents.cjs');

module.exports = { prompts, Memory, rag, tools, AIEngine, provider, MODES: prompts.MODES, buildSystem: prompts.buildSystem, UserStore, SessionStore, agents };
