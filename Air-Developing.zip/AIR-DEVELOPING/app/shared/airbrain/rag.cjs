/**
 * AIR BRAIN — RAG (v1.35.0). Blueprint ka " Retrieval-Augmented Generation":
 * apne asli knowledge sources (Detail Codex, GVE missions/city data, README
 * versions) par keyword retrieval — context chunks prompt mein jatay hain.
 */
function corpus(dir) {
  const out = [];
  // user-editable knowledge base: knowledge/*.txt (blueprint ka knowledge_base.txt)
  const fs = require('fs');
  const path = require('path');
  const kdir = dir || path.join(__dirname, '..', '..', 'knowledge');
  try {
    for (const f of fs.readdirSync(kdir).filter((x) => x.endsWith('.txt'))) {
      const txt = fs.readFileSync(path.join(kdir, f), 'utf8');
      for (const para of txt.split(/\n\s*\n/)) {
        const t = para.trim();
        if (t.length > 12) out.push({ src: `kb:${f}`, text: t.replace(/\n/g, ' ') });
      }
    }
  } catch { /* knowledge dir optional */ }
  try {
    const codex = require('../gamekit/detailcodex.cjs');
    const facts = typeof codex.all === 'function' ? codex.all() : (codex.FACTS || codex.list || []);
    for (const f of (Array.isArray(facts) ? facts : [])) {
      out.push({ src: 'codex', text: typeof f === 'string' ? f : (f.text || f.detail || JSON.stringify(f)) });
    }
  } catch { /* optional */ }
  try {
    const { MISSIONS } = require('../gve/missions.cjs');
    for (const m of MISSIONS) out.push({ src: 'gve-missions', text: `Mission ${m.title}: reward $${m.reward}, phases ${m.phases.map((p) => p.type).join('>')}` });
    const vice = require('../gve/vicecity.cjs');
    for (const z of vice.ZONES) out.push({ src: 'gve-city', text: `Vice City zone ${z.name} (${z.id}) at ${z.x},${z.z} size ${z.w}x${z.h}` });
  } catch { /* optional */ }
  return out;
}

function score(q, text) {
  const toks = new Set(String(q).toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 2));
  const low = String(text).toLowerCase();
  let s = 0;
  for (const t of toks) if (low.includes(t)) s += 1;
  return s;
}

function retrieve(query, k = 3) {
  const docs = corpus().map((d) => ({ ...d, s: score(query, d.text) })).filter((d) => d.s > 0);
  docs.sort((a, b) => b.s - a.s);
  return docs.slice(0, k).map((d) => `[${d.src}] ${d.text}`);
}

module.exports = { retrieve, corpus };
