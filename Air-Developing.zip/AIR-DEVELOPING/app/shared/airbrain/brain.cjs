/**
 * AIR BRAIN — ENGINE (v1.35.0). GitHub-blueprint ka core contract, poori
 * tarah apna: receive message → memory/context → (connected LLM ya offline
 * engine) → smart reply → optional tool calls. AIEngine class blueprint ke
 * AIEngine jaisi hai (build_messages + chat), magar offline-first: key na ho
 * to Air_you ka apna engine jawab deta hai, error string nahi.
 */
const { buildSystem, MODES } = require('./prompts.cjs');
const { Memory } = require('./memory.cjs');
const { SessionStore } = require('./sessions.cjs');
const { routeAgent } = require('./agents.cjs');
const rag = require('./rag.cjs');
const tools = require('./tools.cjs');

class AIEngine {
  constructor(opts = {}) {
    this.mode = opts.mode || 'assistant';          // 'auto' = agent router decide kare
    this.memory = opts.memory || new Memory(opts.memoryOpts || {});
    this.sessions = opts.sessionStore || null;     // SessionStore ho to session_id history
    this.sessionId = opts.sessionId || 'default';
    this.llm = opts.llm || null;          // async (messages) => string
    this.ctx = opts.ctx || {};
  }

  historyFor() {
    if (this.sessions) return this.sessions.history(this.sessionId);
    return this.memory.recent();
  }

  buildMessages(userMessage, history) {
    const ctxLines = rag.retrieve(userMessage);
    this.lastCtx = ctxLines;
    let system = buildSystem(this.mode === 'auto' ? routeAgent(userMessage) : this.mode);
    if (ctxLines.length) system += `\n\nContext (retrieved from your knowledge base):\n${ctxLines.join('\n')}`;
    return this.memory.buildMessages(system, userMessage, history || this.historyFor());
  }

  async chat(userMessage, history, ctx) {
    const c = ctx || this.ctx;
    const used = [];
    let augmented = userMessage;
    const intent = tools.matchIntent(userMessage);
    if (intent) {
      const r = await tools.callTool(intent, {}, c);
      used.push(intent);
      augmented += r.ok ? `\n[tool:${intent}] ${String(r.out).slice(0, 800)}` : `\n[tool:${intent} unavailable: ${r.error}]`;
    }
    const messages = this.buildMessages(augmented, history);
    const hadCtx = messages[0].content.includes('Context (retrieved');
    let reply = null; let source = 'offline';
    if (this.llm) {
      try { reply = await this.llm(messages); source = 'llm'; } catch { reply = null; source = 'offline-fallback'; }
    }
    if (!reply) {
      const providers = require('../providers.cjs');
      reply = await providers.chat('builtin', null, messages);
      source = source === 'offline-fallback' ? 'offline-fallback' : 'offline';
      // offline RAG: engine generic fallback de aur retrieval maujood ho to
      // knowledge-base chunks hi jawab hain (retrieval answer, generation nahi)
      if (hadCtx && /note kiya|crash-course nahi|clear nahi/.test(reply)) {
        reply = `**Knowledge base se mila (offline retrieval):**\n${(this.lastCtx || []).join('\n')}\n\n_Offline engine retrieval deta hai, generation nahi — connected LLM isi context par likha hua jawab dega._`;
      }
    }
    if (this.sessions) {
      this.sessions.push(this.sessionId, 'user', userMessage);
      this.sessions.push(this.sessionId, 'assistant', reply);
    } else {
      this.memory.push('user', userMessage);
      this.memory.push('assistant', reply);
    }
    return { reply, source, tools: used, context: hadCtx };
  }
}

/** providers registry entry: Settings mein "Air_you Brain" choose karo */
const provider = {
  id: 'airbrain',
  name: 'Air_you Brain',
  vendor: 'AIR',
  description: 'Modular brain (prompt + memory + RAG + tools). OPENAI_API_KEY ho to ChatGPT par forward, warna offline engine.',
  meta: true,                               // orchestrator role-chain mein direct select na ho (ye khud router hai)
  models: [
    { id: 'assistant', name: 'Assistant (default)' },
    { id: 'coder', name: 'Coder mode' },
    { id: 'sales', name: 'Sales/Product mode' },
    { id: 'support', name: 'Support mode' },
    { id: 'research', name: 'Research mode' }
  ],
  chat: async (model, messages) => {
    const hist = messages.slice(0, -1).map((m) => ({ role: m.role, content: m.content }));
    const user = messages[messages.length - 1].content;
    const llm = process.env.OPENAI_API_KEY
      ? async (msgs) => require('../providers.cjs').chat('openai', null, msgs)
      : null;
    const eng = new AIEngine({ mode: model || 'assistant', llm });
    const r = await eng.chat(user, hist);
    return r.reply;
  }
};

module.exports = { AIEngine, provider };
