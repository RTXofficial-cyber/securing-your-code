/**
 * AI provider connectors.
 *
 * Each provider is a plain object: { id, name, keyEnv, models, chat(model, messages) }.
 * Keys are held ONLY in the main process (memory + optional .env file) and are
 * never exposed to the renderer.
 *
 * To plug in YOUR OWN model: add an entry below with a `chat` function that
 * calls your endpoint and returns a string. Everything else — agent actions,
 * file writing, terminal — works with it automatically.
 */
const fs = require('fs');
const path = require('path');

// ---------- key store ----------
const runtimeKeys = new Map();

function loadKeysFromEnvFile(file) {
  try {
    if (!fs.existsSync(file)) return;
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
      const t = line.trim();
      if (!t || t.startsWith('#')) continue;
      const i = t.indexOf('=');
      if (i < 1) continue;
      const k = t.slice(0, i).trim();
      let v = t.slice(i + 1).trim();
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
      if (v) runtimeKeys.set(k, v);
    }
  } catch {}
}

function getKey(envName) {
  if (!envName) return null;
  return runtimeKeys.get(envName) || process.env[envName] || null;
}

/* v1.19 — paste-proof key handling. Real pastes arrive with trailing
   newlines, wrapping quotes or stray spaces (copy from email/terminal/
   docs). Normalise once, here, so every layer gets a clean key. */
function normalizeKey(value) {
  let v = String(value == null ? '' : value);
  if ((v.trim().startsWith('"') && v.trim().endsWith('"')) || (v.trim().startsWith("'") && v.trim().endsWith("'"))) {
    v = v.trim().slice(1, -1);
  }
  return v.replace(/\s+/g, '');
}

function setKey(envName, value) {
  if (!envName) return false;
  const v = normalizeKey(value);
  if (v) runtimeKeys.set(envName, v);
  else runtimeKeys.delete(envName);
  return true;
}

/* v1.19 — guess which connector a pasted key belongs to, from its prefix.
   Official prefixes only; returns null when unsure (never guesses wrong). */
const KEY_PREFIXES = [
  { re: /^sk-ant-/i, id: 'anthropic' },
  { re: /^gsk_/i, id: 'groq' },
  { re: /^pplx-/i, id: 'perplexity' },
  { re: /^AIza[0-9A-Za-z_-]{20}/, id: 'gemini' },
  { re: /^sk-[a-zA-Z0-9_-]{8,}/, id: 'openai' }
];
function detectProvider(key) {
  const k = normalizeKey(key);
  if (!k) return null;
  for (const p of KEY_PREFIXES) if (p.re.test(k)) return p.id;
  return null;
}

/* v1.19 — image uploads (vision). `images` are data URLs from the renderer.
   Each connector family gets its own official wire format:
   • Anthropic → content blocks [{type:'image', source:{base64…}}, {type:'text'}]
   • OpenAI-compatible (openai/groq/perplexity/…) → [{type:'text'}, {type:'image_url'}]
   • builtin Air_you → honest metadata note (offline engine cannot see images)
   Returns a NEW messages array (never mutates the caller's history). */
function attachImages(providerId, messages, images) {
  const imgs = (images || []).filter((d) => typeof d === 'string' && /^data:image\/[a-z0-9.+-]+;base64,/i.test(d)).slice(0, 4);
  const out = (messages || []).slice();
  if (!imgs.length) return out;
  let idx = -1;
  for (let i = out.length - 1; i >= 0; i -= 1) if (out[i].role === 'user') { idx = i; break; }
  if (idx < 0) { out.push({ role: 'user', content: '' }); idx = out.length - 1; }
  const text = typeof out[idx].content === 'string' ? out[idx].content : '';
  if (providerId === 'anthropic') {
    const blocks = imgs.map((d) => {
      const m = d.match(/^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i);
      return m ? { type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } } : null;
    }).filter(Boolean);
    out[idx] = { role: 'user', content: [...blocks, { type: 'text', text }] };
  } else if (providerId === 'builtin') {
    const meta = imgs.map((d, i) => {
      const m = d.match(/^data:(image\/[a-z0-9.+-]+);base64,/i);
      const kb = Math.max(1, Math.round((d.length * 0.75) / 1024));
      return `image ${i + 1}: ${m ? m[1] : 'image'}, ~${kb} KB`;
    }).join('; ');
    out[idx] = { role: 'user', content: `${text}\n\n[User ne image attach ki — ${meta}]` };
  } else {
    out[idx] = {
      role: 'user',
      content: [{ type: 'text', text }, ...imgs.map((url) => ({ type: 'image_url', image_url: { url } }))]
    };
  }
  return out;
}

// ---------- helpers ----------
/* Provider failures arrive as raw HTTP + JSON blobs that mean nothing to a
   human. Map the common ones to plain guidance (Roman Urdu + English) with
   the exact next step, and always keep a trimmed raw tail for debugging. */
function friendlyProviderError(status, text) {
  const t = String(text || '');
  const raw = t.replace(/\s+/g, ' ').slice(0, 240);
  const quota = /insufficient_quota|credit_balance_exhausted|no credits remaining|exceeded your current quota/i.test(t);
  const badKey = status === 401 || /invalid_api_key|invalid api key|incorrect api key|invalid x-api-key|unauthorized|authentication_error/i.test(t);
  const noModel = status === 404 && /model/i.test(t);
  if (quota) {
    return [
      `⚠️ API credits khatam (HTTP ${status} — insufficient_quota). Key theek hai, account mein balance nahi.`,
      '• OpenAI: credits add karein → https://platform.openai.com/settings/organization/billing — yaad rahe, ChatGPT Plus subscription API credits NAHI deta, API ka billing alag hai.',
      '• Free alternatives abhi: Groq connector (free-tier key → https://console.groq.com/keys), Ollama (100% free, local models), ya built-in Air_you (koi key hi nahi chahiye).',
      raw ? `Raw: ${raw}` : ''
    ].filter(Boolean).join('\n');
  }
  if (badKey) {
    return [
      `⚠️ Key invalid ya expired (HTTP ${status}). Settings → Connectors mein key dobara paste karein.`,
      '• Key sirf us platform ki honi chahiye (OpenAI ki key OpenAI connector mein, Groq ki Groq mein).',
      '• Nayi key: OpenAI → platform.openai.com/api-keys · Groq → console.groq.com/keys · OpenRouter → openrouter.ai/keys',
      raw ? `Raw: ${raw}` : ''
    ].filter(Boolean).join('\n');
  }
  if (noModel) {
    return [
      `⚠️ Yeh model ID provider par nahi mila (HTTP 404). Dropdown se doosra model select karein.`,
      '• Naye frontier models (jaise GPT-6 Astra) aksar pehle enterprise accounts ko milte hain — aapki key par abhi available na ho.',
      raw ? `Raw: ${raw}` : ''
    ].filter(Boolean).join('\n');
  }
  if (status === 429) {
    return `⚠️ Rate limit (HTTP 429) — provider ne thoda rukne ko kaha. Ek minute baad dobara koshish karein, ya free-tier provider (Groq/Ollama) par switch karein.${raw ? `\nRaw: ${raw}` : ''}`;
  }
  return `Provider error (HTTP ${status}): ${raw || '(empty response)'}`;
}

async function postJSON(url, headers, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...headers },
    body: JSON.stringify(body)
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(friendlyProviderError(res.status, text));
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error('Provider returned non-JSON response');
  }
}

function textOf(messages) {
  const sys = messages.filter((m) => m.role === 'system').map((m) => m.content).join('\n\n');
  const turns = messages.filter((m) => m.role !== 'system');
  return { sys, turns };
}

/* v1.19 — Gemini wire format: string → [{text}], and the OpenAI-style
   content array from attachImages() → text + inline_data parts (vision). */
function geminiParts(content) {
  if (typeof content === 'string') return [{ text: content }];
  if (!Array.isArray(content)) return [{ text: String(content ?? '') }];
  const parts = [];
  for (const p of content) {
    if (p?.type === 'text') parts.push({ text: p.text });
    else if (p?.type === 'image_url') {
      const m = String(p.image_url?.url || '').match(/^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i);
      if (m) parts.push({ inline_data: { mime_type: m[1], data: m[2] } });
    }
  }
  return parts.length ? parts : [{ text: '' }];
}

// ---------- OpenAI-compatible connector factory ----------
function openaiCompatible({ id, name, description, keyEnv, baseUrl, models, defaultModel, docs }) {
  return {
    id, name, description, keyEnv, models, docs,
    async chat(model, messages) {
      const data = await postJSON(
        baseUrl,
        { Authorization: `Bearer ${getKey(keyEnv)}` },
        { model: model || defaultModel, messages }
      );
      return data.choices?.[0]?.message?.content ?? '(empty response)';
    }
  };
}

// ---------- Anthropic ----------
const anthropic = {
  id: 'anthropic',
  name: 'Claude',
  vendor: 'Anthropic',
  description: 'Claude models via the Anthropic Messages API.',
  keyEnv: 'ANTHROPIC_API_KEY',
  docs: 'https://console.anthropic.com/settings/keys',
  models: [
    { id: 'claude-sonnet-4-5', name: 'Claude Sonnet 4.5' },
    { id: 'claude-opus-4-1', name: 'Claude Opus 4.1' },
    { id: 'claude-haiku-4-5', name: 'Claude Haiku 4.5' }
  ],
  async chat(model, messages) {
    const { sys, turns } = textOf(messages);
    const data = await postJSON(
      'https://api.anthropic.com/v1/messages',
      { 'x-api-key': getKey('ANTHROPIC_API_KEY'), 'anthropic-version': '2023-06-01' },
      {
        model: model || 'claude-sonnet-4-5',
        max_tokens: 4096,
        ...(sys ? { system: sys } : {}),
        messages: turns.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }))
      }
    );
    return (data.content || []).map((c) => c.text || '').join('') || '(empty response)';
  }
};

// ---------- Gemini ----------
const gemini = {
  id: 'gemini',
  name: 'Gemini',
  vendor: 'Google',
  description: 'Gemini models via the Generative Language API.',
  keyEnv: 'GEMINI_API_KEY',
  docs: 'https://aistudio.google.com/app/apikey',
  models: [
    { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash' },
    { id: 'gemini-2.5-pro', name: 'Gemini 2.5 Pro' }
  ],
  async chat(model, messages) {
    const { sys, turns } = textOf(messages);
    const m = model || 'gemini-2.5-flash';
    const data = await postJSON(
      `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${encodeURIComponent(getKey('GEMINI_API_KEY') || '')}`,
      {},
      {
        ...(sys ? { systemInstruction: { parts: [{ text: sys }] } } : {}),
        contents: turns.map((t) => ({
          role: t.role === 'assistant' ? 'model' : 'user',
          parts: geminiParts(t.content)
        }))
      }
    );
    const parts = data.candidates?.[0]?.content?.parts ?? [];
    return parts.map((p) => p.text || '').join('') || '(empty response)';
  }
};

// ---------- built-in engine (works with no key) ----------
const builtin = require('./builtin.cjs');

// ---------- registry ----------
const airbrainProvider = require('./airbrain/index.cjs').provider;

const PROVIDERS = [
  builtin,
  airbrainProvider,
  anthropic,
  openaiCompatible({
    id: 'openai', name: 'ChatGPT', vendor: 'OpenAI',
    description: 'GPT models via the OpenAI Chat Completions API.',
    keyEnv: 'OPENAI_API_KEY', baseUrl: 'https://api.openai.com/v1/chat/completions',
    docs: 'https://platform.openai.com/api-keys',
    defaultModel: 'gpt-4o-mini',
    models: [
      { id: 'gpt-6-astra', name: 'GPT-6 Astra (frontier)' },
      { id: 'gpt-4o', name: 'GPT-4o' },
      { id: 'gpt-4o-mini', name: 'GPT-4o mini' },
      { id: 'gpt-4.1', name: 'GPT-4.1' },
      { id: 'o4-mini', name: 'o4-mini (reasoning)' }
    ]
  }),
  openaiCompatible({
    id: 'perplexity', name: 'Perplexity', vendor: 'Perplexity',
    description: 'Search-augmented Sonar models.',
    keyEnv: 'PERPLEXITY_API_KEY', baseUrl: 'https://api.perplexity.ai/chat/completions',
    docs: 'https://www.perplexity.ai/settings/api',
    defaultModel: 'sonar',
    models: [
      { id: 'sonar', name: 'Sonar' },
      { id: 'sonar-pro', name: 'Sonar Pro' },
      { id: 'sonar-reasoning', name: 'Sonar Reasoning' }
    ]
  }),
  gemini,
  openaiCompatible({
    id: 'groq', name: 'Groq', vendor: 'Groq',
    description: 'Very fast Llama inference.',
    keyEnv: 'GROQ_API_KEY', baseUrl: 'https://api.groq.com/openai/v1/chat/completions',
    docs: 'https://console.groq.com/keys',
    defaultModel: 'llama-3.3-70b-versatile',
    models: [
      { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B' },
      { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B Instant' }
    ]
  })
];

function listProviders() {
  return PROVIDERS.map((p) => ({
    id: p.id,
    name: p.name,
    vendor: p.vendor || p.name,
    description: p.description,
    keyEnv: p.keyEnv,
    docs: p.docs || null,
    models: p.models,
    ready: p.keyEnv ? Boolean(getKey(p.keyEnv)) : true,
    meta: Boolean(p.meta),
    plugin: Boolean(p.pluginId)
  }));
}

/**
 * Plugin API — lets a plugin register a new AI provider at runtime.
 * Re-registering the same id replaces it (hot reload).
 */
function registerProvider(provider, pluginId) {
  if (!provider || typeof provider.id !== 'string' || typeof provider.chat !== 'function') {
    throw new Error('provider plugin must export { id, chat(model, messages) }');
  }
  if (!Array.isArray(provider.models) || provider.models.length === 0) {
    throw new Error(`provider plugin "${provider.id}" must export a non-empty models array`);
  }
  const wrapped = { ...provider, pluginId: pluginId || provider.id };
  const i = PROVIDERS.findIndex((p) => p.id === wrapped.id);
  if (i >= 0) PROVIDERS[i] = wrapped;
  else PROVIDERS.push(wrapped);
  return wrapped;
}

function unregisterProvider(id) {
  const i = PROVIDERS.findIndex((p) => p.id === id);
  if (i >= 0) { PROVIDERS.splice(i, 1); return true; }
  return false;
}

function hasProvider(id) {
  return PROVIDERS.some((p) => p.id === id);
}

async function chat(providerId, model, messages) {
  const p = PROVIDERS.find((x) => x.id === providerId) || PROVIDERS[0];
  if (p.keyEnv && !getKey(p.keyEnv)) {
    const err = new Error(
      `${p.name} is not connected yet. Add your ${p.keyEnv} in Settings (or in dev-studio.env next to the app) and try again.`
    );
    err.code = 'NO_KEY';
    throw err;
  }
  return p.chat(model, messages);
}

module.exports = {
  PROVIDERS, listProviders, chat, getKey, setKey, loadKeysFromEnvFile, friendlyProviderError,
  registerProvider, unregisterProvider, hasProvider, envFilePath: path,
  normalizeKey, detectProvider, attachImages, geminiParts
};
