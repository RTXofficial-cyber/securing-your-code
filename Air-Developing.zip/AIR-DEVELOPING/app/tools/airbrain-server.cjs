/**
 * AIR BRAIN standalone HTTP server (v1.35.0) — blueprint ka FastAPI equivalent,
 * zero-dependency Node mein:
 *   node tools/airbrain-server.cjs
 *   curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
 *     -d '{"message":"gve missions","history":[],"mode":"assistant"}'
 * Electron app ke andar brain provider ke tor par bhi maujood hai (Settings).
 */
const http = require('http');
const { AIEngine, Memory, MODES } = require('../shared/airbrain/index.cjs');

const memory = new Memory({ file: process.env.AIRBRAIN_MEM || null });
const engine = new AIEngine({
  memory,
  llm: process.env.OPENAI_API_KEY
    ? async (msgs) => require('../shared/providers.cjs').chat('openai', null, msgs)
    : null
});

function handle(method, url, body) {
  if (method === 'GET' && url === '/') {
    return { status: 200, json: { status: 'AI brain online', module: 'airbrain', modes: Object.keys(MODES), memory: memory.history.length } };
  }
  if (method === 'POST' && url === '/chat') {
    let payload = {};
    try { payload = JSON.parse(body || '{}'); } catch { return { status: 400, json: { error: 'bad json' } }; }
    if (!payload.message) return { status: 400, json: { error: 'message required' } };
    if (MODES[payload.mode]) engine.mode = payload.mode;
    return engine.chat(payload.message, payload.history || []).then((r) => ({
      status: 200,
      json: { reply: r.reply, source: r.source, tools: r.tools, context: r.context }
    })).catch((e) => ({ status: 500, json: { error: String(e.message || e) } }));
  }
  return { status: 404, json: { error: 'not found' } };
}

if (require.main === module) {
  const port = parseInt(process.env.PORT || '8000', 10);
  http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      Promise.resolve(handle(req.method, req.url, body)).then((r) => {
        res.writeHead(r.status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(r.json));
      });
    });
  }).listen(port, '0.0.0.0', () => console.log(`[airbrain] http://localhost:${port}  (POST /chat)`));
}

module.exports = { handle };
