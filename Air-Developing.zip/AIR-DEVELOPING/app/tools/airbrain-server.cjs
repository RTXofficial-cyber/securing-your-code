/**
 * AIR BRAIN standalone HTTP server (v1.36.0) — blueprint ka FastAPI starter
 * (auth + sessions + agents + RAG + tools), zero-dependency Node mein:
 *
 *   node tools/airbrain-server.cjs            (default: 127.0.0.1:8000)
 *   curl -X POST http://localhost:8000/register -H "Content-Type: application/json" \
 *     -d '{"username":"demo","password":"123456"}'
 *   curl -X POST http://localhost:8000/login  -H "Content-Type: application/json" \
 *     -d '{"username":"demo","password":"123456"}'
 *   curl -X POST http://localhost:8000/chat -H "Authorization: Bearer TOKEN" \
 *     -H "Content-Type: application/json" \
 *     -d '{"session_id":"s1","message":"debug this api"}'
 *
 * Security: /chat token (HMAC-signed) mangta hai; register sirf jab koi user
 * na ho ya valid token ho; server default LOCALHOST par (0.0.0.0 nahi).
 */
const http = require('http');
const path = require('path');
const { AIEngine, MODES, UserStore, SessionStore, agents } = require('../shared/airbrain/index.cjs');

const storeDir = process.env.AIRBRAIN_DIR || path.join('.dev-studio', 'airbrain');
const fs = require('fs');
try { fs.mkdirSync(storeDir, { recursive: true }); } catch { /* ro */ }

const users = new UserStore({ file: path.join(storeDir, 'users.json') });
const sessions = new SessionStore({ file: path.join(storeDir, 'sessions.json') });

function mkEngine(mode, sessionId) {
  return new AIEngine({
    mode: mode || 'auto',
    sessionStore: sessions,
    sessionId: sessionId || 'default',
    llm: process.env.OPENAI_API_KEY
      ? async (msgs) => require('../shared/providers.cjs').chat('openai', null, msgs)
      : null
  });
}

function bearer(headers) {
  const h = headers || {};
  const raw = h.authorization || h.Authorization || '';
  return raw.startsWith('Bearer ') ? raw.slice(7) : null;
}

function handle(method, url, body, headers) {
  if (method === 'GET' && url === '/') {
    return { status: 200, json: { status: 'AI brain online', module: 'airbrain', modes: Object.keys(MODES), agents: agents.RULES.map((r) => r.agent), users: users.count(), sessions: sessions.ids().length } };
  }
  if (method === 'POST' && url === '/register') {
    if (users.count() > 0 && !users.verify(bearer(headers))) {
      return { status: 403, json: { error: 'registration band: pehla user maujood hai (invite token chahiye)' } };
    }
    let p = {};
    try { p = JSON.parse(body || '{}'); } catch { return { status: 400, json: { error: 'bad json' } }; }
    const r = users.register(p.username, p.password);
    return r.ok ? { status: 200, json: { ok: true, user: r.user } } : { status: 400, json: r };
  }
  if (method === 'POST' && url === '/login') {
    let p = {};
    try { p = JSON.parse(body || '{}'); } catch { return { status: 400, json: { error: 'bad json' } }; }
    const r = users.login(p.username, p.password);
    return r.ok ? { status: 200, json: { token: r.token } } : { status: 401, json: r };
  }
  if (method === 'POST' && url === '/chat') {
    const user = users.verify(bearer(headers));
    if (!user) return { status: 401, json: { error: 'Bearer token chahiye (pehle /login)' } };
    let payload = {};
    try { payload = JSON.parse(body || '{}'); } catch { return { status: 400, json: { error: 'bad json' } }; }
    if (!payload.message) return { status: 400, json: { error: 'message required' } };
    const mode = MODES[payload.mode] ? payload.mode : 'auto';
    const eng = mkEngine(mode, payload.session_id);
    return eng.chat(payload.message, payload.history || []).then((r) => ({
      status: 200,
      json: { reply: r.reply, source: r.source, tools: r.tools, context: r.context, agent: eng.mode === 'auto' ? agents.routeAgent(payload.message) : eng.mode, user }
    })).catch((e) => ({ status: 500, json: { error: String(e.message || e) } }));
  }
  return { status: 404, json: { error: 'not found' } };
}

if (require.main === module) {
  const port = parseInt(process.env.PORT || '8000', 10);
  const host = process.env.HOST || '127.0.0.1';     // security: LAN par khud na khole
  http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      Promise.resolve(handle(req.method, req.url, body, req.headers)).then((r) => {
        res.writeHead(r.status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(r.json));
      });
    });
  }).listen(port, host, () => console.log(`[airbrain] http://${host}:${port}  (register → login → Bearer /chat)`));
}

module.exports = { handle, users, sessions };
