/**
 * GVE VICE CITY 3D — offline screenshot renderer (v1.32.1).
 * Headless engine frame ko khud rasterize karke PNG banata hai (koi browser,
 * koi GPU zaroori nahi): createPlay({mode:'3d'}) chalao, aakhri frame ke ctx
 * calls record karo, scanline-fill + zlib PNG. Env vars: SHOT_H (heading),
 * SHOT_Z (start z), SHOT_STEPS, SHOT_OUT (output path).
 *   node tools/render-shot.cjs
 */
/** Real GVE 3D frame → PNG: engine ke ctx calls record karke khud rasterize karo. */
const { createPlay } = require('../shared/gve/browser.cjs');

const W = 960, H = 540;
let ops = [], cur = [], bg = '#101418';
const ctx = {
  fillStyle: '#fff', strokeStyle: '#fff', font: '', lineWidth: 1,
  beginPath() { cur = []; },
  moveTo(x, y) { cur.push([x, y]); },
  lineTo(x, y) { cur.push([x, y]); },
  closePath() {},
  fill() { if (cur.length >= 3) ops.push({ t: 'p', pts: cur.slice(), c: ctx.fillStyle }); cur = []; },
  stroke() { cur = []; },
  arc() {},
  fillText(t, x, y) { ops.push({ t: 'tx', s: String(t), x, y, c: ctx.fillStyle }); },
  fillRect(x, y, w, h) { if (w >= W && h >= H) bg = ctx.fillStyle; else ops.push({ t: 'r', x, y, w, h, c: ctx.fillStyle }); }
};
const canvas = { width: W, height: H, getContext: () => ctx };
const play = createPlay({ canvas, mode: '3d' });
play.g.atmo.t = 0.35;                                 // dopahar
const SZ = parseFloat(process.env.SHOT_Z || '300');
play.g.player.body.pos = { x: 380, y: 0.45, z: SZ };
play.g.vehicle.chassis.pos = { x: 380, y: 0.6, z: SZ + 2 };
play.keys.add('f'); play.step(1 / 60); play.keys.delete('f');   // gaadi mein betho
for (let i = 0; i < 45; i += 1) play.step(1 / 60);              // enter lerp khatam
if (process.env.SHOT_CROWD) {                 // sabse bhaari footpath node par khare ho jao
  const cnt = {};
  for (const pd of play.g.peds.list) {
    const ni = play.g.vice.nodes.reduce((bi, n, i) => {
      const d = Math.hypot(n.x - pd.body.pos.x, n.z - pd.body.pos.z);
      return d < bi.d ? { d, i } : bi;
    }, { d: 1e9, i: 0 }).i;
    cnt[ni] = (cnt[ni] || 0) + 1;
  }
  const best = Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a])[0];
  const n = play.g.vice.nodes[best];
  play.g.player.body.pos = { x: n.x, y: 0.45, z: n.z - 8 };
  play.g.vehicle.chassis.pos = { x: n.x, y: 0.6, z: n.z - 6 };
  console.log('crowd node:', best, 'peds:', cnt[best]);
}
play.g.vehicle.heading = parseFloat(process.env.SHOT_H || '0');
for (let i = 0; i < parseInt(process.env.SHOT_STEPS || '300', 10); i += 1) { play.keys.add('w'); play.step(1 / 60); }
ops = []; bg = '#101418';                              // sirf aakhri frame record karo
play.step(1 / 60);
console.log('frame ops:', ops.length, 'bg:', bg, 'state:', JSON.stringify(play.state()));

/* ---------- rasterize ---------- */
const parseC = (s) => {
  const m = /^#([0-9a-f]{6})$/i.exec(s);
  if (m) return [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16)];
  const r = /rgba?\((\d+),(\d+),(\d+)/.exec(s);
  return r ? [+r[1], +r[2], +r[3]] : [255, 255, 255];
};
const buf = Buffer.alloc(W * H * 3);
const bgc = parseC(bg);
for (let i = 0; i < W * H; i += 1) { buf[i * 3] = bgc[0]; buf[i * 3 + 1] = bgc[1]; buf[i * 3 + 2] = bgc[2]; }
const put = (x, y, c) => { if (x >= 0 && x < W && y >= 0 && y < H) { const o = (y * W + x) * 3; buf[o] = c[0]; buf[o + 1] = c[1]; buf[o + 2] = c[2]; } };
/* ---------- 3x5 pixel font (HUD) ---------- */
const F = {
  A:'010 101 111 101 101', B:'110 101 110 101 110', C:'011 100 100 100 011', D:'110 101 101 101 110',
  E:'111 100 110 100 111', F:'111 100 110 100 100', G:'011 100 101 101 011', H:'101 101 111 101 101',
  I:'111 010 010 010 111', J:'001 001 001 101 010', K:'101 101 110 101 101', L:'100 100 100 100 111',
  M:'101 111 111 101 101', N:'101 111 111 111 101', O:'010 101 101 101 010', P:'110 101 110 100 100',
  Q:'010 101 101 110 011', R:'110 101 110 101 101', S:'011 100 010 001 110', T:'111 010 010 010 010',
  U:'101 101 101 101 111', V:'101 101 101 101 010', W:'101 101 111 111 101', X:'101 101 010 101 101',
  Y:'101 101 010 010 010', Z:'111 001 010 100 111',
  '0':'111 101 101 101 111', '1':'010 110 010 010 111', '2':'110 001 010 100 111', '3':'110 001 010 001 110',
  '4':'101 101 111 001 001', '5':'111 100 110 001 110', '6':'011 100 111 101 111', '7':'111 001 010 010 010',
  '8':'111 101 111 101 111', '9':'111 101 111 001 110',
  ' ':'000 000 000 000 000', ':':'000 010 000 010 000', '*':'101 010 111 010 101', '/':'001 001 010 100 100',
  '-':'000 000 111 000 000', '.':'000 000 000 000 010', '(':'001 010 010 010 001', ')':'100 010 010 010 100'
};
function drawText(str, ox, oy, col) {
  let cx = ox;
  for (const ch of str.toUpperCase()) {
    const gl = F[ch] || F[' '];
    const rows = gl.split(' ');
    for (let r = 0; r < 5; r += 1)
      for (let c = 0; c < 3; c += 1)
        if (rows[r][c] === '1') put(cx + c, oy + r, col);
    cx += 4;
  }
}


for (const op of ops) {
  const c = parseC(op.c);
  if (op.t === 'tx') { drawText(op.s, op.x | 0, (op.y - 8) | 0, c); continue; }
  if (op.t === 'r') {
    for (let y = Math.max(0, op.y | 0); y < Math.min(H, (op.y + op.h) | 0); y += 1)
      for (let x = Math.max(0, op.x | 0); x < Math.min(W, (op.x + op.w) | 0); x += 1) put(x, y, c);
    continue;
  }
  const pts = op.pts; let ymin = 1e9, ymax = -1e9;
  for (const p of pts) { if (p[1] < ymin) ymin = p[1]; if (p[1] > ymax) ymax = p[1]; }
  for (let y = Math.max(0, Math.floor(ymin)); y < Math.min(H - 1, Math.ceil(ymax)); y += 1) {
    const sy = y + 0.5, xs = [];
    for (let i = 0; i < pts.length; i += 1) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      if ((a[1] <= sy && b[1] > sy) || (b[1] <= sy && a[1] > sy)) xs.push(a[0] + (sy - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
    }
    xs.sort((p, q) => p - q);
    for (let k = 0; k + 1 < xs.length; k += 2)
      for (let x = Math.max(0, Math.ceil(xs[k])); x < Math.min(W, Math.ceil(xs[k + 1])); x += 1) put(x, y, c);
  }
}

/* ---------- PNG ---------- */
const CRC_T = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n += 1) { let c = n; for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
function crc32(b) { let c = 0xffffffff; for (let i = 0; i < b.length; i += 1) c = CRC_T[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
const raw = Buffer.alloc((W * 3 + 1) * H);
for (let y = 0; y < H; y += 1) { raw[y * (W * 3 + 1)] = 0; buf.copy(raw, y * (W * 3 + 1) + 1, y * W * 3, (y + 1) * W * 3); }
const zlib = require('zlib');
const png = Buffer.concat([
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))
]);
require('fs').writeFileSync(process.env.SHOT_OUT || 'gve3d-shot.png', png);
console.log('PNG saved:', png.length, 'bytes');
