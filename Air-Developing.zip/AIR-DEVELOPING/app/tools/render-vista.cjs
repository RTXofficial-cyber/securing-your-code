/**
 * VICE VISTA offline screenshot renderer (v1.38.0): headless sandbox mein
 * game chalao, aakhri frame ke ctx calls record karke PNG rasterize karo
 * (browser/GPU free). Env: VISTA_FRAMES, VISTA_NIGHT=1, VISTA_OUT.
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = path.join(__dirname, '..');
const engineSrc = fs.readFileSync(path.join(root, 'shared', 'gamekit', 'engine.js'), 'utf8');
const engine3d = fs.readFileSync(path.join(root, 'shared', 'gamekit', 'engine3d.js'), 'utf8');
const gameSrc = fs.readFileSync(path.join(root, 'shared', 'gamekit', 'templates', 'vicevista.js'), 'utf8');

const W = 960; const H = 540;
let ops = []; let cur = []; let bg = '#2f7fb8';
const ctx = {
  fillStyle: '#fff', strokeStyle: '#fff', font: '', lineWidth: 1, globalAlpha: 1,
  beginPath() { cur = []; },
  moveTo(x, y) { cur.push([x, y]); },
  lineTo(x, y) { cur.push([x, y]); },
  closePath() {},
  fill() { if (cur.length >= 3) ops.push({ t: 'p', pts: cur.slice(), c: ctx.fillStyle }); cur = []; },
  stroke() { cur = []; },
  arc() {}, rect() {}, roundRect() {}, save() {}, restore() {}, translate() {}, rotate() {}, scale() {}, setTransform() {}, strokeText() {},
  fillText(t, x, y) { ops.push({ t: 'tx', s: String(t), x, y, c: ctx.fillStyle }); },
  measureText: () => ({ width: 10 }),
  createLinearGradient: () => ({ stops: [], addColorStop(p, col) { this.stops.push(col); } }),
  createRadialGradient: () => ({ stops: [], addColorStop(p, col) { this.stops.push(col); } }),
  fillRect(x, y, w, h) { if (w >= W && h >= H && ops.length === 0) bg = ctx.fillStyle; ops.push({ t: 'r', x, y, w, h, c: ctx.fillStyle }); },
  clearRect() {}, strokeRect() {}, drawImage() {}, putImageData() {}, getImageData: () => ({ data: [] })
};
const canvas = { width: W, height: H, getContext: () => ctx, addEventListener() {}, getBoundingClientRect: () => ({ left: 0, top: 0, width: W, height: H }) };
const listeners = {}; const rafQ = []; let now = 0;
function mulberry32(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const M = Object.create(Math); M.random = mulberry32(0x5eed1234);
const sandbox = {
  console, Math: M, JSON, Date, Object, Array, String, Number, Boolean, isFinite, isNaN, parseInt, parseFloat,
  performance: { now: () => now },
  requestAnimationFrame: (cb) => { rafQ.push(cb); return rafQ.length; },
  addEventListener: (t, f) => { (listeners[t] = listeners[t] || []).push(f); },
  navigator: { getGamepads: () => [] },
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  document: { getElementById: () => canvas, createElement: () => canvas, body: { appendChild() {} } },
  setTimeout: () => 0, setInterval: () => 0, clearInterval() {}, clearTimeout() {}
};
sandbox.window = sandbox; sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(engineSrc, sandbox, { filename: 'engine.js' });
vm.runInContext(engine3d, sandbox, { filename: 'engine3d.js' });
vm.runInContext(gameSrc, sandbox, { filename: 'vicevista.js' });
const G = sandbox.__vicevista;
if (process.env.VISTA_NIGHT) G.night = true;
const fire = (t, ev) => (listeners[t] || []).forEach((f) => f(ev));
const frames = parseInt(process.env.VISTA_FRAMES || '90', 10);
for (let i = 0; i < frames; i += 1) {
  now += 16.6;
  if (i === 10) fire('keydown', { code: 'KeyW', preventDefault() {} });
  const q = rafQ.splice(0, rafQ.length);
  q.forEach((cb) => cb(now));
}
fire('keyup', { code: 'KeyW' });
ops = [];                                     // sirf aakhri frame
now += 16.6;
rafQ.splice(0, rafQ.length).forEach((cb) => cb(now));
console.log('frame ops:', ops.length, 'shards:', G.collected, 'towers:', G.towers.length);
if (process.env.VISTA_DBG) { console.log(JSON.stringify(ops.slice(0, 6), null, 1).slice(0, 900)); const p = ops.filter(o => o.t === 'p'); console.log('polys:', p.length, 'sample pts:', JSON.stringify(p.slice(0, 2).map(o => o.pts.slice(0, 2)))); if (process.env.VISTA_DBG) { const bot = ops.filter(o => o.t === 'p' && o.pts.every(p => p[1] > 430)); const uniq = [...new Set(bot.map(o => JSON.stringify(o.c)))]; const vbot = ops.filter(o => o.t === 'p' && o.pts.every(p => p[1] > 470)); console.log('verybottom:', vbot.length, JSON.stringify(vbot.slice(0, 6).map(o => [o.c, o.pts.map(p => [p[0] | 0, p[1] | 0])])));
const gray = ops.filter(o => o.t === 'p' && /rgb\((15[0-9]|14[0-9]|7[0-9]),\s*\1?/.test('')); console.log('deckgray:', ops.filter(o => o.t === 'p' && typeof o.c === 'string' && o.c.startsWith('rgb(') && (() => { const m = /rgb\((\d+),(\d+),(\d+)/.exec(o.c); return m && Math.abs(m[1]-m[2]) < 6 && Math.abs(m[2]-m[3]) < 6; })()).length);
console.log('bottom colors:', uniq.slice(0, 10)); }
console.log('big rects:', JSON.stringify(ops.filter(o => o.t === 'r' && o.w > 400).map(o => [o.y, o.h, o.c]))); }

/* ---------- rasterize ---------- */
const parseC = (s) => {
  if (typeof s === 'object' && s !== null) { const st = s.stops; s = (st && st.length ? st[0] : '#000000'); } // pehla stop (vignette ka transparent center)
  const m = /^#([0-9a-f]{6})$/i.exec(s);
  if (m) return [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16)];
  const r = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(s);
  return r ? [+r[1], +r[2], +r[3], r[4] === undefined ? 1 : +r[4]] : [255, 255, 255, 1];
};
const buf = Buffer.alloc(W * H * 3);
const bgc = parseC(bg);
for (let i = 0; i < W * H; i += 1) { buf[i * 3] = bgc[0]; buf[i * 3 + 1] = bgc[1]; buf[i * 3 + 2] = bgc[2]; }
const put = (x, y, c) => { if (x >= 0 && x < W && y >= 0 && y < H) { const o = (y * W + x) * 3; const a = c.length > 3 ? c[3] : 1; if (a <= 0) return; const ia = 1 - a; buf[o] = buf[o] * ia + c[0] * a; buf[o + 1] = buf[o + 1] * ia + c[1] * a; buf[o + 2] = buf[o + 2] * ia + c[2] * a; } };
/* ---------- 3x5 pixel font (HUD) ---------- */
const F = {
  A:'010 101 111 101 101', B:'110 101 110 101 110', C:'011 100 100 100 011', D:'110 101 101 101 110',
  E:'111 100 110 100 111', F:'111 100 110 100 100', G:'011 100 101 101 011', H:'101 101 111 101 101',
  I:'111 010 010 010 111', J:'001 001 001 101 010', K:'101 101 110 101 101', L:'100 100 100 100 111',
  M:'101 111 111 101 101', N:'101 111 111 111 101', O:'010 101 101 101 010', P:'110 101 110 100 100',
  Q:'010 101 101 110 011', R:'110 101 110 101 101', S:'011 100 010 001 110', T:'111 010 010 010 010',
  U:'101 101 101 101 111', V:'101 101 101 101 010', W:'101 101 111 111 101', X:'101 101 010 101 101',
  Y:'101 101 010 010 010', Z:'111 001 010 100 111',
  '0':'111 101 101 101 111', '1':'010 110 010 010 111', '2':'110 001 010 100 111', '3':'110 001 010 001 110',
  '4':'101 101 111 001 001', '5':'111 100 110 001 110', '6':'011 100 111 101 111', '7':'111 001 010 010 010',
  '8':'111 101 111 101 111', '9':'111 101 111 001 110',
  ' ':'000 000 000 000 000', ':':'000 010 000 010 000', '*':'101 010 111 010 101', '/':'001 001 010 100 100',
  '-':'000 000 111 000 000', '.':'000 000 000 000 010', '(':'001 010 010 010 001', ')':'100 010 010 010 100'
};
function drawText(str, ox, oy, col) {
  let cx = ox;
  for (const ch of str.toUpperCase()) {
    const gl = F[ch] || F[' '];
    const rows = gl.split(' ');
    for (let r = 0; r < 5; r += 1)
      for (let c = 0; c < 3; c += 1)
        if (rows[r][c] === '1') put(cx + c, oy + r, col);
    cx += 4;
  }
}


for (const op of ops) {
  const c = parseC(op.c);
  if (op.t === 'tx') { drawText(op.s, op.x | 0, (op.y - 8) | 0, c); continue; }
  if (op.t === 'r') {
    for (let y = Math.max(0, op.y | 0); y < Math.min(H, (op.y + op.h) | 0); y += 1)
      for (let x = Math.max(0, op.x | 0); x < Math.min(W, (op.x + op.w) | 0); x += 1) put(x, y, c);
    continue;
  }
  const pts = op.pts; let ymin = 1e9, ymax = -1e9;
  for (const p of pts) { if (p[1] < ymin) ymin = p[1]; if (p[1] > ymax) ymax = p[1]; }
  for (let y = Math.max(0, Math.floor(ymin)); y < Math.min(H - 1, Math.ceil(ymax)); y += 1) {
    const sy = y + 0.5, xs = [];
    for (let i = 0; i < pts.length; i += 1) {
      const a = pts[i], b = pts[(i + 1) % pts.length];
      if ((a[1] <= sy && b[1] > sy) || (b[1] <= sy && a[1] > sy)) xs.push(a[0] + (sy - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
    }
    xs.sort((p, q) => p - q);
    for (let k = 0; k + 1 < xs.length; k += 2)
      for (let x = Math.max(0, Math.ceil(xs[k])); x < Math.min(W, Math.ceil(xs[k + 1])); x += 1) put(x, y, c);
  }
}

/* ---------- PNG ---------- */
const CRC_T = (() => { const t = new Int32Array(256); for (let n = 0; n < 256; n += 1) { let c = n; for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c; } return t; })();
function crc32(b) { let c = 0xffffffff; for (let i = 0; i < b.length; i += 1) c = CRC_T[(c ^ b[i]) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(W, 0); ihdr.writeUInt32BE(H, 4); ihdr[8] = 8; ihdr[9] = 2;
const raw = Buffer.alloc((W * 3 + 1) * H);
for (let y = 0; y < H; y += 1) { raw[y * (W * 3 + 1)] = 0; buf.copy(raw, y * (W * 3 + 1) + 1, y * W * 3, (y + 1) * W * 3); }
const zlib = require('zlib');
const png = Buffer.concat([
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))
]);
const out = process.env.VISTA_OUT || 'vicevista-shot.png';
fs.writeFileSync(out, png);
console.log('PNG saved:', out, png.length, 'bytes');
