@echo off
title AIR DEVELOPING
cd /d "C:\AIR-DEVELOPING\app"
if not exist node_modules call npm install --no-audit --no-fund
call npm start
