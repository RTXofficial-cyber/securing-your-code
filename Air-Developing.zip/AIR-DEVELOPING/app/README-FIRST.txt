=========================================================
 AIR DEVELOPING 1.29.0  -  GTA-VIRTUAL-ENGINE (GVE)
 12 modular subsystems, production-ready, zero deps
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.29.0 (aapki GVE directive: 12 core subsystems,
modular, production-ready, koi placeholder nahi):

  * shared/gve/ mein 12 modules, sab vanilla JS (koi
    Three.js/Cannon.js dependency nahi - hand-written
    vector/quaternion/raycast math, is liye HEADLESS
    tests mein aur offline zip mein asal mein chalta):
    1 engine (fixed 1/60 timestep + pools)  2 render
    (bloom/SSAO/teal-magenta LUT/grain + GPU dispose)
    3 physics (6-layer collision matrix + Coulomb
    impulses)  4 streamer (chunks/LOD/budgets)  5 player
    (6-state FSM + quat camera)  6 vehicle (4-wheel
    raycast suspension + drift)  7 combat (raycast +
    weapon wheel)  8 traffic (lanes/red-light/panic)
    9 wanted (5-star: patrol/pit/roadblock-ahead)  10
    atmosphere (day-night + weather)  11 audio
    (positional + radio, offline honest)  12 ui
    (scaleform HUD + minimap projection)

  * ARCHITECTURE.md: poori dependency tree + har module
    ka contract likha hua.

  * `gve status` command: 2-second live sim chala kar
    12/12 modules ke ASLI numbers dikhata hai.

  * Detail Codex +gve category (12 entries, sab done) ->
    118 total / 108 done / 13 categories.

  * SAB PURANA LIVE (1.0 -> 1.28): MISSION ENGINE +
    VIRSA, same-to-same agent brain (10 tools + loop +
    session memory), BRAIN MODULE (7 regions + Hebbian
    graph), WORLD ORGANIZE PACK, ORGANIZED GYM, AIR
    LOOP, CODEX 2.0, situation engine, KB, STORE DESK,
    connectors, vision, GTA-6 pack, FX Forge, Ollama,
    Team mode, plugins, PIN, Air Vault, Game Studio,
    narration, Windows exe pipeline, ONE-FOLDER zip +
    double-click SETUP.

  * TESTS: 127 logic + 20 UI green (3 stable runs) -
    naya GVE block: fixed-step math, pause freeze, pool
    reuse, impulse resolve, streaming budgets, player
    FSM, vehicle enter+drift, combat ray+impulse+wheel,
    traffic red-light+panic, wanted 5-star roadblock,
    atmosphere cycle+storm, audio attenuation+offline
    honesty, UI minimap clamp, render LUT+GPU dispose.

RUN IT (WINDOWS — double-click, koi command nahi):
  1) Zip kholo -> AIR-DEVELOPING folder -> AIR-DEVELOPING-SETUP.bat
     par DOUBLE-CLICK karo.
  2) Menu aayega:
       [1] app abhi chalao (desktop window)
       [2] Windows .exe installer banao (release\ folder mein)
       [3] browser mein kholo
  Bas. Baaki sab setup khud karta hai (node check, npm install,
  build, launch).

RUN IT (manual / developers):
  1) cd AIR-DEVELOPING\app
  2) npm install
  3) npm run dev          (development)
     npm run build        (production dist/)
     npm run dist:win     (Windows .exe installer)
