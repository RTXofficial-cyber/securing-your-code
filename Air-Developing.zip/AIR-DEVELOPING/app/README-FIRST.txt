=========================================================
 AIR DEVELOPING 1.30.0  -  SETUP WIZARD + INSTALLER
 click -> options -> install finish -> desktop shortcut
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.30.0 (jo aapne kaha: setup click karo, install
options aayen, finish par app sidha desktop par):

  * SETUP WIZARD (AIR-DEVELOPING-SETUP.bat): zip kholo,
    setup par double-click, OPTIONS menu aata hai:
      [1] FULL INSTALL - C:\AIR-DEVELOPING mein copy,
          DESKTOP shortcut + Start Menu shortcut banta
          hai, install finish par app KHUD chal parti
          hai. Bas: desktop par "AIR DEVELOPING" icon.
      [2] PORTABLE RUN - bina install abhi chalao
      [3] BUILD NATIVE .EXE - release\ mein Setup.exe
          (NSIS wizard: install directory choose karo,
          desktop/start-menu shortcuts checkbox)
      [4] BROWSER PREVIEW

  * NATIVE Setup.exe PIPELINE: .github/workflows/
    build-windows-installer.yml - GitHub ka Windows
    runner NSIS installer bana kar Release par dalta
    hai (sandbox Linux hai, Electron runtime wahan
    download nahi hota - honest reason).

  * SAB PURANA LIVE (1.0 -> 1.29): GVE 12-module engine,
    MISSION ENGINE + VIRSA, same-to-same agent brain,
    BRAIN MODULE, WORLD ORGANIZE PACK, ORGANIZED GYM,
    AIR LOOP, CODEX 2.0, KB, STORE DESK, connectors,
    vision, GTA-6 pack, FX Forge, Ollama, Team mode,
    plugins, PIN, Air Vault, Game Studio, narration,
    ONE-FOLDER zip layout.

  * TESTS: 127 logic + 20 UI green (3 stable runs).

RUN IT (WINDOWS — double-click, koi command nahi):
  1) Zip kholo -> AIR-DEVELOPING folder -> AIR-DEVELOPING-SETUP.bat
     par DOUBLE-CLICK karo.
  2) Menu aayega:
       [1] app abhi chalao (desktop window)
       [2] Windows .exe installer banao (release\ folder mein)
       [3] browser mein kholo
  Bas. Baaki sab setup khud karta hai (node check, npm install,
  build, launch).

RUN IT (manual / developers):
  1) cd AIR-DEVELOPING\app
  2) npm install
  3) npm run dev          (development)
     npm run build        (production dist/)
     npm run dist:win     (Windows .exe installer)
