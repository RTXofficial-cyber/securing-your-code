=========================================================
 AIR DEVELOPING 1.28.0  -  MISSION ENGINE + VIRSA
 bara goal kai turns mein; purani yaadon se seekhta hai
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.28.0 ("next" — multi-turn planning + heritage):

  * MISSION ENGINE: `mission: <goal>` likho — Air_you
    goal ko steps mein todta hai (har step = asli tool
    call), PEHLA step usi turn mein chalta hai, baqi
    mission.json mein KHULE rehte hain (multi-turn
    memory, meri tarah). `mission jari` = agla step;
    step fail ho to honest PAUSE (jhootha done nahi),
    fix ke baad `mission jari` = retry -> aage barhta
    hai. `mission status` = progress (done/fail/block/
    next/pending). `mission khatam` = clear.

  * VIRSA (heritage mining): `virsaa: <goal>` — purani
    sessions + airloop journal mine karta hai. Jo tools
    pehle FAIL hue the, unka lesson NAYE mission ke plan
    mein pehle verify step ban jata hai — jo pehle fail
    hua, usse seekhta hai (one-way learning).

  * COMMANDS: mission: / mission jari / mission status /
    mission khatam / virsaa: / kaam karo: / ijazat hai:
    / brain dikhao / brain socho: / brain yaad dikhao /
    airloop / situation / codex mein likho: / bank dikhao

  * SAB PURANA LIVE (1.0 -> 1.27): same-to-same agent
    brain (10-tool registry + asli loop + session
    memory), BRAIN MODULE 3.6 (7 regions + Hebbian
    graph), WORLD ORGANIZE PACK, ORGANIZED GYM, BODY &
    CITY LIFE, AIR LOOP, CODEX 2.0, situation engine,
    KB, STORE DESK, AirMind 2.0, connectors, vision,
    GTA-6 pack, FX Forge, real water, Ollama GB-class
    AI, Team mode, plugins, PIN, Chrome bridge, Air
    Vault, Game Studio, GameKit3D, narration, Windows
    exe pipeline, ONE-FOLDER zip + double-click SETUP.

  * TESTS: 126 logic + 20 UI green (3 stable runs) -
    naya MISSION block: plan-multi-step, pehla step
    turn mein, honest pause, retry-after-fix, complete,
    virsa lessons naye mission mein, routes, powers.

RUN IT (WINDOWS — double-click, koi command nahi):
  1) Zip kholo -> AIR-DEVELOPING folder -> AIR-DEVELOPING-SETUP.bat
     par DOUBLE-CLICK karo.
  2) Menu aayega:
       [1] app abhi chalao (desktop window)
       [2] Windows .exe installer banao (release\ folder mein)
       [3] browser mein kholo
  Bas. Baaki sab setup khud karta hai (node check, npm install,
  build, launch).

RUN IT (manual / developers):
  1) cd AIR-DEVELOPING\app
  2) npm install
  3) npm run dev          (development)
     npm run build        (production dist/)
     npm run dist:win     (Windows .exe installer)
