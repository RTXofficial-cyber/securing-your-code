=========================================================
 AIR DEVELOPING 1.26.0  —  AIR BRAIN MODULE
 feed nahi — jo info milti hai wo BRAIN ko DESIGN karti hai
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.26.0 (jo aapne kaha: "main AI KA BRAIN MODULE
design karwa raha hoon — jaise tum kaam karte ho, jo
info tum mujhe dete ho, sab kuch uske brain ko design
kare, na ke sirf feed"):

  * 🧠 AIR BRAIN MODULE (shared/brain.cjs) — Air_you ki
    apni COGNITIVE ARCHITECTURE. Honest baat: ye neural
    network NAHI (neural weights Ollama se aate hain) —
    ye EXPLICIT BRAIN ENGINE hai, wahi 7 regions jo bare
    coding agents (jaise main) use karte hain:

      PERCEIVE → RECALL → PLAN → REASON → ACT → VERIFY
      → LEARN

  * 🔗 LIVE KNOWLEDGE GRAPH — feed aur brain ka farq:
    feed dead data hota hai; brain module usi info
    (Detail Codex 106 entries, KB topics, aapke sawaal,
    AIR LOOP lessons) se apni TARTEEB banata hai — 400+
    nodes, weighted connections. Aapka har sawaal graph
    ke weights BADALTA hai.

  * ⚡ HEBBIAN LEARNING — "fire together, wire together":
    jo cheezein saath use hoti hain unke connections
    mazboot hote jaate hain (+0.25 har fire par).
    `brain dikhao` mein strongest pathways live dikhte
    hain.

  * 🎯 SPREADING ACTIVATION + HONEST CONFIDENCE — sawal
    ke tokens graph mein activation phailate hain (2-hop);
    recall ki taqat se confidence nikalti hai. Kamzor
    yaad = KAM confidence, saaf lafzon mein — andaza
    nahi, jhootha bharosa nahi.

  * 🗺️ PLAN — har step ki DONE-DEFINITION + risk (bina
    done-def ke step hi nahi). VERIFY — read-back/self-
    check; jhootha "done" kabhi nahi.

  * 💪 ACT = MOTOR CORTEX — workspace mile to AIR LOOP
    khud chalta hai (asli files → artifact → verify);
    warna honest "offline trace-only" mode.

  * 🍂 DECAY + ONE-WAY PERSIST — kamzor connections
    bhool jata hai (honest forgetting); graph disk par
    save hota hai SIRF .dev-studio/air/brain-graph.json
    mein — connected AIs (GPT/Claude/Groq/Perplexity) ko
    ye graph KABHI nahi milta.

  * ⌨️ NAYE COMMANDS:
    - `brain dikhao` — regions map + graph stats +
      strongest pathways (live)
    - `brain socho: <goal>` — poori 7-region pipeline ka
      LIVE TRACE + confidence + plan
    - har KB jawab ke baad brain line: kaun se concepts
      activate hue (sawal ne brain ko re-wire kiya)

  * 📚 DETAIL CODEX FEED: +brain category (8 entries,
    sab done) → 106 total · 96 done · 12 categories.

  * SAB PURANA SYSTEM LIVE (1.0 → 1.25 tak har upgrade
    isi zip mein): WORLD ORGANIZE PACK (26 gym stations,
    VICE GENERAL HOSPITAL, 19 shops), ORGANIZED GYM rule,
    BODY & CITY LIFE PACK, AIR LOOP, CODEX 2.0, THINK,
    GREP, bank dikhao, store diff, Detail Pack 2,
    situation engine, Knowledge Bank, 💎 App Update +
    STORE DESK, AirMind 2.0, connectors, 📎 vision,
    paste-proof API keys, GTA-6 pack, FX Forge (1 arab+),
    real water, Ollama GB-class AI, Team mode,
    Autopilot/Deep, plugins, PIN security, Chrome bridge,
    Air Vault, Game Studio + 12 arcade games, GameKit3D,
    done-tick, narration, Windows exe pipeline.

  * TESTS: 124 logic + 20 UI green (3 stable runs) —
    naya BRAIN block: 7 regions, graph seed 400+ nodes,
    perceive/stopwords, recall (hospital concepts),
    Hebbian growth, per-step done-defs, offline honest
    ACT, weak-recall low confidence, disk persist +
    reload, decay prune, AIR LOOP motor cortex, chat
    routes, codex brain category.

RUN IT (WINDOWS — double-click, koi command nahi):
  1) Zip kholo -> AIR-DEVELOPING folder -> AIR-DEVELOPING-SETUP.bat
     par DOUBLE-CLICK karo.
  2) Menu aayega:
       [1] app abhi chalao (desktop window)
       [2] Windows .exe installer banao (release\ folder mein)
       [3] browser mein kholo
  Bas. Baaki sab setup khud karta hai (node check, npm install,
  build, launch).

RUN IT (manual / developers):
  1) cd AIR-DEVELOPING\app
  2) npm install
  3) npm run dev          (development)
     npm run build        (production dist/)
     npm run dist:win     (Windows .exe installer)
