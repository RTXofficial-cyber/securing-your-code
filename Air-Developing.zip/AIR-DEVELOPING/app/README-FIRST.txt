=========================================================
 AIR DEVELOPING 1.27.0  -  SAME-TO-SAME AGENT BRAIN
 Air_you ab bare coding agent JAISA kaam karta hai
=========================================================

THE APP: AIR DEVELOPING.  THE BUILT-IN AI: Air_you.

NEW IN 1.27.0 (jo aapne kaha: "jaise aap ke module/
structure/brain/working hai, sab us ke brain ko bane -
apna jaisa same to same AI banao"):

  * TOOL REGISTRY (shared/tools.cjs) - Air_you ke HAATH,
    bilkul mere jaise 10 tools: list_files, read_file,
    write_file, edit_file, grep, node_check (asli syntax
    verify), run_tests, codex_search, kb_recall,
    web_search. RULE wahi jo bare agent ka hai: READ
    free, WRITE permission-gated ("ijazat hai:" likho tab
    khulta hai); sirf apna journal area (.dev-studio/)
    permission-free.

  * BRAIN TURN = MERA LOOP: `kaam karo: <goal>` par
    Air_you canned jawab NAHI deta - wo ASLI tool calls
    chalata hai: observe (list_files) -> read (read_file)
    -> verify (node_check) -> answer observations se ->
    learn + session memory. Fix turn asli SYNTAX ERROR
    pakadta hai aur honest diagnosis deta hai; build
    turn artifact likh kar khud read-back + compile
    verify karta hai (jhootha "done" nahi).

  * SESSION MEMORY (meri tarah): har turn save - intent,
    kaun se tools chale, verified ya nahi
    (.dev-studio/air/session.json, cap 40).
    `brain yaad dikhao` = live yaad + graph stats.

  * COMMANDS:
    - `kaam karo: <goal>` - agent turn (asli loop)
    - `ijazat hai: <goal>` - write permission ke saath
    - `brain yaad dikhao` - session memory
    - purane sab: brain dikhao / brain socho: / airloop /
      situation / codex mein likho: / bank dikhao ...

  * SAB PURANA SYSTEM LIVE (1.0 -> 1.26): BRAIN MODULE
    3.6 (7 regions + Hebbian graph), WORLD ORGANIZE PACK,
    ORGANIZED GYM, BODY & CITY LIFE, AIR LOOP, CODEX 2.0,
    situation engine, KB, STORE DESK, AirMind 2.0,
    connectors, vision, GTA-6 pack, FX Forge, real water,
    Ollama GB-class AI, Team mode, plugins, PIN, Chrome
    bridge, Air Vault, Game Studio, GameKit3D, narration,
    Windows exe pipeline, ONE-FOLDER zip + double-click
    SETUP.

  * TESTS: 125 logic + 20 UI green (3 stable runs) - naya
    block: 10-tool registry, read-free/write-gated,
    own-area free, node_check honest, edit honest, grep
    line numbers, brain turn fix/build/question, session
    persist+reload, chat routes, powers.

RUN IT (WINDOWS — double-click, koi command nahi):
  1) Zip kholo -> AIR-DEVELOPING folder -> AIR-DEVELOPING-SETUP.bat
     par DOUBLE-CLICK karo.
  2) Menu aayega:
       [1] app abhi chalao (desktop window)
       [2] Windows .exe installer banao (release\ folder mein)
       [3] browser mein kholo
  Bas. Baaki sab setup khud karta hai (node check, npm install,
  build, launch).

RUN IT (manual / developers):
  1) cd AIR-DEVELOPING\app
  2) npm install
  3) npm run dev          (development)
     npm run build        (production dist/)
     npm run dist:win     (Windows .exe installer)
