=========================================================
 DEV STUDIO 1.3.0  —  Autopilot: your app now works like me
=========================================================

NEW: AUTO MODE (chat -> "Auto" pill)
  Give a goal in plain words. The app will:
    PLAN (JSON plan from your model, or offline plan from the built-in AI)
    EXECUTE (writes + commands, inside your permission toggles)
    VERIFY (every verify command must exit 0)
    FIX (on failure the error goes back in, up to 3 loops)
  Every iteration is shown in chat with skips + exit codes, and audited.
  Try: "add a login page with validation" / "build me a website"

ALSO INSIDE
  * Workspace Inspector: "analyze my project", "find X in my code"
  * Game Studio: any-game composer + headless proof that games run
  * PIN lock + audit, Chrome bridge + guest links, project memory, plugins
  * Arcade at /play/ with 5 games

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 70 logic + 10 UI. Generated 2026-10-29 10:28
=========================================================
