=========================================================
 DEV STUDIO 1.7.0  —  ReAct agent: step-by-step like a real engineer
=========================================================

NEW: with ANY connected model (OpenAI incl. GPT-6 Astra,
Claude, Gemini, Groq, OpenRouter, Ollama), Deep mode now
runs a ReAct loop — the model calls ONE tool per turn and
reads REAL observations before its next move:

  web_search -> read_file -> write_file -> run_command
  (node --check) -> done

* Permission gates per tool; SKIPPED actions are reported
  back so the model adapts instead of pretending
* Every step shown in chat: [step N] tool, args, observation
* Loop capped (14 steps); CHECK phase re-verifies files after
* Offline built-in brain keeps the plan->verify->fix loop

STILL HERE: Deep research with citations, refactor/split,
error doctor, follow-ups, Auto mode, games, memory, PIN,
audit, friendly connector errors.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 84 logic + 10 UI. Generated 2026-10-29 12:05
=========================================================
