=========================================================
 DEV STUDIO 1.5.0  —  the built-in AI now REFACTORS code
=========================================================

NEW IN 1.5.0 — MULTI-FILE REFACTOR (offline, no key):
  refactor util.js
  split util.js into helpers.js
  -> independent functions move to a new module, the original
     file requires it, both verified with node --check.
     Safe: siblings-dependent functions stay put, existing
     target files are never overwritten.

STILL HERE: real-file explain/show, error doctor (11 trace
families + "fix it"), follow-ups (run it / rename / guarded
delete), Auto mode (plan->execute->verify->fix), game
composer, project analyzer, memory, team mode, PIN + audit.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 74 logic + 10 UI. Generated 2026-10-29 10:51
=========================================================
