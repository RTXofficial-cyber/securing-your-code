=========================================================
 DEV STUDIO 1.1.0  —  final release package
 AI development studio for Windows (.exe)
=========================================================

WHAT THIS IS
  A black & white, Claude-style desktop app for building massive software:
  connectors for Claude, ChatGPT/OpenAI, Perplexity, Gemini, Groq, DeepSeek,
  Ollama and OpenRouter, a built-in offline AI engine, a 4-role AI team that
  cooperates in the background (Researcher / Architect / Coder / Reviewer),
  a real terminal, a Monaco editor, an official plugin system, PIN lock with
  an audit log, project memory, and a loopback bridge that opens the SAME
  workspace in Chrome.

---------------------------------------------------------
 GET THE .EXE  (Windows PC, one click)
---------------------------------------------------------
  1. Install Node.js 18 or newer:  https://nodejs.org
  2. Unzip this file anywhere, e.g. C:\DevStudio
  3. Double-click:  build-windows.bat
     It installs, runs the tests, builds and packs the app, then opens the
     release folder for you.

  You get two files in release\:
     Dev Studio Setup 1.1.0.exe   <- normal installer (recommended)
     Dev Studio 1.1.0.exe         <- portable, runs without installing

  Manual build instead:
     npm ci
     npm run dist:win

  No Windows PC handy? GitHub Actions builds it for you:
     copy  ci\build-desktop.yml  ->  .github\workflows\build-desktop.yml
     commit + push, then download the "Dev-Studio-Windows-x64" artifact
     from the Actions tab.

---------------------------------------------------------
 FIRST RUN
---------------------------------------------------------
  * Choose (or create) a workspace folder — all code lives there.
  * Settings -> Providers: paste an API key, or use the built-in engine
    with no key and no internet.
  * Settings -> Security: set a PIN. From then on the app opens locked and
    every sensitive action is written to the audit log.
  * Press the (i) button in the activity bar to open this same workspace in
    Chrome — 127.0.0.1 only, token-gated, optionally read-only.

---------------------------------------------------------
 DEVELOPER COMMANDS  (run inside this folder)
---------------------------------------------------------
  npm run dev          Vite dev server (renderer only)
  npm start            build + launch the Electron app
  npm run build        production renderer build -> dist/
  npm run dist:win     package the Windows .exe -> release/
  npm run test:logic   57 pure-Node tests
  npm run test:ui      10 React component tests (jsdom)
  npm run verify       both of the above
  npm run e2e:install  download Chromium once
  npm run test:e2e     real Chrome end-to-end suite (Playwright)

---------------------------------------------------------
 WHAT IS INSIDE
---------------------------------------------------------
  electron/       main process: window, hardening, IPC, terminal, bridge
  shared/         providers, agent, orchestrator, plugins, lock, memory
  src/            React renderer: landing, setup, studio, lock, memory
  plugins/        official plugins: ollama, openrouter, git-tools
  dist/           the production build (already built for you)
  test/           logic tests + component tests
  e2e/            Playwright specs that drive real Chrome
  ci/             GitHub Actions: tests, Chrome E2E, Windows .exe
  resources/      app icon
  README.md       full documentation (security, plugins, bridge, testing)

  Status at packaging time: 57/57 logic tests, 10/10 UI tests, clean build.
  Generated 2026-10-28 16:55
=========================================================
