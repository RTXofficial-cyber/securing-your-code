=========================================================
 DEV STUDIO 1.1.1  —  final release package
 AI development studio for Windows (.exe)
=========================================================

NEW IN THIS PACKAGE: the built-in offline AI (Studio Agent v2) now ANSWERS
questions instead of repeating one canned intro: greetings, "who are you",
math, time/date, app usage guide, and ~20 offline crash-courses (recursion,
async, git, SQL, regex, CSS layout, security, testing, Big-O, Docker, React,
Node, Python, TypeScript, JSON, arrays, errors, functions, variables,
localhost/CORS). Anything unknown gets a question-aware reply that quotes
your question back — never the same text twice.

GET THE .EXE (Windows PC)
  1. Install Node.js 18+:  https://nodejs.org
  2. Unzip anywhere, e.g. C:\DevStudio  (overwrite if asked)
  3. Double-click:  build-windows.bat
     -> installs, tests (58 logic + 10 UI), builds, packs release\*.exe

  release\ contains:
     Dev Studio Setup 1.1.0.exe   - installer (recommended)
     Dev Studio 1.1.0.exe         - portable, no install

  No Windows PC? GitHub Actions builds it:
     copy ci\build-desktop.yml -> .github\workflows\build-desktop.yml,
     push, download the Dev-Studio-Windows-x64 artifact.

FIRST RUN
  * Pick/create a workspace folder - all code lives there
  * Settings -> Providers: paste an API key, or use the built-in offline AI
  * Settings -> Security: set a PIN (app then opens locked; audit log on)
  * (i) button: open the SAME workspace in Chrome (127.0.0.1, token-gated)
  * Ask the AI anything: "build me a website", "what is recursion?",
    "how do i center a div?", "what is 2+2*10?"

DEV COMMANDS (inside this folder)
  npm run dev | npm start | npm run build | npm run dist:win
  npm run verify (58 logic + 10 UI) | npm run test:e2e (real Chrome)

Generated 2026-10-29 09:49 — 58/58 logic tests, 10/10 UI tests, clean build.
=========================================================
