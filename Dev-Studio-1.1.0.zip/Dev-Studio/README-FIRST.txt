=========================================================
 DEV STUDIO 1.2.0  —  your personal AI, inside your app
=========================================================

THE BUILT-IN AI NOW WORKS LIKE A PERSONAL ASSISTANT
  * "analyze my project"  -> offline audit: stack signals, file/line counts,
    TODO/FIXME total, largest files, most recently touched, next-step advice
  * "find TODO in my code" / 'find "login" in my workspace'
                           -> grep across every text file, path:line matches
  * "make a zombie survival game with dash" -> composes THAT game (DNA spec)
  * concepts, math, time, greetings, app guide — no canned repeats
  * everything offline; frontier models optional via Settings -> Providers

GAMES PROVEN TO RUN: headless harness plays every game 600 frames in tests.
POLISH: arcade title screens, vignette, glow, 4 palettes, gamepad support.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> double-click build-windows.bat
TESTS: 66 logic + 10 UI. Generated 2026-10-29 10:22
=========================================================
