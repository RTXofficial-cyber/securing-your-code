=========================================================
 DEV STUDIO 1.2.0  —  Game Studio "any game" release
=========================================================

WHAT CHANGED SINCE YOUR LAST LOOK
  * ANY game, not 4 templates: your sentence becomes game DNA
    (control scheme, enemy AI, weapon, goal, modifiers, theme) and the
    composed runtime builds exactly that. "zombie survival with dash" and
    "flappy pipe runner" are different games.
  * Games are PROVEN to run: a headless harness plays every game for 600
    simulated frames in the test suite. It already caught and fixed a real
    crash. "game run nahi hoti" cannot ship anymore.
  * Not ugly: arcade title screens (attract mode), vignette, glow particles,
    rounded shapes, themed palettes (mono / neon / paper / crt).
  * Bare requests ("make a platformer") still use the four hand-tuned games.
  * Arcade inside the app at /play/ now has 5 entries incl. COMPOSED.

TRY IT IN THE APP
  make a zombie survival game with dash
  make a flappy pipe runner
  make a space shooter with bombs and rapid fire
  make a platformer reach the flag with double jump
  ...then press the (play) button in the activity bar.

GET THE .EXE (Windows)
  1. Node.js 18+   2. unzip (overwrite)   3. double-click build-windows.bat
  release\ -> Dev Studio Setup.exe (installer) + portable.exe

TESTS: 64 logic (incl. headless game runs) + 10 UI. Generated 2026-10-29 10:16
=========================================================
