=========================================================
 DEV STUDIO 1.13.0  —  THE AI THAT LEARNS FROM OTHER AIs
=========================================================

NEW: TEAM TRAINING LOOP. "When I work in a team, the AI
should watch every agent work and not just enhance itself
— it should LEARN, and grow into a full developer over
time." Done, and tested:
  * every team run is journaled into the workspace's
    .dev-studio/experience.json: which model played which
    role (research/plan/code/review), which files were
    written, whether the reviewer APPROVED or demanded fixes
  * CROSS-AI DISTILLATION: when connected models (Claude,
    GPT, Perplexity, Groq...) take part, the offline
    built-in AI then answers the SAME request and the
    difference is extracted — the tools and terms the
    connected AIs used that it did not. Stored as a
    reusable 'team-distill' lesson.
  * every future Team / Deep / Autopilot prompt starts
    with the most relevant lessons — the built-in carries
    what the other AIs taught it, mission after mission
  * honest limits: no weights change; it is an auditable
    training journal (40 newest lessons) you can read and
    clear. Ask the app "how does the AI learn from other
    AIs?" — it explains exactly this.

GITHUB: as requested, the repo now hosts exactly ONE Dev
Studio file: this zip. All source lives inside it (unzip
to see/build everything). The .exe itself cannot be
uploaded from the build sandbox (no Windows toolchain +
GitHub's 100 MB file limit) — you build it in ONE step on
your PC: unzip (overwrite) -> build-windows.bat, or merge
the PR and GitHub Actions (ci/build-desktop.yml, inside
the zip) attaches the installer for you.

STILL HERE: the franchise factory — Resident Evil detail
pack (3 crests, SEALED gate, herbs, ammo boxes, zombie
dogs, a Tyrant boss + heartbeat), Spider-Man rope swing,
Choo-Choo Charles train vs the Hunter, GTA5 driving +
deliveries, COD waves; MONO CITY 3D; GameKit3D; Deep mode;
ReAct agent; GRAND THEFT MONO 2D; PIN + audit.

TESTS: 97 logic + 10 UI. Generated 2026-10-29
=========================================================
