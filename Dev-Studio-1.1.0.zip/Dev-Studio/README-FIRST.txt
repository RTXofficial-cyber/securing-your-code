=========================================================
 DEV STUDIO 1.1.1  —  Game Studio release
=========================================================

NEW: GAME STUDIO
  * Say "make a game" / "make a platformer" / "make a space shooter" and the
    built-in offline AI scaffolds a COMPLETE game (GameKit engine + genre
    template) into game/, verifies it, and the activity-bar  (play) button
    opens it in your browser.
  * Engine: fixed-timestep loop, gamepad support, particles, screen shake,
    hit-stop, synth SFX, pause, high-scores. Zero dependencies.
  * Four shipped games: VOID ARENA, MONO JUMP, STARFALL, LINE RUNNER.
  * Built-in arcade inside the app at /play/ (also on the preview server).
  * Built-in AI also answers questions now (recursion, git, SQL, CSS, math...)
    instead of repeating one canned intro.

GET THE .EXE (Windows PC)
  1. Node.js 18+: https://nodejs.org
  2. Unzip anywhere (overwrite), e.g. C:\DevStudio
  3. Double-click build-windows.bat  ->  release\*.exe

DEV COMMANDS
  npm run verify (61 logic + 10 UI) | npm run build | npm run dist:win
  npm run test:e2e (real Chrome)

Generated 2026-10-29 10:04 — 61/61 logic, 10/10 UI, clean build, arcade verified.
=========================================================
