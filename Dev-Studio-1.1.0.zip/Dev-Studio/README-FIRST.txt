=========================================================
 DEV STUDIO 1.12.0  —  RESIDENT-EVIL-GRADE DETAIL PACK
=========================================================

NEW: THE HORROR PATH GOT ITS DETAILS. Ask "resident evil
style game" and the composed 3D runtime now gives you the
systems that DEFINE survival horror:
  * 3 CRESTS hidden through the dark mansion — the exit
    GATE IS SEALED (barely reflects light) until you find
    all three
  * the 3rd crest wakes a TYRANT-CLASS BOSS — 10 HP, 30
    damage, relentless; your HEARTBEAT thumps faster the
    closer it gets; put it down for +$500
  * scarce supplies: GREEN HERBS (+30 HP) and AMMO BOXES
    (full mag, reload cancelled) — 9 total in the mansion
  * ZOMBIE DOGS (fast, low, 1 HP) mix into the horde

All white-box tested: sealed gate refuses the win, herb
heals exactly +30, ammo refills, 3 crests spawn the boss,
open gate ends the run. 96 logic + 10 UI tests, 20
consecutive clean suite runs (3 legacy test-flakes hunted
down and killed too: PIN hex collision, city3d car wrap,
arrest window).

STILL HERE: the whole franchise factory — Spider-Man rope
swinging, Choo-Choo Charles train + Hunter, GTA5 driving +
police deliveries, COD waves; MONO CITY 3D; GRAND THEFT
MONO 2D; Deep mode; ReAct agent; mission experience;
GPT-6 Astra connector; PIN + audit.

HONEST NOTE: still a monochrome homage — the genre's
skeleton with real mechanics, not Capcom's assets, story
or faces. No tool on earth prints a AAA original.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 96 logic + 10 UI. Generated 2026-10-29
=========================================================
