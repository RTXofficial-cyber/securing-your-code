=========================================================
 DEV STUDIO 1.4.0  —  the app's OWN AI, fully functional
=========================================================

THE BUILT-IN AI IS NOW AN AGENT (offline, no key):
  * reads your real files:  explain server.js / show app.py
  * debugs pasted errors:   diagnosis + failing snippet + fix + safe action
                            ("fix it" replays the fix)
  * follow-ups:             run it / rename a to b / delete (with confirmation)
  * analyses the project:   analyze my project / find X in my code
  * composes ANY game:      make a zombie survival game with dash
  * AUTO mode:              plan -> execute -> verify -> fix loops
  * remembers:              project memory (decisions, tasks, conventions)
  ...and still: concepts, math, greetings, scaffolds, team mode.

SAFETY UNCHANGED: writes only via permission-gated action blocks, audit log,
PIN lock, sandboxed renderer, loopback bridge with guest links.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 73 logic + 10 UI. Generated 2026-10-29 10:41
=========================================================
