=========================================================
 DEV STUDIO 1.6.0  —  DEEP MODE: full Claude/Perplexity-style agent
=========================================================

NEW: the fourth chat pill "Deep" runs the WHOLE loop:
  1. RESEARCH — real live web search (DuckDuckGo, Wikipedia
     fallback; NO API key). Questions come back as CITED
     answers, Perplexity-style. Nothing written to disk.
  2. BUILD — build goals go through the Autopilot mission
     loop; live research snippets ride into the planner
     prompt, so connected models plan with current facts.
  3. CHECK — every written .js/.py file gets a final
     `node --check` / `py_compile`; only then is it "done".

Also new: "search X" works in normal built-in chat.
Offline is honest: no fake results, graceful fallback.

STILL HERE: refactor/split, real-file explain/show, error
doctor + "fix it", follow-ups, Auto mode, game composer,
project analyzer, memory, team mode, PIN + audit.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 79 logic + 10 UI. Generated 2026-10-29 11:04
=========================================================
