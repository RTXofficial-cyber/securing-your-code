=========================================================
 DEV STUDIO 1.6.1  —  GPT-6 Astra ready
=========================================================

NEW: frontier models plugged into YOUR harness —
  * ChatGPT connector now lists GPT-6 Astra (OPENAI_API_KEY)
  * OpenRouter plugin lists openai/gpt-6-astra (one key)
  * Deep / Auto / Team modes drive whichever model you pick:
    live web research + your project memory go into its
    prompt; every write/command stays behind your permission
    gates; verify + final syntax checks run locally.

The honest pitch: Astra is the engine, Dev Studio is the
cockpit — your files never leave your PC, full audit trail,
and the offline built-in brain keeps the same loop running
with no key at all.

STILL HERE: Deep mode (research->build->check), refactor,
real-file explain/show, error doctor, Auto mode, games,
memory, PIN + audit.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 79 logic + 10 UI. Generated 2026-10-29 11:19
=========================================================
