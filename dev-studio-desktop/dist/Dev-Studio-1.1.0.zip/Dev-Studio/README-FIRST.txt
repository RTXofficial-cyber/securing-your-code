=========================================================
 DEV STUDIO 1.11.0  —  THE 3D FRANCHISE FACTORY
=========================================================

NEW: COMPOSED 3D — ask by franchise name, get a DIFFERENT
3D game every time (not reskins — different DNA):
  * "resident evil style"  -> FPS, zombies, escape a dark
    foggy mansion
  * "spider-man swinging"  -> rope-physics web swinging
    over an open city, collect tokens, stalkers below
  * "choo-choo charles"    -> drive a lane-switching train
    through 4 km of dark rain while THE HUNTER chases you
    (shoot it, it recoils — stop shooting, it gains)
  * "gta 5 open world"     -> drive a car, police pursuit,
    timed deliveries across the city
  * "call of duty"         -> hitscan rifle (21 deg cone,
    mag 12, reload), soldiers that shoot back, waves

HOW: shared/gamekit/spec3d.cjs parses your sentence into
DNA (control, enemy, weapon, goal, world, mood);
templates/composed3d.js runs ANY combination on GameKit3D
(the software 3D renderer from 1.10.0). Every generated
game starts with its GAME_SPEC3D so you can edit the DNA.

PROVEN: tests parse all 5 franchises, assert 5 distinct
DNAs, run each 400 frames headless, fuzz each with chaos
input, then white-box the mechanics (kills pay, tokens pay
$50, the hunter closes in and recoils when hit). The
arcade ships 4 pre-composed demos — horror3d, swing3d,
charles3d, ops3d — 12 playable games in-app now.

HONEST NOTE: these are playable monochrome 3D homages —
the genre skeleton, generated in seconds. AAA is hundreds
of people and years of assets; the app says so itself.

STILL HERE: MONO CITY 3D, GRAND THEFT MONO (2D), Deep
mode, ReAct agent, mission experience, refactor, error
doctor, GPT-6 Astra connector, PIN + audit.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 95 logic + 10 UI. Generated 2026-10-29
=========================================================
