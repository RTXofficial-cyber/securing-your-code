=========================================================
 DEV STUDIO 1.10.0  —  REAL 3D + FUZZ-PROOF QA
=========================================================

NEW: GAMEKIT3D — a genuine 3D renderer, zero dependencies:
  * 4x4 matrix pipeline, perspective projection
  * backface culling, near-plane rejection
  * directional sunlight (Lambert) + ambient + distance fog
  * painter-sorted depth — runs in browser AND in tests

NEW GAME: MONO CITY 3D — "make me a 3d city game"
  * first-person city, 25 lit buildings under fog
  * live traffic that HURTS you, sprint, mouse-drag look
  * 12 floating packages ($50 each), minimap, full HUD

NEW QA: FUZZ STORMS — every shipped game (2D + 3D) must
survive seeded chaos input (random key storms, jittered
frame times, mouse/touch spam) across multiple seeds,
plus 600 scripted frames. White-box tests pin the 3D math
and city mechanics. No "har jagah bugs" — bugs die in CI,
not on your screen.

HONEST KB: "how do AAA games get made?" now answers with
the real numbers (~2000 people, a decade, billions) and
shows which layers Dev Studio genuinely ships.

STILL HERE: GRAND THEFT MONO (2D mini-GTA), Deep mode
(research->build->check), ReAct agent, mission experience,
refactor, error doctor, GPT-6 Astra connector, PIN + audit.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 91 logic + 10 UI. Generated 2026-10-29 16:50
=========================================================
