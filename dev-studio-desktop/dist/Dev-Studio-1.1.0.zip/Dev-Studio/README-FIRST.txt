=========================================================
 DEV STUDIO 1.8.0  —  the agent now LEARNS from its past
=========================================================

NEW: MISSION EXPERIENCE — every Deep/Auto run is recorded
in <workspace>/.dev-studio/experience.json (goal, outcome,
failures, one-line lesson). Before the NEXT mission the most
relevant lessons are injected into the planner / ReAct prompt:

  "script.js had a stray comma; run node --check before done"

-> the agent starts with scar tissue, not amnesia. Caps at 40
entries, travels with the project, transcripts show
[prior] N lessons injected, audits record it.

STILL HERE: ReAct step-by-step agent (connected models),
Deep research with citations, GPT-6 Astra connector support,
refactor/split, error doctor, Auto mode, games, memory, PIN,
audit, friendly connector errors.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 87 logic + 10 UI. Generated 2026-10-29 12:15
=========================================================
