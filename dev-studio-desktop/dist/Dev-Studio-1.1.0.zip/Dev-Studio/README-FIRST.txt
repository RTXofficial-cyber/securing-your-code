=========================================================
 DEV STUDIO 1.6.2  —  connector errors, human-readable
=========================================================

FIXED FOR YOU: "429 no credits remaining" and friends no
longer show raw JSON walls. The app now explains:
  * credits khatam -> billing link + FREE alternatives
    (Groq free tier, Ollama local, built-in Studio Agent)
  * 401 -> key re-paste guidance
  * 404 model -> frontier models roll out slowly; switch model
  * 429 rate limit -> wait or switch provider

IMPORTANT: ChatGPT Plus subscription != OpenAI API credits.
Add API balance at platform.openai.com billing, or use Groq
(free key at console.groq.com/keys) / Ollama (100 percent free).

STILL HERE: Deep mode (research->build->check), GPT-6 Astra
connector support, refactor, error doctor, Auto mode, games,
memory, PIN + audit.

GET THE .EXE: Node 18+ -> unzip (overwrite) -> build-windows.bat
TESTS: 79 logic + 10 UI. Generated 2026-10-29 11:47
=========================================================
